var ds = {};
ds.chartSeriesColor = ecisColors;    
ds.chartGradientColor = ["url( svg-radialgradient-darkblue )" ];    
ds.breadcrumb 		= ko.observableArray([]); 
ds.disabledEventTab = ko.observable(false);
ds.issuerSelected 	= {};
ds.tab 		= ko.observable("Dashboard");
ds.search 	= ko.observable(""),
ds.alias  	= ko.observable(""),
ds.loading 	= ko.observable(true);

ds.font 	= function (size) { return size + " Helvetica Neue, Helvetica, Arial, sans-serif" }

// ds.tab.subscribe(function(tab){
// 	if(ds.disabledEventTab())
// 		return ds.disabledEventTab(false);
// 	return ds.changetab();
// })
function createUid(){
	function s4() {
		return Math.floor((1 + Math.random()) * 0x10000)
		  .toString(16)
		  .substring(1);
	}
	return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
		     s4() + '-' + s4() + s4() + s4();
}
ds.ChangeTab = function(tab){
	ds.tab(tab);
	switch(tab){
		case "Dashboard":
			ds.init() 
		break;
		case "Price Bond":
			priceBond.init();
		break;
	}
};

// 	var tab = ds.route;
// 	_.forEach(ds.tab(), function(o)){
// 		tab .= tab[o]
// 	})
// 	tab.init;
// 	ds.breadcrumb(tab.breadcrumb);
// 	// console.log(tab);
// 	// switch(ds.tab()){
// 	// 	case "Dashboard":
// 	// 		ds.Reset();
// 	// 		ds.breadcrumb(["Home","Client Search"]);
// 	// 	break;
// 	// 	case"Price Bond": 
// 	// 		priceBond.init();
// 	// 		ds.breadcrumb(["Home",ds.alias(),"Price Bond"]); 
// 	// 	break;
// 	// }
// };
 
ds.searchData = function(){
	function onChange(e){
 	 
		var obj = _.find(e.sender.dataSource.options.data, function(o){ return o._id.issuer  == e.sender._old});
	 	if(obj == undefined)
	 		return
	 	ds.issuerSelected = obj._id;
	 	ds.alias(obj._id.aliasname);	 
		ds.search(obj._id.issuer);
		ds.ChangeTab("Price Bond"); 
	}
	ds.loading(true);
	ajaxPost("/dashboard/getissuer", {}, function (res){
		ds.loading(false);
			 
		if(res.IsError)
			return;
	 
	    $("#customers").kendoComboBox({
	        // optionLabel: 'Search for Client',
	        // optionLabelTemplate: function(optionLabel){return '<i class="fa fa-search searchinput"></i><span>' + optionLabel + '</span>'},
	        placeholder: 'Search for Client',
	        placeholderTemplate: function(placeholder){return '<i class="fa fa-search searchinput"></i><span>' + placeholder + '</span>'},
	   
	        dataSource:{
	        	data : res.Data,
	        	schema: {
			      parse: function(response) {
			        var length = response.length;
			        var dataItem;
			        var idx = 0;
			  
			        for (; idx < length; idx++) {
			           dataItem = response[idx];
			           dataItem._id.name = dataItem._id.aliasname + " - " + dataItem._id.issuer;
			        }
			        
			        return response;
			      }
			    }
	        },
	        // value:ds.search(),
	        change:onChange, 
	        dataTextField: "_id.name",
	        dataValueField: "_id.issuer",
	        filter:"contains",
			  
	        // headerTemplate: '<div class="dropdown-header k-widget k-header">' +
	                // '<span>Photo</span>' +
	                // '<span>Data info</span>' +
	            // '</div>',
	        // footerTemplate: 'Total #: instance.dataSource.total() # items found',
	        // '<span class="k-state-default" style="background-image: url(\'/dcmlive/static/img/pdf.png\')"></span>' +
	        template: '<span class="k-state-default"><h3>#: _id.name #</h3></span>',
	        height: 250
	    });
	    var combobox = $("#customers").data("kendoComboBox");
	    $('.k-list-optionlabel').hide()
	    $('.k-item:first-child').removeClass('k-state-focused')
		
    })
};
ds.generateSeriesStackBar =  function(totalStack, dataSource){
	if(totalStack == 0)
		return [];
	var series = [];
	for(var i=1; i<=totalStack; i++){
		series.push({
			categoryField:'Category',
			field : "Value"+i,
			type  : "column",
			stack : true,
			data  : dataSource,
		});
	};
	return series;
};
ds.drawChartBar = function($sel, dataSeries){
	$sel.kendoChart({
		seriesColors: ds.chartSeriesColor,
		theme: "flat",
		series:dataSeries,
        legend: {
            visible: false
        },
      
        seriesDefaults: {
			overlay: {
				gradient: "none"
			},
			gap: 0.1,
		},
        valueAxis: {
			labels: {
				color: "#4c5356",
				font: "7px Arial,Helvetica,sans-serif", 
				visible: true,
			},
			line: {
				visible: false
			},
			majorGridLines: {
				visible: false
	        },
        },
        categoryAxis: {
			labels: {
				color: "#4c5356",
				font: "9px Arial,Helvetica,sans-serif", 
				visible: true,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible: true
			}
        },
        tooltip: {
            visible: true,
            template: " #= value #"
        }
    });
};
ds.init = function(){
	ds.breadcrumb([ {title:'Dashboard',event:ds.ChangeTab, tab:'Dashboard'}, {title:'Client Search'}]);	
	if(ds.alias() !== "")
		ds.Reset();		

	ds.searchData();	
};
ds.Reset =  function(){
	$("#customers").data('kendoComboBox').value("");
	ds.alias("");
	ds.search("");
	priceBond.tab("home");
	pbFormWizard.Reset();
	createTermSheet.Reset();
};
$(function(){
	ds.init();
}) 
