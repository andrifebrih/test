var ds_Detail = {};
ds_Detail.Init =  function(){
	
}