var wa_IChart = {
  title: "Investors",
  menuTitle: 'investors',
  f:{
    defaultTypes: ['Contains', 'Equals'],
    data:ko.observableArray([]),
    val: {
      type:ko.observable("Contains"),
      searchText:ko.observable(""),
      searchMulti:ko.observableArray([]),
    }
  }
};
 
wa_IChart.config = {
  loading: ko.observable(true),
}
alignLeft = function($sel){

}
wa_IChart.createDonut = function($selector, title, dataSource) {

  var series = []
  var total = 0;
  // dataSource= _.sortBy(dataSource, 'value').reverse() ;
  var max = ( dataSource.length == 0 ) ? 0 : dataSource[0].value;

  // _.each(dataSource , function(o, i) {
  //   total += o.value;
  //   series.push({
  //     category: o._id,
  //     value: o.value, 
  //     percentage : parseFloat(o.value / max * 100).toFixed(2)
  //   })
  // });
  // console.log(max);
  // _.each(series, function(o) {
  //   o.value = parseFloat(o.value / total * 100).toFixed(2)
  // })

  var height = 300;
  var gap = 0.5;
  if(dataSource.length < 5 && dataSource.length > 2){
     height = dataSource.length * 50;
     gap = 1;
  }else if( dataSource.length < 2){
    height = dataSource.length * 60;
    gap = 1;
  }
 
  $selector.kendoChart({
    chartArea:{
      height: height,
      margin:{
        left:10,
        right:10,
        top: 20,
        bottom:10
      }
    },
    legend: {
      visible: false,
      position: "bottom",
    },
    seriesDefaults: {
      type: "bar",
      color: "#77c43a",
      gap: gap,
      border:{
        width:0
      },
      labels:{
        visible: true, 
        template: "#= kendo.toString( dataItem.percentage, 'n2' ) #%",
      }
    },
    series: [{
      overlay: { gradient: "none"},
      name: title,
      categoryField:'_id',
      data: dataSource
    }],
    tooltip: {
      visible: true,
      template: "#= category # : #= value #",
    },
    valueAxis: {
      max :max * 1.35,
      majorGridLines: {
          visible: false
      },
      minorGridLines: {
          visible: false
      },
      labels:{
          visible:false,
      },
      line:{
          visible:false
      }
    },
    categoryAxis: {
       majorGridLines: {
          visible: false
      },
      line:{
          visible:false
      },
      labels: {
          font: "9px Helvetica Neue, Helvetica, Arial, sans-serif",
      },
    },
    render:function(){
      setTimeout(function(){ 
        var isFound = false
        $selector.find("> svg > g > g:nth-child(3) > g:gt(3)").each(function(id){ 
          if (isFound) return
          if ($(this).html() == ''){
            isFound= true;
          } 
          $(this).find('text').attr('x',10);
        
        });
      },100);
    }
  });
 

}

wa_IChart.createGrid = function($selector, url, payload) {
  $selector.kendoGrid({
    dataSource: {
      transport: {
        read: function(option) {
          payload.skip = option.data.skip;
          payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : '';
          payload.take = option.data.take
          ajaxPost(url, payload, function(res) {
            option.success({ Records: res.Data, Count: res.Total });
          })
        }
      },
      schema: {
        data: function(d) {
          return d.Records
        },
				total: "Count"
      },
      serverPaging: true,
      serverFiltering: true,
      serverSorting: true,
      pageSize: 10,
    },
    scrollable: true,
    sortable: true,
    // filterable: {
    //   extra:false,
    //   operators: {
    //     string: {
    //       contains: "Contains",
    //       startswith: "Starts with",
    //       eq: "Is equal to",
    //       neq: "Is not equal to",
    //       doesnotcontain: "Does not contain",
    //       endswith: "Ends with"
    //     },
    //   }
    // },
    pageable: {
      number: true,
      previousNext: true,
      messages: {
          display: "Showing {2} data items"
      }
    },
      columns: [
      {field: "issuer", title: "Issuer"},
      {field: "issue_date", title: "Issue Date"},
      {field: "currency", title: "Currency"},
      {field: "industry", title: "Industry"},
      {field: "country", title: "Country"},
      {field: "ownership", title: "Ownership"},
      {field: "ranking", title: "Ranking"},
      {field: "rating_type", title: "Rating Type"},
      {field: "size", title: "Size",  template: "#: kendo.toString(size,'n0') #"},
       {field: "firm", title: "Firm",  template: "#: kendo.toString(firm,'n0') #"},
      {field: "allocated_amount", title: "Allocated",  template: "#: kendo.toString(allocated_amount,'n0') #"},
    ]
  });
}

wa_IChart.generateDonutDataViz = function($selector, payload) {
  ajaxPost("/widgetanalysis/getdonutinvestorone", payload, function(res) {
    wa_IChart.config.loading(false);
    wa_IChart.createDonut($selector.find("#wa-ic-donut-1"), "Industry", res.Data);
  
  })
  ajaxPost("/widgetanalysis/getdonutinvestortwo", payload, function(res) {
    wa_IChart.config.loading(false);
    wa_IChart.createDonut($selector.find("#wa-ic-donut-2"), "Ranking", res.Data);
  })
  ajaxPost("/widgetanalysis/getdonutinvestorthird", payload, function(res) {
    wa_IChart.config.loading(false);
    wa_IChart.createDonut($selector.find("#wa-ic-donut-3"), "Ranking", res.Data);
  })
}
wa_IChart.insertFilter = function(){
  var filterMainPage = wa.activeProp.mainPage().filter;
      filterMainPage.Action =  wa_IChart.f.val.type();
      filterMainPage.Textmulti =  wa_IChart.f.val.searchMulti();
      filterMainPage.Text =  wa_IChart.f.val.searchText();
}

wa_IChart.generateDataViz = function() {
  var template = wa.activeProp.template();
      template.mainPage.mode('preview');
      template.mainPage.type('wa_IChart');
  var payload = _.clone( wa.activeProp.payload() );
  wa.config.caption("Page of Investors");
  wa_IChart.insertFilter();
  payload["Action"] = wa_IChart.f.val.type();
  if(payload['Action'] == "Contains"){
    payload["Textmulti"] = [];  
    payload["Text"] = wa_IChart.f.val.searchText();
  }else{
    payload["Text"] = "";
    payload["Textmulti"] = wa_IChart.f.val.searchMulti();
  }
  

  var $selector = wa.activeProp.selectorPage();

  wa_IChart.createTitle();
  wa_IChart.generateDonutDataViz($selector, payload);
  wa_IChart.createGrid($selector.find("#wa-ic-grid"), "/widgetanalysis/getgridinvestor", payload);
}
wa_IChart.Render = function(){
  wa_IChart.initFilter("open");
  wa_IChart.generateDataViz();
} 
wa_IChart.Reload =  function(){
  var filterMainPage = wa.activeProp.mainPage().filter;
      wa_IChart.f.val.type(filterMainPage.Action);
      wa_IChart.f.val.searchText(filterMainPage.Text);
      wa_IChart.f.val.searchMulti(filterMainPage.Textmulti);
  wa_IChart.generateDataViz();
}
wa_IChart.Close = function(){
    wa_IChart.initFilter("close");
    var template =wa.activeProp.template();
    template.mainPage.mode("chooseData");
    template.mainPage.type("");
}

wa_IChart.GetDataInvestor = function( ) {
  getFilter( "/widgetanalysis/getinvestorname", wa.getActivePage().payload, wa_IChart.f.data );
}

wa_IChart.init =  function(){
  wa_IChart.f.val.type("Contains")
  wa_IChart.f.val.searchText("")
  wa_IChart.f.val.searchMulti([])
  wa_IChart.GetDataInvestor();
  $("#wa_IChartModal").modal("show");
};



























wa_IChart.createTitle = function(){
  var template = wa.activeProp.template();
  var Tfilter = template.mainPage.filter;
  var title = Tfilter.Action + " -";
  if( Tfilter.Action == "Equals"){
    var cond = true;
    _.each(Tfilter.Textmulti, function(d, i){
      if(!cond) return;
      title += " "+d+" ,";
      if(i == 3){
        title += "...";
        cond = false;
      }
    })
  }else{
    title += " "+ Tfilter.Text;
  }
  wa.activeProp.selectorPage().find("#title-investor").text(title);
}

// 
wa_IChart.initFilter =  function(mode){
  var payload = wa.activeProp.payload();
  if(mode == "open")
    payload  = wa_IChart.extendPayload( _.clone(payload) );
  wa.GetDataDefaultFilters(wa.activeProp.filter(), "", payload);
};
wa_IChart.extendPayload =  function(payload){
  payload["Box"] = "Investors";
  payload["Action"] = wa_IChart.f.val.type();
  if(payload['Action'] == "Contains"){
    payload["Textmulti"] = [];  
    payload["Text"] = wa_IChart.f.val.searchText();
  }else{
    payload["Text"] = "";
    payload["Textmulti"] = wa_IChart.f.val.searchMulti();
  }
  return payload;
};