var priceBond = {}; 
priceBond.tab 	 		   = ko.observable("home");
priceBond.disabledEventTab = ko.observable(false);
priceBond.creditProfileActive = ko.observable(false);
// priceBond.homeTab 		   = ko.observableArray([
// 								{id:'clientHome', title:'Clint Home'},
// 								{id:'creditProfil', title:'Credit Profile'},
// 								{id:'outstandingBonds', title:'Outstanding Bonds'},
// 								{id:'tradingComparables',  title:'Trading Comparables'},
// 								{id:'creditcCmparables',  title:'Credit Comparables'},
// 								{id:'keyInvestors',  title:'Key Investors'},
// 							 ]);
// priceBond.EventHomeTab = function(tabId){
// 	switch(tabId){
// 		case"creditProfil":
// 			return creditProfile.init();
// 		case"tradingComparables":
// 			return tradingcomparables.init()
// 		break;
// 	}
// };
// priceBond.tab.subscribe(function(tab){
	// if(priceBond.disabledEventTab())
	// 	return priceBond.disabledEventTab(false);
	// return priceBond.changetab();
// });
priceBond.checkCreditProfile = function(){
	if (ds.issuerSelected.issuer == "Shui On Land Ltd") {
		creditprofilev2.init()
		priceBond.creditProfileActive(true)
	}else{
		creditProfile.init()
		priceBond.creditProfileActive(false)
	};
}
priceBond.ChangeTab =  function(tab){
	priceBond.tab(tab)
	switch(tab){
		case "formWizard":
			return pbFormWizard.init();
		break;
		case "grid":
			return pbGrid.init();
		break;
		case "detailGrid":
			return detailGrid.init(); 
		break;
		case "termSheet":
			return termSheet.init(); 
		break;
	}
};
priceBond.changetab = function(tab){
	priceBond.tab();
};

priceBond.init = function(){
	ds.breadcrumb([ {title:'Dashboard', event:ds.ChangeTab, tab:'Dashboard'}, {title: ds.alias(), event:priceBond.ChangeTab, tab:'home'}, {title:'Client Search'} ]);
	clienthome.init();
	// return $(".pricebond-home-tab").find("li a#tab1").click();
};
 
