var wa_reviseQryChart = {
	title: "Reverse Enquiry",
	menuTitle: 'reverseenquiry',
	leftFilter:[
		{
			id:"RatingtypeReverse",
			payload: "Ratingtype",
			flag: "Ratingtype",
			title:"Ratingtype",
			 
		},
		{
			id: "RatingactionReverse",
			payload: "Ratingaction",
			flag: "Ratingaction",
			title: "Ratingaction",
			 
		},
		{
			id:"RatingValueReverse",
			payload: "RatingvalueCustom", 
			flag: "Ratingvalue",
			title:"Ratingvalue",
		},
		{
			id:"OwnershipReverse",
			payload: "Ownership", 
			flag: "ownership",
			title:"ownership",
			ajax: 'true',
		},
		{
			id:"RankingReverse",
			payload: "Ranking", 
			title:"Ranking",
			flag: "ranking",
			ajax: 'true',
		},
		{
			id:"ProductReverse",
			payload: "Product", 
			title:"Product",
			flag: "product",
			ajax: 'true',
		},

		{
			id:"EmtnProgramReverse",
			payload: "Emtnprogram", 
			flag: "emtn_program",
			title:"EMTN Program",
			ajax: 'true'
		},
		{
			id:"ScbDealerProgramReverse",
			payload: "Scbdealer", 
			flag: "scb_dealer_program",
			title:"SCB Dealer Program",
			ajax: 'true',
		},
		{
			id:"IsdaReverse",
			payload: "Isda", 
			title:"ISDA",
			flag: "isda",
			ajax: 'true',
		},
		{
			id:"CsaReverse",
			payload: "Csa", 
			title:"CSA",
			flag: "csa",
			ajax: 'true',
		}
	],
	f: {
		flag: ko.observableArray([
									{text: 'Bid Ytm', value: 'bid_ytm'},
									{text: 'Z Spread', value: 'bid_z_spread'},
									{text: 'G Spread', value: 'bid_g_spread'}
								]),
		tenor: ko.observableArray([
									{text: 3, value: 3},
									{text: 5, value: 5},
									{text: 7, value: 7},
									{text: 10, value: 10},
									{text: 15, value: 15},
									{text: 30, value: 30},
								 ]),
		val:{
			flag: ko.observable("bid_ytm"),
			flagValue: ko.observable(0),
			tenor: ko.observable(3),
		}
	}
};
wa_reviseQryChart.RenderGrid = function(payload, $selector){
 
	// payload['Flag'] = 	payload['Flag'];
	// payload['FlagValue'] = parseInt(wa_reviseQryChart.f.val.flagValue());
	var url = "/widgetanalysis/widgetsyndicate";
	var titleValue = "";
	var decimal = "N0";
	switch(wa_reviseQryChart.f.val.flag()){
		case"bid_ytm":
			titleValue = "Bid Ytm (%)";
		 	decimal = "N2";
		break;
		case"bid_z_spread":
			titleValue = "Z Spread (bps)";
		break;
		case"bid_g_spread":
			titleValue = "G Spread (bps)";
		break;
	} 

	var $selector1 = $selector.find("#tab-reviseQryChart01 .grid");	
	$selector1.html("");
	$selector1.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take;
                    ajaxPost(url, payload, function(res){
                        option.success({ Records: res.Data, Count: res.Total });
                    })
                },
			},
			schema: {
				data: function(data) {
                    return data.Records;
				},
				total: "Count",
			},
			pageSize: 10,
			serverPaging: true,
			serverSorting: true,
		},
		sortable: true,
		pageable: {
              numeric: true,
              previousNext: true,
              messages: {
                  display: "Showing {2} data items"
              }
        },
		columns: [
			{
				title: "Issuer Name",
				field: "Issuer",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Industry",
				field: "Industry",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Product",
				field: "Product",
			 	attributes: {
	                "class": "align-left"
                },
                headerAttributes: {
					"class": "align-left"
                },
			},
			{
				title: "Country",
				field: "Country",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},

			// {
			// 	title: "Bucket",
			// 	field: "Bucket",
			// 	attributes: {
		   //                  "class": "align-center"
		   //              },
		   //              headerAttributes: {
		   //                  "class": "align-center"
		   //              },
			// },
			{
				title: "Years To Maturity",
				field: "Yearsmaturity",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Yearsmaturity,'N0') #"

			},
			{
				title: titleValue,
				field: "Value",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },

                template: function(e){
					if(wa_reviseQryChart.f.val.flag() == "bid_ytm")
						return kendo.toString(e.Value,'N2');
					return kendo.toString(e.Value,'N0');
				}
			},
			{
				title: "3",
				field: "Three",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Three,'N0') #"
			},
			{
				title: "5",
				field: "Five",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Five,'N0') #"
			},
			{
				title: "7",
				field: "Seven",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Seven,'N0') #"
			},
			{
				title: "10",
				field: "Ten",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Ten,'N0') #"
			}
		]
	});

	var $selector2 = $selector.find("#tab-reviseQryChart02 .grid");	
	$selector2.html("");
	$selector2.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take;
                    ajaxPost(url, payload, function(res){
                        option.success({ Records: res.Data, Count: res.Total });
                    })
                },
			},
			schema: {
				data: function(data) {
                    return data.Records;
				},
				total: "Count",
			},
			pageSize: 10,
			serverPaging: true,
			serverSorting: true,
		},
		sortable: true,
		pageable: {
              numeric: true,
              previousNext: true,
              messages: {
                  display: "Showing {2} data items"
              }
        },
		columns: [
			{
				title: "Isin",
				field: "Isin",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Issuer",
				field: "Issuer",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Issuedate",
				field: "Issuedate",
			 	attributes: {
	                "class": "align-center"
                },
                headerAttributes: {
					"class": "align-center"
                },
			},
			{
				title: "Maturitydate",
				field: "Maturitydate",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Bid Price",
				field: "Bidprice",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Bidprice,'N0') #"
			},
			{
				title: "Bid Ytm",
				field: "Bidytm",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Bidytm,'N2') #"
			},
			{
			// 	title: "Rating",
			// 	headerAttributes: {
			// 		"class": "align-center"
		 //        },
			// 	columns: [
			// 		{
				title: "Bid Z",
				field: "Bidzspread",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Bidzspread,'N0') #"
			},
			{
				title: "Bid G",
				field: "Bidgspread",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				template: "#= kendo.toString(Bidgspread,'N0') #"
			},
			// 	]
			// },
			{
				// title: "Rating",
				// headerAttributes: {
				// 	"class": "align-center"
		  //       },
				// columns: [
				// 	{
				title: "Moody's",
				field: "Moodysissuerrating",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				// template: "#= kendo.toString(Moodysissuerrating,'N0') #"
			},
			{
				title: "S&P",
				field: "Spissuerrating",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				// template: "#= kendo.toString(Spissuerrating,'N0') #"
			},
			{
				title: "Fitch",
				field: "Fitchissuerrating",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
				// template: "#= kendo.toString(Bidgspread,'N0') #"
			},
			// 	]
			// }
		]
	});
};	
wa_reviseQryChart.modifyPayload =  function(payload){
	payload["Ratingvalue"] =  payload["Ratingvalue"] == "" || payload["Ratingvalue"] == 0 ? 99 : payload["Ratingvalue"];
	return  payload;
};
wa_reviseQryChart.changeRatingtype = function(e){
	var template = wa.activeProp.template();

	var payload = wa_reviseQryChart.extendPayload( wa.activeProp.payload() );
		payload['Ratingtype'] = e._old;
		payload['Ratingvalue']  =  99;
		// payload['Ratingtype']  =  e._old;
	
	var filter = wa.activeProp.filter();
		filter.RatingValueReverse.value("");
	var p = _.clone(payload);
		p['Flag'] = "rating_value";
	ajaxPost("/widgetanalysis/getfilterrating",  p, function(res) {
	    template.filter.RatingValueReverse.data(res)
	});	  	 
};
wa_reviseQryChart.changeRatingAction = function(e){
	var payload = wa.activeProp.payload();
		payload.Ratingaction = e._old;
};
wa_reviseQryChart.ChangeFilter = function( e, idFilter, idPayload ) {

 	var template = wa.activeProp.template();
 	var filter = wa.activeProp.filter();
  	 	filter[idFilter].value(e._old);
  	var payload = wa.activeProp.payload();
  		payload[idPayload] = e._old;
	wa_reviseQryChart.GetDataFilter( template.filter, idFilter, wa_reviseQryChart.extendPayload( payload ) ) ; 
	var $selector = wa.activeProp.selectorPage();
	wa_reviseQryChart.RenderGrid( wa_reviseQryChart.extendPayload( payload ) , $selector);
};

wa_reviseQryChart.GetDataFilter =  function(filter, exceptFilter, payload){
  _.each(wa_reviseQryChart.leftFilter, function(o){
   	var p = _.clone(payload);
    if( ( exceptFilter != "" && exceptFilter == o.id ) || ! o.ajax )
      return;
    p["Flag"] = o.flag;
    p = wa_reviseQryChart.extendPayload(p);
    getFilter("/widgetanalysis/getfilterrating", p, filter[o.id].data);
  });
};
wa_reviseQryChart.insertFilter =  function(){
  var filterMainPage = wa.activeProp.mainPage().filter;
      filterMainPage.Flag =  wa_reviseQryChart.f.val.flag();
      filterMainPage.FlagValue =  parseInt( wa_reviseQryChart.f.val.flagValue() );
}; 
wa_reviseQryChart.createPayload = function(){
	var template = wa.activeProp.template();
	template.mainPage.mode('preview');
	template.mainPage.type('wa_reviseQryChart');
	template.payload = wa.createPayload( wa.filterProperties(), wa_reviseQryChart.leftFilter);
 	wa_reviseQryChart.GetDataFilter( template.filter, "", wa_reviseQryChart.extendPayload( _.clone( template.payload ) ) ); 
}
wa_reviseQryChart.generateDataViz = function() {
	wa_reviseQryChart.insertFilter();
	var $selector = wa.activeProp.selectorPage();
	var payload = wa_reviseQryChart.extendPayload( _.clone( wa.activeProp.payload() ) );	
	wa_reviseQryChart.RenderGrid(payload, $selector);
};
wa_reviseQryChart.Render =function(){
	wa_reviseQryChart.createPayload();
	wa_reviseQryChart.generateDataViz();
}
wa_reviseQryChart.Reload = function(){

	var filterMainPage = wa.activeProp.mainPage().filter;
    wa_reviseQryChart.f.val.flag(filterMainPage.Flag);
    wa_reviseQryChart.f.val.flagValue(filterMainPage.FlagValue);
	wa_reviseQryChart.generateDataViz();
}
wa_reviseQryChart.Close = function(){
	var template = wa.activeProp.template();
    	template.mainPage.mode("chooseData");
    	template.mainPage.type("");
    	template.payload = wa.createPayload(template.filter, wa.defFilter());
    	wa_reviseQryChart.ResetFilter();
}
wa_reviseQryChart.init = function(){
	$("#wa_reviseQryChart").modal('show');
};
wa_reviseQryChart.ResetFilter =  function(){
	var template = wa.activeProp.template();
		tFilter = template.filter;
		tFilter.RatingtypeReverse.value("");
		tFilter.RatingactionReverse.value("$eq");
		tFilter.RatingValueReverse.value("");

		tFilter.RankingReverse.value([]);
		tFilter.OwnershipReverse.value([]);
		tFilter.ProductReverse.value([]);

		tFilter.EmtnProgramReverse.value([]);
		tFilter.ScbDealerProgramReverse.value([]);
		tFilter.IsdaReverse.value([]);
		tFilter.CsaReverse.value([]); 
}






wa_reviseQryChart.extendPayload =  function(payload){
	// payload['Flagpopup'] = _.clone(payload['Flag'])

	payload['Tenor'] = parseInt( wa_reviseQryChart.f.val.tenor() );
	payload['Flagpopup'] = wa_reviseQryChart.f.val.flag();
	payload['FlagValue'] = parseInt(wa_reviseQryChart.f.val.flagValue());
	payload['Ratingvalue'] = (  payload['RatingvalueCustom']  == "" || parseInt( payload['RatingvalueCustom'] ) == 0 ) ? 99 : parseInt( payload['RatingvalueCustom'] );
  	return payload;
};