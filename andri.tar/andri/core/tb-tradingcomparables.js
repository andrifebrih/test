var tradingcomparables 	= {};
tradingcomparables.widget = {
	tcgrid :{
		id 	 :"tcgrid",
		title:"",
		url  :"/tradingcomparables/getdatagrid",
		loading : ko.observable(false),
	},
	zspreadvsytm :{
		id 	 :"zspreadvsytm",
		title:"Z Spread (y axis) vs. YTM (x axis)",
		url  :"/tradingcomparables/zspreadvsytm",
		loading : ko.observable(false),
	},
	zspreadvsytmhistorical :{
		id 	 :"zspreadvsytmhistorical",
		title:"Z spread vs YTM Historical trend",
		url  :"/tradingcomparables/zspreadvsytmhistorical",
		loading : ko.observable(false),
	},
	yieldvsytm :{
		id 	 :"yieldvsytm",
		title:"Yield (y axis) vs. YTM (x axis)",
		url  :"/tradingcomparables/yieldvsytm",
		loading : ko.observable(false),
	},
	yieldvsytmhistorical:{
		id 	 :"yieldvsytmhistorical",
		title:"Yield vs YTM Historical trend",
		url  :"/tradingcomparables/yieldvsytmhistorical",
		loading : ko.observable(false),
	},
};
tradingcomparables.getPayload = function(){
	return {
		issuer:ds.search(),
	}
};
tradingcomparables.widget.tcgrid.render = function(){
	with(tradingcomparables.widget.tcgrid){
		var payload = tradingcomparables.getPayload()
		loading(true);
		$("#"+id).find(".contentGrid").html("");
		ajaxPost(url, payload, function(res){
			loading(false);
			if(res.IsError)
				return;
			$("#"+id).find(".contentGrid").kendoGrid({
				dataSource: {
                    data:res.Data,
                    pageSize: 20,
                },
                height: 300,
                sortable: true,
                pageable: true,
                columns: [{
                    field: "Security",
                    title: "Security"
                },{
                    field: "Issuedate",
                    title: "Issue Date",
					attributes: {
						"class": "field-ellipsis"
					},
                },{
                    field: "Issuer",
                    title: "Issuer",
                    width: 100
                },{
                    field: "Moodysissuerating",
                    title: "Moodys Issue Rating"
                },{
                    field: "Spissuerating",
                    title: "S&P Issue Rating"
                },{
                    field: "Fitchissuerrating",
                    title: "Fitch Issue Rating"
                },{
                    field: "Maturitydate",
                    title: "Maturity Date",
					attributes: {
						"class": "field-ellipsis"
					},
                },{
                    field: "Calldate",
                    title: "Call Date"
                },{
                    field: "Tenor",
                    title: "Tenor (yrs)"
                },{
                    field: "Currency",
                    title: "Currency"
                },{
                    field: "Size",
                    title: "Size (m)"
                },{
                    field: "Coupon",
                    title: "Coupon"
                },{
                    field: "Yearsmaturity",
                    title: "Years to Maturity"
                },{
                    field: "Bidprice",
                    title: "Bid Price"
                },{
                    field: "Bidytm",
                    title: "Bid YTM"
                },{
                    field: "Bidtspread",
                    title: "Bid T-Spread"
                },{
                    field: "Bidgspread",
                    title: "Bid G-Spread"
                },{
                    field: "Bidzspread",
                    title: "Bid Z-Spread"
                }]
			});
		})
	}
};

tradingcomparables.widget.zspreadvsytm.render = function(){
	with(tradingcomparables.widget.zspreadvsytm){
		var payload = tradingcomparables.getPayload()
		loading(true);
		$("#"+id).find(".contentWidget").html("");
		ajaxPost(url, payload, function(res){
			loading(false);
			
			data = []
			max = 10;
			if(res.Data.Datasource.length < 10){
				max = res.Data.Datasource.length
			}
			for(i=0; i<max; i++){
				data.push(res.Data.Datasource[i])
			}
			
			if(res.IsError)
				return;
			$("#"+id).find(".contentWidget").kendoChart({
                legend: {
                    visible: false
                },
                series: [{
                    type: "line",
                    data: data,
                    categoryField:'Category',
                    field:'Value',
                    style: "smooth",
                    markers: {
                        visible: false
                    }
                }],
                categoryAxis: {
                	labels: {
				      rotation: -90,
				      font: ds.font('9px'),
				    },
                    majorGridLines: {
                        visible: false
                    },
                    majorTicks: {
                        visible: false
                    }
                },
                valueAxis: {
                	labels: { 
				      font: ds.font('9px'),
				    },
				    majorUnit: 200
				},
			});
		})
	}
};
tradingcomparables.widget.zspreadvsytmhistorical.render = function(){
	with(tradingcomparables.widget.zspreadvsytmhistorical){
		var payload = tradingcomparables.getPayload()
		loading(true);
		$("#"+id).find(".contentWidget").html("");
		ajaxPost(url, payload, function(res){
			loading(false);
			
			data = []
			max = 10;
			if(res.Data.Datasource.length < 10){
				max = res.Data.Datasource.length
			}
			for(i=0; i<max; i++){
				data.push(res.Data.Datasource[i])
			}
			
			if(res.IsError)
				return;
			$("#"+id).find(".contentWidget").kendoChart({
                legend: {
                    visible: false
                },
                series: [{
                    type: "line",
                    data: data,
                    categoryField:'Category',
                    field:'Value',
                    style: "smooth",
                    markers: {
                        visible: false
                    }
                }],
                categoryAxis: {
                	labels: {
				      rotation: -90,
				      font: ds.font('9px'),
				    },
                    majorGridLines: {
                        visible: false
                    },
                    majorTicks: {
                        visible: false
                    }
                },
                valueAxis: {
                	labels: { 
				      font: ds.font('9px'),
				    },
				    majorUnit: 200
				},
			});
		})
	}
};
tradingcomparables.widget.yieldvsytm.render = function(){
	with(tradingcomparables.widget.yieldvsytm){
		var payload = tradingcomparables.getPayload()
		loading(true);
		$("#"+id).find(".contentWidget").html("");
		ajaxPost(url, payload, function(res){
			loading(false);
			
			data = []
			max = 10;
			if(res.Data.Datasource.length < 10){
				max = res.Data.Datasource.length
			}
			for(i=0; i<max; i++){
				data.push(res.Data.Datasource[i])
			}
			
			if(res.IsError)
				return;
			$("#"+id).find(".contentWidget").kendoChart({
                legend: {
                    visible: false
                },
                series: [{
                    type: "line",
                    data: data,
                    categoryField:'Category',
                    field:'Value',
                    style: "smooth",
                    markers: {
                        visible: false
                    }
                }],
                categoryAxis: {
                	labels: {
				      rotation: -90,
				      font: ds.font('9px'),
				    },
                    majorGridLines: {
                        visible: false
                    },
                    majorTicks: {
                        visible: false
                    }
                },
                valueAxis: {
                	labels: { 
				      font: ds.font('9px'),
				    },
				    majorUnit: 200
				},
			});
		})
	}
};
tradingcomparables.widget.yieldvsytmhistorical.render = function(){
	with(tradingcomparables.widget.yieldvsytmhistorical){
		var payload = tradingcomparables.getPayload()
		loading(true);
		$("#"+id).find(".contentWidget").html("");
		ajaxPost(url, payload, function(res){
			loading(false);
			
			data = []
			max = 10;
			if(res.Data.Datasource.length < 10){
				max = res.Data.Datasource.length
			}
			for(i=0; i<max; i++){
				data.push(res.Data.Datasource[i])
			}
			
			if(res.IsError)
				return;
			$("#"+id).find(".contentWidget").kendoChart({
                legend: {
                    visible: false
                },
                series: [{
                    type: "line",
                    data: data,
                    categoryField:'Category',
                    field:'Value',
                    style: "smooth",
                    markers: {
                        visible: false
                    }
                }],
                categoryAxis: {
                	labels: {
				      rotation: -90,
				      font: ds.font('9px'),
				    },
                    majorGridLines: {
                        visible: false
                    },
                    majorTicks: {
                        visible: false
                    }
                },
                valueAxis: {
                	labels: { 
				      font: ds.font('9px'),
				    },
				    majorUnit: 200
				},
			});
		})
	}
};
tradingcomparables.init =  function(){
	tradingcomparables.widget.tcgrid.render()
	tradingcomparables.widget.zspreadvsytm.render()
	tradingcomparables.widget.zspreadvsytmhistorical.render()
	tradingcomparables.widget.yieldvsytm.render()
	tradingcomparables.widget.yieldvsytmhistorical.render()
};