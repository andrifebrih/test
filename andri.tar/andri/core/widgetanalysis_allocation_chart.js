 var wa_AlcChart = {
	title: "Allocations",
	menuTitle: 'allocations',
	f:{
		val: {
			InputOne:ko.observable(0),
			InputTwo:ko.observable(0),
		}
	},
	pullRequest: ko.observable(0),
	loading: ko.observable(false),
};
wa_AlcChart.pullRequest.subscribe(function(n){
	if(n == 0)
		return wa_AlcChart.loading(false);
})
wa_AlcChart.RenderGrid = function(payload, selector){
	var $selector = $(selector).find(".wa_alcChart #grid");
	var url = "/widgetanalysis/getgridallocation";
	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : '';
					payload.take = option.data.take;
                    ajaxPost(url, payload, function(res){
                        option.success({ Records: res.Data, Count: res.Total });
                    })
                },
			},
			schema: {
				data: function(data) {
                    return data.Records;
				},
				total: "Count",
			},
			pageSize: 20,
			serverPaging: true,
			serverSorting: true,
		},
		sortable: true,
		pageable: {
              numeric: true,
              previousNext: true,
              messages: {
                  display: "Showing {2} data items"
              }
        },
		columns: [
			{
				title: "Issuer",
				field: "issuer",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },

                template: "#: kendo.toString(issuer,'n0') #"
			},
			{
				title: "Issue Date",
				field: "issue_date",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Currency",
				field: "currency",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Investor Name",
				field: "investor_name",
			 	attributes: {
	                "class": "align-left"
                },
                headerAttributes: {
					"class": "align-left"
                },
			},
			{
				title: "Issue Size",
				field: "size",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Ranking(Senior AT1 Tier2)",
				field: "ranking",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Product(HY/IG)",
				field: "product",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Product(HY/IG)",
				field: "product",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
			},
			{
				title: "Firm",
				field: "firm",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
                template: "#: kendo.toString(firm,'n0') #"
			},
			{
				title: "Allocated ",
				field: "allocated_amount ",
				attributes: {
                    "class": "align-center"
                },
                headerAttributes: {
                    "class": "align-center"
                },
                template: "#: kendo.toString(allocated_amount,'n0') #"
			}
		]
	});
};
wa_AlcChart.insertFilter =  function(){
  var filterMainPage = wa.activeProp.mainPage().filter;
      filterMainPage.InputOne =  parseInt( wa_AlcChart.f.val.InputOne() );
      filterMainPage.InputTwo =  parseInt( wa_AlcChart.f.val.InputTwo() ); 
}
wa_AlcChart.generateDataViz =  function(){
	var $selector = wa.activeProp.selectorPage();
	var template = wa.activeProp.template();
	wa_AlcChart.insertFilter();
	var payload = _.clone( wa.activeProp.payload() );
		payload.InputOne = parseInt( wa_AlcChart.f.val.InputOne(), 10 );
		payload.InputTwo = parseInt( wa_AlcChart.f.val.InputTwo(), 10 );

	template.mainPage.mode('preview');
	template.mainPage.type('wa_AlcChart');

	wa_AlcChart.RenderGrid(payload, $selector);
};
wa_AlcChart.Reload =  function(){	
	var filterMainPage = wa.activeProp.mainPage().filter;
    wa_AlcChart.f.val.InputOne(parseInt( filterMainPage.InputOne  ));
    wa_AlcChart.f.val.InputOne(parseInt( ilterMainPage.InputTwo ));

	wa_AlcChart.generateDataViz();
};
wa_AlcChart.Render = function(){
  wa_AlcChart.initFilter("open");
  wa_AlcChart.generateDataViz();
} 
wa_AlcChart.Close = function(){
	  wa_AlcChart.initFilter("close");
	var template = wa.activeProp.template();
 		template.mainPage.mode("chooseData");
 		template.mainPage.type("");
}
wa_AlcChart.init =  function(){
	$modal = $("#wa_AlcChartModal");
	$modal.modal("show");
};




// 
wa_AlcChart.initFilter =  function(mode){
  var payload = wa.activeProp.payload();
  if(mode == "open")
    payload  = wa_AlcChart.extendPayload( _.clone(payload) );
  wa.GetDataDefaultFilters(wa.activeProp.filter(), "", payload);
};
wa_AlcChart.extendPayload =  function(payload){
	payload['InputOne'] = parseInt( wa_AlcChart.f.val.InputOne(), 10 );
	payload['InputTwo'] = parseInt( wa_AlcChart.f.val.InputTwo(), 10 );

	payload['Box'] = "Allocations";
	return payload;
};