var dashboard = {
	pullRequest: ko.observable(),
	tab: ko.observable(""),
	breadcrumb: ko.observableArray([]),
	rowSelected: ko.observable({}),
	f:{
		issuer: ko.observableArray([]),
		ownership: ko.observableArray([]),
		corporation: ko.observableArray([]),
		specialcharacter: ko.observableArray([]),
		currency: ko.observableArray([]),
		industry: ko.observableArray([]),
		product: ko.observableArray([]),
		region: ko.observableArray([]),
		country: ko.observableArray([]),
		ranking: ko.observableArray([]),
		ratingType: ko.observableArray([{text:"Fitch",value:"point_fitch"},{text:"Moody",value:"point_moody"},{text:"SP",value:"point_sp"}]),
	 	ratingValue: ko.observableArray([]),
		val:{
			issuer: ko.observableArray([]),
			min: ko.observable(0),
			max: ko.observable(55000),
			corporation: ko.observableArray([]),
			specialcharacter: ko.observableArray([]),
			ownership: ko.observableArray([]),
			currency: ko.observableArray([]),
			industry: ko.observableArray([]),
			product: ko.observableArray([]),
			region: ko.observableArray([]),
			country: ko.observableArray([]),
			ranking: ko.observableArray([]),	
			ratingType: ko.observable("point_sp"),
			ratingValue: ko.observableArray(),
		}
	},
};
dashboard.tab.subscribe(function(n){
	if( window[n] == undefined)
		return;
	window[n]['Init']()
});
dashboard.DefaultPayload =  function(){
	var p = dashboard.f.val;
	return {
		Issuer: p.issuer(),
        Corpfissa: p.corporation(),
        Specialcharacter: p.specialcharacter(),
        Ownership: p.ownership(),
        Region: p.region(),
        Country: p.country(),
        Ranking: p.ranking(),
        Currency: p.currency(),
        Industry: p.industry(),
        Product: p.product(),
        Ratingtype: p.ratingType(),
        Ratingaction: "",
        Ratingvalue: isNaN( p.ratingValue() ) || p.ratingValue() == "" ? 99.0 : parseInt( p.ratingValue() ) ,
        Sizestart:  parseInt( p.min() ),
        Sizeend: parseInt( p.max() )
	};
}
 
dashboard.f.val.issuer.subscribe(function(n){
	dashboard.submit( );
});
dashboard.f.val.region.subscribe(function(n){
	dashboard.submit( );
});
dashboard.f.val.country.subscribe(function(n){
	dashboard.submit( );
});
dashboard.f.val.ranking.subscribe(function(n){
	dashboard.submit( );
});
dashboard.f.val.currency.subscribe(function(n){
	dashboard.submit( );
});
dashboard.f.val.industry.subscribe(function(n){
	dashboard.submit( );
});
dashboard.f.val.product.subscribe(function(n){
	dashboard.submit( );
});
dashboard.f.val.ownership.subscribe(function(n){
	dashboard.submit();
});
dashboard.f.val.specialcharacter.subscribe(function(n){
	dashboard.submit();
});
dashboard.f.val.corporation.subscribe(function(n){
	dashboard.submit();
});
dashboard.f.val.max.subscribe(function(n){
	if(isNaN(parseInt(n))) 	
		return dashboard.f.val.max(55000);

	dashboard.submit();
	return dashboard.f.val.max(parseInt(n));
});
dashboard.f.val.min.subscribe(function(n){
	if(isNaN(parseInt(n))) 	
		return dashboard.f.val.min(0);

	dashboard.submit();
	return dashboard.f.val.min(parseInt(n));
});

dashboard.f.val.ratingType.subscribe(function(n){
	dashboard.f.val.ratingValue(0);
	dashboard.GetRatingValue();
	dashboard.CreateGrid();
});

dashboard.submit = function(){
	dashboard.GetAllFilters();
	dashboard.CreateGrid();
};

// Get Ajax Data 
dashboard.GetIssuer = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "issuer";
		payload.Issuer = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id.issuer != null)
				resData.push( { text: d._id.aliasname + " - "  + d._id.issuer , value: d._id.issuer } );
	    });
		dashboard.f.issuer(resData);
		dashboard.initSearhIssuer();
	}); 
};
dashboard.GetCorporation = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "corp_fi_ssa";
		payload.Corpfissa = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id != null)
				resData.push( { text: d._id, value: d._id } );
	    });
		dashboard.f.corporation(resData);
	}); 
};
dashboard.GetOwnership = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "ownership";
		payload.Ownership = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id != null)
				resData.push( { text: d._id, value: d._id } );
	    });
		dashboard.f.ownership(resData);
	}); 
};
dashboard.GetRegion = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "region";
		payload.Region = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id != null)
				resData.push( { text: d._id, value: d._id } );
	    });
		dashboard.f.region(resData);
	}); 
};
dashboard.GetCountry = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "country";
		payload.Country = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id != null)
				resData.push( { text: d._id, value: d._id } );
	    });
		dashboard.f.country(resData);
	}); 
};
dashboard.GetRanking = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "ranking";
		payload.Ranking = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id != null)
				resData.push( { text: d._id, value: d._id } );
	    }); 
		dashboard.f.ranking(resData);
	});
};
dashboard.GetSpecialcharacter = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "special_caracters";
		payload.Specialcharacter = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id != null){
				if(d._id == "")
         	 		resData.push( { text: "General", value: d._id } );
          		else
            		resData.push( { text: d._id, value: d._id } );
			}
	    });
		dashboard.f.specialcharacter(resData);
	});
};
dashboard.GetCurrency = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "currency";
		payload.Currency = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id != null)
				resData.push( { text: d._id, value: d._id } );
	    });
		dashboard.f.currency(resData);
	});
};
dashboard.GetIndustry = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "industry";
		payload.Industry = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id != null)
				resData.push( { text: d._id, value: d._id } );
	    });
		dashboard.f.industry(resData);
	});
};
dashboard.GetProduct = function(){
	var url = "/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "product";
		payload.Product = [];
	ajaxPost(url, payload, function(res){
		var resData = [];
		_.each(res, function(d) {
			if(d._id != null)
				resData.push( { text: d._id, value: d._id } );
	    });
		dashboard.f.product(resData);
	});
};
dashboard.GetRatingValue =  function(){
	var url ="/dashboardv2/gethomefilter";
	var payload = dashboard.DefaultPayload();
		payload.Flag = "rating_value";
		payload.Ratingvalue  =  99;
		ajaxPost(url, payload, function(res){
			var resData = [];
			// ;
			_.each(res , function(d) {
				if(d._id.sendbackend == "-")
					d._id.sendbackend = "NR";
				if(d._id != null)
					resData.push( { value: d._id.displayui , text:  d._id.sendbackend } );
		    });
    		dashboard.f.ratingValue(resData);
		    dashboard.initSliderRating();
		});
};


dashboard.CreateGrid =  function(){
	var payload = dashboard.DefaultPayload();
	var url = "/dashboardv2/homescreen";
	$("#dsGrid").html("");
	$("#dsGrid").kendoGrid({ 
					dataSource: {
						transport: {
							read:function(option){
								payload.skip = option.data.skip;
								payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
								payload.take = option.data.take;
			                    ajaxPost(url, payload, function(res){
			                        option.success({ Records: res.Data, Count: res.Total });
			                    })
			                },
						},
						schema: {
							data: function(data) {
			                    return data.Records;
							},
							total: "Count",
						},
					    pageSize: 20,
				        serverPaging: true,
						serverSorting: true,
						serverFiltering: true,
					},
					sortable: true,
					pageable: {
						numeric: true,
						previousNext: true,
						messages: {
							display: "Showing {2} data items"
						}
					},
					columns: [
						{
							title: "Issuer Name",
							field: "issuer",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
							template: function(e){
								// console.log(e);
								return "<a class='issuer-link' onclick='dashboard.clickIssuer("+JSON.stringify(e)+")'>"+e.issuer+"</a>";
							}
						},
						{
							title: "Issue Date",
							field: "issue_date",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
						},
						{
							title: "Size (M)",
							field: "size",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
							template:  "#= kendo.toString(size,'n0') #",
						},
							{
							title: "Currency",
							field: "currency",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
						},
						{
							title: "Distribution </br> Format",
							field: "distributions_format",
							headerAttributes: {
								"class": "align-center field-ellipsis"
							},
							attributes: {
								"class": "align-center"
							},
						},
						{
							title: "Maturity Date",
							field: "maturity_date",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
						},
						{
							title: "Coupon",
							field: "coupon",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
							template:  "#= kendo.toString(coupon,'n3') #",
						},
						{
							title: "Issuer Ratings",
							headerAttributes: {
								"class": "align-center"
							},
							columns: [
								{
									title: "Moody",
									field: "moodys_issuer_rating",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "S&P",
									field: "sp_issuer_rating",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "Fitch",
									field: "fitch_issuer_rating",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
							]
						},
					
						{
							title: "Bid",
							headerAttributes: {
								"class": "align-center"
							},
							columns: [
								{
									title: "Price",
									field: "bid_price",
									headerAttributes: {
										"class": "align-center"
									},
									attributes: {
										"class": "align-center"
									},
									template:  "#= kendo.toString(bid_price,'n1') #",
								},
								
								{
									title: "T Spread",
									field: "bid_t_spread",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "G Spread",
									field: "bid_g_spread",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "Z Spread",
									field: "bid_z_spread ",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "YTM",
									field: "bid_ytm",
									headerAttributes: {
										"class": "align-center"
									},
									attributes: {
										"class": "align-center"
									},
									template:  "#= kendo.toString(bid_ytm,'n2') # %",
								},
							]
						},

					
					
					] 
				});
};
dashboard.clickIssuer =  function(e){
	ds.issuerSelected =e;
	ds.alias(e.aliasname);	 
	ds.search(e.issuer);
	ds.ChangeTab("Price Bond"); 
}
dashboard.initSliderRating = function(){
	// var ratingvalue = ( dashboard.f.ratingValue().length > 0 ) ? dashboard.f.ratingValue() : [ { text: "" ,value: "" } ];
	var lastRating = _.last( dashboard.f.ratingValue() ) == undefined ? [{text: "", value: ""}] : _.last( dashboard.f.ratingValue() )
	var $sel = $("#ratingSlider");
	var moveSlider = function(e){
		// $sel.find("#label-ratingSlider").text( dashboard.f.ratingValue()[e.value].text );
		// var label =
		$("#ratingSlider").find("a.k-draghandle").text( dashboard.f.ratingValue()[e.value].text )
		dashboard.f.val.ratingValue( dashboard.f.ratingValue()[e.value].value );
		dashboard.submit();
	}
	
	$sel.html("");
	$sel.append("<input id='input-ratingSlider' width='190%' /> <div id='label-ratingSlider'>"+ lastRating.text +"</di>");
	var slider = $("#input-ratingSlider").kendoSlider({
	    tickPlacement: "none",
	    showButtons: false,
	    min: 0,
	    max: ( dashboard.f.ratingValue().length == 0 ) ? 0 : dashboard.f.ratingValue().length - 1,
	    value: 0,
	    slide: moveSlider,
		tooltip: {
          enabled: false
        },
	});
	$("#ratingSlider").find("a.k-draghandle").text( dashboard.f.ratingValue()[0].text );
		
} 
dashboard.initSearhIssuer = function(){
	$("#searchIssuer").kendoAutoComplete({
        dataSource: _.pluck( dashboard.f.issuer(), "text"),
        filter: "contains",
        placeholder: "Search corporate issuer",
    });
}
dashboard.GetAllFilters =  function(){
	// exceptFilter = exceptFilter || "";
	// if(exceptFilter !== "corporation")
	dashboard.GetCorporation();
	// if(exceptFilter !== "ownership")
	dashboard.GetOwnership();
	// if(exceptFilter !== "region")
	dashboard.GetRegion();
	// if(exceptFilter !== "country")
	dashboard.GetCountry();
	// if(exceptFilter !== "ranking")
	dashboard.GetRanking();
	// if(exceptFilter !== "specialcharacter")
	dashboard.GetSpecialcharacter();
	// if(exceptFilter !== "currency")
	dashboard.GetCurrency();
	// if(exceptFilter !== "industry")
	dashboard.GetIndustry();
	// if(exceptFilter !== "product")
	dashboard.GetProduct();
	// if(exceptFilter !== "issuer")
	dashboard.GetIssuer();

	// dashboard.GetRatingValue();
}
dashboard.Init = function(){
	dashboard.breadcrumb([{ title:'Dashboard', event: dashboard.ChangeTab, tab:'Dashboard'}, {title:'Client Search' } ] );
	dashboard.GetAllFilters(); 
	 dashboard.GetRatingValue();
	dashboard.CreateGrid();
}

$(function(){
	dashboard.tab("dashboard");	
})