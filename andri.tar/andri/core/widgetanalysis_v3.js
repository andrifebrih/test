var wa = {
	loading: ko.observable(false),
	template: ko.observableArray([]),
	listTemplateId: ko.observableArray([]),
	templateId: ko.observable(""),
	inputTemplateId: ko.observable(""),
	mode: ko.observable("preview"),
	hoverNavTabWidget: ko.observable(false),
	page:{
		active: ko.observable(0),
		total: ko.observable(0),
	},
	listWidget: [
		{id: "wa_DefChart", title: "Transactions" },
		{id: "wa_IChart", title: "Investors" },
		{id: "wa_DisChart", title: "Distributions" },
		{id: "wa_AlcChart", title: "Allocations" },
		{id: "wa_CommonUnInvChart", title: "Common Un Investor" },
		{id: "wa_CommonInvChart", title: "Common Investor" },
		{id: "wa_DSChart", title: "Distribution Statistic" },
		{id: "wa_SlsPersonChart", title: "Sales Person" },
		{id: "wa_reviseQryChart", title: "Reverse enquiry" },
		{id: "wa_ScatterChart", title: "Scatter Chart" }
	], 
}
 

function createUid(){
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
         s4() + '-' + s4() + s4() + s4();
}
function ajaxFilter(url, payload, observerData, callback){
    ajaxPost(url, payload, function(res) {
	    var resData = _.map(res, function(d) {
	        return { text: d._id, value: d._id }
	    });
	   
	    observerData(resData);
	    if(typeof callback == "function"){
	        callback();

	    }
	});
}
function searchFilterPropertiesById(id, filter){
	return _.findWhere(filter, {id: id});
}
function getSelectorPage(id){
	return $("#page-" + id );
}
function openModal(id){
	$(id).modal('show');
}
function getWidthNav(){
  if(wa.template().length <= 5)
    return "20%";
  return  ( 100 / wa.template().length )  + "%";
}

wa.activeTemplate = {
	idx: function(){	
		return wa.page.active() - 1;
	},
	init: function(){
		return wa.template()[ wa.activeTemplate.idx() ];
	},
	mainPage: function(){
		return wa.activeTemplate.init().mainPage;
	},
	selector: function(){
	}
}
wa.changeTemplateId = function(val){
 	ajaxPost('/widgetanalysis/getdetailswidgetanalysis',{ id: val }, function(res) {
    	   	wa.inputTemplateId(val);
    	wa.setupTemplate(res.Data.details);

  	});
}
wa.propLeftFilter = function(type){
	type =  type || "default";
	switch(type){
		case"a":
				return"";
			break
		default:
			return [
				{
				   	id: "issuer",
				   	data: ko.observableArray([]), 
				   	value: ko.observableArray([]), 
				   	payload: "Issuer",
				   	flag: "issuer",
				   	title: "Issuer Name",
				   	ajax:  true
				},
				{
					id: "Parentcompanyname",
					data: ko.observableArray([]),
				   	value: ko.observableArray([]), 
				   	payload: "Parentcompanyname",
				   	flag: "parent_company_name",
				   	title: "Parent Company Name",
				   	ajax:  true
				},
			    {
					id: 'Continent', 
					data: ko.observableArray([]),
					value: ko.observableArray([]), 
					payload : "Continent",
					flag: 'continent',
					title: 'Continent',
					ajax: true,
			    },
			    {
					id: 'Region', 
					data: ko.observableArray([]),
					value: ko.observableArray([]), 
					payload : "Region",
					flag: 'region',
					title: 'Continent',
					ajax: true,
			    },
			    {
					id: 'Country', 
					data: ko.observableArray([]),
					value: ko.observableArray([]), 
					payload : "Country",
					flag: 'country',
					title: 'Country',
					ajax: true,
			    },

			    {
					id: 'Superindustry', 
					data: ko.observableArray([]),
					value: ko.observableArray([]), 
					payload : "Superindustry",
					flag: 'super_industry',
					title: 'Super Industry',
					ajax: true,
			    },
 				{
					id: 'Ownership', 
					data: ko.observableArray([]),
					value: ko.observableArray([]), 
					payload : "ownership",
					flag: 'super_industry',
					title: 'Ownership',
					ajax: true,
			    },
			    {
					id: 'Currency', 
					data: ko.observableArray([]),
					value: ko.observableArray([]), 
					payload : "Currency",
					flag: 'currency',
					title: 'Currency',
					ajax: true,
			    },
  				{
					id: 'Ranking', 
					data: ko.observableArray([]),
					value: ko.observableArray([]), 
					payload : "Ranking",
					flag: 'ranking',
					title: 'Ranking',
					ajax: true,
			    },
  				{
					id: 'Product', 
					data: ko.observableArray([]),
					value: ko.observableArray([]), 
					payload : "Product",
					flag: 'product',
					title: 'Product',
					ajax: true,
			    }, 
   				{
					id: 'Specialcharacter', 
					data: ko.observableArray([]),
					value: ko.observableArray([]), 
					payload : "Specialcharacter",
					flag: 'special_caracters',
					title: 'Special Character',
					ajax: true,
			    }, 
			];
	}
}
wa.getDataLeftFilter = function(filter, payload, mode){
	mode = mode || "addPageTemplate";
	_.each(filter, function(f){
		if(!f.ajax) return;
		var url = ! _.has( f, "url") ? "/widgetanalysis/getfilterwidget" : f.url;
		var p = _.clone(payload);
			p[f.payload] = [];	
			p["Flag"] = f.flag;
		// if(mode == "addPageTemplate")
		var callback = "";
		if(mode == "setupTemplate"){
			callback = function(){
				console.log("dd");
				f.value(payload[f.payload]);
			};
		}

		ajaxFilter(url, p, f.data, callback);	
	});
}
wa.changeLeftFilter =  function(e, keyPayload, value){
	e.payload[keyPayload] = value;
	wa.getDataLeftFilter( e.filter(), wa.getPayload(e) );  
	wa.reloadWidget(e);
}
wa.createPayload = function(filter){
	var payload = {};
	_.each(filter, function(f){
		payload[f.payload] = f.value(); 
	});
	return payload;
} 

wa.getPayload = function(e){
	var payload =  Object.assign({}, e.payload, e.mainPage.payload);
	return payload;
}
 
wa.addPage = function(){
	var pg = wa.page.total() + 1;
	var tFilter = ko.observableArray( wa.propLeftFilter() );
	var tPayload = wa.createPayload( tFilter() );

	wa.getDataLeftFilter(tFilter(), tPayload);
	wa.template.push({
		id:  createUid(),
		filter: tFilter,
		payload: tPayload,
		mainPage: {
			type: ko.observable(""),
			title: ko.observable("Analytics"),
			mode: ko.observable("chooseData"),
			filter: {},
			payload:{}
		}
	});

	wa.page.active(pg);
	wa.page.total(pg);
}
wa.closePage = function(page){
	var lenTemplate = wa.template().length; 
	if(page == wa.page.active()){
		if(page < lenTemplate){
	      wa.page.active(page);
	    }else{
	      wa.page.active(wa.page.active() - 1)
	    }
	}else if(page < wa.page.active()){
		wa.page.active(wa.page.active() - 1);
	}
	
	wa.page.total(wa.page.total() - 1);
  	wa.template().splice((page - 1), 1);
  	wa.template.valueHasMutated();
}

wa.saveTemplate = function(){
	if(wa.inputTemplateId() == "") {
    	return swal("", "Please insert a template name", "warning");
  	}

  	var newTemplate = [];
	_.each(wa.template(), function(t){
	    newTemplate.push({
			payload : t.payload,
			mainPage : {
				type: t.mainPage.type(),
				mode: t.mainPage.mode(),
				payload: t.mainPage.payload,
			}
		});
	});
	var payload = {TemplateName: wa.inputTemplateId(), details: newTemplate};
	ajaxPost("/widgetanalysis/savewidgetanalysis", payload, function(res) {
	    wa.listTemplateId(wa.inputTemplateId());
	    // var currentData = wa.config.template.data();
	    // 	currentData.push( wa.inputTemplateId() )
	    // wa.listTemplateId(currentData);
	    swal("Saved!", "", "success");
	 });

}
wa.exportPdf = function(){

}
wa.setupTemplate = function(template){
	var newTemplate = [];
	_.each(template, function(t){
		var tFilter = ko.observableArray( wa.propLeftFilter(t.mainPage.type) );
		var e = {
	        id: createUid(),
	        filter: tFilter,
	        payload: t.payload, 
	        mainPage: {
				title: ko.observable("Analytics"),
				type: ko.observable(t.mainPage.type),  
				mode: ko.observable(t.mainPage.mode), 
				payload: t.mainPage.payload
	        }
		};
		wa.getDataLeftFilter(tFilter(), wa.getPayload(e), 'setupTemplate');
		newTemplate.push(e);
	});
 
 	wa.template(newTemplate);
 	wa.page.active(0);
 	wa.page.total(newTemplate.length);
 	_.each(wa.template(), function(e,i){
 		var pg = i+ 1;
 		wa.page.active(pg);
 		wa.setupWidget(e);
 	});
}
 
wa.setupFilterWidget = function(filter){
}

wa.validationProcessWidget = function(id){
	if(id == "")
		return false;
	if(window[id] == undefined)
		return false;

	return true;
}
wa.generateWidget = function(e,id){
	if(!wa.validationProcessWidget(id)) return;
	window[id].init(e);	
}
wa.setupWidget = function(e){
	var id =  e.mainPage.type();
	if(!wa.validationProcessWidget(id)) return;
	if( window[id].setupFilter != undefined ) window[id].setupFilter(e);
	wa.reloadWidget(e);
}
wa.reloadWidget = function(e){
	var id =  e.mainPage.type();
	if(!wa.validationProcessWidget(id)) return;
	window[id].render(e);	
}
wa.closeWidget = function(e){
}  

wa.getListTemplate = function(){ 
	ajaxPost("/widgetanalysis/getwidgetanalysis", {}, function(res) {
		var data = _.map(res.Data, function(o) {
			return o._id;
		});
		wa.listTemplateId(data);
	}); 
} 

$(function(){
	wa.getListTemplate();
	wa.addPage();
});