var wa_DefChart = {
	title: "Transactions",
	menuTitle: 'transactions',
	pullRequest: ko.observable(0),
	loading: ko.observable(false)
};
wa_DefChart.pullRequest.subscribe(function(n){
	if(n == 0)
		return wa_DefChart.loading(false);
})

wa_DefChart.RenderGrid = function(url, payload, $selector,pullRequest){
	var $selector = $($selector).find(".defChart #grid");
	var maxAllocated = 0;

	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost(url, payload, function(res){
						pullRequest(pullRequest() - 1);
					//        	var datas = res;
					// var sortDatas = sortBarChart(datas)
					// console.log('sss',sortDatas)
						wa_DefChart.pullRequest(wa_DefChart.pullRequest() - 1);
						maxAllocated = res.Data.max;
						option.success({ Records: _.sortBy(res.Data.data, 'allocated').reverse(), Count: res.Total });
					})
	      	},
		},
		schema: {
			data: function(data) {
                return data.Records;
			},
			total: "Count",
		},
	    pageSize: 20,
		serverPaging: true,
		serverSorting: true,
		serverFiltering: true,
		},
		sortable: true,
		pageable: {
			numeric: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns: [
			{
				title: "Investor Name",
				field: "_id",
				width: 300,
			 	attributes: {
	                "class": "align-left"
	            },
	            headerAttributes: {
					"class": "align-left"
	            },
			},
			{
				title: "Firm",
				field: "firm",
				width: 100,
				attributes: {
	                "class": "align-center"
	            },
	            headerAttributes: {
	                "class": "align-center"
	            },
	            template: "#: kendo.toString(firm,'n0') #"
			},
			{
				title: "Allocation Amount",
				field: "allocated",
				attributes: {
					"class": "progressbar-cel"
				},
				headerAttributes: {
	                "class": "align-left"
	            },
				template: function(e){

					var percentage = ( maxAllocated == 0 ) ? 0 : 92 / ( maxAllocated / e.allocated );
					return  "<div class='pull-left series-bar' style='margin:2px 0;padding-top:3px;color:#fff;width: "+ percentage +"%'>"+kendo.toString(e.percentage,'n1')+"%</div>" +
							"<div class='pull-left number' style='padding-top:5px;'>" + kendo.toString(e.allocated,'n0') + "</div>";
				}
			}
		]
	});
};

wa_DefChart.generateDataViz = function(template) {
	var template = (template == null)? wa.activeProp.template() : template;
		template.mainPage.mode('preview');
		template.mainPage.type('wa_DefChart');
		template.pullRequest(1);
	var payload = _.clone( wa.activeProp.payload() );
		payload['Flag'] = "";
	wa_DefChart.RenderGrid(
							"/widgetanalysis/getgridtransaction",
							payload,
							wa.activeProp.selectorPage().find(".wa_DefChart"),
							template.pullRequest
						);
}
wa_DefChart.Reload =  function(template){
 	
	wa_DefChart.generateDataViz(template)

}
wa_DefChart.Close = function(){
	
	wa_DefChart.initFilter("close");
	var template =wa.activeProp.template();
 		template.mainPage.mode("chooseData");
 		template.mainPage.type("");
}
wa_DefChart.init = function(){
	 wa_DefChart.initFilter("open");
	wa_DefChart.generateDataViz();
};

wa_DefChart.initFilter =  function(mode){
  var payload = wa.activeProp.payload();
  if(mode == "open")
    payload  = wa_DefChart.extendPayload( _.clone(payload) );
  wa.GetDataDefaultFilters(wa.activeProp.filter(), "", payload);
};
wa_DefChart.extendPayload =  function(payload){ 
	payload["Box"] = "Transactions";
  	return payload;
};
