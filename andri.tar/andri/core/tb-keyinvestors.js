var keyinvestors 	= {};
keyinvestors.createGrid = function(){
	var payload  = {
		Issuer: [ds.issuerSelected.issuer]
	}
	$(".grid-key-investor").html("")
	$(".grid-key-investor").kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost("/widgetanalysis/getgridtransaction", payload, function(res){
						maxAllocated = res.Data.max;
						option.success({ Records: _.sortBy(res.Data.data, 'allocated').reverse(), Count: res.Total });
					})
	      	},
		},
		schema: {
			data: function(data) {
                return data.Records;
			},
			total: "Count",
		},
	    pageSize: 20,
		serverPaging: true,
		serverSorting: true,
		serverFiltering: true,
		},
		sortable: true,
		pageable: {
			numeric: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns: [
			{
				title: "Investor Name",
				field: "_id",
				width: 300,
			 	attributes: {
	                "class": "align-left"
	            },
	            headerAttributes: {
					"class": "align-left"
	            },
			},
			{
				title: "Firm",
				field: "firm",
				width: 100,
				attributes: {
	                "class": "align-center"
	            },
	            headerAttributes: {
	                "class": "align-center"
	            },
	            template: "#: kendo.toString(firm,'n0') #"
			},
			{
				title: "Allocation Amount",
				field: "allocated",
				attributes: {
					"class": "progressbar-cel"
				},
				headerAttributes: {
	                "class": "align-left"
	            },
				template: function(e){

					var percentage = ( maxAllocated == 0 ) ? 0 : 92 / ( maxAllocated / e.allocated );
					return  "<div class='pull-left series-bar' style='margin:2px 0;padding-top:3px;color:#fff;width: "+ percentage +"%'>"+kendo.toString(e.percentage,'n1')+"%</div>" +
							"<div class='pull-left number' style='padding-top:5px;'>" + kendo.toString(e.allocated,'n0') + "</div>";
				}
			}
		]
	});
}
keyinvestors.init =  function(){
	keyinvestors.createGrid();
};