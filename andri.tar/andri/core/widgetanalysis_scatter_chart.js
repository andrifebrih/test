var wa_ScatterChart = {
	title: "Scatter Chart",
	validation: ko.observable(false),
	filter: {
		bid: ko.observable("Bidytm"),
		val:{
			bid:ko.observable("Bidytm")
		},
	},
	// dataScatterChart : ko.observableArray([])
};
wa_ScatterChart.checkSelectedFilter =  function(){

	wa_ScatterChart.validation(false);
	var totalSelected = 0;
	if( wa.activeProp.filter()["Issuer"].value().length  > 0 ){
		return  wa_ScatterChart.validation(true)
	}
	_.each(wa.defFilter(), function(i){	
		if( wa.activeProp.filter()[i.id].value().length > 0)
		 	totalSelected += 1;
	});
	if(totalSelected >= 4)
		wa_ScatterChart.validation(true);
}
wa_ScatterChart.init =  function(){
	wa_ScatterChart.checkSelectedFilter();
	$("#wa_ScatterChart").modal('show');
}
wa_ScatterChart.createScatterChart =  function(bidType){
	var template = wa.activeProp.template();
	var $sel = wa.activeProp.selectorPage().find(".wa_ScatterChart");
	var circelData = [];
 
	_.each(template.mainPage.dataSource, function(o){
	 
		circelData.push({
						x: o.Yearsmaturity, 
						y: o[template.mainPage.filter.bid],
						color: "#7BBFF6",
						desc: o.Security + ' / ' + o.Moodysissuerrating + " "+ o.Spissuerrating + " " + o.Fitchissuerrating,
						 
					});
	});
	var minY 		= _.min(_.clone(circelData), function(data){
							if(!_.has(data,'y'))
								return 0;
						 	return data.y;
						}).y; 
	var minX 		= _.min(_.clone(circelData), function(data){
						if(!_.has(data,'x'))
							return 0;
					 	return data.x;
					 }).x;

	var maxY		= _.min(_.clone(circelData), function(data){
							if(!_.has(data,'y'))
								return 0;
						 	return data.y;
						}).y; 
	var maxX 		= _.min(_.clone(circelData), function(data){
						if(!_.has(data,'x'))
							return 0;
					 	return data.x;
					 }).x;
	var xAxisMin = ( ( parseInt(minX.toFixed(0)) - 1 ) < 0 ) ? 0 : parseInt(minX.toFixed(0)) - 1;
	var yAxisMin =  parseInt( minY.toFixed(0) );
	$sel.find("#chart").html("")
	$sel.find("#chart").kendoChart({
		series: [
			{
				type: "scatter",
				xField: "x",
				yField: "y",
				data: circelData,
				color : function(e){ 
					 return  e.dataItem.color;
				}, 
				markers: {
					size: function(e){
						return 10 
					}, 
					background : function(e){
						 return  e.dataItem.color;
					}
				},
				labels:{
					font:"9px Helvetica Neue, Helvetica, Arial, sans-serif",
			   		visible:true,
				    template:function(e){
				    	return  e.dataItem.desc;
				    }
				},
			}
		],
		chartArea: {
		    background: "#fff",
		    margin:{
		    	top:40,
		    	left:20,
		    	right:50,
		    	bottom:20
		    }
		},  
		legend:{
			visible:false
		},
		xAxis: { 
			min : xAxisMin,
			labels: { 
			   	font:"11px Helvetica Neue, Helvetica, Arial, sans-serif",
			    template:function(e){
			    	return e.value.toFixed(0);
			    },
			    color: "#0e678d"
   			},
   			majorGridLines: {
   				visible:false
   			},
 
        },
        yAxis:{ 
    		min  : yAxisMin,
    		labels: { 
			   	font:"11px Helvetica Neue, Helvetica, Arial, sans-serif",
			    template:function(e){
			    	return e.value.toFixed(0); 
			    },
			    color: "#0e678d"
   			},
   			majorGridLines: {
				visible: true,
				dashType: "dash"
			},
			majorUnit :  maxY / 3

        },
		  
		//tooltip:{
		// 	background:"#353D47",
		//           border: {
		//               width: 1,
		//               color: "#DDD"
		//           },
		//           visible:true,
		// 	template:function(e){  
		// 			return "<table>"+
		// 						"<tr>"+
		// 							"<td>Issuer</td>"+ 
		// 							"<td>"+e.dataItem.Security+"</td>"+ 
		// 						"</tr>"+
		// 						"<tr>"+
		// 							"<td>Moody's</td>"+ 
		// 							"<td>"+e.dataItem.Moodysissuerrating+"</td>"+ 
		// 						"</tr>"+
		// 						"<tr>"+
		// 							"<td>S&P</td>"+ 
		// 							"<td>"+e.dataItem.Spissuerrating+"</td>"+ 
		// 						"</tr>"+
		// 						"<tr>"+
		// 							"<td>Fitch</td>"+ 
		// 							"<td>"+e.dataItem.Fitchissuerrating+"</td>"+ 
		// 						"</tr>"+ 
		// 					"</table>"; 
		// 	}
		// },
        
		pannable 	: true,
        zoomable 	: false,
	});

}
wa_ScatterChart.changeBid =  function(val){
	var template = (template == null)? wa.activeProp.template() : template;
		template.mainPage.filter.bid = val;
		
		wa.activeProp.selectorPage().find(".scatter-btn-group").find("button").each(function(idx){
			$(this).attr("class","btn btn-scatter-chart");
		});
		wa.activeProp.selectorPage().find(".scatter-btn-group #"+val).attr("class","btn btn-scatter-chart-active");
		// template.mainPage.filter.bidObsevable(val)
		wa_ScatterChart.createScatterChart(val)
}
wa_ScatterChart.generateDataViz = function(){
	var template = (template == null)? wa.activeProp.template() : template;
		// template.mainPage.filter.bid = ( !_.has(template.mainPage.filter.bid ) ) ? "Bidytm" : template.mainPage.filter.bid;
		// template.mainPage.filter.bidObsevable = ( !_.has(template.mainPage.filter.bidObsevable ) ) ? ko.observable("Bidytm") : ko.observable(template.mainPage.filter.bid);
	 // 	template.mainPage.mode('preview');
		// template.mainPage.type('wa_ScatterChart');
	var payload = _.clone( wa.activeProp.payload() );
	ajaxPost("/widgetanalysis/schatterchart", payload, function (res){

		template.mainPage.dataSource = res.Data;
		wa_ScatterChart.createScatterChart(template.mainPage.filter.bid);
		
	})
}
wa_ScatterChart.render =  function(){
	var template = (template == null)? wa.activeProp.template() : template;
		template.mainPage.filter.bid = ( !_.has(template.mainPage.filter.bid ) ) ? "Bidytm" : template.mainPage.filter.bid;
	// template.mainPage.filter.bidObsevable = ( !_.has(template.mainPage.filter.bidObsevable ) ) ? ko.observable("Bidytm") : ko.observable(template.mainPage.filter.bid);
 	template.mainPage.mode('preview');
	template.mainPage.type('wa_ScatterChart');

	wa_ScatterChart.generateDataViz();	
}
wa_ScatterChart.Reload = function(){
    wa_ScatterChart.generateDataViz();
}
wa_ScatterChart.Close = function(){
  	var template =wa.activeProp.template();
    	template.mainPage.mode("chooseData");
    	template.mainPage.type("");
}
wa_ScatterChart.extendPayload = function(payload){
	return payload 
};