function getFilter(url, payload, observerData, funk) {
    ajaxPost(url, payload, function(res) {
        var resData = _.map(res, function(d) {
            return { text: d._id, value: d._id }
        });
        observerData(resData);
        if(typeof funk == "function"){
            funk();
        }
    })
}
var wa = {
	page:{
		active: ko.observable(0),
		total: ko.observable(0),
		data: ko.observableArray([])
	},
	template: ko.observableArray([]),
}

wa.activeTemplate = {
	idx: function(){ 
		return wa.page.active() - 1; 
	},
	init: function( idx ){ 
		idx = idx || wa.activeTemplate.idx();
		return wa.template()[idx]; 
	},
	selectorPage: function(){
		return  $("#page-" + wa.page.active());
	}
}
wa.getSelectorPage = function(page){
    page = page || "";
    if(page == "")
        return wa.activeTemplate.selectorPage();
    return $("#page-" + page);
}

wa.filterProperties = function(){
  return {
    "Issuer": { data: ko.observableArray([ { text: 'Issuer', value: 'Issuer'} ] ), value: ko.observableArray([]) },
    "Parentcompanyname": { data: ko.observableArray([ { text: 'Parentcompanyname', value: 'Parentcompanyname'}]), value: ko.observableArray([]) },
    "Continent": { data: ko.observableArray([ { text: 'Continent', value: 'Continent' } ] ), value: ko.observableArray([]) },
    "Region": { data: ko.observableArray([ { text: 'Region', value:'Region' } ] ), value: ko.observableArray([]) },
    "Country": { data: ko.observableArray([ { text: 'Country', value:'Country' } ] ), value: ko.observableArray([]) },
    "Superindustry": { data: ko.observableArray([ { text: 'Superindustry', value:'Country' } ] ), value : ko.observableArray([]) },
    "Industry": { data: ko.observableArray([ { text: 'Industry' , value:'Industry' } ] ), value : ko.observableArray([])  },
    "Ownership": { data: ko.observableArray([ { text: 'Ownership', value:'Country' } ] ), value: ko.observableArray([]) },
    "Currency": { data: ko.observableArray([ { text: 'Currency', value:'Country' } ] ), value : ko.observableArray([]) },
    "Ranking": { data: ko.observableArray([ { text: 'Ranking', value:'Country' } ] ), value : ko.observableArray([]) },
    "Product": { data: ko.observableArray([ { text: 'Product', value:'Country' } ] ), value : ko.observableArray([]) },
    // reverse query  
    "RatingtypeReverse": {  data: ko.observableArray([{text:"Fitch",value:"point_fitch"},{text:"Moody",value:"point_moody"},{text:"SP",value:"point_sp"}]), value: ko.observable("") }, 
    "RatingactionReverse": { 
      data: ko.observableArray([
                                  {text:"equal to",value:"$eq"},
                                  {text:"worse than",value:"$gt"},
                                  {text:"worse than or equal to",value:"$gte"},
                                  {text:"better than",value:"$lt"},
                                  {text:"better than or equal to",value:"$lte"}
                              ]),
      value: ko.observable('$eq'),
    },
    "RatingValueReverse": { 
      data: ko.observableArray([]),
      value: ko.observable("")
    },
    "RankingReverse": { 
      data: ko.observableArray(['Ranking' ]),
      value: ko.observableArray("")
    },
    "OwnershipReverse": { 
      data: ko.observableArray(['Ownership']),
      value: ko.observableArray()
    }, 
    "ProductReverse": { 
      data    : ko.observableArray(['Product' ]),
      value: ko.observableArray()
    },
  }
};
wa.defFilter = function(){
  return [
    {
      payload : "Issuer",
      id: 'Issuer', 
      title: 'Issuer Name',
      flag: 'issuer',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Parentcompanyname",
      id: 'Parentcompanyname', 
      title: 'Parent Company Name',
      flag: 'parent_company_name',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Continent",
      id: 'Continent', 
      title: 'Continent',
      flag: 'continent',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Region",
      id: 'Region', 
      title: 'Region',
      flag: 'region',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Country",
      id: 'Country', 
      title: 'Country',
      flag: 'country',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Superindustry",
      id: 'Superindustry', 
      title: 'Super Industry',
      flag: 'super_industry',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Ownership",
      id: 'Ownership', 
      title: 'Ownership',
      flag: 'ownership',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Currency",
      id: 'Currency', 
      title: 'Currency',
      flag: 'currency',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Ranking",
      id: 'Ranking', 
      title: 'Ranking',
      flag: 'ranking',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Product",
      id: 'Product', 
      title: 'Product',
      flag: 'product',
      type: 'multiselect',
      ajax: 'true',
    }
  ];
};
wa.createPayload =  function(filters, keys){
	var payload = []
	_.each(keys, function(o){
		payload[ o.payload ] = filters[o.id].value();
	});
	return payload;
};
wa.changeFilter = function(e, idFilter, idPayload){
    var template = wa.activeTemplate.init();
    var tFilter = template.filter;
    var tPayload = template.payload; 
    var tType = template.mainPage.type();

    wa.insertFilter(tFilter, idFilter, e._old);
    wa.insertPayload(tPayload, idPayload, e._old);    
    var p = _.clone(tPayload);
    if(template.mainPage.type() != ""){
        p = window[template.mainPage.type()].extendPayload(p);
    }
    wa.getDataFilter(tFilter, wa.getKeysFilter(tType),  p, "change filter" );
};
wa.getKeysFilter = function(type){
    type = type || "";
    switch(type){
        case"wa_reviseQryChart":
            return wa_reviseQryChart.leftFilter();
            break;
        case"wa_DisChart"
            return wa_DisChart.leftFilter();
            break;
        default:
            return wa.defFilter();
    }
};
wa.getDataFilter = function(filters, keys, payload, type){
    _.each(keys, function(f){
        if(! _.has(f,'ajax'))
            return 
        var p = _.clone(payload);
            p[f.payload] = [];

        var callback = "";
        if(type == "reload"){
            callback = function(){
                filters[f.id].value(payload[f.payload]);
            }
        }
        getFilter("/widgetanalysis/getfilterwidget", p, filters[f.id].data, callback);
    });
};

wa.createPage = function(){
	var pgActive = wa.page.total() + 1;
	var tFilter = _.clone( wa.allfilterProp() );
	var tPayload = wa.createPayload( tFilter, wa.getKeysFilter() );
	wa.getDataFilter( tFilter, wa.getKeysFilter() , tPayload, 'create page' );
	
    wa.template.push({
        page: pgActive(),
		filter: tFilter,
		payload: tPayload,
		mainPage: {
			type: ko.observable(""),
			mode: ko.observable(""),
			filter: {}
		}
	});
	
    wa.template.valueHasMutated();
	wa.page.data().push(page);
	wa.page.total(pgActive);
	wa.page.active(pgActive);
}
wa.goToPage =  function(page){
	wa.page.active(page);	
}

wa.setupTemplate = function(templates){
	var newTemplate = [];
	var newPage = [];
	_.each(templates, function(d,i){
		var tFilter = _.clone( wa.allfilterProp() );
     
        var tType = d.mainPage.type;
        var tMode = d.mainPage.mode;
        
        var p = _.clone( d.payload )
        if(tType != ""){
            p = window[template.mainPage.type()].extendPayload(p);
        }
		  wa.getDataFilter( tFilter, wa.getKeysFilter(tType), p, "reload" );
		
        newTemplate.push({
			filter: tFilter, 
			payload: d.payload,
			mainPage:{
				type: ko.observable( tType ),
				mode: ko.observable( tMode ),
				filter: {}
			}
		});
        newPage.push(d+1);
	});
	wa.template(newTemplate);
    wa.page.total(newPage);
    wa.page.active(0);

    _.each(wa.template(), function(d,i){
        wa.page.active(i + 1);
        window[ d.mainPage.type() ].reloadChart(d);
    });
}

// wa.resetFilterMainPage = function(filter){
//     _.each(filter function(f){
//         // var f = o   
//         if(Array.isArray(f))
//             if(typeof f == "function")
//                 return
//         else
//             if(typeof f == "function")
//                 return
//     });
// }
wa.reloadFilterMainPage = function(source, destination){
    _.each(source, function(o,i){
        if( _.has( destination, i ) )
            destination[i] = o;
    });
}
// wa.insertFilterMainPage = function(payload, filter){

// }
wa.closeChart = function(e){
	if(e.mainPage.type() == "")
		return;
	window[e.mainPage.type()].Close(e);
}
wa.reloadChart =  function(e){
	if(e.mainPage.type() == "")
		return;
	window[e.mainPage.type()].Reload(e);
}
wa.generateChart =  function(e){
	if(e.mainPage.type() == "")
		return;
	window[e.mainPage.type()].init(e);
}

wa.init = function(){
	wa.createPage();
}