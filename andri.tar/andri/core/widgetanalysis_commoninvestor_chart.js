var wa_CommonInvChart = {
	title: "Common Investor",
	menuTitle: 'commoninvestor',
	f:{
		investorsList: ko.observableArray([]),
		val: {
			Issuerdetail: ko.observableArray([]),
		}
	}
};

// wa_CommonInvChart.GetDatacommonUnInv = function() {
//   var payload = wa.getPayload();
//   payload["Flag"] = "issuer";
//   getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonInvChart.f.commonInvestorsList);
//   payload["Flag"] = "issuer";
//   getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonInvChart.f.commonInvestedList);
// };
wa_CommonInvChart.createColumn =  function(){ 
	
	_.map(wa.activeProp.template().mainPage.filter, function(d){

	}) 

}
wa_CommonInvChart.RenderGrid = function(url, payload, $selector){
 
	var $selector = $($selector).find("#grid");
	var maxAllocated = 0;
 	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost(url, payload, function(res){
					//        	var datas = res;
					// var sortDatas = sortBarChart(datas)
					// console.log('sss',sortDatas)
						wa_DefChart.pullRequest(wa_DefChart.pullRequest() - 1);
						maxAllocated = res.Data.max;
						option.success({ Records: _.sortBy(res.Data.data, 'allocated').reverse(), Count: res.Total });
					})
	      	},
		},
		schema: {
			data: function(data) {
                return data.Records;
			},
			total: "Count",
		},
	    pageSize: 20,
		serverPaging: true,
		serverSorting: true,
		serverFiltering: true,
		},
		sortable: true,
		pageable: {
			numeric: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns:(function(){
					var column =  [
									{
										title: "Investor Name",
										field: "_id",
										width: 300,
									 	attributes: {
							                "class": "align-left"
							            },
							            headerAttributes: {
											"class": "align-left"
							            },
									},
								  ];
					_.map(wa.activeProp.template().mainPage.filter.Issuerdetail, function(d){
						column.push({
							title: "<div class='field-ellipsis'>"+d+"</div>",
			  				field: d,
			  				width: 100,
			  				attributes: {
			  					"class": "text-center"
			  				},
			  				headerAttributes: {
			  					"class": "text-center"
			  				},
			  				template: function(dataItem) {
			  					return "<span class='fa fa-check green' ></span>"
			  				}
						});
					});
					column.push({
						title: "Firm",
						field: "firm",
						width: 100,
						attributes: {
			                "class": "align-center"
			            },
			            headerAttributes: {
			                "class": "align-center"
			            },
			            template: "#: kendo.toString(firm,'n0') #"
					},
					{
						title: "Allocation Amount",
						field: "allocated",
						attributes: {
							"class": "progressbar-cel"
						},
						headerAttributes: {
			                "class": "align-center"
			            },
						template: function(e){

							var percentage = ( maxAllocated == 0 ) ? 0 : 92 / ( maxAllocated / e.allocated );
							return  "<div class='pull-left series-bar' style='margin:2px 0;padding-top:3px;color:#fff;width: "+ percentage +"%'>"+kendo.toString(e.percentage,'n1')+"%</div>" +
									"<div class='pull-left number' style='padding-top:5px;'>" + kendo.toString(e.allocated,'n0') + "</div>";
						}
					});
					return column;
				})()
		
	});
};
wa_CommonInvChart.insertFilter =  function(){
  var filterMainPage = wa.activeProp.mainPage().filter;
      filterMainPage.Issuerdetail =  wa_CommonInvChart.f.val.Issuerdetail(); 
}
wa_CommonInvChart.generateDataViz =  function(){
	var template = wa.activeProp.template();
	template.mainPage.mode('preview');
	template.mainPage.type('wa_CommonInvChart');
	$("#commonInvestorModal").modal("hide");
	wa_CommonInvChart.insertFilter();
	var payload =  _.clone( wa.activeProp.payload() );
	payload['Flag'] = 'investor_name';
	payload['Issuerdetail'] = wa_CommonInvChart.f.val.Issuerdetail();
	var $selector = wa.activeProp.selectorPage().find(".wa_CommonInvChart");
	wa_CommonInvChart.RenderGrid("/widgetanalysis/getgridcommon",  payload, $selector);
};


wa_CommonInvChart.GetDataCommonInvestor = function() {
  var payload = wa.activeProp.payload();
  	  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonInvChart.f.investorsList);
};

wa_CommonInvChart.Reload =  function(){

	var filterMainPage = wa.activeProp.mainPage().filter;
	wa_CommonInvChart.f.val.Issuerdetail(filterMainPage.Issuerdetail); 

	wa_CommonInvChart.generateDataViz();
}

wa_CommonInvChart.Render = function() {
	wa_CommonInvChart.initFilter("open");
	wa_CommonInvChart.generateDataViz();
}
wa_CommonInvChart.Close = function(){
	wa_CommonInvChart.initFilter("close")
	var template =wa.activeProp.template();
 		template.mainPage.mode("chooseData");
 		template.mainPage.type("");
}

wa_CommonInvChart.init =  function(){
	wa_CommonInvChart.GetDataCommonInvestor();
	$("#commonInvestorModal").modal("show");
};










wa_CommonInvChart.initFilter =  function(mode){
  var payload = wa.activeProp.payload();
  if(mode == "open")
    payload  = wa_CommonInvChart.extendPayload( _.clone(payload) );
  wa.GetDataDefaultFilters(wa.activeProp.filter(), "", payload);
};
wa_CommonInvChart.extendPayload =  function(payload){
	payload['Box'] = 'Common Investor';
	payload['Flag'] = 'investor_name';
	payload['Issuerdetail'] = wa_CommonInvChart.f.val.Issuerdetail(); 
	return payload;
};