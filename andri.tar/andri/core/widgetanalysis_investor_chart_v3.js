var wa_IChart = {
}
wa_IChart.propFilter = function(){
	return {
		"Action":
		{
		   	id: "Action",
		   	data: ko.observableArray(['Contains', 'Equals']), 
		   	value: ko.observable("Contains"), 
		   	payload: "Action",  
		},
		"Textmulti":
		{
			id: "Textmulti",
			data: ko.observableArray([]),
		   	value: ko.observableArray([]), 
		   	payload: "Textmulti", 
		},
		"Text":
		{
			id: "Text",
			data: ko.observable(""),
		   	value: ko.observable(""), 
		   	payload: "Text", 
		}
	}
}

wa_IChart.getDataInvestor = function(f, callback){
	ajaxFilter( "/widgetanalysis/getinvestorname", {}, f.data, callback);
}
wa_IChart.drawBar =function($sel, title, dataSource){
	var series = [];
	var total = 0;
	var max = ( dataSource.length == 0 ) ? 0 : dataSource[0].value;
	var height = 300;
  	var gap = 0.5;
  	
  	if(dataSource.length < 5){
  		height =  ( dataSource.length * 30 ) * 2; 
  		gap = 1;
  	}
	
	$sel.html("");
	$sel.kendoChart({
		chartArea:{
			height: height,
			margin:{
				left:10,
				right:10, 
			}
		},
		legend: {
			visible: false,
			position: "bottom",
    	},
		seriesDefaults: {
			type: "bar",
			color: "#77c43a",
			gap: gap,
			border:{
				width:0
			},
			labels:{
				visible: true, 
				template: "#= kendo.toString( dataItem.percentage, 'n2' ) #%",
			}
		},
    	series: [
	    	{
				overlay: { gradient: "none"},
				name: title,
				categoryField:'_id',
				data: dataSource
			}
		],
		tooltip: {
			visible: true,
			template: "#= category # : #= value #",
		},
		valueAxis: {
			max :max * 1.35,
			majorGridLines: {
				visible: false
			},
			minorGridLines: {
				visible: false
			},
			labels:{
				visible:false,
			},
			line:{
				visible:false
			}
		},
    	categoryAxis: {
      		majorGridLines: {
          		visible: false
      		},
      		line:{
         		visible:false
      		},
			labels: {
				font: "9px Helvetica Neue, Helvetica, Arial, sans-serif",
			},
    	},
		render:function(){
			setTimeout(function(){ 
				var isFound = false
				$sel.find("> svg > g > g:nth-child(3) > g:gt(3)").each(function(id){ 
					if (isFound) return;
					if ($(this).html() == ''){
						isFound= true;
					} 
					$(this).find('text').attr('x',10);

				});
			},100);
		}
  	})
}
wa_IChart.createBars = function($selector, payload){
	ajaxPost("/widgetanalysis/getdonutinvestorone", payload, function(res) {
	 	wa_IChart.drawBar($selector.find("#wa-ic-donut-1"), "Industry", res.Data);
	});
	
	ajaxPost("/widgetanalysis/getdonutinvestortwo", payload, function(res) {
	 	wa_IChart.drawBar($selector.find("#wa-ic-donut-2"), "Ranking", res.Data);
	});

	ajaxPost("/widgetanalysis/getdonutinvestorthird", payload, function(res) {
	 	wa_IChart.drawBar($selector.find("#wa-ic-donut-3"), "Ranking", res.Data);
	});
}
wa_IChart.createGrid = function($selector, payload) {
	var $grid = $selector.find(".wa-ic-grid");
	$grid.html("");
	$grid.kendoGrid({
		dataSource: {
			transport: {
				read: function(option) {
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take;
					ajaxPost("/widgetanalysis/getgridinvestor", payload, function(res) {
						option.success({ Records: res.Data, Count: res.Total });
					});
				}
			},
			schema: {
				data: function(d) {
					return d.Records
				},
				total: "Count"
			},
			serverPaging: true,
			serverFiltering: true,
			serverSorting: true,
			pageSize: 10,
		},
		scrollable: true,
		sortable: true,  
		pageable: {
			number: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns: [
			{field: "issuer", title: "Issuer"},
			{field: "issue_date", title: "Issue Date"},
			{field: "currency", title: "Currency"},
			{field: "industry", title: "Industry"},
			{field: "country", title: "Country"},
			{field: "ownership", title: "Ownership"},
			{field: "ranking", title: "Ranking"},
			{field: "rating_type", title: "Rating Type"},
			{field: "size", title: "Size",  template: "#: kendo.toString(size,'n0') #"},
			{field: "firm", title: "Firm",  template: "#: kendo.toString(firm,'n0') #"},
			{field: "allocated_amount", title: "Allocated",  template: "#: kendo.toString(allocated_amount,'n0') #"},
		]
	});
}

wa_IChart.render =  function(e){
	e.mainPage.mode("preview");
	var payload = wa.getPayload(e);
	var $selector = getSelectorPage(e.id);
	wa.getDataLeftFilter(e.filter(), wa.getPayload(e));
	wa_IChart.createBars($selector, _.clone( payload ) );
	wa_IChart.createGrid($selector, _.clone( payload ) );
}

wa_IChart.init = function(e){
	e.mainPage.filter = wa_IChart.propFilter() ;
	e.mainPage.payload =  Object.assign( {}, wa.createPayload( e.mainPage.filter  ), { Box: "Investors" } );
	
	_.each(e.mainPage.filter, function(f){
		f.value.subscribe(function(n){
			e.mainPage.payload[f.payload] = n;
		});
	});
	
	e.mainPage.type("wa_IChart");

	wa_IChart.getDataInvestor( e.mainPage.filter.Textmulti );
	openModal('#wa_IChartModal');
}

wa_IChart.setupFilter = function(e){
	console.log(e);
	e.mainPage.filter =  wa_IChart.propFilter() ;
	wa_IChart.getDataInvestor( e.mainPage.filter.Textmulti , function(){ 
																e.mainPage.filter.Textmulti.value(e.mainPage.payload.Textmulti) 
															});
}


 