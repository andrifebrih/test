// function toogleFilter(){
// 	var $sel = $(".body-filter");
// 	var $header =  $(".header-filter");
// 	var display = $sel.css("display");
// 	if(display == "block"){ 
// 		$sel.slideUp();
// 		$header.find("i").removeClass('fa-caret-down').addClass('fa-caret-up');
// 		return;
// 	}
// 	$sel.slideDown();
// 	$header.find("i").removeClass('fa-caret-up').addClass('fa-caret-down');
// }
var sm = {}

sm.timeToShow = ko.observable(0);
sm.regionFilter = ko.observableArray([]);
sm.countryFilter = ko.observableArray([]);
sm.counterPartyFilter = ko.observableArray([]);
sm.industryFilter = ko.observableArray([]);
sm.issuerFilter = ko.observableArray([]);

sm.selectedRegion = ko.observableArray([]);
sm.selectedCountry = ko.observableArray([]);
sm.selectedCounterParty = ko.observableArray([]);
sm.selectedIndustry = ko.observableArray([]);
sm.selectedIssuer = ko.observableArray([]);
sm.isLoaded = ko.observable(0);
sm.chartModalTitle = ko.observable("Modal Title");
sm.donutLegendZoom = ko.observableArray([]);
sm.showDonut = ko.observable(false);
sm.showGrid = ko.observable(false);

sm.totalSecurityBuy = ko.observable(0);
sm.totalSecuritySell = ko.observable(0);
sm.totalBuy = ko.observable(0);
sm.totalSell = ko.observable(0);

sm.init = ko.observable(false);
sm.tabActive = ko.observable("sm");
sm.slider = "";
sm.optionValue = ko.observableArray([{
		lable: "Region",
		value: "$Region"
	},
	{
		lable: "Industry",
		value: "$Industry"
	},
	// { lable : "Country", value : "$Country" },
]);
sm.showBodyFilter = ko.observable(true);
sm.urlFilter = "/secondarymarket/getfilter";
/*sm.keyFilter = ["Name", "IssuerTicker", "Country", "Region", "Industry",
	"Rating", "Product","Security", "Currency", "issue_date_from", "issue_date_to", "Coupon","TenorFilter","FiCorpSov",
	 "MaturityType","DistributionType", "SpecialCharacter", "BaselClassification", "CountryListing", "Ranking",
	"InvestorNameFilter", "InvestorIndustry", "Investorcountry","InvestorRegion"
];
*/
sm.keyFilter = ["Name", "IssuerTicker", "Country", "Region", "Industry",
"Rating", "Product","Security", "Currency", "issue_date_from", "issue_date_to", "Coupon","TenorFilter","FiCorpSov",
 "MaturityType", "Ranking","space","space",
"InvestorNameFilter", "InvestorIndustry", "Investorcountry","InvestorRegion"
];
sm.filters = ko.observableArray([]);
sm.tableValue = ko.observableArray([]);
sm.sliderValue = ko.observable(4);
sm.TotalNumberofTransactions = ko.observable("");
sm.TotalTradeVolume = ko.observable("");
sm.TotalNumberofSecurities = ko.observable("");
sm.EarliestTransactionDate = ko.observable("");
sm.LatestTransactionDate = ko.observable("");
sm.TotalNumberofIssuers = ko.observable("");
sm.TotalNumberofInvestors = ko.observable("");
sm.ajaxFilter = ko.observable(0);

sm.allDataBuy = ko.observableArray([]);
sm.allDataSel = ko.observableArray([]);

sm.allDataSecurityBuy = ko.observableArray([]);
sm.allDataSecuritySel = ko.observableArray([]);

sm.payload = {};
sm.isRendered = ko.observable(false);
sm.defaultPayload = function () {
	return sm.payload;
}
sm.showModal = function (myid) {
	$("#modal-zoom").modal("show");
	$("#zoomedChart").height(300);
	sm.showDonut(false);
	sm.showGrid(false);
	setTimeout(function () {
		if (myid == "#sm_bar_main") {
			sm.renderMainBar(sm.barMainData(), "#zoomedChart")
		} else if (myid == "#sm_donut_region") {
			sm.showDonut(true);
			sm.renderDonutLeft(sm.donutLeftData(), "#zoomedChart_donut")
		} else if (myid == "#sm_donut_industry") {
			sm.showDonut(true);
			sm.renderDonutRight(sm.donutRightData(), "#zoomedChart_donut")
		} else if (myid == "#grid_container") {
			sm.showGrid(true);
		}
	}, 500);
}

sm.timeToShow.subscribe(function () {
	sm.refreshAllChartUI();
})

sm.selectedIssuer.subscribe(function () {
	setTimeout(function () {
		sm.getFilter("issuer");
		sm.refreshAllChart();
	}, 200);
});
sm.selectedCountry.subscribe(function () {
	setTimeout(function () {
		sm.getFilter("country");
		sm.refreshAllChart();
	}, 200);
});
sm.selectedCounterParty.subscribe(function () {
	setTimeout(function () {
		sm.getFilter("counterparty");
		sm.refreshAllChart();
	}, 200);
});
sm.selectedIndustry.subscribe(function () {
	setTimeout(function () {
		sm.getFilter("industry");
		sm.refreshAllChart();
	}, 200);
});
sm.selectedRegion.subscribe(function () {
	setTimeout(function () {
		sm.getFilter("region");
		sm.refreshAllChart();
	}, 200);
});

sm.topBuy = ko.observableArray([]);
sm.topSell = ko.observableArray([]);
sm.topBuyAll = ko.observableArray([]);
sm.topSellAll = ko.observableArray([]);

sm.topSecurityBuy = ko.observableArray([]);
sm.topSecuritySell = ko.observableArray([]);
sm.topSecurityBuyAll = ko.observableArray([]);
sm.topSecuritySellAll = ko.observableArray([]);

sm.valPeriod = ko.observable(3);

sm.donutRightData = ko.observableArray([]);
sm.donutLeftData = ko.observableArray([]);
sm.barMainData = ko.observableArray([]);
sm.donutLegendLeft = ko.observableArray([]);
sm.donutLegendRight = ko.observableArray([]);
sm.topDataConfig = [{
		"id": "top-buy",
		Box: "Buyer",
		Toggle: "Net",
		Order: "sumBuy"
	},
	{
		"id": "top-sell",
		Box: "Seller",
		Toggle: "Net",
		Order: "sumSell"
	},
	{
		"id": "top-security-buy",
		Box: "Security Buyer",
		Toggle: "Net",
		Order: "sumBuy"
	},
	{
		"id": "top-security-sell",
		Box: "Security Seller",
		Toggle: "Net",
		Order: "sumSell"
	},
];
sm.period = ko.computed(function () {

	var period = "";
	switch (sm.valPeriod()) {
		case 0.01:
			period = "1 Day";
			break;
		case 0.1:
			period = "1 Week";
			break;
		case 1:
			period = "1 Month";
			break;
		case 3:
			period = "3 Month";
			break;
		case 6:
			period = "6 Month";
			break;
		case 12:
			period = "1 Year";
			break;
		case 999:
			period = "Max";
			break;
	}
	return period;
});
sm.titleFilter = ko.computed(function () {
	var title = "-";
	var titleTopFilter = [];
	_.each([{
			title: "Region",
			data: sm.selectedRegion()
		},
		{
			title: "Country",
			data: sm.selectedCountry()
		},
		{
			title: "Counter Party",
			data: sm.selectedCounterParty()
		},
		{
			title: "Industry",
			data: sm.selectedIndustry()
		},
		{
			title: "Issuer",
			data: sm.selectedIssuer()
		},
	], function (d) {
		if (d.data.length == 0) return;
		titleTopFilter.push(d.title + ": " + d.data.join(", "));

	});
	if (titleTopFilter.length > 0)
		title += " By " + titleTopFilter.join(" And ");
	title += " For " + sm.period();
	return title;

});

sm.setFilter = function (additional) {
	if (additional == undefined) {
		return {
			"region": sm.selectedRegion(),
			"country": sm.selectedCountry(),
			"industry": sm.selectedIndustry(),
			"issuer": sm.selectedIssuer(),
			"counterparty": sm.selectedCounterParty(),
		}
	}

	if (additional.fieldfield != "$Region")
		additional["region"] = sm.selectedRegion();

	if (additional.fieldfield != "$Country")
		additional["country"] = sm.selectedCountry();

	if (additional.fieldfield != "$Industry")
		additional["industry"] = sm.selectedIndustry();

	if (additional.fieldfield != "$Issuer")
		additional["issuer"] = sm.selectedIssuer();

	if (additional.fieldfield != "$CounterParty")
		additional["counterparty"] = sm.selectedCounterParty();

	return additional;
}

sm.getFilter = function (except) {

	var all = ["region", "country", "counterparty", "industry", "issuer"];
	if (except != undefined) {
		all = _.filter(all, function (n) {
			return n != except;
		});
	}

	if (all.indexOf("region") > -1) {
		var payload = {
			"fieldfield": "$Region"
		};
		payload = sm.setFilter(payload);
		ajaxPost("/secondarymarket/getfilter", payload, function (res) {
			sm.regionFilter(res);
		});
	}

	if (all.indexOf("country") > -1) {
		var payload = {
			"fieldfield": "$Country"
		}
		payload = sm.setFilter(payload);
		ajaxPost("/secondarymarket/getfilter", payload, function (res) {
			sm.countryFilter(res)
		});
	}
	if (all.indexOf("counterparty") > -1) {
		var payload = {
			"fieldfield": "$CounterParty"
		}
		payload = sm.setFilter(payload);
		ajaxPost("/secondarymarket/getfilter", payload, function (res) {
			sm.counterPartyFilter(res);
		});
	}
	if (all.indexOf("industry") > -1) {
		var payload = {
			"fieldfield": "$Industry"
		}
		payload = sm.setFilter(payload);
		ajaxPost("/secondarymarket/getfilter", payload, function (res) {
			sm.industryFilter(res);
		});
	}
	if (all.indexOf("issuer") > -1) {
		var payload = {
			"fieldfield": "$Issuer"
		}
		payload = sm.setFilter(payload);
		ajaxPost("/secondarymarket/getfilter", payload, function (res) {
			sm.issuerFilter(res);
		});
	}
}

sm.getMainBar = function () {
	// var curVal = $("#dropDownBy").getKendoDropDownList().value();
	var payload = $.extend(sm.defaultPayload(), {
		"volumeby": "$Region",
		"period": sm.valPeriod()
	})
	ajaxPost("/secondarymarket/getbarchart", payload, function (res) { 
		sm.timeToShow(true);
		sm.isLoaded(sm.isLoaded() + 1);
		sm.barMainData(res.Data);
		sm.renderMainBar(res.Data);
	})
}
sm.renderDataNotFound = function (data, id, obs) {
	$(id).attr("isfound", true)
	if (data.length == 0) {
		if (obs != undefined) {
			obs([]);
		}
		$(id).attr("isfound", false);

		if (id == "#sm_bar_main" || id == "#zoomedChart") {
			$(id).attr("isfound", "falsemain");
		}
		$(id).html("Data Not Found");
		return true;
	}
	return false;
}

sm.renderMainBar = function (data, id) {
	$("#sm_bar_main").html("");
	if(data.length == 0) return;
	var catRotation = 0;
	var labelRotation = 0;
	if(data.length > 10){
		var catRotation = 65;
		var labelRotation = -90;
	}
	var totalCsumBuy = 0;
	var totalCsumSell = 0;
	var totalLSumBuy = 0; 
   	_.each(data, function(d){ 
  		totalCsumBuy += d.cSumBuy;
		totalCsumSell += d.cSumSell;
		totalLSumBuy += d.lSumBuy;
  	});
  	data.unshift({_id:"Grand Total \n (All Regions)", cSumBuy: totalCsumBuy, cSumSell: totalCsumSell, lSumBuy: totalLSumBuy, })    
 	var templatetooltip = function (val) {
		return "$" + kendo.toString(val.value, "N2") + "m"
	};
	$("#sm_bar_main").kendoChart({
		theme: "flat",
		title: { 
			font: "12px Arial,Helvetica,sans-serif", 
		},
		legend: {
			visible: false,
			position: 'bottom',
		},
		chartArea: {
			height: 300,
			background: "#f4f4f9",
			margin: {
				top: 0,
				left: 0,
				right: 0,
				bottom: 0
			}
		},
		dataSource: {
			data: data,
		},
		seriesDefaults: {
			type: "column",
			stack: true,
			overlay: {
				gradient: "none"
			}, 
			border: {
				width: 0
			},
			labels: {
				template: "$#= kendo.toString(value,'N0')#m",
				position: "InsideEnd",
				color: "#f4f4f9",
				margin: {
					top: 0,
				}
			}
		},
		legendItemClick: function (e) {
			sm.legendItemClick(e);
		}, 
		series: [
			{
				field: "cSumBuy",
				name: "Buy",
				color: "#FB7676",
				stack: "barCenter"
			},
			{
				field: "cSumSell",
				name: "Buy",
				color: "#26B397",
				stack: "barCenter"
			},
			{
				field: "lSumBuy",
				type:"line",
				name: "Buy",
				color: "#26B397",
				stack: "barCenter",
				color: "transparent", 
				markers: {
					size: 15,
					border: {
		              width: 3,
		              color: "#26B397"
		            },
				},
				tooltip:{
					background: "#fff",
					border:{
						color: "#26B397",
						width: 2
					}
				},
				labels: {
					font: "bold 12px Arial,Helvetica,sans-serif",
					visible: true,
					position: "top",
					color: "#000000",
					rotation:labelRotation,
					template: function(e){
						return  "$" + kendo.toString(e.dataItem.lSumBuy,'n0') + "m\n"+ 
								"$" + kendo.toString(e.dataItem.cSumSell,'n0') + "m\n"+ 
								"$" + kendo.toString(e.dataItem.cSumBuy,'n0') + "m";
					}
				},

			},
		],
		categoryAxis: {
			name: "catAxis",
			labels: {
				font: "bold 12px Arial,Helvetica,sans-serif",
				visible: true,
				rotation: catRotation,
			},
			field: "_id",
			line: {
				visible: false
			},
			majorGridLines: {
				visible: false
			}
		},
		labels: {
			font: "bold 12px Arial,Helvetica,sans-serif",
			align: "center",
			template: "#= value #",
			rotation: "auto", 
			visible: false
		},
		justified: false,
		tooltip: {
			"visible": true,
			"template": templatetooltip,
			"padding": "1px 1px 1px 1px",
			"border": "1px solid #f4f4f4",
			"background-color": "#f4f4f4",
		},
		valueAxis: {
			max: data.length == 0 ? 0 : data[0].lSumBuy * 1.3,
			min:0,
			name: "sales",
			labels: {
				template: "$#= kendo.toString(value,'n0')#m",
				color: "#0e678d",
			},
			line: {
				visible: false
			},
			visible: false,
			majorGridLines: {
				visible: false
			},
		},
		render: function(){
			var gt = data.length + 3;
			$("#sm_bar_main > svg > g > g:nth-child(3) > g:gt( "+gt+" )").each(function (i, e) { 
				$(e).find("text").eq(1).attr("fill","#26B397");
				$(e).find("text").eq(2).attr("fill","#FB7676"); 
			})
		}
	});
 


}
sm.visibleStatus = ko.observable({});
sm.visibleStatus().buy = true;
sm.visibleStatus().sell = true;
sm.legendItemClick = function (e) {
	var text = e.text.toLowerCase();
	sm.visibleStatus()[text] = !sm.visibleStatus()[text];
}

sm.renderLable = function (coorvalue, textvalue, text, idx, e, myid, otherValue) {
	var axis = e.sender.getAxis("sales")._axis.plotArea.axisY;
	var slot = axis.slot(coorvalue);
	var categoryAxis = e.sender.getAxis("catAxis")._axis.plotArea.axisY;
	var categorySlot = categoryAxis.slot(coorvalue);

	// if(minval != undefined){
	// 	slot = axis.slot(minval);
	// 	categorySlot = categoryAxis.slot(minval);
	// }



	if (otherValue != undefined) {
		var myCategorySlot = categoryAxis.slot(otherValue);
		var first = categorySlot.origin.y;
		var second = myCategorySlot.origin.y;
		var sel = first - second;
		if (sel > -15 && sel < 15) {
			categorySlot.origin.y = first - (15 - Math.abs(sel));
		}
	}

	var coor = sm.GetCoordinate(myid);
	// console.log(coor);
	var cate = coor.category;
	var x = parseInt(cate[idx].attr("x"));
	var num = "$" + kendo.toString(Math.abs(textvalue), "n0") + "m";
	// var numlength = num.replace(".","").replace(",","").length;
	var text = cate[idx].text();
	var numlength = sm.getTextWidth(num, "12px sans-serif");
	var textlength = sm.getTextWidth(text, "12px sans-serif");
	var selisih = numlength - textlength
	var gap = selisih * -0.5;
	// if(selisih	> -3 && selisih < 0){
	// 	gap = 0;
	// }
	//(value >1 ? categorySlot.origin.y-18 : categorySlot.origin.y + 6)
	var labelPos = [x + gap, (categorySlot.origin.y - 18)];
	var label = new kendo.drawing.Text(num, labelPos, {
		fill: {
			"color": "black",
		},
		font: "12px sans-serif",
		"font-weight": "bold",
		class: "add-avg"
	});
	var group = new kendo.drawing.Group();
	group.append(label);
	e.sender.surface.draw(group);
}

sm.GetCoordinate = function (cl) {
	var alltext = $(cl).find("text");
	var category = [];
	var value = [];
	alltext.each(function () {
		var keycat = parseInt($(alltext[0]).attr("y") + 10);
		var el = parseInt($(this).attr("y") + 10);
		if (el > (keycat - 5) && el < (keycat + 5)) {
			category.push($(this));
		} else {
			var keyval = parseInt($(alltext[category.length]).attr("x"));
			el = parseInt($(this).attr("x"));
			if (el > (keyval - 5) && el < (keyval + 5)) {
				value.push($(this));
			}
		}
	});

	return {
		category: category,
		value: value
	}
}

sm.getDonutLeft = function () {
	var payload = $.extend(sm.defaultPayload(), {
		"volumeby": "$Region",
		"period": sm.valPeriod()
	})
	ajaxPost("/secondarymarket/getbarchart", payload, function (res) {
		sm.isLoaded(sm.isLoaded() + 1);
		sm.renderDonutLeft(res);
		sm.donutLeftData(res);
	})
}

sm.renderDonutLeft = function (data, id) {
	var height = 320;
	var myid = "#sm_donut_region";
	var showlable = false;
	var legendDs = sm.donutLegendLeft;

	if (id != undefined) {
		myid = id;
		height = screen.height * 0.6;
		showlable = false;
		legendDs = sm.donutLegendZoom;
		$(".legend-cont-zoomed").height(height);
	}
	if (sm.renderDataNotFound(data, myid, sm.donutLegendLeft)) {
		return false;
	}
	var templatetooltip = function (val) {
		return "<div class='tooltipChart backColor'>" + val.category.replace("|", " ") + "</div>";
	};

	var myfield = "sumBuy";
	var selected = $("#leftToggle").prop('checked');

	if (!selected) {
		myfield = "sumSell"
	}

	data = sm.calcPercentage(data, myfield, "_id");


	$(myid).kendoChart({
		theme: "flat",
		legend: {
			position: 'right',
			visible: false
		},
		dataSource: {
			data: data,
		},
		chartArea: {
			height: height,
			background: "#f4f4f9",
			// margin:10
		},
		seriesDefaults: {
			type: "donut",
			stack: true,
			holeSize: height / 4,
			labels: {
				visible: showlable,
				template: "#= category.replace('|',' ')#",
				// position : "Inside"	
			}
		},
		series: [{
				field: myfield,
				categoryField: "mycategory",
				name: "Buy",
				color: "#3d9618",
				padding: 30
			},
			// {
			//    	field : "sumSell",
			//    	name: "Sell",
			//    	color: "#3d9618",
			// },
		],
		// categoryAxis: {
		// 	name: "catAxis",
		// 	field : "_id",
		// 	majorGridLines: {
		// 	visible: false,
		// 	line: {
		// 	    visible: false
		// 	},
		// 	majorGridLines : {
		// 		visible : false
		// 	}
		// },
		labels: {
			font: "12px Arial,Helvetica,sans-serif",
			align: "center",
			template: "#= value #",
			rotation: "auto",
			color: "#0e678d",
		},
		// justified: false,
		// },
		tooltip: {
			"visible": true,
			"template": templatetooltip,
			"padding": "1px 1px 1px 1px",
			"border": "1px solid #f4f4f4",
			"background-color": "#f4f4f4",
		},
		//       valueAxis: {
		// 	labels: {
		// 	    template: "#= kendo.toString(value,'n0')#  mil"
		// 	},
		// 	line: {
		// 	    visible: false
		// 	},
		// 	majorGridLines : {
		// 		visible : false
		// 	},
		// 	min : calcval,
		// 	axisCrossingValue: calcval
		// },
	});


	// sm.genLegendData(myid,data,legendDs);
};

sm.genLegendData = function (myid, data, obs) {
	var curcol = $(myid).getKendoChart().options.seriesColors;
	obs([]);
	_.each(data, function (val, idx) {
		obs.push({
			label: val.mycategory.split("|")[0],
			value: val.mycategory.split("|")[1],
			color: (curcol[idx] == undefined ? curcol[idx % curcol.length] : curcol[idx])
		});
	});
};
// sm.getTopData = function () {
// 	var payload = sm.defaultPayload();
// 	payload["TopData"] = [];
// 	payload["Level"] = model.userLevel();
// 	_.each(sm.topDataConfig, function (d) {
// 		d.Toggle = "Gross";
// 		if ($("#" + d.id).prop("checked") == false) {
// 			d.Toggle = "Net";
// 		}
// 		payload["TopData"].push({
// 			Box: d.Box,
// 			Toggle: d.Toggle,
// 			Order: d.Order
// 		})
// 	});



// 	ajaxPost("/secondarymarket/gettopdata", payload, function (res) {

// 		sm.isLoaded(sm.isLoaded() + 1);

// 		sm.totalBuy(Math.abs(res.Data.Buyer.total));
// 		sm.renderTopData(res.Data.Buyer.res, 0, sm.topDataConfig[0]);
// 		sm.allDataBuy(res.Data.Buyer.res);

// 		sm.totalSell(Math.abs(res.Data.Seller.total));
// 		sm.renderTopData(res.Data.Seller.res, 0, sm.topDataConfig[1]);
// 		sm.allDataSel(res.Data.Seller.res);

// 		sm.totalSecurityBuy(Math.abs(res.Data.Security_Buyer.total));
// 		sm.renderTopData(res.Data.Security_Buyer.res, 0, sm.topDataConfig[2]);
// 		sm.allDataSecurityBuy(res.Data.Security_Buyer.res);


// 		sm.totalSecuritySell(Math.abs(res.Data.Security_Seller.total));
// 		sm.renderTopData(res.Data.Security_Seller.res, 0, sm.topDataConfig[3]);
// 		sm.allDataSecuritySel(res.Data.Security_Seller.res);


// 	});
// }
sm.renderTopData = function (data, addData, e) {

	switch (e.Box) {
		case "Buyer":
			var arr = sm.topBuy;
			var arrAll = sm.topBuyAll;
			var total = sm.totalBuy;
			break;
		case "Seller":
			var arr = sm.topSell;
			var arrAll = sm.topSellAll;
			var total = sm.totalSell;
			break;
		case "Security Seller":
			var arr = sm.topSecuritySell;
			var arrAll = sm.topSecuritySellAll;
			var total = sm.totalSecuritySell;
			break;
		case "Security Buyer":
			var arr = sm.topSecurityBuy;
			var arrAll = sm.topSecurityBuyAll;
			var total = sm.totalSecurityBuy;
			break;
	}
	arr([]);
	arrAll([]);

	data = _.sortBy(data, "percentage").reverse();
	_.each(data, function (val, idx) {
		var volume = val[e.Order];
		if (e.Toggle == "Net") {
			volume = val.diff;
		}
		var obj = {
			counterparty: val._id.cnparty,
			industry: val._id.industry,
			product: val._id.product,
			region: val._id.region,
			security: val._id.security,
			investor: val._id.investor_country,
			volume: kendo.toString(Math.abs(volume), "N0"),
			pct: kendo.toString(val.percentage, "N0")
		};
		if (idx < 10 + addData) {
			arr.push(obj);
		}
		arrAll.push(obj);
	})
	var obj = {
		counterparty: "Total",
		industry: "",
		product: "",
		region: "",
		security: "",
		investor: "",
		volume: kendo.toString(total(), 'N0'),
		pct: kendo.toString(100, 'N0')
	};
	arrAll.push(obj);
	var obj = {
		counterparty: "Total",
		industry: "",
		product: "",
		region: "",
		security: "",
		investor: "",
		volume: kendo.toString(total(), 'N0'),
		pct: kendo.toString(100, 'N0')
	};
	arr.push(obj);
}



sm.getTableTopBuy = function () {
	var Toggle = "Gross"
	if ($("#top-buy").prop("checked") == false) {
		Toggle = "Net"
	}
	var payload = $.extend(sm.defaultPayload(), {
		"order": "sumBuy",
		"period": sm.valPeriod(),
		"Toggle": Toggle
	})
	ajaxPost("/secondarymarket/gettopdata", payload, function (res) {
		sm.isLoaded(sm.isLoaded() + 1);

		sm.totalBuy(Math.abs(res.total));
		sm.renderTableTopBuy(res.res, 0);
		sm.allDataBuy(res.res);

		sm.totalSell(Math.abs(res.total));
		sm.renderTableTopBuy(res.res, 0);
		sm.allDataSel(res.res);

		sm.totalSecurityBuy(Math.abs(res.total));
		sm.renderTableTopBuy(res.res, 0);
		sm.allDataSecurityBuy(res.res);

		sm.totalSecuritySell(Math.abs(res.total));
		sm.renderTableTopBuy(res.res, 0);
		sm.allDataSecuritySel(res.res);
	})
}

sm.renderTableTopBuy = function (data, addData) {
	sm.topBuyAll([]);
	sm.topBuy([]);
	data = _.sortBy(data, "percentage").reverse();
	_.each(data, function (val, idx) {
		var volume = val.sumBuy
		if ($("#top-buy").prop("checked") == false) {
			volume = val.diff
		}

		var obj = {
			counterparty: val._id.cnparty,
			industry: val._id.industry,
			volume: kendo.toString(Math.abs(volume), "N0"),
			pct: kendo.toString(val.percentage, "N0")
		};
		if (idx < 10 + addData) {
			sm.topBuy.push(obj);
		}
		sm.topBuyAll.push(obj);
	})
	var obj = {
		counterparty: "Total",
		industry: "",
		volume: kendo.toString(sm.totalBuy(), 'N0'),
		pct: kendo.toString(100, 'N0')
	};
	sm.topBuyAll.push(obj);
	var obj = {
		counterparty: "Total",
		industry: "",
		volume: kendo.toString(sm.totalBuy(), 'N0'),
		pct: kendo.toString(100, 'N0')
	};
	sm.topBuy.push(obj);
}

sm.getTableTopSell = function () {
	var Toggle = "Gross"
	if ($("#top-Sell").prop("checked") == false) {
		Toggle = "Net"
	}
	var payload = $.extend(sm.defaultPayload(), {
		"order": "sumSell",
		"period": sm.valPeriod(),
		"Toggle": Toggle
	})
	ajaxPost("/secondarymarket/gettopdata", payload, function (res) {
		sm.isLoaded(sm.isLoaded() + 1);
		sm.totalSell(Math.abs(res.total));

		sm.renderTableTopSell(res.res, 0);
		sm.allDataSel(res.res);
	})
}

sm.renderTableTopSell = function (data, addData) {
	sm.topSell([]);
	sm.topSellAll([]);
	data = _.sortBy(data, "percentage").reverse();
	_.each(data, function (val, idx) {
		var volume = val.sumSell
		if ($("#top-Sell").prop("checked") == false) {
			volume = val.diff
		}

		var obj = {
			counterparty: val._id.cnparty,
			industry: val._id.industry,
			volume: kendo.toString(volume, "N10"),
			pct: kendo.toString(val.percentage, "N10")
		}
		if (idx < 10 + addData) {
			sm.topSell.push(obj);
		}
		sm.topSellAll.push(obj);
	});
	var obj = {
		counterparty: "Total",
		industry: "",
		volume: kendo.toString(sm.totalSell(), 'N0'),
		pct: kendo.toString(100, 'N0')
	};
	sm.topSellAll.push(obj);
	var obj = {
		counterparty: "Total",
		industry: "",
		volume: kendo.toString(sm.totalSell(), 'N0'),
		pct: kendo.toString(100, 'N0')
	};
	sm.topSell.push(obj);
}


sm.getDonutRight = function () {
	var payload = $.extend(sm.defaultPayload(), {
		"volumeby": "$Industry",
		"period": sm.valPeriod()
	})
	ajaxPost("/secondarymarket/getbarchart", payload, function (res) {
		sm.isLoaded(sm.isLoaded() + 1);
		sm.renderDonutRight(res);
		sm.donutRightData(res);
	})
}

sm.renderDonutRight = function (data, id) {
	var height = 320;
	var myid = "#sm_donut_industry";
	var showlable = false;
	var legendDs = sm.donutLegendRight;
	if (id != undefined) {
		myid = id;
		height = screen.height * 0.6;
		showlable = false;
		legendDs = sm.donutLegendZoom;
		$(".legend-cont-zoomed").height(height);
	}
	if (sm.renderDataNotFound(data, myid, sm.donutLegendRight)) {
		return false;
	}
	var templatetooltip = function (val) {
		return "<div class='tooltipChart backColor'>" + val.category.replace("|", " ") + "</div>";
	};

	var myfield = "sumBuy";
	var selected = $("#rightToggle").prop('checked');

	if (!selected) {
		myfield = "sumSell"
	}

	data = sm.calcPercentage(data, myfield, "_id");

	$(myid).kendoChart({
		theme: "flat",
		legend: {
			position: 'right',
			visible: false
		},
		chartArea: {
			height: height,
			background: "#f4f4f9",
			// margin:10
		},
		dataSource: {
			data: data,
		},
		seriesDefaults: {
			type: "donut",
			stack: true,
			holeSize: height / 4,
			padding: 30
		},
		series: [{
				field: myfield,
				categoryField: "mycategory",
				name: "Buy",
				color: "#3d9618",
				labels: {
					visible: showlable,
					template: "#= category.replace('|',' ')#",
					// position : "Inside"	
				}
			},
			// {
			//    	field : "sumSell",
			//    	name: "Sell",
			//    	color: "#3d9618",
			// },
		],
		// categoryAxis: {
		// 	name: "catAxis",
		// 	field : "_id",
		// 	majorGridLines: {
		// 	visible: false,
		// 	line: {
		// 	    visible: false
		// 	},
		// 	majorGridLines : {
		// 		visible : false
		// 	}
		// },
		labels: {
			font: "12px Arial,Helvetica,sans-serif",
			align: "center",
			template: "#= value #",
			rotation: "auto",
			color: "#0e678d",
		},
		// justified: false,
		// },
		tooltip: {
			"visible": true,
			"template": templatetooltip,
			"padding": "1px 1px 1px 1px",
			"border": "1px solid #f4f4f4",
			"background-color": "#f4f4f4",
		},
		//       valueAxis: {
		// 	labels: {
		// 	    template: "#= kendo.toString(value,'n0')#  mil"
		// 	},
		// 	line: {
		// 	    visible: false
		// 	},
		// 	majorGridLines : {
		// 		visible : false
		// 	},
		// 	min : calcval,
		// 	axisCrossingValue: calcval
		// },
	});
	// sm.genLegendData(myid,data,legendDs);
}

sm.valPeriod.subscribe(function (val) {
	// if (val == 0.01) {
	// 	$("#slider").data("kendoSlider").value(1);
	// } else if (val == 0.1) {
	// 	$("#slider").data("kendoSlider").value(2);
	// } else if (val == 1) {
	// 	$("#slider").data("kendoSlider").value(3);
	// } else if (val == 3) {
	// 	$("#slider").data("kendoSlider").value(4);
	// } else if (val == 6) {
	// 	$("#slider").data("kendoSlider").value(5);
	// } else if (val == 12) {
	// 	$("#slider").data("kendoSlider").value(6);
	// } else if (val == 999) {
	// 	$("#slider").data("kendoSlider").value(7);
	// }

	if(sm.tabActive() == "sm"){
		sm.valPeriod(val);
		sm.setDate(val);
	}
});


sm.ddlOnchange = function () {
	setTimeout(function () {
		sm.isLoaded(4);
		sm.getMainBar();
	}, 1000)
}

sm.loadAll = function () {

	sm.ajaxFilter(1);
	// sm.ajaxFilter()
	filter.ajax(sm.filters(), sm.payload, sm.ajaxFilter);
	// $("#rightToggle").change(function(){
	// 	sm.renderDonutRight(sm.donutRightData());
	// });

	// $("#leftToggle").change(function(){
	// 	sm.renderDonutLeft(sm.donutLeftData());
	// });

	$("#dropDownBy").kendoDropDownList({
		dataTextField: "lable",
		dataValueField: "value",
		dataSource: sm.optionValue(),
		index: 0,
		change: sm.ddlOnchange
	});

	//   $("#periodSlider").kendoSlider({
	//       tickPlacement: "none",
	//    showButtons: false,
	//       min: 1,
	//       max: 7,
	//       smallStep: 0.1,
	//       largeStep: 1,
	//       slide: sm.moveSlider ,
	//       change : sm.changeSlider,
	// tooltip: {
	//         enabled: false
	//       },
	//   })
	sm.slider = $("#slider").kendoSlider({
		tickPlacement: "none",
		increaseButtonTitle: "Right",
		decreaseButtonTitle: "Left",
		min: 1,
		max: 7,
		smallStep: 1,
		largeStep: 1,
		// change : sm.changeSlider,
		//       slide: sm.moveSlider ,
		change: filter.changeSlider,
		value: sm.sliderValue(),
		tooltip: {
			enabled: false
		},
		increaseButtonTitle: "",
		decreaseButtonTitle: "",
		dragHandleTitle: ""
	}).data("kendoSlider");
	sm.refreshAllChart();
}

sm.changeSlider = function (e) {
	if (e.value == 1) {
		$("#term_sheet-tab > ul > li:nth-child(1) > button").click()
	} else if (e.value == 2) {
		$("#term_sheet-tab > ul > li:nth-child(2) > button").click()
	} else if (e.value == 3) {
		$("#term_sheet-tab > ul > li:nth-child(3) > button").click()
	} else if (e.value == 4) {
		$("#term_sheet-tab > ul > li:nth-child(4) > button").click()
	} else if (e.value == 5) {
		$("#term_sheet-tab > ul > li:nth-child(5) > button").click()
	} else if (e.value == 6) {
		$("#term_sheet-tab > ul > li:nth-child(6) > button").click()
	} else if (e.value == 7) {
		$("#term_sheet-tab > ul > li:nth-child(7) > button").click()
	}
}
$(document).ready(function () {
	// model.userInfo.loading.subscribe(function(n){
	// 	if(n) return
	// 	if(model.userInfo.username() != "eaciit") return sm.init(false);
	sm.isLoaded(0);
	sm.init(true);

	model.getMenuStatus.subscribe(function (nv) {
		if (!nv) return;
		filter.createAllFilter();
		filter.createAllPayload();
		sm.loadAll();
		$('.custom-tooltip').tooltipster({
			position: 'right',
			contentAsHTML: true,
	    }) 
	    $('[data-toggle=popover]').popover({
		    content: $('#myPopoverContent').html(),
		    html: true,
		    placement: 'bottom',
		}).hover(function() {
		    $(this).popover('show');
		}).on('mouseleave', function(){
			$(this).popover('hide');	
		});

		$('[data-toggle=popover-issurating]').popover({
		    content: $('#issue-rating-popover').html(),
		    html: true,
		    placement: 'bottom',
		}).hover(function() {
		    $(this).popover('show');
		}).on('mouseleave', function(){
			$(this).popover('hide');	
		});

	})
	// newme.loadAll();
	// pricet.loadAll();
	// bstation.loadAll();
	// }) 

})



sm.mainBarData2 = ko.observableArray([]);

sm.gettracebility = function () {
	var payload = $.extend(sm.defaultPayload(), {
		"volumeby": "$Industry",
		"period": sm.valPeriod()
	})
	ajaxPost("/secondarymarket/gettracebility", payload, function (res) {
		sm.isLoaded(sm.isLoaded() + 1);
		if(res.length == 0){
			sm.TotalNumberofTransactions("");
			sm.TotalTradeVolume("");
			sm.TotalNumberofSecurities("");
			sm.EarliestTransactionDate("");
			sm.LatestTransactionDate("");
			sm.TotalNumberofIssuers("");
			sm.TotalNumberofInvestors("");
			return;
		}
		var sm_indexDateFrom =  filter.getIndexFilter("issue_date_from",sm.filters());
		var sm_indexDateTo =  filter.getIndexFilter("issue_date_to",sm.filters());

		sm.filters()[sm_indexDateFrom].value(res[0].old);
		sm.filters()[sm_indexDateTo].value(res[0].new);  
		sm.dateFrom(res[0].old);
		sm.dateTo(res[0].new);

		filter.insertPayload(sm.payload, sm.filters()[sm_indexDateFrom].payload, sm.filters()[sm_indexDateFrom].value()); 
		filter.insertPayload(sm.payload, sm.filters()[sm_indexDateTo].payload, sm.filters()[sm_indexDateTo].value()); 

		var newme_indexDateFrom =  filter.getIndexFilter("issue_date_from",newme.filters());
		var newme_indexDateTo =  filter.getIndexFilter("issue_date_to",newme.filters());
 

		newme.filters()[newme_indexDateFrom].value(res[0].old);
		newme.filters()[newme_indexDateTo].value(res[0].new);  
		filter.insertPayload(newme.payload, newme.filters()[newme_indexDateFrom].payload, newme.filters()[newme_indexDateFrom].value()); 
		filter.insertPayload(newme.payload, newme.filters()[newme_indexDateTo].payload, newme.filters()[newme_indexDateTo].value()); 
		newme.dateFrom(res[0].old);
		newme.dateTo(res[0].new);

		sm.TotalNumberofTransactions(kendo.toString(res[0].trx, "n0"));
		sm.TotalTradeVolume(kendo.toString(res[0].vol, "n0"));
		sm.TotalNumberofSecurities(kendo.toString(res[0].sec, "n0"));
		sm.EarliestTransactionDate(moment(res[0].old).format("DD-MMM-YYYY"));
		sm.LatestTransactionDate(moment(res[0].new).format("DD-MMM-YYYY"));
		sm.TotalNumberofIssuers(kendo.toString(res[0].iss, "n0"));
		sm.TotalNumberofInvestors(kendo.toString(res[0].inv, "n0"));
	})
}


sm.aggregation = ko.observable("M");
sm.currency = ko.observable("BASE");
sm.currencies = ko.observableArray([]);
sm.currencyIssuance = ko.observable("");
sm.aggregation.subscribe(function(){
	sm.refreshAllChart();
});
sm.lastDate = ko.computed(function(){
	if(sm.mainBarData2() == null)  return "-";
	if(sm.mainBarData2().length == 0) return "-";
			return moment(sm.mainBarData2()[sm.mainBarData2().length - 1].maxDate).format("DD-MMM-YYYY")
})
sm.earlierDate = ko.computed(function(){

	if(sm.mainBarData2() == null) return "-";
	if(sm.mainBarData2().length == 0) return "-";
			return moment(sm.mainBarData2()[0].maxDate).format("DD-MMM-YYYY")
})
sm.currency.subscribe(function(nv){
	if(sm.currencyIssuance().length <= 1){
		if(nv == "BASE")
			var data = _.map(sm.mainBarData2(), function(d){
				d.buy = d.sumBuy;
			 	d.sell = d.sumSell;
			 	d.total = d.sumBuy + d.sumSell;
			 	return d; 
			});
		else
			var data = _.map(sm.mainBarData2(), function(d){
				d.buy = d.sumBuyCCY;
			 	d.sell = d.sumSellCCY;
			 	d.total = d.sumBuyCCY + d.sumSellCCY;
			 	return d; 
			});
		return sm.renderMainBar2(data);
	}
	sm.refreshAllChart(); 	
});
sm.renderMainBar2 = function(data){
	$("#newme_bar_main").html("");	
	if(data.length == 0) return;
	var catRotation = 0;
	var labelRotation = 0;
	if(data.length > 10){
		var catRotation = 65;
		var labelRotation = -90;
	}
	var templatetooltip = function (val) {
		return "$" + kendo.toString(val.value, "N2") + "m"
	};

	var max =_.maxBy(data, function(o) {
	  return o.total;
	});
 
	$("#newme_bar_main").kendoChart({
		theme: "flat",
		title: { 
			font: "12px Arial,Helvetica,sans-serif", 
		},
		legend: {
			visible: false,
			position: 'bottom',
		},
		chartArea: {
			width: data.length > 15 ? data.length * 150 : $(".bar-main").width() - 30,
			height: 300,
			background: "#f4f4f9",
			margin: {
				top: 0,
				left: 0,
				right: 0,
				bottom: 0
			}
		},
		dataSource: {
			data: data,
		},
		seriesDefaults: {
			type: "column",
			stack: true,
			overlay: {
				gradient: "none"
			}, 
			border: {
				width: 0
			},
			labels: {
				template: "$#= kendo.toString(value,'N0')#m",
				position: "InsideEnd",
				color: "#f4f4f9",
				margin: {
					top: 0,
				}
			},
			gap:0.2
		},
		legendItemClick: function (e) {
			sm.legendItemClick(e);
		}, 
		series: [
			{
				field: "buy",
				name: "Buy",
				color: "#FB7676",
				stack: "barCenter"
			},
			{
				field: "sell",
				name: "Buy",
				color: "#26B397",
				stack: "barCenter"
			},
			{
				field: "total",
				type:"line",
				name: "Buy",
				color: "#26B397",
				stack: "barCenter",
				color: "transparent", 
				markers: {
					size: 15,
					border: {
		              width: 3,
		              color: "#26B397"
		            },
				},  	
				tooltip:{
					background: "#fff",
					border:{
						color: "#26B397",
						width: 2
					}
				},
				labels: {
					font: "bold 12px Arial,Helvetica,sans-serif",
					visible: true,
					position: "top",
					color: "#000000",
					// rotation:labelRotation,
					template: function(e){
						return  "$" + kendo.toString(e.dataItem.total,'n0') + "m\n"+ 
								"$" + kendo.toString(e.dataItem.sell,'n0') + "m\n"+ 
								"$" + kendo.toString(e.dataItem.buy,'n0') + "m";
					}
				},
			},
		],
		categoryAxis: {
			name: "catAxis",
			
			labels: {
				font: "bold 12px Arial,Helvetica,sans-serif",
				visible: true,
				template: function(d){ 
					if(sm.aggregation() == "M")
						return moment(d.value).format('MMM-YY');
					else
						return moment(d.value).format('DD-MMM-YYYY');
				},
				rotation: catRotation,
			},

			
			field: "maxDate",
			line: {
				visible: false
			},
			majorGridLines: {
				visible: false
			}
		},
		labels: {
			font: "bold 12px Arial,Helvetica,sans-serif",
			align: "center",
			template: "#= value #",
			rotation: "auto", 
			visible: false
		},
		justified: false,
		tooltip: {
			"visible": true,
			"template": templatetooltip,
			"padding": "1px 1px 1px 1px",
			"border": "1px solid #f4f4f4",
			"background-color": "#f4f4f4",
		},
		valueAxis: {
			max: (data.length == 0) ? 0 : max.total * 1.6,
			title: {
		      text: "Total Volume (mil)",
		      margin: 15,
		      color: "#000000"
		    },
			min:0,
			name: "sales",
			labels: {
				template: "#= kendo.toString(value,'n0') #",
				color: "#0e678d",
				visible: false,
			},
			line: {
				visible: false
			},
			visible: true,
			majorGridLines: {
				visible: false
			},
		},
		render: function(){
			var gt = data.length + 3;
			$("#newme_bar_main > svg > g > g:nth-child(3) > g:gt( "+gt+" )").each(function (i, e) { 
				$(e).find("text").eq(1).attr("fill","#26B397");
				$(e).find("text").eq(2).attr("fill","#FB7676"); 
			})
		}
	});
}

sm.getMainBar2 = function(){
	var payload = $.extend( sm.defaultPayload(), {"volumeby" : "$DateInt", "period" : sm.valPeriod()} )
	payload = sm.setFilter(payload);
	payload["valueAggr"] = sm.aggregation(); 
	payload["tradingCurrency"] = sm.currency(); 
	ajaxPost("/new/getbarchart", payload, function (res){
	 sm.currencyIssuance(res.Data.currencies);
	 sm.currencies(res.Data.currencies)
	 sm.timeToShow(true);
	 sm.isLoaded(sm.isLoaded() + 1);
	 var data = _.map(res.Data.result, function(d){
	 	d.buy = d.sumBuy;
	 	d.sell = d.sumSell;
	 	d.total = d.sumBuy + d.sumSell;
	 	return d;
	 })
	 sm.renderMainBar2(data)
	 sm.mainBarData2(res.Data.result);
	})
}

 
sm.refreshAllChart = function () {
	sm.isLoaded(0);
	// sm.getMainBar();
	sm.getMainBar2();

	// sm.getTopData();
	// sm.getDonutLeft();
	// sm.getTableTopBuy();
	// sm.getTableTopSell();
	// sm.getDonutRight();
	sm.gettracebility();
	if(sm.investorBoxGrid.isLoaded())
		sm.generateDataTabInvestor();
	if(sm.securityBoxGrid.isLoaded())
		sm.generateDataTabSecurity();
	if(sm.issuerBoxGrid.isLoaded())
		sm.generateDataTabIssuer();

	// $("#top-buy").change(function () {
	// 	sm.isLoaded(sm.isLoaded() - 1);
	// 	sm.getTopData();
	// });
	// $("#top-sell").change(function () {
	// 	sm.isLoaded(sm.isLoaded() - 1);
	// 	sm.getTopData();
	// });
	// $("#top-security-buy").change(function () {
	// 	sm.isLoaded(sm.isLoaded() - 1);
	// 	sm.getTopData();
	// });
	// $("#top-security-sell").change(function () {
	// 	sm.isLoaded(sm.isLoaded() - 1);
	// 	sm.getTopData();
	// });

}
sm.dateFrom = ko.observable("");
sm.dateTo = ko.observable("")
 
sm.getTableMoreTopBuy = function () {
	var cl = $("#show-more-buy").hasClass("fa-sort-desc");
	if (cl == true) {
		$("#show-more-buy").removeClass("fa-sort-desc").addClass("fa-sort-asc")
		sm.renderTopData(sm.allDataBuy(), 5, sm.topDataConfig[0]);
	} else {
		$("#show-more-buy").removeClass("fa-sort-asc").addClass("fa-sort-desc")
		sm.renderTopData(sm.allDataBuy(), 0, sm.topDataConfig[0]);
	}
}

sm.getTableMoreTopSell = function () {
	var cl = $("#show-more-sell").hasClass("fa-sort-desc");
	if (cl == true) {
		$("#show-more-sell").removeClass("fa-sort-desc").addClass("fa-sort-asc")
		sm.renderTopData(sm.allDataSel(), 5, sm.topDataConfig[1]);
	} else {
		$("#show-more-sell").removeClass("fa-sort-asc").addClass("fa-sort-desc")
		sm.renderTopData(sm.allDataSel(), 0, sm.topDataConfig[1]);
	}
}
sm.getTableMoreTopSecuritySell = function () {
	var cl = $("#show-more-security-sell").hasClass("fa-sort-desc");
	if (cl == true) {
		$("#show-more-security-sell").removeClass("fa-sort-desc").addClass("fa-sort-asc")
		sm.renderTopData(sm.allDataSecuritySel(), 5, sm.topDataConfig[3]);
	} else {
		$("#show-more-security-sell").removeClass("fa-sort-asc").addClass("fa-sort-desc")
		sm.renderTopData(sm.allDataSecuritySel(), 0, sm.topDataConfig[3]);
	}
}
sm.getTableMoreTopSecurityBuy = function () {
	var cl = $("#show-more-security-buy").hasClass("fa-sort-desc");
	if (cl == true) {
		$("#show-more-security-buy").removeClass("fa-sort-desc").addClass("fa-sort-asc")
		sm.renderTopData(sm.allDataSecurityBuy(), 5, sm.topDataConfig[2]);
	} else {
		$("#show-more-security-buy").removeClass("fa-sort-asc").addClass("fa-sort-desc")
		sm.renderTopData(sm.allDataSecurityBuy(), 0, sm.topDataConfig[2]);
	}
}





sm.getTableTopBuySwitch = function () {
	var Toggle = "Gross"
	if ($("#top-buy").prop("checked") == false) {
		Toggle = "Net"
	}
	$("#show-more-buy").removeClass("fa-sort-desc").removeClass("fa-sort-asc").addClass("fa-sort-desc")
	var payload = $.extend(sm.defaultPayload(), {
		"order": "sumBuy",
		"period": sm.valPeriod(),
		"Toggle": Toggle
	})
	ajaxPost("/secondarymarket/gettopdata", payload, function (res) {
		sm.totalBuy(Math.abs(res.total));
		sm.isLoaded(8);
		sm.renderTableTopBuy(res.res, 0);
		sm.allDataBuy(res.res);
	})
}

sm.getTableTopSellSwitch = function () {
	var Toggle = "Gross"
	if ($("#top-Sell").prop("checked") == false) {
		Toggle = "Net"
	}
	$("#show-more-sell").removeClass("fa-sort-desc").removeClass("fa-sort-asc").addClass("fa-sort-desc")
	var payload = $.extend(sm.defaultPayload(), {
		"order": "sumSell",
		"period": sm.valPeriod(),
		"Toggle": Toggle
	})
	ajaxPost("/secondarymarket/gettopdata", payload, function (res) {
		sm.totalSell(Math.abs(res.total));
		sm.isLoaded(8);
		sm.renderTableTopSell(res.res, 0);
		sm.allDataSel(res.res);
	})
}

sm.refreshAllChartUI = function () {
	setTimeout(function () {
		try {
			$("#sm_bar_main").getKendoChart().refresh();
		} catch (e) {

		}
		try {
			$("#sm_donut_region").getKendoChart().refresh();
		} catch (e) {

		}
		try {
			$("#sm_donut_industry").getKendoChart().refresh();
		} catch (e) {

		}
	}, 500)
}

sm.calcPercentage = function (datas, field, category) {
	var sum = _.sumBy(datas, field);
	_.each(datas, function (val, idx) {
		var pct = (val[field] / sum) * 100;
		var strpct = kendo.toString(pct, "N2");
		datas[idx].pct = strpct;
		datas[idx].realpct = pct;
		datas[idx].mycategory = val[category] + "|" + strpct + "%";
	})

	datas = _.sortBy(datas, 'realpct').reverse();

	return datas;
}

sm.hideShowDonut = function (id, legend, idx) {
	idx = idx();
	$id = $(id);

	var donutChart = $id.getKendoChart();
	var visibleData = $id.getKendoChart().options.series[0].data[idx].visible;
	var colors = $id.getKendoChart().options.seriesColors;
	visibleData = visibleData == undefined ? true : visibleData;

	$id.getKendoChart().options.series[0].data[idx].visible = !visibleData
	$id.getKendoChart().redraw();

	var datas = $id.getKendoChart().options.series[0].data

	color = (!visibleData) ? colors[idx] : '#9b9898';
	lablecolor = (!visibleData) ? "#428bca" : '#9b9898';

	$(legend + " li").eq(idx).find(".square").css('background', color);
	$(legend + " li").eq(idx).find("span:eq(0)").css('color', lablecolor + "!important");
	$(legend + " li").eq(idx).find("span:eq(1)").css('color', lablecolor);
}

sm.getTextWidth = function (text, font) {
	// re-use canvas object for better performance
	var canvas = sm.getTextWidth.canvas || (sm.getTextWidth.canvas = document.createElement("canvas"));
	var context = canvas.getContext("2d");
	context.font = font;
	var metrics = context.measureText(text);
	return metrics.width;
}

sm.exportBarToPPT = function (id, filename, width) {
	var kend = $(id).getKendoChart();
	var pptx = new PptxGenJS();
	var slide = pptx.addNewSlide();
	var mydata = "";
	width = width - 0.2;
	var height = width / 2.5;
	kend.exportImage().done(function (data) {
		mydata = data;
		// console.log(data)
	});
	slide.addImage({
		data: mydata,
		w: width,
		h: height,
		y: 0.5,
		x: ((10 - width) / 2)
	});
	pptx.save(filename);
}

sm.exportDivToPPT = function (id, filename, width) {
	var pptx = new PptxGenJS();
	var slide = pptx.addNewSlide();
	var mydata = "";
	width = width - 0.2;
	var height = width * 0.7;
	kendo.drawing.drawDOM($(id))
		.then(function (group) {
			return kendo.drawing.exportImage(group);
		})
		.done(function (data) {
			mydata = data;
		});
	slide.addImage({
		data: mydata,
		w: width,
		h: height,
		y: 0.5,
		x: ((10 - width) / 2)
	});
	pptx.save(filename);
}


sm.boxGridLoading = ko.observable(0);
sm.investorBoxGrid = {
	isLoaded: ko.observable(false), 
	collapse: ko.observable(false),
	grandTotal: ko.observable({sumBuy:0,sumSell:0,totalVolume:0,transCount:0}),
	dataInvestorType: ko.observableArray([]),
	dataInvestorRegion: ko.observableArray([]),
	dataInvestorName: ko.observableArray([]),
	investortypeShowAll: ko.observable(false),
	investorregionShowAll: ko.observable(false),
	investornameShowAll: ko.observable(false),
	totalDataInvestorType: ko.observable({pct:0, vol:0, buy:0, sel:0}),
	totalDataInvestorRegion: ko.observable({pct:0, vol:0, buy:0, sel:0}),
	totalDataInvestorName: ko.observable({pct:0, vol:0, buy:0, sel:0})
};
sm.securityBoxGrid = {
	isLoaded: ko.observable(false), 
	collapse: ko.observable(false),
	dataSecurityTraded: ko.observableArray([]),
	dataSecuritySold: ko.observableArray([]),
	dataSecurityBought: ko.observableArray([]),
	securityTradedShowAll: ko.observable(false),
	securitySoldShowAll: ko.observable(false),
	securityBoughtShowAll: ko.observable(false),
	totalSecurityTraded: ko.observable({pct:0, vol:0, buy:0, sel:0}),
	totalSecuritySold: ko.observable({pct:0, vol:0, buy:0, sel:0}),
	totalSecurityBought: ko.observable({pct:0, vol:0, buy:0, sel:0})
};

 
sm.issuerBoxGrid = {
	isLoaded: ko.observable(false),
	collapse: ko.observable(false),

	dataIssueRating: ko.observableArray([]),
	dataIssueIndustry: ko.observableArray([]),
	dataIssuerType: ko.observableArray([]),
	dataYearMaturity: ko.observableArray([]), 
	
	issueRatingShowAll: ko.observable(false),
	issueIndustryShowAll: ko.observable(false),
	issuerTypeShowAll: ko.observable(false),
	yearMaturityShowAll: ko.observable(false),  
	
	totalIssueRating: ko.observable({pct:0, count:0, vol:0, buy:0, sel:0}),
	totalIssueIndustry: ko.observable({pct:0,count:0,  vol:0, buy:0, sel:0}),
	totalIssuerType: ko.observable({pct:0, count:0, vol:0, buy:0, sel:0}),
	totalYearMaturity: ko.observable({pct:0, count:0, vol:0, buy:0, sel:0})
};


sm.dataGridInvestorTotal = ko.observable({sumBuy:0,sumSell:0,totalVolume:0,transCount:0});
sm.dataGridInvestorType = ko.observableArray([]);
sm.dataGridInvestorRegion = ko.observableArray([]);
sm.dataGridInvestorName = ko.observableArray([]);
sm.totalGridInvestorType = ko.observable(0);
sm.totalGridInvestorRegion = ko.observable(0);
sm.totalGridInvestorName = ko.observable(0);


sm.dataGridSecurityTotal = ko.observable({sumBuy:0,sumSell:0,totalVolume:0,transCount:0})
sm.dataGridSecurityDed = ko.observableArray([]);
sm.dataGridSecuritySold = ko.observableArray([]);
sm.dataGridSecurityBought = ko.observableArray([]);
sm.dataGridIssueRating = ko.observableArray([]);
sm.dataGridYearMaturity = ko.observableArray([]);
sm.dataGridSecurityCurrency = ko.observable([]);

sm.totalGridSecurityDed = ko.observable(0);
sm.totalGridSecuritySold = ko.observable(0);
sm.totalGridSecurityBought = ko.observable(0);
sm.totalGridIssueRating = ko.observable(0);
sm.totalGridYearMaturity = ko.observable(0); 
sm.totalGridSecurityCurrency = ko.observable(0);



sm.dataGridIssuerTotal = ko.observable({sumBuy:0,sumSell:0,totalVolume:0,transCount:0})
sm.dataGridIssuerType  = ko.observableArray([]);
sm.dataGridIssuerIndustry = ko.observableArray([]);

sm.dataGridIssuerRegion  = ko.observableArray([]);
sm.dataGridIssuerName = ko.observableArray([]);

sm.totalGridIssuerType  = ko.observable(0);
sm.totalGridIssuerIndustry = ko.observable(0); 
sm.totalGridIssuerRegion  = ko.observable(0);
sm.totalGridIssuerName = ko.observable(0);

sm.totalYearMaturity = ko.computed(function(){
	var sumBuy = 0;
	var sumSell = 0;
	var totalVolume = 0;
	var transCount = 0; 
	var transBuy = 0;
	var transSell = 0;
	
	_.each(sm.dataGridYearMaturity(), function(d){
		sumBuy += d.sumBuy;
		sumSell += d.sumSell;
		totalVolume += d.totalVolume;
		transCount += d.transCount;
		transBuy += d.transBuy;
		transSell += d.transSell;

	});
	return {sumBuy: sumBuy, sumSell: sumSell, totalVolume: totalVolume, transCount: transCount, transBuy: transBuy, transSell: transSell} 
})

 
 

sm.generateDataTabInvestor = function(){
	var d = sm.investorBoxGrid;
	var payload = sm.defaultPayload();
	payload["TopData"] = [];
	payload["Level"] = model.userLevel();
	payload["TopData"] = [
		{
			"id": "top-buy",
			Box: "investortype",
			Toggle: "gross",
			Order: "totalVolume",
			OrderMethod: "desc"
		},
		{
			"id": "top-sell",
			Box: "investorregion",
			Toggle: "gross",
			Order: "totalVolume",
			OrderMethod: "desc"
		},
			{
			"id": "top-sell",
			Box: "investorname",
			Toggle: "gross",
			Order: "totalVolume",
			OrderMethod: "desc"
		},
	];
	payload.skip = 0;
	payload.take = 10;
	sm.boxGridLoading(sm.boxGridLoading() + 1);

	ajaxPost("/secondarymarket/gettopdata", payload, function (res) {
		sm.dataGridInvestorType(res.Data.investortype.res);
		sm.dataGridInvestorRegion(res.Data.investorregion.res);
		sm.dataGridInvestorName(res.Data.investorname.res);
		
		sm.totalGridInvestorType(res.Data.investortype.total);
		sm.totalGridInvestorRegion(res.Data.investorregion.total);
		sm.totalGridInvestorName(res.Data.investorname.total);
 

		sm.dataGridInvestorTotal(res.Data.grandtotal.res[0]);

		sm.boxGridLoading(sm.boxGridLoading() - 1);
	
	});
}
sm.generateDataTabSecurity = function(){
	var d = sm.securityBoxGrid;
	var payload = sm.defaultPayload();
	payload["TopData"] = [];
	payload["Level"] = model.userLevel();
	payload["TopData"] = [
		{
			"id": "top-buy",
			Box: "issuerating",
			Toggle: "gross",
			Order: "_id.rating_level",
			OrderMethod: "desc"
		},
		{
			"id": "top-sell",
			Box: "yearmaturity",
			Toggle: "gross",
			Order: "_id.yeartomaturity",
			OrderFlow:1,
			OrderMethod: "desc"
		},
		{
			"id": "top-buy",
			Box: "securitytraded",
			Toggle: "gross",
			Order: "totalVolume",
			OrderMethod: "desc"
		},
		{
			"id": "top-sell",
			Box: "securitysold",
			Toggle: "gross",
			Order: "sumSell",
			OrderMethod: "desc"
		},{
			"id": "top-sell",
			Box: "securitybought",
			Toggle: "gross",
			Order: "sumBuy",
			OrderMethod: "desc"
		},{
			"id": "top-sell",
			Box: "securitycurrency",
			Toggle: "gross",
			Order: "totalVolume",
			OrderMethod: "desc"
		},
	];
	payload.skip = 0;
	payload.take = 10;

	sm.boxGridLoading(sm.boxGridLoading() + 1);
	ajaxPost("/secondarymarket/gettopdata", payload, function (res) {
		sm.dataGridSecurityDed(res.Data.securitytraded.res);
		sm.dataGridSecuritySold(res.Data.securitysold.res);
		sm.dataGridSecurityBought(res.Data.securitybought.res);
		sm.dataGridIssueRating(res.Data.issuerating.res);
		sm.dataGridYearMaturity(res.Data.yearmaturity.res);	

		sm.dataGridSecurityCurrency(res.Data.securitycurrency.res);	


		sm.totalGridSecurityDed(res.Data.securitytraded.total);
		sm.totalGridSecuritySold(res.Data.securitysold.total);
		sm.totalGridSecurityBought(res.Data.securitybought.total);
		sm.totalGridIssueRating(res.Data.issuerating.total);
		sm.totalGridYearMaturity(res.Data.yearmaturity.total);

		sm.totalGridSecurityCurrency(res.Data.securitycurrency.total);


		sm.dataGridSecurityTotal(res.Data.grandtotal.res[0]); 
		sm.boxGridLoading(sm.boxGridLoading() - 1);
	});
}
sm.dataRangeTabIssuer = ko.observable(10);
sm.generateDataTabIssuer = function(){
	var d = sm.issuerBoxGrid;
	var payload = sm.defaultPayload();
	payload["TopData"] = [];
	payload["Level"] = model.userLevel();
	payload["TopData"] = [
		
		{
			"id": "top-sell",
			Box: "issuertype",
			Toggle: "gross",
			Order: "totalVolume",
			OrderMethod: "desc"
		},
		{
			"id": "top-sell",
			Box: "issuerindustry",
			Toggle: "gross",
			Order: "totalVolume",
			OrderMethod: "desc"
		},
		{
			"id": "top-sell",
			Box: "issuerregion",
			Toggle: "gross",
			Order: "totalVolume",
			OrderMethod: "desc"
		},
		{
			"id": "top-sell",
			Box: "issuername",
			Toggle: "gross",
			Order: "totalVolume",
			OrderMethod: "desc"
		},
	];
	
	payload.skip = 0;
	payload.take = 10;

	sm.boxGridLoading(sm.boxGridLoading() + 1);
	ajaxPost("/secondarymarket/gettopdata", payload, function (res) {
		if( res.Data.issuerindustry.res.length < res.Data.issuertype.res.length ){
			sm.dataRangeTabIssuer(res.Data.issuerindustry.res.length)
		}else{
			sm.dataRangeTabIssuer(res.Data.issuertype.res.length)
		}
		sm.dataGridIssuerIndustry(res.Data.issuerindustry.res);
		sm.dataGridIssuerType(res.Data.issuertype.res); 
		sm.dataGridIssuerRegion(res.Data.issuerregion.res); 
		sm.dataGridIssuerName(res.Data.issuername.res); 


		sm.totalGridIssuerIndustry(res.Data.issuerindustry.total);
		sm.totalGridIssuerType(res.Data.issuertype.total);
		sm.totalGridIssuerRegion(res.Data.issuerregion.total);
		sm.totalGridIssuerName(res.Data.issuername.total);




		sm.dataGridIssuerTotal(res.Data.grandtotal.res[0]);
		
		sm.boxGridLoading(sm.boxGridLoading() - 1);
	});
}

sm.dataShowInvestorType = ko.computed(function(){
	var totalData = (sm.investorBoxGrid.investortypeShowAll()) ?  sm.investorBoxGrid.dataInvestorType().length : 10;
	var data = [];
	var pct = 0;
	var vol = 0;
	var buy = 0;
	var sel = 0;
	for(var i=0; i<totalData; i++){
		
		if(sm.investorBoxGrid.dataInvestorType().length == i) break;
		var d =  sm.investorBoxGrid.dataInvestorType()[i];
		data.push(d);
		pct += d.percentage; 
		vol += d.totalVolume;
		buy += d.sumBuy;
		sel += d.sumSell;
	}
	sm.investorBoxGrid.totalDataInvestorType({pct: pct, vol:vol, buy:buy, sel:sel})
	return data;
});
sm.dataShowInvestorRegion = ko.computed(function(){
	var totalData = (sm.investorBoxGrid.investorregionShowAll()) ?  sm.investorBoxGrid.dataInvestorRegion().length : 9;
	var data = [];
	var pct = 0;
	var vol = 0;
	var buy = 0;
	var sel = 0;
	for(var i=0; i<totalData; i++){
		
		if(sm.investorBoxGrid.dataInvestorRegion().length == i) break;
		var d =  sm.investorBoxGrid.dataInvestorRegion()[i];
		data.push(d);
		pct += d.percentage; 
		vol += d.totalVolume;
		buy += d.sumBuy;
		sel += d.sumSell;
	}
	sm.investorBoxGrid.totalDataInvestorRegion({pct: pct, vol:vol, buy:buy, sel:sel})
	return data;
});
sm.dataShowInvestorName = ko.computed(function(){
	var totalData = (sm.investorBoxGrid.investornameShowAll()) ?  sm.investorBoxGrid.dataInvestorName().length : 9;
	var data = [];
	var pct = 0;
	var vol = 0;
	var buy = 0;
	var sel = 0;
	for(var i=0; i<totalData; i++){
		
		if(sm.investorBoxGrid.dataInvestorName().length == i) break;
		var d =  sm.investorBoxGrid.dataInvestorName()[i];
		data.push(d);
		pct += d.percentage; 
		vol += d.totalVolume;
		buy += d.sumBuy;
		sel += d.sumSell;
	}
	sm.investorBoxGrid.totalDataInvestorName({pct: pct, vol:vol, buy:buy, sel:sel})
	return data;
});


sm.dataShowSecurityTraded = ko.computed(function(){
	var totalData = (sm.securityBoxGrid.securityTradedShowAll()) ?  sm.securityBoxGrid.dataSecuritySold().length : 10;
	var data = [];
	var pct = 0;
	var vol = 0;
	var buy = 0;
	var sel = 0;
	for(var i=0; i<totalData; i++){
		
		if(sm.securityBoxGrid.dataSecurityTraded().length == i) break;
		var d =  sm.securityBoxGrid.dataSecurityTraded()[i];
		data.push(d);
		pct += d.percentage; 
		vol += d.totalVolume;
		buy += d.sumBuy;
		sel += d.sumSell;
	}
	sm.securityBoxGrid.totalSecurityTraded({pct: pct, vol:vol, buy:buy, sel:sel})
	return data;
});
sm.dataShowSecuritySold = ko.computed(function(){
	var totalData = (sm.securityBoxGrid.securitySoldShowAll()) ?  sm.securityBoxGrid.dataSecuritySold().length : 9;
	var data = [];
	var pct = 0;
	var vol = 0;
	var buy = 0;
	var sel = 0;
	for(var i=0; i<totalData; i++){
		
		if(sm.securityBoxGrid.dataSecuritySold().length == i) break;
		var d =  sm.securityBoxGrid.dataSecuritySold()[i];
		data.push(d);
		pct += d.percentage; 
		vol += d.totalVolume;
		buy += d.sumBuy;
		sel += d.sumSell;
	}
	sm.securityBoxGrid.totalSecuritySold({pct: pct, vol:vol, buy:buy, sel:sel})
	return data;
});
 


sm.tabActive.subscribe(function (nv) {

	switch (nv) {
		case "sm":
			sm.loadAll();
			break;
		case "newme":
			newme.loadAll();
			break;
		case "pricet":
			pricet.loadAll();
			break;
		case "bstation":
			bstation.loadAll();
			break;

	}
})





sm.exportexcel = function () {
	// payload = filter.createPayload(sm.filters());
	// payload["FlagExport"] = "EXCEL";
	// sm.timeToShow(false)
	// ajaxPost("/secondarymarket/gettracebility", payload, function(res){
	//     sm.timeToShow(true)
	//     redirectUrl("/static/download/"+res.Data);
	// });
	var payload = sm.defaultPayload();
	payload["FlagExport"] = "EXCEL";
	payload["TopData"] = [];
	payload["Level"] = model.userLevel();
	sm.timeToShow(false);
	_.each(sm.topDataConfig, function (d) {
		d.Toggle = "Gross";
		if ($("#" + d.id).prop("checked") == false) {
			d.Toggle = "Net";
		}
		payload["TopData"].push({
			Box: d.Box,
			Toggle: d.Toggle,
			Order: d.Order
		})
	});
	ajaxPost("/secondarymarket/gettopdata", payload, function (res) {
		sm.timeToShow(true);
		payload["FlagExport"] = "";
		redirectUrl("/static/download/" + res.Data);

	});
}