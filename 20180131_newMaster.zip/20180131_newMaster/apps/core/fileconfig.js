function paging(page){ 
	return  _.range(page.start, page.end);
}

var fc = { 
	view: ko.observable("grid"),
	listFormatFile: ko.observableArray([{text:"Horizontal Period", value:"Horizontal Period"},{text:"Vertical Period", value:"Vertical Period"}]),
	listTypeColumn: ko.observableArray([{text:"String",value:"string"},{text:"Summary",value:"Summary"},{text:"Float",value:"float"},{text:"Date",value:"date"},{text:"Period",value:"period"}]),
	listFieldMaster: ko.observableArray([]),
	listDbSql: ko.observableArray([]),
	listDateConfig: ko.observableArray([{text:"mm/dd/yyyy", value:"mm/dd/yyyy"},{text:"dd/mm/yyyy", value:"dd/mm/yyyy"},{text:"yyyy/mm/dd", value:"yyyy/mm/dd"},{text:"yyyy/dd/mm", value:"yyyy/dd/mm"}]),
	listPeriodConfig1: ko.observableArray([
											{text:"Jan", value:"Jan"},
											{text:"Feb", value:"Feb"},
											{text:"Mar", value:"Mar"},
											{text:"Apr", value:"Apr"},
											{text:"May", value:"May"},
											{text:"Jun", value:"Jun"},
											{text:"Jul", value:"Jul"},
											{text:"Aug", value:"Aug"},
											{text:"Sep", value:"Sep"},
											{text:"Oct", value:"Oct"},
											{text:"Nov", value:"Nov"},
											{text:"Dec", value:"Dec"},
											{text:"Qtr1", value:"Qtr1"},
											{text:"Qtr2", value:"Qtr2"},
											{text:"Qtr1", value:"Qtr1"},
											{text:"Qtr3", value:"Qtr3"},
											{text:"Qtr4", value:"Qtr4"},
											{text:"HF1", value:"HF1"},
											{text:"HF2", value:"HF2"},
											{text:"CM", value:"CM"} 
										]),
	listPeriodConfig2: ko.observableArray([{text:"2010", value:"10"},
											{text:"2011", value:"11"},
											{text:"2012", value:"12"},
											{text:"2013", value:"13"},
											{text:"2014", value:"14"},
											{text:"2015", value:"15"},
											{text:"2016", value:"16"},
											{text:"2017", value:"17"},
											{text:"2018", value:"18"},  
										 ]),
	listPeriodConfig3: ko.observableArray([{text:"MTD", value:"MTD"},
											{text:"YTD", value:"YTD"}]),
	listPeriodConfig4: ko.observableArray([{text:"Act", value:"Act"},
											{text:"Bud", value:"Bud"},
											{text:"Fc", value:"FC "}]),
	listPeriodConfig5: ko.observableArray([{text:"Resp", value:"Resp"},
											{text:"Ccy", value:"Ccy"}]),
	listPeriodConfigs: ko.observableArray([]),
	listMasterField: ko.observableArray([]),
	form: { 
		dbSql: ko.observable(),
		prefix: ko.observable(),
		description: ko.observable(),
		summary: ko.observable(),
		startYear: ko.observable(),
		haveValue: ko.observable(),
		excelType: ko.observable(), 
		formatFile:ko.observable(),
		totalColumn: ko.observable(), 
		details: ko.observableArray([]),
		validationDetails: ko.observable(true),
		validation: ko.observable(true),
		processDetails: ko.observable(false),
		indexErrorDetails: ko.observableArray([]),
		listIdDelete: ko.observableArray([]), 
		startYear: ko.observable(new Date(2010, 11 , 31)),
		endYear: ko.observable(new Date(2018, 11 , 31)),
	}, 
	listExpandDetails: ko.observableArray([]),
	modalDateConfig: ko.observable({}),
	modalPeriodConfig: ko.observable({}),
	loading: ko.observable(false),
	ajaxRequest: ko.observable(0)
};
 
fc.listYearPeriod =  ko.computed(function(){
	var data = [];
	for(var i= fc.form.startYear().getFullYear(); i<= fc.form.endYear().getFullYear(); i++){  
		data.push({text: i, value: i - 2000});
	}
	return data;
});
fc.pagingDetails = ko.computed(function(){
	var page = 10;
	var data = [];
	var len = (!fc.form.details().length)? 0 : Math.ceil(fc.form.details().length / page);
	for(var i=1; i<=len; i++){
		var index = i - 1;
		var start = index * page;
		var end = (i == len) ?  fc.form.details().length   : (i * page);
		data.push({
					page: index,
					start: start,
					end: end, 
				});
	} 
	return data;
})
fc.form.indexErrorDetails = ko.computed(function(){
	var r = []
	_.each(fc.form.details(), function(d,i){
		if(!d.validation()) 
			r.push(i+1);
	})
	return r
});
fc.form.validationDetails = ko.computed(function(){
	return fc.form.indexErrorDetails().length == 0;
});

fc.ajaxIsDone = function(){
	if(fc.ajaxRequest() > 0 )
		fc.ajaxRequest(fc.ajaxRequest() - 1);
}

fc.ajaxRequest.subscribe(function(n){
	if(n == 0) fc.loading(false);	
});
fc.listTypeFields =  function(currentValueHolder){
    return ko.computed(function () {
        var data = _.clone(fc.listTypeColumn()); 
   		if(currentValueHolder() == "Summary"){
   			return data;
   		}
		
		var totalSummary = 0;
		_.each(fc.form.details(), function(d,i){
	 		if(d.typefield() == "Summary"){
				fc.form.summary(i);
				totalSummary +=1;
			} 
		});
		if(totalSummary == 0){ 
			fc.form.summary(""); 
			return data;
		}
		data = _.without(data, _.findWhere(data, {
					  value: "Summary"
					}));
		return data
	}, fc);
};
fc.listUniqueMasterField = function (currentValueHolder) {
    return ko.computed(function () {
        var data = fc.listMasterField(); 
        var values = [];
       
        _.each(fc.form.details(), function(d){
        	values.push(d.fieldmaster);
        }); 
		
		values.forEach(function (eachHolder, i) {	  
			if (eachHolder == currentValueHolder) {
				return
			} 
			data = data.filter(function (d) {
				return d._id != eachHolder()
			});
		})
		return data
	}, fc)
}
fc.changePeriodField = function(value, observ, idx){	 
	var split = observ().split(" "); 
	split[idx] = value;  
	observ(split.join(" "));
}
fc.generateGridExcelType = function(){
	var editRow = kendo.template("<button type='button' class='btn command btn-success btn-flat' onclick='fc.initForm(#= e #)'>"+
									"<i class='fa fa-pencil' aria-hidden='true'></i>"+
								"</button>");


	$gridSelector = $(".grid-dataExcelType");
	$gridSelector.kendoGrid({
  		dataSource: {
         	transport: {
				read:function(option){
					var payload = {}
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost("/live/upload/getkindfile", payload , function(res){
						option.success({ Records: res.Data, Count: res.Total });
					})
	            },
	        },
		    schema: {
				data: function(data) {
					return data.Records;
				},
		  		total: "Count",
        	},
        	pageSize: 15,
	        serverPaging: true,
	        serverSorting: true,
	        serverFiltering: true,
        },
        sortable: true,
        pageable: {
          	numeric: true,
          	previousNext: true,
          	messages: {
            	display: "Showing {2} data items"
         	}
        },
		columns: [
			{
				field:"exceltype",
				title:'Excel Type'
			},{
				field:"format",
				title:'Format',  
			},{
				field:"hasvaluestr",
				title:'Have value', 
			},{
				field:"totalcolumn",
				title:"Total Column",
				  
			},{ 
				title: "Edit",
				width: 50,
				template: function(dataItem){
                    return editRow({
                    	e: JSON.stringify(dataItem),
                        exceltype: dataItem.exceltype,
                 	});
                },
                attributes: {"class": "text-center"},
                headerAttributes: {"class": "text-center"},
			}
		],
		sortable: true,
		pageable: {
			refresh: true,
			pageSizes: true,
			buttonCount: 5
		}, 
    });
} 
fc.changeTypeField = function(typefield,arr){  
	arr.splitperiod = false; 
	if(typefield == "date"){
		arr.typefieldLabel("mm/dd/yyyy");
		fc.modalDateConfig(arr);
		$modal = $("#modal-fieldDateConfig");
		$modal.modal("show");
	}else if(typefield == "period"){
		arr.splitperiod = true;
		arr.periodLabel = [ko.observable("Jan"),
							ko.observable("10"),
							ko.observable("MTD"),
							ko.observable("Act"),
							ko.observable("Resp")] 
		arr.typefieldLabel(arr.periodLabel[0]() + " " + 
							arr.periodLabel[1]() + " " + 
							arr.periodLabel[2]() + " " + 
							arr.periodLabel[3]() +" " + 
							arr.periodLabel[4]());
		
		fc.modalPeriodConfig(arr);
		$modal = $("#modal-fieldPeriodConfig");
		$modal.modal("show"); 
	}else{
		arr.typefieldLabel("");
	}
	// })
}
fc.eventChangeLabel = function(d){
	d.label.subscribe(function(n){
		if(n.trim() == "") return d.validation(false);
		return d.validation(true);
	});
} 
fc.getListColumn = function(){
	var payload ={ Filetype: fc.form.excelType() };
	ajaxPost("/live/upload/getconfigfile", payload, function (res){
		fc.form.processDetails(true)
		fc.form.details([]); 
		fc.listExpandDetails([]);
		var d = []; 
	 	_.each(res.Data, function(o, i){ 
	 		var typeFieldLabel = "";
	 		var periodLabel  = [];

	 		
			if(o.typefield == "period"){
				var period = o.field.split(" ");
				periodLabel = [ko.observable(period[0]),
									ko.observable(period[1]),
									ko.observable(period[2]),
									ko.observable(period[3]),
									ko.observable(period[4])] 
	 		  	typeFieldLabel = o.field;
			}else if(o.typefield.split("|")[1] == "date"){
				typeFieldLabel = o.typefield.split("|")[0] ;
				o.typefield = "date";
			}  
			var arr = {
				index: i,
				_id: o._id,
				exceltype: o.exceltype,
				field: o.field,
				fieldmaster: ko.observable(o.fieldmaster),
				label: ko.observable(o.label),
				order: o.order,
				splitperiod: o.splitperiod,
				typefieldLabel: ko.observable(typeFieldLabel),
				typefield: ko.observable(o.typefield),
				year: o.year, 
				periodLabel: periodLabel,
				mappingfield: ko.observable(o.mappingfield),
				validation: ko.observable(true)
			};
			
			if(o.typefield == "Summary"){
				fc.form.summary(i);
			}
			fc.listUniqueMasterField(arr.typefield)  
		 	fc.eventChangeLabel(arr);
		 	d.push(arr);
		 
		});   
		fc.form.details(d); 
		if(fc.form.details().length <= 10){
			fc.listExpandDetails([0])
		}
		fc.ajaxIsDone();
		fc.form.processDetails(false);
    })
}
fc.getMasterField = function(){
	var payload ={ Filetype: fc.form.excelType()  };
	ajaxPost("/live/upload/getmasterconfig", payload, function (res){ 	
		fc.ajaxIsDone();
		fc.listMasterField(res.Data)
    })
}
fc.getListDb  = function(){
	fc.listDbSql([]);
	ajaxPost("/live/upload/getlistdb", {}, function (res){ 
		fc.listDbSql(res.Data)
    })
}

// FORM
fc.closeForm = function(){
	fc.view("grid");
	fc.generateGridExcelType();
 
}
fc.resetForm = function(){
	with(fc.form){
		haveValue(),
		excelType(),
		formatFile(),	
		totalColumn(0),
		details([])
	} 
}
fc.saveForm = function(){
	if(fc.form.formatFile() == "Vertical Period"){ 
	 	if(String(fc.form.summary()) == "") return swal("Error","Config doesn't have a Summary Column","error");
	}

	if(!fc.form.validation()) return "";
	var totalTypFieldPeriod = 0;
	var details = _.map(fc.form.details(), function(d){
		var typefieldStr = d.typefield();
		var year = "0"
		var mappingfield = d.mappingfield();
		if(d.typefield() == "date"){
			typefieldStr = d.typefieldLabel() + "|" + d.typefield();
		}else if(d.typefield() == "period"){
			totalTypFieldPeriod += 1; 
			typefieldStr = d.typefieldLabel();
			year = "20" + d.typefieldLabel() .split(" ")[1]; 
			mappingfield = "";
		}

		return {
			exceltype: d.exceltype,
			field: d.field,
			fieldmaster: d.fieldmaster(),
			label: d.label(),
			order: d.order,
			splitperiod: d.splitperiod,
			typefield: d.typefield(),
			typefieldStr: typefieldStr,
			year: year,
			_id: d._id, 
			mappingfield: mappingfield
		};
	});
	if(fc.form.formatFile() == "Horizontal Period"){
	 	if(totalTypFieldPeriod == 0) return swal("Error","Config doesn't have a Period Column","error");
	}

  	var payload = {
		Format: fc.form.formatFile(),
		Exceltype: fc.form.excelType(),
		Dbsql: fc.form.dbSql(),
		Description: fc.form.description(),
		Prefix: fc.form.prefix(),
		HaveValue: fc.form.haveValue(),
		HaveValueStr: (fc.form.haveValue() >= 0) ? details[fc.form.haveValue()].label : "",
		DeleteColumn: fc.form.listIdDelete(),
		Details: details,
		Totalcolumn: details.length
	}  
 
 	ajaxPost("/live/upload/saveconfig",payload, function(res){
		if(res.IsError)	return swal("Error!",res.Message, "error");  
		swal("Success",res.Message, "success");
		fc.closeForm()
	});
}
fc.initForm = function(e){ 
	fc.view("form");
	fc.form.summary("");
	fc.form.formatFile(e.format);
	fc.form.dbSql(e.dbsql);
	fc.form.prefix(e.prefix);
	fc.form.excelType(e._id);
	fc.form.description(e.description);
	fc.form.totalColumn(e.totalColumn);
	fc.form.haveValue(e.hasvalue);
	fc.loading(true);
	fc.ajaxRequest(2);
	
	// $("#startYear").kendoDatePicker({
 //        start: "decade",                          
 //        depth: "decade",                           
 //        format: "yyyy"
 //    });
    // $("#endYear").kendoDatePicker({
    //     start: "decade",                          
    //     depth: "decade",                           
    //     format: "yyyy"
    // });
	
	fc.getListColumn();
	fc.getMasterField();
}

// LIST COLUMN
fc.addColumn =  function(){  
	var arr = {
		index: fc.form.details().length,
		_id: "",
		exceltype: fc.form.excelType(),
		field: "",
		fieldmaster: ko.observable(""),
		label: ko.observable("Column " + fc.form.details().length),
		order: fc.form.details().length + 1,
		splitperiod: false,
		typefield: ko.observable("string"),
		year:"",
		typefieldLabel: ko.observable(""),
		periodLabel: [],  
		mappingfield: ko.observable(""),
		validation: ko.observable(true)
	};
 	fc.eventChangeLabel(arr);
	fc.changeTypeField(arr.typefield, arr);
	fc.form.details().push(arr);
	fc.form.details.valueHasMutated(); 
	fc.expandLastPaging();
	$('.body-table').scrollTop($(".body-table table").height());
}
fc.deleteColumn = function(index, id){
	fc.loading(true); 
	if(fc.form.details()[index].typefield() == "Summary"){
		fc.form.summary("");
	}
	fc.form.listIdDelete().push(id); 
	fc.form.details().splice(index, 1); 
	fc.form.details.valueHasMutated()

 
	fc.loading(false);
}

fc.openPopUpTypeFieldConfig = function(data){
	if(data.typefield() == "date"){
		fc.modalDateConfig(data);
		$modal = $("#modal-fieldDateConfig");
		$modal.modal("show"); 	
	}else if(data.typefield() == "period"){
		fc.modalPeriodConfig(data);
		$modal = $("#modal-fieldPeriodConfig");
		$modal.modal("show"); 
	}
}
fc.expandLastPaging =  function(){
	var lastIdx = fc.pagingDetails().length - 1;
	var idx = _.indexOf( fc.listExpandDetails(), lastIdx );
	if(idx == -1)  fc.listExpandDetails().push(lastIdx);

	fc.listExpandDetails.valueHasMutated();
}
fc.expandPagingDetails = function(data){ 
	var idx = _.indexOf( fc.listExpandDetails(), data.page );
	if(idx > -1) fc.listExpandDetails().splice(idx, 1);
	else fc.listExpandDetails().push(data.page);
	fc.listExpandDetails.valueHasMutated();
}
 
fc.exportColumnToExcel =  function(){
 

	var rows = [{
		cells: [
			{ value: "Index Column" },
			{ value: "Label" },
			{ value: "Type Column" },
			{ value: "Sql Column" },
			{ value: "Field Master" },
			{ value: "Always Have Value" }
		],

	}];
	_.each(fc.form.details(), function(d,i){
		rows.push({
			cells:[
				{ value: i + 1 },
				{ value: d.label() },
				{ value: d.typefield() },
				{ value: d.mappingfield() },
				{ value: d.fieldmaster() },
				{ value: (function(){ return i == fc.form.haveValue() })() }
			]
		})
	});
	var workbook = new kendo.ooxml.Workbook({
          sheets: [
            {
              columns: [
                // Column settings (width)
                { autoWidth: true },
                { autoWidth: true },
                { autoWidth: true },
                { autoWidth: true },
                { autoWidth: true },
                { autoWidth: true }
              ],
              title: "Orders",
              rows: rows
            }
          ]
    });
    var fileName = fc.form.excelType() + "_" + "config"
	kendo.saveAs({dataURI: workbook.toDataURL(), fileName: fileName + ".xlsx"});
}
$(function(){
	fc.getListDb();
	fc.generateGridExcelType();
});