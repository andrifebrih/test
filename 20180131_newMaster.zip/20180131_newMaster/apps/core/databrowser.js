function ajaxIsDone(){
	if(dBrowser.ajaxRequest() > 0 ) return dBrowser.ajaxRequest(dBrowser.ajaxRequest() - 1);
}

var dBrowser = {
	FtypenameFile: ko.observable(""),
	listTypeNameFile: ko.observableArray([]),
	loading: ko.observable(false),
	ajaxRequest: ko.observable(0),
};
dBrowser.ajaxRequest.subscribe(function(n){
	if(n == 0) dBrowser.loading(false);	
})
dBrowser.getTypeNameFile = function(){
 	// dBrowser.FtypenameFile("cbic");
	
	ajaxPost("/live/databrowser/getfilename", {}, function (res){
		
		dBrowser.listTypeNameFile(res.Data);
		dBrowser.FtypenameFile("cbic");
		dBrowser.generateDataBrowserGrid();
	})


}
dBrowser.createGrid =  function(columns){
	var payload = {Filetype: dBrowser.FtypenameFile()}
	$gridSelector = $(".grid-dataBrowser"); 
	$gridSelector.html("");
	$gridSelector.kendoGrid({
  		dataSource: {
         	transport: {
				read:function(option){
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost("/live/upload/getdatabrowser", payload , function(res){  
						ajaxIsDone();
						option.success({ Records: res.Data, Count: res.Total });
					})
	            },
	        },
		    schema: {
				data: function(data) {
					return data.Records;
				},
		  		total: "Count",
        	},
        	pageSize: 15,
	        serverPaging: true,
	        serverSorting: true,
	        serverFiltering: true,
        },
        sortable: true,
        pageable: {
          	numeric: true,
          	previousNext: true,
          	messages: {
            	display: "Showing {2} data items"
         	}
        },
		columns:columns,
		sortable: true,
		pageable: {
			refresh: true,
			pageSizes: true,
			buttonCount: 5
		}, 
    });	
}
dBrowser.generateDataBrowserGrid = function(){ 
	var payload ={ Filetype: dBrowser.FtypenameFile() };
	ajaxPost("/live/upload/getfielddatabrowser", payload, function (res){
		ajaxIsDone();		
		var listField = _.uniq(res.Data, function(x){
							return x.field;
						});  
		var columns = [];
		_.each(listField, function(v){
			columns.push({
				field: v.field,
				title: v.label,
				width: 120,
			});
		});
		dBrowser.createGrid(columns);
	})
}
dBrowser.search = function(){
	dBrowser.loading(true);
	dBrowser.ajaxRequest(2)
	dBrowser.generateDataBrowserGrid();
}
dBrowser.exportToSqlite = function(){
	dBrowser.ajaxRequest(1);
	dBrowser.loading(true);
	var payload = { Filetype: _.first( _.where( dBrowser.listTypeNameFile(), { _id: dBrowser.FtypenameFile() } )).exceltype } 
	// console.log(payload)
		// dBrowser.FtypenameFile() };
	var fullPath = "/live/static/sqlate/";
	
	$.ajax({
        url: "/live/exportsqlate/doexportsql",
        type: 'POST',
        data: ko.mapping.toJSON(payload),
        contentType: "application/json; charset=utf-8",
      	timeout: 10000 * 60 * 60, // 60 second * 60
        success: function (data) {
            ajaxIsDone();
			// console.log(data);
			// window.open(fullPath + data.Data,'_blank');
			redirectUrl(fullPath + data.Data);
        },
        error: function (error) { 
        	alert("There was an error posting the data to the server: " + error.responseText); 
        }
    });

	// ajaxPost("/live/exportsqlate/doexportsql", payload, function (res){ 
	// 	ajaxIsDone();
	// 	redirectUrl(fullPath + res.Data);
	// });
}
$(function(){
	dBrowser.ajaxRequest(2)
	dBrowser.loading(true);
	dBrowser.getTypeNameFile();
	// dBrowser.generateDataBrowserGrid();
})