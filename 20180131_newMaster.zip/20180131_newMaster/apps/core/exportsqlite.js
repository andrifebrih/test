function stripe(index){
	if(index % 2 == 0) return "#eae8e8";
}
var exp = {
	dataFile: ko.observableArray([]), 
	intervalAjax: ko.observable(true)
};
exp.downloadStatus = function(type){
	return ko.computed(function(){
		var proccess = true;
		_.each(exp.dataFile(), function(d){
			if(d.type == type){
				_.each(d.detail, function(o){
					if(o.status == "") proccess = false;
					if(parseInt(o.status) < 100) proccess = false;
				});
			}
		});
		return proccess;
	});
}
exp.getFileName = function(){
	 
	ajaxPost("/live/upload/getfilestatus", {}, function (res){ 
		data = _.chain(res.Data)
				.groupBy('dbsql') 
				.map(function(value, key) {
					    return {
					        type: key,
					        total: value.length,
					        detail: value,
						}
				}).value();
		exp.dataFile(data); 
		var processDone = true;
		_.each(res.Data, function(d){
			// if(d.status == "") processDone = true;
			if(parseInt(d.status) < 100) processDone = false; 
		})
		exp.intervalAjax(processDone);
		if(exp.intervalAjax() == false){
			exp.interval();
		}
	});

	
}
exp.interval = function(){


	 	var interval = setInterval(function(){
			ajaxPost("/live/upload/getfilestatus", {}, function (res){
		 
				data = _.chain(res.Data)
						.groupBy('dbsql') 
						.map(function(value, key) {
							    return {
							        type: key,
							        total: value.length,
							        detail: value,
								}
						}).value();
				exp.dataFile(data);
				processDone = true;
				_.each(res.Data, function(d){
					// if(d.status == "") processDone = true;
					if(parseInt(d.status) < 100) processDone = false; 
				})
				if(processDone) clearInterval(interval);
			});  
		}, 5000);
	 
	 
}

exp.downloadSqlite =  function(id){
	var fullPath = "/live/static/sqlate/";
	redirectUrl(fullPath + id);
}
exp.exportSqlite = function(data){

	var payload = {Exceltype: data._id}
	ajaxPost("/live/exportsqlate/doexportsql", payload, function (res){
		swal("Success",res.Message, "success");
		setTimeout(function(){
			exp.getFileName();
		}, 5000);
	});
}
$(function(){
	exp.getFileName();
 
})