function refreshGrid($gridSelector){
	var grid = $gridSelector.getKendoGrid();
	if(grid == undefined) return;
	grid.dataSource.read();
	grid.refresh();
}
// function generateIcheck(){
// 	$('.checked-row input[type="checkbox"]').iCheck({
//       checkboxClass: 'icheckbox_flat-blue',
//       radioClass: 'iradio_flat-blue'
//     });
// }
var kendoTemplate = {
	progresbarGrid: kendo.template(
										'# if (percentage >= 100) { #' +
											'<div class="progress progress-md">'+
										'# } else { #' +
											'<div class="progress progress-md progress-striped active">'+
										'# } #' + 
										  	'<div class="progress-bar progress-bar-primary" style="width : #= percentage #% "></div>'+
										 '</div>'
									),
	linkErrorItemGrid: kendo.template(
										'# if (label > 0 ) { #' +
											'<a   onclick="upl.showGridErrorItem(\'#= id #\')">#= label # item</a>'+
									  	'# }else{ #'+
											'#= label # item'+
										'# } #'
									),
	checkboxGrid: kendo.template("<input type='checkbox' name='row-check' onchange='upl.checkRow(\"#= filename #\")'> "),
	checkboxAllGrid: kendo.template("<input type='checkbox' id='checkAllConfirm' onchange='upl.checkAllrow(this)'>")
}


var upl = {
	loading: ko.observable(""),
	allCheck: ko.observable(false),
	checkProcessGrid: ko.observableArray([]),
	intervalRefreshGrid: ko.observable(true),
}

upl.generateGridLogUpload = function(){
	$gridSelector = $(".grid-logUpload");
	$gridSelector.kendoGrid({
  		dataSource: {
         	transport: {
				read:function(option){
					var payload = {}
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost("/live/upload/getuploadlogdata", payload , function(res){ 
						option.success({ Records: res.Data, Count: res.Total });
					})
	            },
	        },
		    schema: {
				data: function(data) {
					return data.Records;
				},
		  		total: "Count",
        	},
        	pageSize: 15,
	        serverPaging: true,
	        serverSorting: true,
	        serverFiltering: true,
        },
        sortable: true,
        pageable: {
          	numeric: true,
          	previousNext: true,
          	messages: {
            	display: "Showing {2} data items"
         	}
        },
		columns: [
			{
				field:"filename",
				title:'File Name'
			},{
				field:"Percentage",
				title:'Progress',
				template: function(dataItem){
                    return kendoTemplate.progresbarGrid({
                        percentage: dataItem.percentage,
                 	});
                } 
			},{
				field:"filesize",
				title:"File Size",
				template:'#: kendo.toString(filesize, "n2") # MB'
			},{
				field:"itemerror",
				title:"Error Items",
				template: function(dataItem){
                    return kendoTemplate.linkErrorItemGrid({
                        id: dataItem._id,
                        label: dataItem.itemerror 
                 	});
                } 
			},{
				field:"error",
				title:"Error",
				  
			},{
				field:"uploaddate",
				title: "Upload Date",
				template:'#: kendo.toString(new Date(uploaddate), "yyyy-MM-dd")  #'
			}
		],
		sortable: true,
		pageable: {
			refresh: true,
			pageSizes: true,
			buttonCount: 5
		}, 
    });
}
upl.generateGridProcessUpload = function(){
	upl.checkProcessGrid([]);
	$gridSelector = $(".grid-processUpload");
	$gridSelector.kendoGrid({
  		dataSource: {
         	transport: {
				read:function(option){
					var payload = {}
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost("/live/upload/getlogdatareadyprocess", payload , function(res){
							option.success({ Records: res.Data, Count: res.Total });
					})
	            },
	        },
		    schema: {
				data: function(data) {
					return data.Records;
				},
		  		total: "Count",
        	},
        	pageSize: 15,
	        serverPaging: true,
	        serverSorting: true,
	        serverFiltering: true,
        },
        sortable: true,
        pageable: {
          	numeric: true,
          	previousNext: true,
          	messages: {
            	display: "Showing {2} data items"
         	}
        },
		columns:  [
			{
				headerTemplate: function(dataItem){

                    return kendoTemplate.checkboxAllGrid({
                        id : "",
                	});
                },
	            template: function(dataItem){
	              return kendoTemplate.checkboxGrid({
                        filename : dataItem.filename,
                 	});
                },
                width:25,
			},
			{
				field:"filename",
				title:'File Name'
			},{
				field:"Percentage",
				title:'Progress',
				template: function(dataItem){
                    return kendoTemplate.progresbarGrid({
                        percentage: dataItem.percentage,
                 	});
                } 
			},{
				field:"filesize",
				title:"File Size",
				template:'#: kendo.toString(filesize, "n2") # MB'
			},{
				field:"itemerror",
				title:"Error Items",
				template: function(dataItem){
                    return kendoTemplate.linkErrorItemGrid({
                        id: dataItem._id,
                        label: dataItem.itemerror
                 	});
                } 
			},{
				field:"uploaddate",
				title: "Upload Date",
				template:'#: kendo.toString(new Date(uploaddate), "yyyy-MM-dd")  #'
			}
		],
		sortable: true,
		pageable: {
			refresh: true,
			pageSizes: true,
			buttonCount: 5
		}, 
    });
}
upl.uploadFile = function(){  
	var upload = $("#uploadFile").data("kendoUpload");
    var files = upload.getFiles();
	var formData = new FormData();
	for(var i = 0; i < files.length; i++){
		formData.append("UploadFile",files[i].rawFile);
	}
	upl.loading("upload");

	$.ajax({
      	url: "/live/upload/doupload",
      	data: formData,
      	contentType: false,
      	dataType: "json",
      	timeout: 1000 * 60 * 120, // 60 second * 120
      	mimeType: 'multipart/form-data',
      	processData: false,
      	type: 'POST',
      	beforeSend: function (jqXHR, settings) {
        	if(files.length == 0){ 
        		upl.loading("");
        		swal("Error!", "Please Choose a File", "error");
        		xhr.abort();
        	}
      	},
      	success: function (res) {
      		$('.nav-tabs a[href="#logUpload"]').tab('show');
      		upl.loading("");
			var alerObj = {};
			// switch(res.Data.type){
			// 	case"":
			// 		swal({
   //    					title: "Success",  
   //  					text:  res.Message,
   //  					html: true 
   //    				});
			// 	break;
			// 	case"":
			// 	break;
			// 	case"":
			// 	break;
			// 	case"":
			// 	break;
			// }
		 
			if(res.Data == ""){
				swal({
      					title: "Success",  
    					text:  res.Message,
    					html: true 
      				}); 
			}else if(res.Data.typeerror == "Error2"){
      			swal({
      					title: "Error!",  
    					text:  res.Message,
    					html: true 
      				}); 
      		}else{	
      			swal({
      					title: "Error!",  
    					text:  res.Message + "click <a data-dismiss='modal' onclick=' swal.close();  upl.showGridErrorItem(\"" + res.Data.id +"\")'  style='cursor: pointer'>Here</a> for more details",
    					html: true 
      				});
      		}
      		$(".k-upload-files.k-reset").find("li").remove();
			refreshGrid($(".grid-logUpload"));
			// refreshGrid($(".grid-processUpload"));
      		if(!upl.intervalRefreshGrid()) upl.intrvalStopRefreshGrid();
      	},
      	error: function (jqXHR, textStatus, errorThrown) {
      	}
  	});
}
upl.intrvalStopRefreshGrid = function(){ 
	upl.intervalRefreshGrid(true);
	var interval = setInterval(function(){
		ajaxPost("/live/upload/stoprefreshdatagrid", {}, function(res){
			refreshGrid($(".grid-logUpload"));
			if(res.Data){ 
				upl.intervalRefreshGrid(false);
				clearInterval(interval);
			}
		});
	}, 5000);
}
upl.showGridErrorItem = function(idUpload){
	upl.loading("gridErrorItem");
	$modal = $("#modal-errorItem");
	$modal.modal("show");
	
	$gridSelector = $(".grid-errorItem");
	$gridSelector.html("");
	$gridSelector.kendoGrid({
  		dataSource: {
         	transport: {
				read:function(option){
					var payload = {Idupload: idUpload};
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take;
					ajaxPost("/live/upload/getmissmatchdata", payload , function(res){
						upl.loading("");
						option.success({ Records: res.Data, Count: res.Total });
					})
	            },
	        },
		    schema: {
				data: function(data) {
					return data.Records;
				},
		  		total: "Count",
        	},
        	pageSize: 10,
	        serverPaging: true,
	        serverSorting: true,
	        serverFiltering: true,
        },
        sortable: true,
        pageable: {
          	numeric: true,
          	previousNext: true,
          	messages: {
            	display: "Showing {2} data items"
         	}
        },
		columns: [
			{
				field:"excelname",
				title:'Excel Name'
			},
			{
				field:"column",
				title:'Column'
			},
			{
				field:"value",
				title:'Value'
			}
		],
		sortable: true,
		pageable: {
			refresh: true,
			pageSizes: true,
			buttonCount: 5
		}, 
    });
}
upl.checkRow = function(filename){
	var index  = _.indexOf(upl.checkProcessGrid(), filename); 
	if(index > -1) upl.checkProcessGrid().splice(index, 1);
	else upl.checkProcessGrid().push(filename);
	upl.checkProcessGrid.valueHasMutated();
}
upl.checkAllrow = function(element){ 
	upl.allCheck(!upl.allCheck());
	var dataGrid = $(".grid-processUpload").data("kendoGrid").dataSource.data();
	var checkboxes = document.getElementsByName('row-check');
	if(upl.allCheck()){
		for(var i=0; i < checkboxes.length; i++) {
			 $(checkboxes[i]).prop("checked", true);
    	}
    	dataGrid.forEach(function(d){
  			upl.checkProcessGrid().push(d.filename);
  		});
	}else{
		for(var i=0; i < checkboxes.length; i++) {
			$(checkboxes[i]).prop('checked', false);
		}
		upl.checkProcessGrid([])	 
	}
	upl.checkProcessGrid.valueHasMutated(); 
}
upl.processRow = function(){
	var payload ={
		Filename: upl.checkProcessGrid()
	};

	ajaxPost("/live/upload/temptoproduction", payload, function (res){
	
		swal("Success", res.Message, "success");
    	refreshGrid($(".grid-processUpload"));
    })
}
$(function(){
 
    $("#uploadFile").kendoUpload({multiple: false});
    upl.generateGridLogUpload();
    // upl.generateGridProcessUpload();
  
    upl.intrvalStopRefreshGrid();
})