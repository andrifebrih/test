var wa_SlsPersonChart = {
	title: "Sales Person",
	menuTitle: 'salesperson',
	pullRequest: ko.observable(0),
	loading: ko.observable(false)
};
wa_SlsPersonChart.pullRequest.subscribe(function(n){
	if(n == 0)
		return wa_SlsPerson.loading(false);
})

wa_SlsPersonChart.RenderGrid = function(url, payload, $selector){
	var $selector = $($selector).find("#grid");
	payload.Flag = "sales_person";
	var maxAllocated = 0;

	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost(url, payload, function(res){
				 		wa_SlsPersonChart.pullRequest(wa_SlsPersonChart.pullRequest() - 1);
						maxAllocated = res.Data.max;
						option.success({ Records: _.sortBy(res.Data.data, 'allocated').reverse(), Count: res.Total });
					})
	      	},
		},
		schema: {
			data: function(data) {
                return data.Records;
			},
			total: "Count",
		},
	    pageSize: 20,
		serverPaging: true,
		serverSorting: true,
		serverFiltering: true,
		},
		sortable: true,
		pageable: {
			numeric: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns: [
			{
				title: "Investor Name",
				field: "_id",
				width: 300,
			 	attributes: {
	                "class": "align-left"
	            },
	            headerAttributes: {
					"class": "align-left"
	            },
			},
			{
				title: "Firm",
				field: "firm",
				width: 100,
				attributes: {
	                "class": "align-center"
	            },
	            headerAttributes: {
	                "class": "align-center"
	            },
	            template: "#: kendo.toString(firm,'n0') #"
			},
			{
				title: "Allocation Amount",
				field: "allocated",
				attributes: {
					"class": "progressbar-cel"
				},
				headerAttributes: {
	                "class": "align-center"
	            },
				template: function(e){

					var percentage = ( maxAllocated == 0 ) ? 0 : 92 / ( maxAllocated / e.allocated );
					return  "<div class='pull-left series-bar' style='margin:2px 0;padding-top:3px;color:#fff;width: "+ percentage +"%'>"+kendo.toString(e.percentage,'n1')+"%</div>" +
							"<div class='pull-left number' style='padding-top:5px;'>" + kendo.toString(e.allocated,'n0') + "</div>";
				}
			}

		]
	});
};

wa_SlsPersonChart.generateDataViz = function() {

	var template = wa.activeProp.template();
	template.mainPage.mode('preview');
	template.mainPage.type('wa_SlsPersonChart');
	var payload = _.clone( wa.activeProp.payload() );
	var $selector = wa.activeProp.selectorPage();
	wa_SlsPersonChart.RenderGrid(
							"/widgetanalysis/getgridtransaction",
							payload,
							$selector.find(".wa_SlsPersonChart")
						);
}
wa_SlsPersonChart.Reload = function(){
    wa_SlsPersonChart.generateDataViz();
}
wa_SlsPersonChart.Close = function(){

	
	wa_SlsPersonChart.initFilter("close");
  	var template =wa.activeProp.template();
    	template.mainPage.mode("chooseData");
    	template.mainPage.type("");
}

wa_SlsPersonChart.init = function(){

	wa_SlsPersonChart.initFilter("open");
 	wa_SlsPersonChart.generateDataViz();
};
wa_SlsPersonChart.initFilter =  function(mode){
	var payload = wa.activeProp.payload();
	if(mode == "open")
		payload  = wa_SlsPersonChart.extendPayload( _.clone(payload) );
	wa.GetDataDefaultFilters(wa.activeProp.filter(), "", payload);
};

wa_SlsPersonChart.extendPayload = function(payload){
	payload["Box"] = "Sales Person";
	return payload
 	// wa_SlsPersonChart.generateDataViz();
};


