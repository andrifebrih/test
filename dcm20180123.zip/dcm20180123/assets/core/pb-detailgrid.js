
var detailGrid = {}; 
// detailGrid.prop 	= ko.observableArray([]);

detailGrid.initFormWizard =  function(){
    $('.wizard-detailGrid a[data-toggle="tab"]').on('show.bs.tab', function (e) {
        var $target = $(e.target);
        if ($target.parent().hasClass('disabled')) {
            return false;
        }
    });

    $(".wizard-detailGrid .next-step").unbind('click').click(function (e) {
        var $active = $('.wizard-detailGrid .nav-tabs li.active');
        $active.next().removeClass('disabled');
       
        $active.next().find('a[data-toggle="tab"]').click();
    });
    $(".wizard-detailGrid .prev-step").unbind('click').click(function (e) {
        var $active = $('.wizard-detailGrid .nav-tabs li.active');
       
        $active.prev().find('a[data-toggle="tab"]').click();
    });
};

detailGrid.Reset = function(){
	$(".wizard-detailGrid-inner").find("li[id='tab-tenors']").find('a[data-toggle="tab"]').click();
	$("li[id='tab-tenors']").attr("class","active");
	$("li[id='tab-ratings']").attr("class","disabled");
	$("li[id='tab-nip']").attr("class","disabled");
	$("li[id='tab-liquidity']").attr("class","disabled");
}

detailGrid.init = function(){
	detailGrid.initFormWizard();
	dgTenorDifferent.init();
	detailGrid.Reset();
}