var creditprofilev2 	= {};
creditprofilev2.loading = ko.observable(false)
creditprofilev2.maturityList = ko.observableArray([
											{value:"",text:"Maturity Profile for all Debt"},
											{value:"LOANBOND",text:"Maturity by Loans and Bonds"},
										])
creditprofilev2.maturity = ko.observable('');
creditprofilev2.title = ko.observable('');
creditprofilev2.lastPanel = ko.observable(true);
creditprofilev2.lastPanelTwo = ko.observable(true);
creditprofilev2.modalTitle = ko.observable("")
creditprofilev2.grid = function(){
}
creditprofilev2.currencyChart = function(){
	$("#chart1").kendoChart({
        chartArea: { 
            background: "#f4f4f9"
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Currency",
            data: [6977, 4154, 2439, 384]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "CNY", "USD", "HKD"],
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}
creditprofilev2.fixedFloatingChart = function(){
	$("#chart2").kendoChart({
        chartArea: {
			height:280,
			width:310
		},
		legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Fixed Vs Floating",
            data: [6976, 4346, 2630]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Floating", "Fixed"],
            majorGridLines: {
                visible: false
            },
			labels: {
				font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        	},
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}
creditprofilev2.loadBondsChart = function(){
	$("#chart3").kendoChart({
        chartArea: {
			height:280,
			width:310
		},
		legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.8,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            color: "#005C84",
        },
        series: [{
            name: "Loan Vs Bonds",
            data: [6976, 4413, 2563]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "Loan", "Bonds"],
            majorGridLines: {
                visible: false
            },
			labels: {
				font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        	},
            line:{
                visible:false
            }
        },
        tooltip: {
            visible: true,
          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}
creditprofilev2.maturityChart = function(val){
	if (val == '' || val == undefined) {
		$("#chart4").kendoChart({
	        chartArea: {
				height:280,
				width:470
			},
			legend: {
	            visible: false
	        },
	        seriesDefaults: {
	            type: "bar",
	            overlay: {
	              gradient: "none"
	            },
                gap: 0.5,
	            labels: {
	                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	                color: "#002951",
	                visible: true,
	                position:"outsideEnd",
	            },
	            color: "#005C84",
	        },
	        series: [{
	            name: "Maturity",
	            data: [2929, 1844, 1519, 684]
	        }],
	        valueAxis: {
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            },
	            labels:{
                    visible:false,
                },
                line:{
                    visible:false
                }
	        },
	        categoryAxis: {
	            categories: [">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
	            majorGridLines: {
	                visible: false
	            },
				labels: {
					font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	        	},
                line:{
                    visible:false
                }
	        },
	        tooltip: {
            visible: true,
          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
	        }
	    });
	}else{
		$("#chart4").kendoChart({
	        chartArea: {
				height:280,
				width:470
			},
			legend: {
	            visible: true,
                position: 'bottom',
	        },
	        seriesDefaults: {
                type: "bar",
                stack: true,
                overlay: {
                    gradient: "none"
                },
                gap: 0.5,
                labels: {
                    font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                    color: "#fff",
                    visible: true,
                    position:"center",
                    background: "transparent",
                },
            },
	        series: [{
                    name: "Loans",
                    data: [1908, 952, 869, 684],
                    color: "#005C84"
                }, {
                    name: "Bonds",
                    data: [1021, 892, 650, 0],
                    color: "#50d0ff"
                }],
	        valueAxis: {
	            majorGridLines: {
	                visible: false
	            },
	            minorGridLines: {
	                visible: false
	            },
	            labels:{
                    visible:false,
                },
                line:{
                    visible:false
                }
	        },
	        categoryAxis: {
	            categories: [">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
	            majorGridLines: {
	                visible: false
	            },
				labels: {
					font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	        	},
                line:{
                    visible:false
                }
	        },
	        tooltip: {
	            visible: true,
	          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	            template: "#= series.name #: #= value #"
	        }
	    });
	};
}
creditprofilev2.revenueEbitdaChart = function(){
	$("#chart5").kendoChart({
        chartArea: {
			height:280,
			width:470
		},
		legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 1517, 958],
            stack: true,
            name: "Revenue",
            color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.55, 24.46, 15.24],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
          	name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
          	majorGridLines: {
				visible: false
			},
        }, {
            name: "ebitda",
            color: "#f1f1f1",
          	visible: true,
          	labels: {
        		font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
             	step: 2,
                color: "#000"
    		},
          	majorGridLines: {
				visible: false
			},
        }],
        categoryAxis: {
            color: "#f1f1f1",
           	categories: ["FY2016A", "FY2014A", "FY2015A"],
          	labels: {
        		font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
    		},                  
          	majorGridLines: {
				visible: false
			},
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
          	font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}

creditprofilev2.expandedWidget = function(title){
    // creditprofilev2.modalTitle(title);
    // creditprofilev2.modalCurrencyChart()
    // creditprofilev2.lastPanel(true)


    if (title == 'Currency Mix of Debt'){
        creditprofilev2.title('Currency')
        creditprofilev2.modalCurrencyChart()
        creditprofilev2.lastPanel(true)
        creditprofilev2.lastPanelTwo(false)
    }else if (title == 'Fixed Rate Vs Floating Rate'){
        creditprofilev2.title('Fixed & Floating')
        creditprofilev2.modalFixedFloatingChart()
        creditprofilev2.lastPanel(false)
        creditprofilev2.lastPanelTwo(true)
    }else if (title == 'Loans Vs Bonds'){
        creditprofilev2.title('Loan & Bonds')
        creditprofilev2.modalLoadBondsChart()
    }else if (title == 'Maturity Profile for all debts'){ 
        // if(creditprofilev2.maturity() == 'LOANBOND'){
        //     creditprofilev2.title('Maturity by Loans and Bonds')
        //     creditprofilev2.modalMaturityChart()
        // creditprofilev2.lastPanel(true)
        // }else{
        // creditprofilev2.title('Maturity Profile for all Debt')
        creditprofilev2.modalMaturityChart()
        creditprofilev2.lastPanel(true)
        // }
    }else if (title == 'Revenue and ebitda'){
        creditprofilev2.title('Revenue & EBITDA')
        creditprofilev2.modalRevenueEbitdaChart()
        creditprofilev2.lastPanel(true)
    }else{
    }
    $('#expandmodal').modal('show')
}

creditprofilev2.modalCurrencyChart = function(){
    var dummyData = [
                 {
                    Category: "Total", 
                    Name: "", 
                    Value1: 1235, 
                    Value2: 961,  
                    Value3: 91,
                    Value4: 0
                },
                {
                    Category: "USD", 
                    Name: "",
                    Value1: 1235, 
                    Value2: 0,  
                    Value3: 0,
                    Value4: 0
                },
                {
                    Category: "CNY", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 961,  
                    Value3: 0,
                    Value4: 0
                }, 
                {
                    Category: "HKD", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 0,  
                    Value3: 91,
                    Value4: 0
                }, 
                 
            ];

        var series = [
            {
                categoryField:'Category',
                field : "Value1",
                type  : "bar",
                stack : true,
                data  : dummyData,
                color : "#4ba543"
            },
            {
                categoryField:'Category',
                field : "Value2",
                type  : "bar",
                stack : true,
                data  : dummyData,
                color : "#0e678d"
               
            },
            {
                categoryField:'Category',
                field : "Value3",
                type  : "bar",
                stack : true,
                data  : dummyData,
                color : "#b7b7b7",
                 labels: {
                    template: "#= stackValue #",
                    visible: true,
                    font: ds.font('10px'),
                    // color: "#0e678d",
                } 
            }, 
            {
                categoryField:'Category',
                field : "Value4",
                type  : "bar",
                stack : true,
                data  : dummyData,
                color : "#fff"
            }, 

        ]; 
    $("#chart6-1").kendoChart({
        theme: "flat",
            series:series,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 2745,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData2 = [
                {
                    Category: "Total", 
                    Name: "", 
                    Value1: 5223, 
                    Value2: 134,  
                    Value3: 69,
                    Value4: 0
                },
                {
                    Category: "CNY", 
                    Name: "",
                    Value1: 5223, 
                    Value2: 0,  
                    Value3: 0,
                    Value4: 0
                },
                {
                    Category: "USD", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 134,  
                    Value3: 0,
                    Value4: 0
                }, 
                {
                    Category: "HKD", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 0,  
                    Value3: 69,
                    Value4: 0
                }, 
                 
            ];

    var series2 = [
         {
                categoryField:'Category',
                field : "Value1",
                type  : "bar",
                stack : true,
                data  : dummyData2,
                color : "#4ba543"
            },
            {
                categoryField:'Category',
                field : "Value2",
                type  : "bar",
                stack : true,
                data  : dummyData2,
                color : "#0e678d"
               
            },
            {
                categoryField:'Category',
                field : "Value3",
                type  : "bar",
                stack : true,
                data  : dummyData2,
                color : "#b7b7b7",
                 labels: {
                    template: "#= stackValue #",
                    visible: true,
                    font: ds.font('10px'),
                    // color: "#0e678d",
                } 
            }, 
            {
                categoryField:'Category',
                field : "Value4",
                type  : "bar",
                stack : true,
                data  : dummyData2,
                color : "#fff"
            }, 

    ]; 
    $("#chart6-2").kendoChart({
        theme: "flat",
            series:series2,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 6512,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData3 = [
        {
            Category: "Total", 
            Name: "", 
            Value1: 13710, 
            Value2: 5444,  
            Value3: 605,
            Value4: 0
        },
        {
            Category: "CNY", 
            Name: "",
            Value1: 13711, 
            Value2: 0,  
            Value3: 0,
            Value4: 0
        },
        {
            Category: "USD", 
            Name: "", 
            Value1: 0, 
            Value2: 5444,  
            Value3: 0,
            Value4: 0
        }, 
        {
            Category: "HKD", 
            Name: "", 
            Value1: 0, 
            Value2: 0,  
            Value3: 605,
            Value4: 0
        }, 
    ];

    var series3 = [
         {
                categoryField:'Category',
                field : "Value1",
                type  : "bar",
                stack : true,
                data  : dummyData3,
                color : "#4ba543"
            },
            {
                categoryField:'Category',
                field : "Value2",
                type  : "bar",
                stack : true,
                data  : dummyData3,
                color : "#0e678d"
               
            },
            {
                categoryField:'Category',
                field : "Value3",
                type  : "bar",
                stack : true,
                data  : dummyData3,
                color : "#b7b7b7",
                 labels: {
                    template: "#= stackValue #",
                    visible: true,
                    font: ds.font('10px'),
                    // color: "#0e678d",
                } 
            }, 
            {
                categoryField:'Category',
                field : "Value4",
                type  : "bar",
                stack : true,
                data  : dummyData3,
                color : "#fff"
            }, 

        ]; 
    $("#chart6-3").kendoChart({
        theme: "flat",
            series:series3,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 23711,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData4 = [
         {
            Category: "Total", 
            Name: "", 
            Value1: 2437, 
            Value2: 1500,  
            Value3: 414,
            Value4: 0
        },
        {
            Category: "CNY", 
            Name: "",
            Value1: 2437, 
            Value2: 0,  
            Value3: 0,
            Value4: 0
        },
        {
            Category: "USD", 
            Name: "", 
            Value1: 0, 
            Value2: 1500,  
            Value3: 0,
            Value4: 0
        }, 
        {
            Category: "HKD", 
            Name: "", 
            Value1: 0, 
            Value2: 0,  
            Value3: 414,
            Value4: 0
        }, 
         
    ];

    var series4 = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#4ba543"
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#0e678d"
           
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#b7b7b7",
             labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        }, 
        {
            categoryField:'Category',
            field : "Value4",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#fff"
        }, 

    ]; 
    $("#chart6-4").kendoChart({
        theme: "flat",
            series:series4,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 5222,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData5 = [
        {
            Category: "Total", 
            Name: "", 
            Value1: 3624, 
            Value2: 1731,  
            Value3: 1071,
            Value4: 0
        },
        {
            Category: "CNY", 
            Name: "",
            Value1: 3624, 
            Value2: 0,  
            Value3: 0,
            Value4: 0
        },
        {
            Category: "USD", 
            Name: "", 
            Value1: 0, 
            Value2: 1731,  
            Value3: 0,
            Value4: 0
        }, 
        {
            Category: "HKD", 
            Name: "", 
            Value1: 0, 
            Value2: 0,  
            Value3: 1071,
            Value4: 0
        },  
    ];

    var series5 = [
         {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#4ba543"
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#0e678d"
           
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#b7b7b7",
             labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        }, 
        {
            categoryField:'Category',
            field : "Value4",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#fff"
        }, 

    ]; 
    $("#chart6-6").kendoChart({
        theme: "flat",
            series:series5,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 7712,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    }); //secured unsecured
    /*$("#chart6-5").kendoChart({
        chartArea: {
            height:220,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
           border:{
                width:0
            },
            // color : "url(#svg-radialgradient-darkblue-darkgreen)"
            color: "#005C84"
        },
        series: [{
            name: "Currency",
            data: [6513, 3624, 1731, 1070, 88]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", "CNY", "USD", "HKD", "MYR"],
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });*/
}
creditprofilev2.modalFixedFloatingChart = function(){
    var dummyData = [
            {
                Category: "Total", 
                Name: "", 
                Value1: 1346, 
                Value2: 941,  
                value3: 0
            },
            {
                Category: "Fixed", 
                Name: "",
                Value1: 1346, 
                Value2: 0,  
                value3: 0
            },
            {
                Category: "Floating", 
                Name: "", 
                Value1: 0, 
                Value2: 941,  
                value3: 0
            }, 
             
        ];

    var series = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData,
            color : "#0e678d",
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData,
            color : "#4ba543",
            labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData,
            color : "#fff"
        }, 

    ]; 
    $("#chart6-1").kendoChart({
        theme: "flat",
            series:series,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 2757,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
   var dummyData2 = [
                {
                    Category: "Total", 
                    Name: "", 
                    Value1: 2728, 
                    Value2: 2697,  
                    value3: 0
                },
                {
                    Category: "Fixed", 
                    Name: "",
                    Value1: 2728, 
                    Value2: 0,  
                    value3: 0
                },
                {
                    Category: "Floating", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 2697,  
                    value3: 0
                }, 
                 
            ];

    var series2 = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData2,
            color : "#0e678d",
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData2,
            color : "#4ba543",
            labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData2,
            color : "#fff"
        }, 

    ]; 
    $("#chart6-2").kendoChart({
        theme: "flat",
            series:series2,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 6510,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData3 = [
                {
                    Category: "Total", 
                    Name: "", 
                    Value1: 10248, 
                    Value2: 9915,  
                    value3: 0
                },
                {
                    Category: "Fixed", 
                    Name: "",
                    Value1: 10248, 
                    Value2: 0,  
                    value3: 0
                },
                {
                    Category: "Floating", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 9915,  
                    value3: 0
                }, 
                 
            ];

    var series3 = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData3,
            color : "#0e678d",
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData3,
            color : "#4ba543",
            labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData3,
            color : "#fff"
        }, 

        ]; 
    $("#chart6-3").kendoChart({
        theme: "flat",
            series:series3,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 24196,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData4 = [
                {
                    Category: "Total", 
                    Name: "", 
                    Value1: 2621, 
                    Value2: 1730,  
                    value3: 0
                },
                {
                    Category: "Fixed", 
                    Name: "",
                    Value1: 2621, 
                    Value2: 0,  
                    value3: 0
                },
                {
                    Category: "Floating", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 1730,  
                    value3: 0
                }, 
                 
            ];

    var series4 = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#0e678d",
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#4ba543",
            labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#fff"
        }, 

        ]; 
    $("#chart6-4").kendoChart({
        theme: "flat",
            series:series4,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 5222,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData5 = [
            {
                Category: "Total", 
                Name: "", 
                Value1: 3257, 
                Value2: 747,  
                value3: 0
            },
            {
                Category: "Fixed", 
                Name: "",
                Value1: 3257, 
                Value2: 0,  
                value3: 0
            },
            {
                Category: "Floating", 
                Name: "", 
                Value1: 0, 
                Value2: 747,  
                value3: 0
            }, 
             
        ];

    var series5 = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#0e678d",
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#4ba543",
            labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#fff"
        }, 

    ]; 
    $("#chart6-5").kendoChart({
        theme: "flat",
            series:series5,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 4805,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    //no fixed floating for chart6-6
}
creditprofilev2.modalLoadBondsChart = function(){

    var dummyData = [
                {
                    Category: "Total", 
                    Name: "", 
                    Value1: 1158, 
                    Value2: 1129,  
                    value3: 0
                },
                {
                    Category: "Bonds", 
                    Name: "",
                    Value1: 1158, 
                    Value2: 0,  
                    value3: 0
                },
                {
                    Category: "Loan", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 1129,  
                    value3: 0
                }, 
                 
            ];

        var series = [
            {
                categoryField:'Category',
                field : "Value1",
                type  : "bar",
                stack : true,
                data  : dummyData,
                color : "#4ba543"
            },
            {
                categoryField:'Category',
                field : "Value2",
                type  : "bar",
                stack : true,
                data  : dummyData,
                color : "#0e678d",
                labels: {
                    template: "#= stackValue #",
                    visible: true,
                    font: ds.font('10px'),
                    // color: "#0e678d",
                } 
            },
            {
                categoryField:'Category',
                field : "Value3",
                type  : "bar",
                stack : true,
                data  : dummyData,
                color : "#fff"
            }, 

        ]; 
    $("#chart6-1").kendoChart({
        theme: "flat",
            series:series,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 2745,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
   var dummyData2 = [
                {
                    Category: "Total", 
                    Name: "", 
                    Value1: 2801, 
                    Value2: 2624,  
                    value3: 0
                },
                {
                    Category: "Bonds", 
                    Name: "",
                    Value1: 2801, 
                    Value2: 0,  
                    value3: 0
                },
                {
                    Category: "Loan", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 2624,  
                    value3: 0
                }, 
                 
            ];

    var series2 = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData2,
            color : "#4ba543"
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData2,
            color : "#0e678d",
            labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData2,
            color : "#fff"
        }, 

    ]; 
    $("#chart6-2").kendoChart({
        theme: "flat",
            series:series2,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 6510,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData3 = [
                {
                    Category: "Total", 
                    Name: "", 
                    Value1: 10248, 
                    Value2: 9915,  
                    value3: 0
                },
                {
                    Category: "Bonds", 
                    Name: "",
                    Value1: 10248, 
                    Value2: 0,  
                    value3: 0
                },
                {
                    Category: "Loan", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 9915,  
                    value3: 0
                }, 
                 
            ];

    var series3 = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData3,
            color : "#4ba543"
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData3,
            color : "#0e678d",
            labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData3,
            color : "#fff"
        }, 

        ]; 
    $("#chart6-3").kendoChart({
        theme: "flat",
            series:series3,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 24196,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData4 = [
                {
                    Category: "Total", 
                    Name: "", 
                    Value1: 2343, 
                    Value2: 2008,  
                    value3: 0
                },
                {
                    Category: "Bonds", 
                    Name: "",
                    Value1: 2343, 
                    Value2: 0,  
                    value3: 0
                },
                {
                    Category: "Loan", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 2008,  
                    value3: 0
                }, 
                 
            ];

    var series4 = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#4ba543"
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#0e678d",
            labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData4,
            color : "#fff"
        }, 

        ]; 
    $("#chart6-4").kendoChart({
        theme: "flat",
            series:series4,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 5222,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData5 = [
            {
                Category: "Total", 
                Name: "", 
                Value1: 3257, 
                Value2: 747,  
                value3: 0
            },
            {
                Category: "Bonds", 
                Name: "",
                Value1: 3257, 
                Value2: 0,  
                value3: 0
            },
            {
                Category: "Loan", 
                Name: "", 
                Value1: 0, 
                Value2: 747,  
                value3: 0
            }, 
             
        ];

    var series5 = [
        {
            categoryField:'Category',
            field : "Value1",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#4ba543"
        },
        {
            categoryField:'Category',
            field : "Value2",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#0e678d",
            labels: {
                template: "#= stackValue #",
                visible: true,
                font: ds.font('10px'),
                // color: "#0e678d",
            } 
        },
        {
            categoryField:'Category',
            field : "Value3",
            type  : "bar",
            stack : true,
            data  : dummyData5,
            color : "#fff"
        }, 

    ]; 
    $("#chart6-5").kendoChart({
        theme: "flat",
            series:series5,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 4805,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
    var dummyData6 = [
                {
                    Category: "Total", 
                    Name: "", 
                    Value1: 3436, 
                    Value2: 3077,  
                    value3: 0
                },
                {
                    Category: "Bonds", 
                    Name: "",
                    Value1: 3436, 
                    Value2: 0,  
                    value3: 0
                },
                {
                    Category: "Loan", 
                    Name: "", 
                    Value1: 0, 
                    Value2: 3077,  
                    value3: 0
                }, 
                 
            ];

        var series6 = [
            {
                categoryField:'Category',
                field : "Value1",
                type  : "bar",
                stack : true,
                data  : dummyData6,
                color : "#4ba543"
            },
            {
                categoryField:'Category',
                field : "Value2",
                type  : "bar",
                stack : true,
                data  : dummyData6,
                color : "#0e678d",
                labels: {
                    template: "#= stackValue #",
                    visible: true,
                    font: ds.font('10px'),
                    // color: "#0e678d",
                } 
            },
            {
                categoryField:'Category',
                field : "Value3",
                type  : "bar",
                stack : true,
                data  : dummyData6,
                color : "#fff"
            }, 

        ]; 
    $("#chart6-6").kendoChart({
        theme: "flat",
            series:series6,
            legend: {
                visible: false
            },
            chartArea: {
                 height:220,
                 width:250
            },
          
            seriesDefaults: {
                overlay: {
                    gradient: "none"
                },
                gap:  0.8,
                border:{
                    width:0
                },
                 
            },
            valueAxis: {
                labels: {
                    font: ds.font('10px'),
                    color: "#0e678d",
                    visible: false,
                },
                line: {
                    visible: false
                },
                majorGridLines: {
                    visible: false
                },
                max : 7816,
            },
            categoryAxis: {
                labels: {
                    font: ds.font('10px'),
                    // color: "#0e678d",
                    visible: true,
                    background: "transparent",
                },
                majorGridLines: {
                    visible: false
                },
                line:{
                    visible: false
                }
            },
            tooltip: {
                visible: true,
                template: " #= value #"
            }
    });
}
creditprofilev2.modalMaturityChart = function(){
    $("#chart6-1").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            }, border:{
                width:0
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
           // color : "url(#svg-radialgradient-darkblue-darkgreen)"
           color: "#005C84"
        },
        series: [{
            name: "Maturity",
            data: [2287, 1272, 775, 204, 36]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-2").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
             // color : "url(#svg-radialgradient-darkblue-darkgreen)"
             color: "#005C84"
       },
        series: [{
            name: "Maturity",
            data: [5425, 2497, 1202, 884, 842]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">5Y", ">1Y, <2Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-3").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
             // color : "url(#svg-radialgradient-darkblue-darkgreen)"
             color: "#005C84"
       },
        series: [{
            name: "Maturity",
            data: [20163, 8950, 5732, 5108, 372]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-4").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
            // color : "url(#svg-radialgradient-darkblue-darkgreen)"
            color: "#005C84"
         },
        series: [{
            name: "Maturity",
            data: [4351, 2927, 660, 634, 131]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-5").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
             // color : "url(#svg-radialgradient-darkblue-darkgreen)"
             color: "#005C84"
       },
        series: [{
            name: "Maturity",
            data: [4004, 3257, 946, 454, 0]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">5Y", "<1Y", ">2Y, <5Y", ">1Y, <2Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
    $("#chart6-6").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#002951",
                visible: true,
                position:"outsideEnd",
            },
             // color : "url(#svg-radialgradient-darkblue-darkgreen)"
             color: "#005C84"
       },
        series: [{
            name: "Maturity",
            data: [6513, 2312, 1897, 1609, 695]
        }],
        valueAxis: {
            majorGridLines: {
                visible: false
            },
            minorGridLines: {
                visible: false
            },
            labels:{
                visible:false,
            },
            line:{
                visible:false
            }
        },
        categoryAxis: {
            categories: ["Total", ">2Y, <5Y", "<1Y", ">1Y, <2Y", ">5Y"],
            majorGridLines: {
                visible: false
            },
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            line:{
                visible:false
            }
        },
        tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#= value #"
        }
    });
}
creditprofilev2.modalRevenueEbitdaChart = function(){
    $("#chart6-1").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 2170],
            stack: true,
            name: "Revenue",
                 // color : "url(#svg-gradient-darkblue-darkgreen)",
                 color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 21.5],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Dec-16"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-2").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 4331],
            stack: true,
            name: "Revenue",
                 // color : "url(#svg-gradient-darkblue-darkgreen)",
                 color: "#005C84",
             labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
              
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 33.5],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Mar-17"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-3").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 3347],
            stack: true,
            name: "Revenue",
              // color : "url(#svg-gradient-darkblue-darkgreen)",
              color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                  
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 20.1],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Dec-16"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-4").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 23053],
            stack: true,
            name: "Revenue",
                     // color : "url(#svg-gradient-darkblue-darkgreen)",
                     color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
       
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 15.0],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Dec-16"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-5").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 7385],
            stack: true,
            name: "Revenue",
                    // color : "url(#svg-gradient-darkblue-darkgreen)",
                    color: "#005C84",
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
       
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.6, 18.00],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Mar-17"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
    $("#chart6-6").kendoChart({
        chartArea: {
            height:180,
            width:250
        },
        legend: {
            visible: false
        },
        seriesDefaults: {
            overlay: {
              gradient: "none"
            },
             border:{
                width:0
            },
            gap: 0.5,
        },
        series: [{
            type: "column",
            data: [2606, 7029],
            stack: true,
            name: "Revenue",
                     // color : "url(#svg-gradient-darkblue-darkgreen)",
                     color: "#005C84",
             labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
           
                background: "transparent",
                visible: true,
            },
        }, {
            type: "line",
            data: [27.55, 19.3],
            name: "EBITDA Margin",
            color: "#002951",
            axis: "ebitda"
        }],
        valueAxes: [{
            name: "revenue",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }, {
            name: "ebitda",
            color: "#f1f1f1",
            visible: true,
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                position:"insideEnd",
                step: 2,
                color: "#000"
            },
            majorGridLines: {
                visible: false
            },
        }],
        categoryAxis: {
            color: "#f1f1f1",
            categories: ["Dec-16", "Dec-16"],
            labels: {
                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                color: "#000"
            },                  
            majorGridLines: {
                visible: false
            },
            axisCrossingValue: [0, 3]
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#= value #"
        }
    });
}

creditprofilev2.expandedWidgetGrid = function(title){
    // if (title == 'summaryFinancial')
    creditprofilev2.modalTitle(title);
        // creditprofilev2.title('Summary Financials')

    $('#expandmodalgrid').modal('show')
}

creditprofilev2.maturity.subscribe(function(newValue){
	creditprofilev2.maturityChart(newValue)
})

creditprofilev2.init =  function(){
	creditprofilev2.grid()
	creditprofilev2.currencyChart()
	creditprofilev2.fixedFloatingChart()
	creditprofilev2.loadBondsChart()
	creditprofilev2.maturityChart()
	creditprofilev2.revenueEbitdaChart()
};