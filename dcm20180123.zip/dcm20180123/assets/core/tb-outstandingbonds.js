var outstandingbonds 	= {
	dataSource: ko.observableArray([]),
	total: ko.observableArray([])
};
outstandingbonds.dataSource.subscribe(function(n){
	var groups = _(n).groupBy('currency');

	var out = _(groups).map(function(g, key) {
  		return { type: key, 
           currencyTotal: _(g).reduce(function(m,x) { return m + x.size; }, 0) };
	});
	outstandingbonds.total(out);
});
outstandingbonds.createGrid =  function(){
	var payload ={
		Issuer : [ ds.issuerSelected.issuer ],
		Sort:[],
		Sizeend:dashboard.f.val.max(),
		Sizestart:dashboard.f.val.min(),
	}
	var url = "/dashboardv2/homescreen";
	$("#outStandingGrid").html("");
	$("#outStandingGrid").kendoGrid({ 
					dataSource: {
						transport: {
							read:function(option){
								payload.skip = option.data.skip;
								payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
								payload.take = option.data.take;
			                    ajaxPost(url, payload, function(res){
			                        option.success({ Records: res.Data, Count: res.Total });
			                    })
			                },
						},
						schema: {
							data: function(data) {
			                    return data.Records;
							},
							total: "Count",
						},
					    pageSize: 20,
				        serverPaging: true,
						serverSorting: true,
						serverFiltering: true,
					},
					sortable: true,
					pageable: {
						numeric: true,
						previousNext: true,
						messages: {
							display: "Showing {2} data items"
						}
					},
					columns: [
						{
							title: "Issuer Name",
							field: "issuer",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
							template: function(e){
								// console.log(e);
								return  e.issuer;
							}
						},
						{
							title: "Issue Date",
							field: "issue_date",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
						},
						{
							title: "Size (M)",
							field: "size",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
							template:  "#= kendo.toString(size,'n0') #",
						},
							{
							title: "Currency",
							field: "currency",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
						},
						{
							title: "Distribution </br> Format",
							field: "distributions_format",
							headerAttributes: {
								"class": "align-center field-ellipsis"
							},
							attributes: {
								"class": "align-center"
							},
						},
						{
							title: "Maturity Date",
							field: "maturity_date",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
						},
						{
							title: "Coupon",
							field: "coupon",
							headerAttributes: {
								"class": "align-center"
							},
							attributes: {
								"class": "align-center"
							},
							template:  "#= kendo.toString(coupon,'n3') #",
						},
						{
							title: "Issuer Ratings",
							headerAttributes: {
								"class": "align-center"
							},
							columns: [
								{
									title: "Moody",
									field: "moodys_issuer_rating",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "S&P",
									field: "sp_issuer_rating",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "Fitch",
									field: "fitch_issuer_rating",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
							]
						},
					
						{
							title: "Bid",
							headerAttributes: {
								"class": "align-center"
							},
							columns: [
								{
									title: "Price",
									field: "bid_price",
									headerAttributes: {
										"class": "align-center"
									},
									attributes: {
										"class": "align-center"
									},
									template:  "#= kendo.toString(bid_price,'n1') #",
								},
								
								{
									title: "T Spread",
									field: "bid_t_spread",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "G Spread",
									field: "bid_g_spread",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "Z Spread",
									field: "bid_z_spread ",
									attributes: {
										"class": "align-center"
									},
									headerAttributes: {
										"class": "align-center"
									}, 
								},
								{
									title: "YTM",
									field: "bid_ytm",
									headerAttributes: {
										"class": "align-center"
									},
									attributes: {
										"class": "align-center"
									},
									template:  "#= kendo.toString(bid_ytm,'n2') # %",
								},
							]
						},

					
					
					] 
				});
// };
	// ajaxPost("/dashboardv2/outstandingbond", payload, function (res){
	// 	outstandingbonds.dataSource(res.Data);
 
 //    });
};
outstandingbonds.init =  function(){
	outstandingbonds.createGrid();
};