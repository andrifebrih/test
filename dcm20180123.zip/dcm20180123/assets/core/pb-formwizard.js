var pbFormWizard = {}
pbFormWizard.pullRequest 	= ko.observable(0);
pbFormWizard.formNavTab		= ko.observableArray([
								{ title:'Instrument Type', id:'instrument' },
								{ title:'Currency', id:'currency' },
								{ title:'Tenor', id:'tenor' },
								{ title:'#Comps', id:'comp' },
								{ title:'Result', id:'result' },
							  ]);
pbFormWizard.comp 			= {
	value: ko.observable(10),
	customMax: 20,
	customMin: 11,
	customStep: 1,
	custom: ko.observable(false),
	validation: ko.observable(true),
	list: ko.observableArray(_.range(1, 11))
};
pbFormWizard.otherTransaction = {
	value: ko.observable(0),
	step: 1,
}
pbFormWizard.distribution = {
	list: ko.observableArray([{text: "Reg S",  value: "Reg S"},{text: "144A", value: "144A"}]),
	val: ko.observable("Reg S")
}
pbFormWizard.issuerRating = ko.observable();
pbFormWizard.industry = ko.observable(); 
pbFormWizard.region = ko.observable(); 
	// switch(type){
	// 	case"moody":
	// 		title = ds.issuerSelected.moodys_issuer_rating;
	// 	break;
	// 	case"sp":
	// 		title = ds.issuerSelected.sp_issuer_rating;
	// 	break;
	// 	case"fitch":
	// 		title = ds.issuerSelected.fitch_issuer_rating;
	// 	break;
	// 	default:
			;
	// }
// )

pbFormWizard.orderFilter 	= ["instrument","currency","tenor"];
pbFormWizard.filters 	= {
	instrument:{ 
		list 		: ko.observableArray([]),
		validation 	: ko.observable(false),
	},
	currency:{ 
		list 		: ko.observableArray([
						{text:"USD",value:"USD"},
						{text:"SGD",value:"SGD"},
						{text:"CNH",value:"CNH"},
						{text:"EUR",value:"EUR"}, 
					]),
		validation 	: ko.observable(false),
	},
	tenor:{	 
		list 		: ko.observableArray([
						{text:3, value:3},
						{text:5, value:5},
						{text:7, value:7},
						{text:10, value:10}, 
						{text:15, value:15},
						{text:30, value:30},
					]),
		validation 	: ko.observable(false),
	}
};
pbFormWizard.filterTemplate = ko.observableArray([]);
pbFormWizard.pullRequest.subscribe(function(newValue){
	if(newValue == 0)
		return ds.loading(false);
});

pbFormWizard.otherTransaction.value.subscribe(function(newValue){
	
	if(newValue == "")
		return pbFormWizard.otherTransaction.value(0);; 
	if(pbFormWizard.otherTransaction.value()){
		if( isNaN( parseInt( newValue ) ) ) 	
			return pbFormWizard.otherTransaction.value(0);
	 
	}else{
		return pbFormWizard.otherTransaction.value( parseInt(newValue) );
	}
});
pbFormWizard.comp.value.subscribe(function(newValue){
	if(newValue == "")
		return;

	if(pbFormWizard.comp.custom()){
		if(isNaN(parseInt(newValue))) 	
			return pbFormWizard.comp.value(pbFormWizard.comp.customMin);
		else if(parseInt(newValue) > pbFormWizard.comp.customMax)
			return pbFormWizard.comp.value(pbFormWizard.comp.customMax);
		else if(parseInt(newValue) < pbFormWizard.comp.customMin)
			return pbFormWizard.comp.value(pbFormWizard.comp.customMin);
	}else{
		return pbFormWizard.comp.value(parseInt(newValue));
	}
});
pbFormWizard.filterTemplate.subscribe(function(newValue){
	if(newValue.length == 0)
		return;
	_.map(pbFormWizard.filters, function(o){ return o.validation(true) });
	pbFormWizard.validationFilter();
});
pbFormWizard.CheckedComp = function(newValue){
	with(pbFormWizard.comp){
		custom(false);
		if(newValue == value()){
			value("");
			validation(false);
		}else{
			value(newValue);
			validation(true);
		}
	}
};
pbFormWizard.UpdateTenorCustomValue = function(operator, data, parentData){
	if(parseFloat(data.value) > parseFloat(data.max) && parseFloat(data.value) < parseFloat(data.min))
		return;

	switch(String(operator)){
		case"+":
			data.input(parseFloat(data.input()) + parseFloat(data.step));
		break;
		case"-":
			data.input(parseFloat(data.input()) - parseFloat(data.step));
		break;
	}
	var tenorMatch = _.findWhere( parentData.details(), {value : data.input()} ); 
	if(tenorMatch)
		tenorMatch.checked(true);

	data.text  = data.input();
	data.value = data.input();
};
pbFormWizard.validationFilter =  function(filters){
	
	filters = filters || [];
	if(filters.length == 0){
		filters = pbFormWizard.filterTemplate();
		pbFormWizard.filters[pbFormWizard.orderFilter[0]].validation(_.reject(filters, function(o){ return !o.checked()  }).length > 0 );
	}
	// counter = counter || 0;

	// if(counter > (pbFormWizard.orderFilter.length - 1))
	// 	return;

	// if(counter == 0){
	// 	var key = pbFormWizard.orderFilter[counter];	
	// 	pbFormWizard.filters[key].validation(_.reject(data, function(o){ return !o.checked()  }).length > 0 );
	// }

	// counter += 1;
 
	_.each(filters,function(obj,idx){
		if(!(_.has(obj),'details') || !obj.checked())
			return;

		var childKey = pbFormWizard.getChildTypeFilter(obj.type);
		if(childKey == "")
			return;
 
		var totalDetailsChecked = _.reject(obj.details(), function(o){ return !o.checked() }).length;
		if( totalDetailsChecked == 0){ 
			pbFormWizard.filters[childKey].validation(false);
 
		}else {
			pbFormWizard.validationFilter(obj.details());	
		}
	});
};
pbFormWizard.getChildTypeFilter    = function(type){
	var idx = _.indexOf(pbFormWizard.orderFilter,type);
	if(idx == -1)
		return "";
	var typeAfter = pbFormWizard.orderFilter[idx+1];
	if(typeAfter == undefined)
		return "";
	return typeAfter;
}; 
pbFormWizard.CheckedfilterTemplate = function(data){
 	var checked = data.checked(!data.checked())
	

	// sementara 
 	if(data.type == "instrument"){
 		if(checked)
 			_.each( pbFormWizard.filterTemplate(), function(o){
 				if(o.value == data.value)
 					o.checked(checked);
 				else 
 					o.checked(false);
 			})		
 	}
 	// 

	if(_.has(data,'details')){
		var childKey = pbFormWizard.getChildTypeFilter(data.type);
		if(childKey == "")
			return pbFormWizard.filterTemplate.valueHasMutated();
		if(checked)
			data.details(pbFormWizard.createFilter(childKey));
		else 				
			data.details([]);
	}
 
	return pbFormWizard.filterTemplate.valueHasMutated()
};
pbFormWizard.createFilter = function(type){
	var template = [];
	var arr = pbFormWizard.filters[type];
	 
	if(arr == undefined){
		return template;
	}else{
		arr = arr.list;
		if(arr == undefined)
			return template;
	}
	if(typeof arr == "function")
		arr = arr();
	if(!Array.isArray(arr))
		return template;
		 
	_.each(arr, function(o,i){
		obj = {
			type    : type,
			text    : o.text,
			value   : o.value,
			checked : ko.observable(false),
		};
		if(type != _.last(pbFormWizard.orderFilter)){
			obj.details 		= ko.observableArray([]); 
		}
		template.push(obj);
	});

	if(type == "tenor"){
		var objCustom = 
			{
				type    : type,
				text    : 0.5,
				value   : 0.5,
				input 	: ko.observable(0.5),
				checked : ko.observable(false),
				custom  : true,
				max     : 30,
				min 	: 0.5,
				step 	: 0.5,
			};
	 	
		template.push(objCustom);

		objCustom.input.subscribe(function(newValue){
			if(isNaN(parseFloat(newValue))) 	
				objCustom.input(objCustom.min);
			else if(parseFloat(newValue) > objCustom.max)
				objCustom.input(objCustom.max);
	 		else
	 			objCustom.input(parseFloat(newValue));
	 		
			var tenorMatch  = _.findWhere(template, { text :  objCustom.input() });   
			if(tenorMatch)
				tenorMatch.checked(true); 
			objCustom.text  = objCustom.input();
			objCustom.value = objCustom.input();
		});
	}


	return template;
};
pbFormWizard.GetInstrument =  function(){
	// var payload = {};
	// ajaxPost("/dashboard/getinstrument", payload, function (res){
		// pbFormWizard.filters.instrument.list(_.map(res, function(o){
		// 	return {text:o._id, value:o._id};
		// }));
		// pbFormWizard.filterTemplate(pbFormWizard.createFilter("instrument"));
		// pbFormWizard.pullRequest(pbFormWizard.pullRequest() - 1);
	// });
	 
	var instrument = [];
	if(ds.issuerSelected.super_industry == "Financial Services"){
		instrument = [{text:"Senior",value:"Senior"},{text:"AT1",value:"AT1"},{text:"AT2",value:"AT2"},];
	}else{
		instrument = [{text:"Senior",value:"Senior"},{text:"Perpetual",value:"Perpetual"}];
	}
	pbFormWizard.filters.instrument.list(instrument);
	pbFormWizard.filterTemplate(pbFormWizard.createFilter("instrument"));
	pbFormWizard.pullRequest(pbFormWizard.pullRequest() - 1);
};
pbFormWizard.getFilterPropertiesChecked =  function(key, type) {
	var result = [];
	var loop =  function(data ,key, type){
		_.each(data,  function(d){
			if( d.type == type && d['checked']() !== false){
				result.push( d[key] );
			}else if ( _.has(d, 'details')){
	 			loop(d.details(), key, type)
		
	 		}
	 	});	
	}
	loop(pbFormWizard.filterTemplate(), key, type)
	return result;
}

pbFormWizard.ClickTabFormWizard = function(tab){
	// priceBond.disabledEventTab(true);
	priceBond.tab("formWizard");
	$(".wizard-inner").find("li[id='tab-"+tab+"']").find('a[data-toggle="tab"]').click();
}
pbFormWizard.initFormWizard =  function(){
    $('a[data-toggle="tab"]').on('show.bs.tab', function (e) {  
        var $target = $(e.target);
        if ($target.parent().hasClass('disabled')) {
   			return false;
        }else{
        	if($target.parent().attr("id") == "tab-result"){
        		return priceBond.ChangeTab("grid");
        	}
        }
    });

    $(".wizard .next-step").unbind('click').click(function (e) {
       
        var $active = $('.wizard .nav-tabs li.active');
        $active.removeClass("active").addClass("checked").next().removeClass('disabled');
  	
  		$active.next().find('a[data-toggle="tab"]').click();
    });
    		
    $(".wizard .prev-step").unbind('click').click(function (e) {
        var $active = $('.wizard .nav-tabs li.active');
        $active.removeClass("active").addClass("checked");
        
        $active.prev().find('a[data-toggle="tab"]').click();
    });
};
pbFormWizard.Reset = function(){

	$(".wizard .wizard-inner ul li").each(function (idx){
		if(idx == 0){ 
			$(this).attr("class","active");
		}else{
			$(this).attr("class","disabled");
		}
	});
	$(".wizard .tab-content .tab-pane").each(function (idx){
	
		if(idx == 0){ 
			$(this).attr("class","tab-pane active");
		}else{
			$(this).attr("class","tab-pane");
		}
	});
 
	pbFormWizard.filterTemplate([]);
 	pbFormWizard.comp.validation(false); 
 	pbFormWizard.comp.custom(false);
 	pbFormWizard.comp.value(10);
};
pbFormWizard.init = function(){
	ds.breadcrumb([ {title:'Dashboard',event:ds.ChangeTab,tab:'Dashboard' }, {title: ds.alias(),event:priceBond.ChangeTab, tab:'home' }, {title:'Client Search'}]);
	pbFormWizard.Reset();
	ds.loading(true);
	pbFormWizard.pullRequest(1);
	pbFormWizard.initFormWizard();
	pbFormWizard.GetInstrument();

	pbFormWizard.issuerRating( ds.issuerSelected.moodys_issuer_rating + '/' + ds.issuerSelected.sp_issuer_rating + '/' + ds.issuerSelected.fitch_issuer_rating);
	pbFormWizard.region( ds.issuerSelected.region);
	pbFormWizard.industry( ds.issuerSelected.industry);

};