var wa_IChart = {
	f:{
		defaultTypes: ['Contains', 'Equals'],
		data:ko.observableArray([]),
		val:{
	  		Action: ko.observable("Contains"),
	  		Text: ko.observable(""),
	  		Textmulti: ko.observableArray([]),
		}
	},
};
wa_IChart.f.val.Action.subscribe(function(n){
	if(n == "Contains"){
		wa_IChart.f.val.Textmulti([]);
	}
	wa_IChart.f.val.Text("");
});
wa_IChart.createDonut =  function($selcPage, payload){

};
wa_IChart.createGrid =  function($selcPage, payload){

};
wa_IChart.Generate = function(e){
	e.mainPage.mode('preview');
	e.mainPage.type('wa_IChart');
	var p = wa_IChart.extendPayload( _.clone(e.payload) );
	var $selectorPage = wa.getSelectorPage();
	wa_IChart.createDonut($selectorPage, p);
	wa_IChart.createDonut($selectorPage, p);
	wa_IChart.createDonut($selectorPage, p);
	wa_IChart.createGrid($selectorPage, p);
}

wa_IChart.ResetFilter =  function(){
	with(wa_IChart.f.val){
		Action("Contains");
		Text("");
		Textmulti([]);
	}	
}
wa_IChart.Reload = function(e){
	wa.reloadFilterMainPage( e.mainPage.filter, wa_IChart.f.val );
	wa_IChart.Generate(e);
}
wa_IChart.Close =  function(e){	
	e.mainPage.mode('preview');
	e.mainPage.type('wa_IChart');

	wa.getDataFilter(e.filter, wa.getKeysFilter( e.mainPage.type() ), e.payload, 'create chart' ); 
}

wa_IChart.Init =  function(e, action){
	action = action || "";
	if(action == "submit"){
		wa.getDataFilter(e.filter, wa.getKeysFilter( e.mainPage.type() ), wa_IChart.extendPayload( _.clone( e.payload ) ), 'create chart' ); 
		wa.reloadFilterMainPage( wa_IChart.f.val, e.mainPage.filter);
		wa_IChart.Generate(e);
		return;
	}
	wa_IChart.ResetFilter();
	$("#wa_IChartModal").modal("show");
}
wa_IChart.extendPayload = function(payload){
	_.each(wa_IChart.payload, function(p,i){
		var value = p
		if(typeof p == "function"){
			value = p();
		}
		payload[ i ] = value;
	});
  	return payload;
}