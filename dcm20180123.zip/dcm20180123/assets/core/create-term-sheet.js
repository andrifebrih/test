var createTermSheet = {
	pullRequest: ko.observable(0),
	loading: ko.observable(false),
	tabRatting: ko.observable(true),
	openStatus: ko.observable(false),
	bidType: ko.observable(""),
	changeBidType: ko.observable(false),
	titleModal: ko.observable("Choose  basis for further calculations"),
	tenor: {
		syndicateTabel: ko.observableArray([]),
		trendingCurve: ko.observableArray([]),
		titleBasis: ko.observable("Benchmark Spread (bps)"),
		basis: ko.observableArray(),
		tenorList: ko.observableArray([]),
		checkeds: ko.observableArray([]),
		manualInput: ko.observableArray([]),
		ytm: ko.observable(),
		tenorDifferetial: ko.observableArray([]),
	},
	issuenze: {
		currency: ko.observable("USD"),
		issueSize: ko.observable(0),
		liquityPerm: ko.observable(0)
	},
	premium: {
		checked: ko.observable(false),
		value: ko.observable(0) 
	},
	ratting: {
		issuerMoody: ko.observable(""),
		issuerSp: ko.observable(""),
		issuerFitch: ko.observable(""),
		
		basisMoody: ko.observable(""),
		basisSp: ko.observable(""),
		basisFitch: ko.observable(""),

		sugested: ko.observable(),
		checked: ko.observable(true),
		manualInput: ko.observable()
	},
	finish: {
		value: ko.observable('Range'),
		range: ko.observableArray(_.range(10,50)),
		rangeValue: ko.observable(10),
	}
};
createTermSheet.openGridSyndicateTable = function(){
	$("#modal-create-term").modal('hide');
	$("#modal-grid-tenor-sheetTerm").modal('show');
	
	$("#grid-tenor-sheetTerm").find(".contentGrid").html("");
	ajaxPost("/pricebond/getdatagridslope", {}, function(res){
	 
		if(res.IsError)
			return;
		$("#grid-tenor-sheetTerm").find(".contentGrid").kendoGrid({
			dataSource: {
                data:res.Data,
                pageSize: 20,
            },
            height: 300,
            sortable: true,
            pageable: true,
            columns: [{
                field: "B1",
                title: "B1"
            },{
                field: "B2",
                title: "B2",
            },{
                field: "B3",
                title: "B3",
            },{
                field: "B4",
                title: "B4",
            },{
                field: "B5",
                title: "B5",
            },{
                field: "B6",
                title: "B6",
            },{
                field: "B7",
                title: "B7",
            },{
                field: "fromyear",
                title: "Form Year"
            },{
                field: "toyear",
                title: "To Year"
            }]
		});
	});
	$("#modal-grid-tenor-sheetTerm").find('button[aria-label="Close"]').click(function(e){
		$("#modal-create-term").modal('show');
	})
}
createTermSheet.openChartTradingCurve = function(){
	$("#modal-create-term").modal('hide');
	$("#modal-chart-tenor-sheetTerm").modal('show');
	var chartData = pbGrid.gridTemplateFirst().chartData;	
	var series = dgTenorDifferent.createSeriesChart('chart-tenor-sheetTerm', chartData.circle, chartData.line)
	setTimeout(function(){	
		dgTenorDifferent.createChart('chart-tenor-sheetTerm',series,false);
	},1000);
	$("#modal-chart-tenor-sheetTerm").find('button[aria-label="Close"]').click(function(e){
		$("#modal-create-term").modal('show');
	});
}
createTermSheet.bidProp = ko.computed(function(){
	switch(createTermSheet.bidType()){
		case"bid_ytm":
			return { 
					title:"Bid YTM", 
					titleRelativeChart:"Bench YTM", 
					key:"Bidytm", 
					val: pbGrid.rowBasis().Bidytm,
					titleTenorTab: "Yield",
					valTenorTab: ( parseFloat( pbGrid.rowBasis().Bidytm ) / parseFloat( 100 ) ).toFixed(2) + "%"
				};
		break;
		case"bid_z_spread":
			return {
					title:"Bid Spread Z", 
					titleRelativeChart:"Bench Z", 
					key:"Bidzspread", 
					val: _.clone( pbGrid.rowBasis().Bidzspread ),
					titleTenorTab: "Z Spread",
					valTenorTab:  pbGrid.rowBasis().Bidzspread 
				};
		break;
		case"bid_g_spread":
			return { 
					title:"Bid Spread G", 
					titleRelativeChart:"Bench G",  
					key:"Bidgspread", 
					val: pbGrid.rowBasis().Bidgspread ,
					titleTenorTab : "G Spread",
					valTenorTab:   pbGrid.rowBasis().Bidgspread
				};
		break;
		default:
			return { 
					title:"", 
					titleRelativeChart:"",  
					key:"", 
					val:0,
					titleTenorTab : "",
					valTenorTab: 0
				};
	}
});

createTermSheet.validationBidType = ko.computed(function(){  return ( createTermSheet.bidType() != "" ); });
createTermSheet.tenor.validation = ko.computed(function(){
	var found =  true;
	_.each(createTermSheet.tenor.checkeds(), function(o){
		if(!found)
			return;
		if(!o())
			found = false;
	})
	return found;
});
createTermSheet.issuenze.validation = ko.computed(function(){ return (createTermSheet.issuenze.issueSize() > 0); });
createTermSheet.premium.validation = ko.computed(function(){ return true; });
createTermSheet.finish.validation = ko.computed(function(){ return true; });

createTermSheet.bidType.subscribe(function(n){ return createTermSheet.changeBidType(true); }); 

createTermSheet.pullRequest.subscribe(function(n){
	if(n > 0)
		return;

	createTermSheet.loading(false);
	createTermSheet.openStatus(true);
});

createTermSheet.sameIssuer = function(){ return (ds.issuerSelected.issuer == pbGrid.rowBasis().Issuer); };
createTermSheet.checkedTenor = function(data){


	with(data){
		createTermSheet.tenor.syndicateTabel()[index].checked(false);
		createTermSheet.tenor.trendingCurve()[index].checked(false);
		createTermSheet.tenor.manualInput()[index].checked(false);
		checked(true)
		createTermSheet.tenor.checkeds()[index](type);
	};
	return true;
};
createTermSheet.setFilterRatting  = function(){
	with(createTermSheet.ratting){
		issuerMoody(ds.issuerSelected.moodys_issuer_rating);
		issuerSp(ds.issuerSelected.sp_issuer_rating);
		issuerFitch(ds.issuerSelected.fitch_issuer_rating);
		
		var rowBasis = pbGrid.rowBasis(); 
		basisMoody(rowBasis.Moodysissuerating);
		basisSp(rowBasis.Spissuerating);
		basisFitch(rowBasis.Fitchissuerrating);
	};
}
createTermSheet.setFilterTenor = function(){
	
	var template = pbGrid.gridTemplateFirst();
	var tenorList = [];
	var checkeds = [];
	var manualInput = [];

	_.each(template.tenors(), function(o,i){
		tenorList.push(o);
		checkeds.push(ko.observable(false));
		manualInput.push( { index:i, tenor: o, value : ko.observable(0), type: 'manualInput', checked:ko.observable(false) } );
	});

	createTermSheet.tenor.tenorList(tenorList);
	createTermSheet.tenor.checkeds(checkeds);
	createTermSheet.tenor.manualInput(manualInput);
	createTermSheet.tenor.basis(pbGrid.rowBasis()[createTermSheet.bidProp().key].toFixed(1));
	createTermSheet.tenor.titleBasis(createTermSheet.bidProp().title);
	
};
createTermSheet.PrepareTabTenor = function(){
 
	if(!createTermSheet.changeBidType())
		return;

	createTermSheet.loading(true);
	createTermSheet.pullRequest(3);

	var template = pbGrid.gridTemplateFirst();
	var payload       =  {
		Tenor: customPayloadTenor(template.payload.Tenor),
		Ranking: template.payload.Ranking,
		Currency: template.payload.Currency,
		Comp: template.payload.Comp,
		issuer: [],
		Country: ds.issuerSelected.country,
		Industry: ds.issuerSelected.industry,
		Spissuerating: ds.issuerSelected.sp_issuer_rating, 
		Moodysissuerating: ds.issuerSelected.moodys_issuer_rating,
		Fitchissuerrating: ds.issuerSelected.fitch_issuer_rating,		
		Product: ds.issuerSelected.product,
		Region: ds.issuerSelected.region,
		Superindustry: ds.issuerSelected.super_industry,
		Bucket: ds.issuerSelected.bucket,
		Ownership: ds.issuerSelected.ownership,
		Typevalue: createTermSheet.bidType()
	};

	var tenorDifferetial = []
	_.each(pbGrid.gridTemplateFirst().payload.Tenor, function(d){
		tenorDifferetial.push( Math.abs( ( parseFloat( pbGrid.rowBasis().Yearsmaturity ) - parseFloat( d ) ).toFixed(1) )  )
	})
	createTermSheet.tenor.tenorDifferetial(tenorDifferetial);

	ajaxPost("/pricebond/gettenordifferential" , payload , function(res){
		if(res.IsErrors)
			return;
		var circelData = res.Data.DataSource;
		
		var payloadQuerySlope = _.clone(payload); 
		payloadQuerySlope.Tenor = customPayloadTenor(template.payload.Tenor);
		payloadQuerySlope.Tenorx = _.pluck(_.clone(circelData), 'x').sort();
		payloadQuerySlope.Typevalue = createTermSheet.bidType();

		ajaxPost("/dashboard/queryslope", payloadQuerySlope, function (resQuerySlope){
			var lineDatas = resQuerySlope.Data;
			_.each(circelData, function(circle){
				circle.Spread = 0
				var gridData = _.filter(resQuerySlope.GridData, function(o){ if(circle.x >= o.IncStart && circle.x < o.Inc) return o  })[0];				
				if(gridData != undefined || _.has(gridData, 'Spread'))
					circle.Spread = gridData.Spread;
			});

			template.spread(resQuerySlope.GridData);
			template.chartData.line = lineDatas;
			// var newCircleData = []
			// if(createTermSheet.bidProp().title == "Bid YTM"){
			//  	_.each(circelData, function(o){
			//  		o.y = o.y / 100;
			//  		newCircleData.push(o);
			//  	});
			// }else{
			// 	newCircleData = circelData;			
			// }
			// console.log(newCircleData);
			template.chartData.circle = circelData;

			createTermSheet.setFilterTenor();
			createTermSheet.GetTenorTrendingCurve();
			createTermSheet.GetTenorSyndicate();
			createTermSheet.changeBidType(false);
			createTermSheet.pullRequest(createTermSheet.pullRequest() - 1);
		});
	});
};
createTermSheet.GetTenorTrendingCurve = function(){
	var gridFirstTemplate = pbGrid.gridTemplateFirst();
	var rowBasis = pbGrid.rowBasis();
	
	var payload = {
		Tenor 				: gridFirstTemplate.payload.Tenor,
		Yearsmaturitybasis 	: rowBasis.Yearsmaturity,
		Valuebasis 			: rowBasis[createTermSheet.bidProp().key],
		GridData 			: gridFirstTemplate.spread, 
		Valuetype 			: createTermSheet.bidProp().key
	};
	
	ajaxPost("/dashboard/termsheet",payload, function(res){
		if(res.IsError)
			return "";
		var arr = [];
		_.each(res.Data, function(o,i){
			arr.push({ 
						index   : i,
						tenor 	: o.tenor,
						value 	: ko.observable(o.result.toFixed(2)), 
						checked : ko.observable(false),
						type 	: 'trending' 
					});
		});

		createTermSheet.tenor.trendingCurve(arr);
		createTermSheet.pullRequest(createTermSheet.pullRequest() - 1);
	});
};
createTermSheet.GetTenorSyndicate = function(){
	var gridFirstTemplate = pbGrid.gridTemplateFirst();
	var rowBasis = pbGrid.rowBasis();
	
	var payload = {
		Tenor: gridFirstTemplate.payload.Tenor,
		Yearsmaturitybasis: rowBasis.Yearsmaturity,
		Valuebasis: rowBasis[createTermSheet.bidProp().key],
		Bucket: ds.issuerSelected.bucket
	};
	
	ajaxPost("/dashboard/termsheetsyndicate",payload, function(res){
		if(res.IsError)
			return "";
		var arr = [];
		_.each(res.Data, function(o,i){
			arr.push({ 
						index: i,
						tenor: o.tenor,
						value: ko.observable(o.result.toFixed(2)), 
						checked: ko.observable(false),
						type: 'syndicate' 
					});
		});
		
		createTermSheet.tenor.syndicateTabel(arr);
		createTermSheet.pullRequest(createTermSheet.pullRequest() - 1);
	});
};
createTermSheet.GetSugestedRating = function(){
	createTermSheet.ratting.sugested(0);
	var payload ={
		Moodyrating : createTermSheet.ratting.issuerMoody(),
		Sprating 	: createTermSheet.ratting.issuerSp(),
		Fitchrating : createTermSheet.ratting.issuerFitch(),

		Moodybasis 	: createTermSheet.ratting.basisMoody(),
		Spbasis 	: createTermSheet.ratting.basisSp(),
		Fitchbasis 	: createTermSheet.ratting.basisFitch(),
	};
	if(createTermSheet.sameIssuer())
		return createTermSheet.pullRequest(createTermSheet.pullRequest() - 1);

	ajaxPost("/dashboard/ratingdifferential", payload, function (res){
 		createTermSheet.ratting.sugested(res.Data);
 		createTermSheet.pullRequest(createTermSheet.pullRequest() - 1);
    });
};
createTermSheet.Reset = function(){
	createTermSheet.openStatus(false);
	createTermSheet.bidType("");
	createTermSheet.changeBidType(false);
	with(createTermSheet.tenor){
		syndicateTabel([]);
		trendingCurve([]);
	};
	with(createTermSheet.issuenze){
		currency("USD");
		issueSize(0);
		liquityPerm(0);
	};
	with(createTermSheet.premium){
		checked(false);
		value(0);
	};
	with(createTermSheet.ratting){
		issuerMoody(""),
		issuerSp(""),
		issuerFitch(""),
		basisMoody(""),
		basisSp(""),
		basisFitch(""),
		sugested(),
		checked(true),
		manualInput()
	};
	with(createTermSheet.finish){
		value('Range'),
		rangeValue(10)
	}
};

createTermSheet.getTitleModal =  function(idName){
	switch(idName){
		case"tab-bidType":
			return createTermSheet.titleModal("Choose  basis for further calculations");
			break;
		case"tab-tenor":
			return createTermSheet.titleModal("Calculating Tenor Adjustment on "+ createTermSheet.bidProp().titleTenorTab +" Vs Base Comp");
			break;
		case"tab-ratings":
			return createTermSheet.titleModal("Calculating Liquidity Premium");
			break;
		case"tab-premium":
			return createTermSheet.titleModal("Calculating NIC");
			break;
		case"tab-ratting":
			return createTermSheet.titleModal("Rating Differential");
			break;
		case"tab-finish":
			return createTermSheet.titleModal("Finish to Create Term Sheet"); 
			break;
	}

}
createTermSheet.initFormWizard	  = function(){
	createTermSheet.getTitleModal("tab-bidType");
    $('.wizard-modal-createTerm a[data-toggle="tab"]').on('show.bs.tab', function (e) {
        var $target = $(e.target);
        if ($target.parent().hasClass('disabled')) {
            return false;
        }
    });

    $(".wizard-modal-createTerm .next-step").unbind('click').click(function (e) {
        var $active = $('.wizard-modal-createTerm .nav-tabs li.active');

        if(createTermSheet.sameIssuer() == true && $active.next().attr("id") == 'tab-ratting'){
       		$active = $active.next(); 
       	}
       
       	if( parseInt( pbFormWizard.otherTransaction.value() ) >= 300  &&  $active.next().attr("id") == "tab-ratings" ){
       		$active = $active.next(); 
       	}

        $active.next().removeClass('disabled');
        createTermSheet.getTitleModal( $active.next().attr("id") )
        $active.next().find('a[data-toggle="tab"]').click();
    });
    $(".wizard-modal-createTerm .prev-step").unbind('click').click(function (e) {
        var $active = $('.wizard-modal-createTerm .nav-tabs li.active');
       	
       	if(createTermSheet.sameIssuer() == true && $active.prev().attr("id") == 'tab-ratting'){
       		$active = $active.prev();
       	} 
       	
       	if( parseInt( pbFormWizard.otherTransaction.value() )  >= 300 && $active.prev().attr("id") == 'tab-ratings'){
       		$active = $active.prev(); 
       	}

        createTermSheet.getTitleModal( $active.prev().attr("id") )
        $active.prev().find('a[data-toggle="tab"]').click();
    });
};
createTermSheet.openPopUp = function(){
	$('#modal-create-term a:first').tab('show');
	$("#modal-create-term").modal('show');
	if(createTermSheet.openStatus())
		return;
	
	createTermSheet.loading(true);
	createTermSheet.issuenze.issueSize( parseInt( pbFormWizard.otherTransaction.value() ) )
	createTermSheet.pullRequest(1);
	createTermSheet.initFormWizard();
	createTermSheet.setFilterRatting();
	createTermSheet.GetSugestedRating();
};

createTermSheet.finishProses = function(){
	$("#modal-create-term").modal('hide');
	priceBond.ChangeTab('termSheet');
};

createTermSheet.init = function(){
	var firstGriTemplate = 	pbGrid.gridTemplateFirst();
	if(firstGriTemplate.rendered() == true)
		return createTermSheet.openPopUp();
};