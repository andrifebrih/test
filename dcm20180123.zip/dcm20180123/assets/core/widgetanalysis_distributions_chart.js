var wa_DisChart = {
  title: "Distributions",
  menuTitle: 'distributions',
  leftFilter: function(){
   var filter =  [
      {
        payload : "Issuer",
        id: 'IssuerDistribution', 
        title: 'Issuer Name',
        flag: 'issuer',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Parentcompanyname",
        id: 'ParentcompanynameDistribution', 
        title: 'Parent Company Name',
        flag: 'parent_company_name',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Continent",
        id: 'ContinentDistribution', 
        title: 'Continent',
        flag: 'continent',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Region",
        id: 'RegionDistribution', 
        title: 'Region',
        flag: 'region',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Country",
        id: 'CountryDistribution', 
        title: 'Country',
        flag: 'country',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Superindustry",
        id: 'SuperindustryDistribution', 
        title: 'Super Industry',
        flag: 'super_industry',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Ownership",
        id: 'OwnershipDistribution', 
        title: 'Ownership',
        flag: 'ownership',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Currency", 
        id: 'CurrencyDistribution', 
        title: 'Currency',
        flag: 'currency',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Ranking", 
        id: 'RankingDistribution', 
        title: 'Ranking',
        flag: 'ranking',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Product",
        id: 'ProductDistribution', 
        title: 'Product',
        flag: 'product',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Distributionsformat",
        id: 'DistributionformatDistribution', 
        title: 'Distribution Format',
        flag: 'distributions_format',
        type: 'multiselect',
        ajax: 'true',
      },
      // {
      //   payload : "Onefourfour",
      //   id: 'OnefourfourDistribution', 
      //   title: '144A',
      //   flag: 'one_four_four',
      //   type: 'multiselect',
      //   ajax: 'true',
      // },
      // {
      //   payload : "Regs",
      //   id: 'RegsDistribution', 
      //   title: 'Reg s',
      //   flag: 'regs',
      //   type: 'multiselect',
      //   ajax: 'true',
      // },
      {
        payload : "Specialcharacter",
        id: 'SpecialcharacterDistribution', 
        title: 'Special Character',
        flag: 'special_caracters',
        type: 'multiselect',
        ajax: 'true',
      }
    ];
    return filter;
  },
  f:{
    defaultTypes: ['Contains', 'Equals'],
    investorsList: ko.observableArray([]),
    investedList: ko.observableArray([]),
    val: {
      Countrydetail: ko.observableArray([]),
      Actions: ko.observable("Equals"),
      Text: ko.observable(""),
      Textmulti: ko.observableArray([]),
    }
  },
	pullRequest: ko.observable(0),
	loading: ko.observable(false),
	columns: ko.observableArray([])
};
var columns = [], gridSelector;
var url = "/widgetanalysis/getgriddistributions";

wa_DisChart.pullRequest.subscribe(function(n){
	if(n == 0)
		return wa_DisChart.loading(false);
});
function generateColumn(payload, cb) {
	payload.skip = 0;
	payload.take = 10;
	payload.sort = [];
	ajaxPost("/widgetanalysis/getgriddistributionsfield", payload, function(res) {
		if(res.Data.length > 0) {
      _.each(res.Data, function(o) {
  			columns.push({
  				title: o._id,
  				field: o._id,
  				width: 200,
  				attributes: {
  					"class": "text-center"
  				},
  				headerAttributes: {
  					"class": "text-center"
  				},
  				template: function(dataItem) {
  					if(dataItem[o._id] == 'x') {
  						return "<span class='fa fa-times red' ></span>"
  					} else {
  						return "<span class='fa fa-check green' ></span>"
  					}
  				}
  			});
  		});
  		cb(payload);
    } else {
      gridSelector.html("data not found");
    }
	})
}

var generateGrid = function(payload) {
  gridSelector.kendoGrid({
		dataSource: {
			transport: {
				read: function(option) {
					payload.skip = option.data.skip;
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take;
					ajaxPost(url, payload, function(res) { 
						option.success({ Records: res.Data.data, Count: res.Total });
					});
				}
			},
			schema: {
				data: "Records",
				total: "Count"
			},
			serverPaging: true,
			serverSorting: true,
			serverFiltering: true,
			pageSize: 20,
		},
    dataBound: function(){
      setTimeout(function(){
        console.log("ddd")
        $(window).on('resize', function(){
          gridSelector.find(".k-grid-content td").css('width', '200');
          gridSelector.find(".k-grid-content col").css('width', '200');
          gridSelector.data('kendoGrid')._adjustLockedHorizontalScrollBar();
        });
        $(window).resize(); 
      },300)
    },
		scrollable: true,
		pageable: {
              numeric: true,
              previousNext: true,
              messages: {
                  display: "Showing {2} data items"
              }
        },
		columns: columns
	});
}
var createColumn = function(){
  var columns = [];
  columns.push({
    title: "Investor Name",
    field: "investorname",
    width: 200,
    locked: true,
    // lockable: false,
    attributes: {
             "class": "align-left"
    },
    headerAttributes: {
       "class": "align-left"
    },
  });

  _.each(wa_DisChart.f.val.Textmulti(), function(o){
      columns.push({
          title: o,
          field: o, 
            width: 200,
          attributes: {
            "class": "text-center"
          },
          headerAttributes: {
            "class": "text-center"
          },
          template: function(dataItem) {
            
            if(dataItem[o] == 'v') {
              
              return "<div> <span class='fa fa-check green' ></span> </div>"
            } else {
              return "<div> <span class='fa fa-times red' ></span> </div>"
            }
          } 
      });
  });
  return columns;
}
wa_DisChart.GetDataDefaultFilters =  function(filter, exceptFilter, payload){
  _.each(wa_DisChart.leftFilter(), function(o,i){
    var p = _.clone(payload);
    if(!o.ajax )
      return;
    p["Flag"] = o.flag;
    p = wa_DisChart.extendPayload(p); 
    // if( exceptFilter != "" && exceptFilter == o.id ) 
    p[o.payload]  = [];  
    getFilter("/widgetanalysis/getfilterwidget", p, filter[o.id].data);
  });
};
wa_DisChart.ChangeFilter = function( e, idFilter, idPayload ) {
  
  var template = wa.activeProp.template();
  var filter = template.filter;
      filter[idFilter].value(e._old);
  
  var payload = template.payload;
      payload[idPayload] = e._old;
  wa_DisChart.GetDataDefaultFilters(filter, idFilter, _.clone( payload) );
  wa.reloadPage2();
};
wa_DisChart.RenderGrid = function(payload, $selector){
  $selector = $selector.find("#grid");


  $selector.html("");
  gridSelector = $selector;
  columns = [];
  columns.push({
    title: "Investor Name",
    field: "investorname",
    width: 200,
    locked: true,
    lockable: false,
    attributes: {
              "class": "align-left"
            },
            headerAttributes: {
      "class": "align-left"
            },
  });

  generateColumn(payload, generateGrid);
}
 

wa_DisChart.insertFilter =  function(){
  var filterMainPage = wa.activeProp.mainPage().filter;
      filterMainPage.Countrydetail =  wa_DisChart.f.val.Countrydetail();
      filterMainPage.Actions =  wa_DisChart.f.val.Actions();
      filterMainPage.Textmulti =  wa_DisChart.f.val.Textmulti();
      filterMainPage.Text =  wa_DisChart.f.val.Text();
}

wa_DisChart.createPayload = function(){
  var template = wa.activeProp.template(); 
      template.payload = wa.createPayload( wa.filterProperties(), wa_DisChart.leftFilter() );
  wa_DisChart.GetDataDefaultFilters( template.filter, "", _.clone( template.payload ) ); 
}

wa_DisChart.generateDataViz = function(template){
 
  var template = (template == null)? wa.activeProp.template() : template;
      template.mainPage.mode('preview');
      template.mainPage.type('wa_DisChart');
      template.pullRequest(1);

  wa_DisChart.insertFilter();
  var payload = _.clone( wa.activeProp.payload() );
      payload['Countrydetail'] =  wa_DisChart.f.val.Countrydetail();
      payload['Actions'] =  wa_DisChart.f.val.Actions();
      payload['Text'] =   wa_DisChart.f.val.Text();
      payload['Textmulti'] = wa_DisChart.f.val.Textmulti();

  wa.config.caption("Page of Investors");

  var $selector = wa.activeProp.selectorPage().find('.wa_DisChart ');
  wa_DisChart.RenderGrid(payload, $selector);
    // template.columns = createColumn();
  // setTimeout(function(){
  // wa_DisChart.RenderGrid("/widgetanalysis/getgriddistributions", payload, $selector);
  // },500)
};
wa_DisChart.GetDataDistributions = function( ) {
  var template = wa.activeProp.template();
  var payload = _.clone( wa.activeProp.payload() );
  payload["Flag"] = "country";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_DisChart.f.investorsList);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa_DisChart.f.investedList);
};
wa_DisChart.render =  function () {
    wa_DisChart.createPayload();
    wa_DisChart.generateDataViz();
}
wa_DisChart.Reload =  function(){
  var filterMainPage = wa.activeProp.mainPage().filter;
  wa_DisChart.f.val.Countrydetail(filterMainPage.Countrydetail);
  wa_DisChart.f.val.Actions(filterMainPage.Actions);
  wa_DisChart.f.val.Textmulti(filterMainPage.Textmulti);
  wa_DisChart.f.val.Text(filterMainPage.Text);

  wa_DisChart.generateDataViz();
}
wa_DisChart.Close = function(){
  var template =wa.activeProp.template();
      template.mainPage.mode("chooseData");
      template.mainPage.type("");
      template.payload = wa.createPayload(template.filter, wa.defFilter());
}


wa_DisChart.init =  function(){
  wa_DisChart.GetDataDistributions();
  $("#wa_DisChartModal").modal("show");
};


wa_DisChart.extendPayload =  function(payload){
  payload["Box"] = "Distributions";
  payload['Countrydetail'] =  wa_DisChart.f.val.Countrydetail();
  payload['Actions'] =  wa_DisChart.f.val.Actions();
  payload['Text'] =   wa_DisChart.f.val.Text();
  payload['Textmulti'] = wa_DisChart.f.val.Textmulti();
  return payload;
};