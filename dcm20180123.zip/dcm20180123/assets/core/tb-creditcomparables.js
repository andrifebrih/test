var creditcomparables 	= {};

creditcomparables.init =  function(){
};