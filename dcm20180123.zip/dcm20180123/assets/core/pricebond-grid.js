var pbGrid = {
	GridTemplate : ko.observableArray([]),
	popUpClickedGrid : {}, 
	pullRequest: ko.observable(),
};

function getMaxWidthCellData(index){
	return $(".data-header").find("th").eq(index).width() + "px";
};
var customPayloadTenor =  function(tenors){ 
	if(tenors.indexOf(7) > -1)
		return [3,5,7,10];
	else
		return [3,5,10];
};
pbGrid.showTemplate = ko.computed(function(){
	if(pbGrid.GridTemplate().length == 0)
		return {};
	return pbGrid.GridTemplate()[0]
})
pbGrid.pullRequest.subscribe(function(n){
	if(n == 0)
		return ds.loading(false);
})

pbGrid.gridTemplateFirst =  function(){
	var template =  _.first(pbGrid.GridTemplate());
	return 	( template == undefined ) ? _.clone(pbGrid.structGridTemplate()) : template;
};
pbGrid.getOrderGrid = function(id){
	var dOrder = [];
	$("table.data-list#"+id+" tbody").find("tr").each(function(idx){
		dOrder.push($(this).attr("isin"));
	});
	return dOrder;
};
pbGrid.initDragTable = function(id){
	var fixHelperModified = function(e, tr) {
	    var $originals = tr.children();
	    var $helper = tr.clone();
	    $helper.children().each(function(index) {
	        $(this).width($originals.eq(index).width())
	    });
	    return $helper;
	},
    updateIndex = function(e, ui) {
        $('td.index', ui.item.parent()).each(function (i) {
            $(this).html(i + 1);
        });
    };

	$("table.data-list#"+id+" tbody").sortable({
	    helper: fixHelperModified,
	    stop: updateIndex
	}).disableSelection();
};
pbGrid.dataGridTemplateFirst =  function(){
	var firstTemplate = pbGrid.gridTemplateFirst() 
 	if(!firstTemplate.rendered())
 		return [];
	return firstTemplate.gridData();
};
pbGrid.rowBasis = function(){
	var firstTemplate = pbGrid.gridTemplateFirst();
	var dataGrid = pbGrid.dataGridTemplateFirst();
	if(dataGrid.length == 0)
		return {};
	var basisRow = _.first( _.where(dataGrid, { Isin: firstTemplate.basisIsin() }) ); 
	return ( basisRow == undefined ) ? {} : basisRow;
};
pbGrid.structGridTemplate = function(){
	return {
		id: ko.observable(""),
		title: "",
		tenors: ko.observableArray([]),
		isinConfig: "",
		deleteIsin: ko.observableArray([]),
	 	orderIsin: ko.observableArray([]),
	 	basisIsin: ko.observable(""),
	 	spread: ko.observableArray([]),
		expand: ko.observable(false),
		loading: ko.observable(false),
		rendered: ko.observable(false),
		gridData: ko.observableArray([]),
		chartData: { line  : [], circle: [] },
		enableClick: ko.observable(true),
		payload: {
			Issuer: ds.search(),
			Tenor: [],
			Ranking: "",
			Currency: "",
			Comp: pbFormWizard.comp.value(),
			Productmoody: "",
			Productsp: "",
			Productfitch: "",
			Product: "",
			Ownership: "",
			Corpfissa: ds.issuerSelected.corp_fi_ssa
		},
		clickedRow: function (isin) {
			var self = this;
			if(String(self.basisIsin()) == String(isin))
				return;
			$('#modal-rowGrid').modal('show');
			pbGrid.popUpClickedGrid = this;
			pbGrid.popUpClickedGrid.isinConfig = isin;
		},
	};
};
pbGrid.GetDataGrid = function(payload, fnc){
	ajaxPost("/dashboard/querysheet", payload, function(res){
		fnc(res);
	})
};
pbGrid.renderGrid = function(e){
	e.loading(true);
	pbGrid.GetDataGrid(e.payload, function(res){
		 
		pbGrid.pullRequest(0);
		if(res.IsError)
			return; 
		e.basisIsin( (res.Data.length > 0)  ? _.first(res.Data).Isin: "") 
		e.gridData(res.Data); 
		e.orderIsin(_.pluck(res.Data, 'Isin'));
		e.rendered(true);
		e.loading(false);
		e.expand(true); 
		pbGrid.initDragTable(e.id);
	});
};
pbGrid.expandGrid = function(e){
	if(e.loading())
		return;
	if(e.rendered())
		return e.expand(!e.expand()); 

	pbGrid.renderGrid(e);
};
pbGrid.showMoreGrid =  function(e){	
	if(e.loading())
		return;
	
	e.loading(true);
	var step = 5;
	e.payload.Comp += step;
	e.orderIsin(pbGrid.getOrderGrid(e.id));

	pbGrid.GetDataGrid(e.payload, function(res){
		if(res.IsError)
			return;
		var lenIsin = e.orderIsin().length;
		var data = [];
		var dataOver = [];

		_.each(e.orderIsin(), function(o, i ){  
			var row = _.first( _.where(res.Data,  {Isin: o}) );
			if(row !=  undefined)
				data.push(row);
		}); 
		
		if(res.Data.length > lenIsin){
			dataOver = res.Data.splice(lenIsin, res.Data.length);
		}

		e.gridData( _.union( data,  dataOver ) );
		e.orderIsin( _.union( e.orderIsin() , _.pluck(dataOver, 'Isin') ) ); 
		e.loading(false); 

	});
};
pbGrid.resetPopUpClickedGrid = function(){ return pbGrid.popUpClickedGrid = {}; };
pbGrid.deleteRowGrid = function(){ 
	$('#modal-rowGrid').modal('hide');
	var e = pbGrid.popUpClickedGrid;
	e.deleteIsin().push(e.isinConfig); 
	e.deleteIsin.valueHasMutated();
	pbGrid.resetPopUpClickedGrid(); 
};
pbGrid.markAsBasisRowGrid = function(){
	$('#modal-rowGrid').modal('hide'); 
	var e = pbGrid.popUpClickedGrid;
	e.basisIsin( e.isinConfig ); 
	pbGrid.resetPopUpClickedGrid();
	createTermSheet.Reset();
};
pbGrid.createTitleTenor = function(tenors){
	var len = tenors.length;
	if(len >= 2){
		// tenors.splice( len-2, 1, String( tenors[len-2] ).replace( /(\d+)/g, "$1, ") );
		tenors.splice( len-1, 1, String( tenors[len-1] ).replace(/(\d+)/g, "& $1 Years") );
	}else{
		tenors.splice( 0, 1, String( tenors[0] ).replace(/(\d+)/g, "$1 Years") );
	}
	return tenors.join(", ");
};
pbGrid.loopCurrency = function(parentData,data){
 	var results = [];
	_.each(data, function(currency){
		if(!currency.checked() || !_.has(currency,'details'))
			return;
		
		var tenors 				=  _.pluck(	
										_.reject(
												_.sortBy(
														_.uniq(currency.details(), function(item,key,a){
															return item.value;
														})
												, 'value') 
										,function(item){ return !item.checked(); })
								  ,'value');
		var obj = pbGrid.structGridTemplate();
			obj.id = createUid(); 
			obj.tenors(tenors);
			obj.payload.Ranking = parentData.value;
			obj.payload.Currency = currency.value;
			obj.payload.Tenor = tenors;
			obj.payload.Productmoody = ds.issuerSelected.product_moody;
			obj.payload.Productsp = ds.issuerSelected.product_sp;
			obj.payload.Productfitch = ds.issuerSelected.product_fitch;
			obj.payload.Product = ds.issuerSelected.product;
			obj.payload.Ownership = ds.issuerSelected.ownership;
			obj.title = parentData.text + " - " + currency.text + " - " + pbGrid.createTitleTenor(_.clone(tenors)); 
		
		results.push(obj);
		
		// obj.pullRequest.subscribe(function(newValue){
		// 	if(newValue == 0){
		// 		obj.rendered(true);
		// 		obj.loading(false);
		// 		obj.expand(true);
		// 	}
		// })
	}); 
 	return results;	
};
pbGrid.CreateGridTemplate = function(){
	var template = []; 
	_.each(pbFormWizard.filterTemplate(), function(instrument){
		if(!instrument.checked() || !_.has(instrument,'details'))
			return;
		template = _.union(template, pbGrid.loopCurrency(instrument, instrument.details()));
	});
 
	pbGrid.GridTemplate(template);

	if(pbGrid.GridTemplate().length > 0)
		pbGrid.renderGrid(pbGrid.GridTemplate()[0])

	createTermSheet.Reset();
};
pbGrid.init = function(){ 
	ds.loading(true);
	pbGrid.pullRequest(1)
	pbGrid.CreateGridTemplate(); 
};



