var creditProfile 	= {};

creditProfile.widget = {
	
	currency :{
		id 	 :"currency",
		title:"Currency Mix of Debt",
		url  :"/creditprofile/getloanborrower",
		loading : ko.observable(false),
	},
	fixedFloating :{
		id 	 :"fixedFloating",
		title:"Fixed Rate Vs Floating Rate",
		url  :"/creditprofile/getfunding",
		loading : ko.observable(false),
	},
	loanBond:{
		id 	 :"loanBond",
		title:"Loans Vs Bonds",
		url  :"/creditprofile/getnimavg",
		loading : ko.observable(false),
	},
	maturityProfile :{
		id 	 :"maturityProfile",
		title:"Maturity Profile for all debts",
		url  :"/creditprofile/getassetquality",
		loading : ko.observable(false),
	},
	revenueEbitda:{
		id 	 :"revenueEbitda",
		title:"Revenue and EBITDA",
		url  :"/creditprofile/getrevenueincome",
		loading : ko.observable(false),
	},

	summaryFinancial :{
		id 	 :"summaryFinancial",
		title:"Summary Financials",
		url  :"#",
		loading : ko.observable(false),
	},
	loanByborrower :{
		id 	 :"loanByborrower",
		title:"Loans by borrower type (KRW bn)",
		url  :"/creditprofile/getloanborrower",
		loading : ko.observable(false),
	},
	fundingMix :{
		id 	 :"fundingMix",
		title:"Funding mix",
		url  :"/creditprofile/getfunding",
		loading : ko.observable(false),
	},
	nimAndAverage:{
		id 	 :"nimAndAverage",
		title:"NIM and average interest earned (%)",
		url  :"/creditprofile/getnimavg",
		loading : ko.observable(false),
	},
	assetQuality :{
		id 	 :"assetQuality",
		title:"Asset Quality (%)",
		url  :"/creditprofile/getassetquality",
		loading : ko.observable(false),
	},
	loanByIndustry:{
		id 	 :"loanByIndustry",
		title:"Loans by Industry (KRW bn)",
		url  :"/creditprofile/getloanindustry",
		loading : ko.observable(false),
	},
	capitalAdquaecy:{
		id 	 :"capitalAdquaecy",
		title:"Capital adequacy and ROE %",
		url  :"/creditprofile/getcapitaladequacy",
		loading : ko.observable(false),
	},
	revenueBytype:{
		id 	 :"revenueBytype",
		title:"Revenue by type of income (KRW bn)",
		url  :"/creditprofile/getrevenueincome",
		loading : ko.observable(false),
	},
};

creditProfile.getPayload = function(){
	return {
		issuer:ds.search(),
	}
};
creditProfile.drawChartBar = function($sel, dataSeries){
	$sel.kendoChart({
	 	// color: ds.chartGradientColor,
		theme: "flat",
		series:dataSeries,
        legend: {
            visible: false
        },
        chartArea:{
        	height : 220,
            background: "#f4f4f9",
            margin:20
        },
      
        seriesDefaults: {
			overlay: {
				gradient: "none"
			},
			gap:  0.3,
			border:{
				width:0
			},
			labels:{
				visible:true,
				template: function(e){
					return kendo.toString(e.value, 'n0');

				},
				  font: ds.font('10px'),
    			color: "#0e678d",
			}
		},
        valueAxis: {
			labels: {
				  font: ds.font('10px'),
    			color: "#0e678d",
				visible: false,
			},
			line: {
				visible: false
			},
			majorGridLines: {
				visible: false
	        },
        },
        categoryAxis: {
			labels: {
				  font: ds.font('10px'),
   				 color: "#0e678d",
				visible: true,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible: false
			}
        },
        tooltip: {
            visible: true,
            template: " #= value #"
        }
    });
};
creditProfile.drawChartBar2 = function($sel, dataSeries){
	$sel.kendoChart({ 
		seriesColors: ["#1E88E5","#4ba543","#65B7F5","#559f5c"],
		theme: "flat",
		series:dataSeries,
        legend: {
            visible: false
        },
        chartArea:{
        	height : 220,
            background: "#f4f4f9",
            margin:20
        },
      
        seriesDefaults: {
			overlay: {
				gradient: "none"
			},
			gap:  0.3,
			border:{
				width:0
			}
		},
        valueAxis: {
			labels: {
				  font: ds.font('10px'),
    			color: "#0e678d",
				visible: false,
			},
			line: {
				visible: false
			},
			majorGridLines: {
				visible: false
	        },
        },
        categoryAxis: {
			labels: {
				  font: ds.font('10px'),
   				 color: "#0e678d",
				visible: true,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible: false
			}
        },
        tooltip: {
            visible: true,
            template: " #= value #"
        }
    });
};


creditProfile.widget.currency.Render = function(){
	with(creditProfile.widget.currency){
		loading(true);
 
		var dummyData = [
							{
								Category: "Total", 
								Name: "", 
								Value1: 4154, 
								Value2: 2439, 
								Value3: 384,
								value4: 0
							},
							{
								Category: "CNY ", 
								Name: "", 
								Value1: 4154, 
								Value2: 0, 
								Value3: 0,
								value4: 0
							},
							{
								Category: "USD", 
								Name: "", 
								Value1: 0, 
								Value2: 2439, 
								Value3: 0,
								value4: 0
							},
							{
								Category: "HKD", 
								Name: "", 
								Value1: 0, 
								Value2: 0, 
								Value3: 384,
								value4: 0
							}
						];

		var series = [
						{
							categoryField:'Category',
							field : "Value1",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#0e678d"
						},
						{
							categoryField:'Category',
							field : "Value2",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#4ba543"
						},
						{
							categoryField:'Category',
							field : "Value3",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#b7b7b7",
								labels: {
				                template: "#= stackValue #",
				                visible: true,
				                font: ds.font('10px'),
	   							color: "#0e678d",
				            }
						},
						{
							categoryField:'Category',
							field : "Value4",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#fff", 
						},
					]; 

	 

		$sel = $("#"+id).find(".contentWidget");
		$sel.html("");
		loading(false);		 
 
		$sel.kendoChart({ 

			theme: "flat",
			series:series,
	        legend: {
	            visible: false
	        },
	        chartArea:{
	        	height : 220,
	            background: "#f4f4f9",
	            margin:20
	        },
	      
	        seriesDefaults: {
				overlay: {
					gradient: "none"
				},
				gap:  0.3,
				border:{
					width:0
				},
				 
			},
	        valueAxis: {
				labels: {
					 font: ds.font('10px'),
	    			color: "#0e678d",
					visible: false,
				},
				line: {
					visible: false
				},
				majorGridLines: {
					visible: false
		        },
	        },
	        categoryAxis: {
				labels: {
					font: ds.font('10px'),
	   				color: "#0e678d",
					visible: true,
					background: "transparent",
				},
				majorGridLines: {
					visible: false
				},
				line:{
					visible: false
				}
	        },
	        tooltip: {
	            visible: true,
	            template: " #= value #"
	        }
	    });
		// ds.drawChartBar($sel, series);
			
		// });
	};
};
creditProfile.widget.fixedFloating.Render = function(){
 

	with(creditProfile.widget.fixedFloating){
		loading(true); 

		// var dummyData = {
		// 	Datasource: [
		// 		{Category: "Total", Name: "", Value: 6976},
		// 		{Category: "Floating", Name: "", Value: 4346},
		// 		{Category: "Fixed", Name: "", Value: 2630}
		// 	],
		// 	Max: 90,
		// 	Min: 30
		// };
		var dummyData = [
							{
								Category: "Total", 
								Name: "", 
								Value1: 4346, 
								Value2: 2630, 
								Value3: 0,  
							},
							{
								Category: "Floating ", 
								Name: "", 
								Value1:4346, 
								Value2:0,  
								Value3: 0,  
							},
							{
								Category: "Fixed", 
								Name: "", 
								Value1: 0, 
								Value2: 2630,  
								Value3: 0,   
							},
							 
						];

		var series = [
						{
							categoryField:'Category',
							field : "Value1",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#4ba543"
						},
						{
							categoryField:'Category',
							field : "Value2",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#0e678d", 
							labels: {
				                template: "#= stackValue #",
				                visible: true,
				                font: ds.font('10px'),
	   							color: "#0e678d",
				            } 
						}, 
						{
							categoryField:'Category',
							field : "Value3",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#fff"
						},
					]; 

	 

		$sel = $("#"+id).find(".contentWidget");
		$sel.html("");
		loading(false);		 
 
		$sel.kendoChart({ 

			theme: "flat",
			series:series,
	        legend: {
	            visible: false
	        },
	        chartArea:{
	        	height : 220,
	            background: "#f4f4f9",
	            margin:20
	        },
	      
	        seriesDefaults: {
				overlay: {
					gradient: "none"
				},
				gap:  0.3,
				border:{
					width:0
				},  
				 
			},
	        valueAxis: {
				labels: {
					 font: ds.font('10px'),
	    			color: "#0e678d",
					visible: false,
				},
				line: {
					visible: false
				},
				majorGridLines: {
					visible: false
		        },
	        },
	        categoryAxis: {
				labels: {
					font: ds.font('10px'),
	   				color: "#0e678d",
					visible: true,
					background: "transparent",
				},
				majorGridLines: {
					visible: false
				},
				line:{
					visible: false
				}
	        },
	        tooltip: {
	            visible: true,
	            template: " #= value #"
	        }
	    });  
	 
	};
};
creditProfile.widget.loanBond.Render = function(){
	// with(creditProfile.widget.nimAndAverage){
	// 	loading(true); 

	// 	var payload = creditProfile.getPayload()
	// 	ajaxPost(url, payload, function(res){
	// 		$sel = $("#"+id).find(".contentWidget");
	// 		$sel.html("");
	// 		loading(false);		 
	// 		if(res.IsError)
	// 			return; 

	// 		ds.drawChartBar($sel, [
	// 									{
	// 										categoryField:'Category',
	// 										field:  "Value",
	// 										type: "line", 
	// 										data: res.Data.Datasource,
	// 									}
	// 								]
	// 						);
			
	// 	});
	// };


	with(creditProfile.widget.loanBond){
		loading(true);


		// var dummyData = {
		// 	Datasource: [
		// 		{Category: "Total", Name: "", Value: 6976},
		// 		{Category: "Loan", Name: "", Value: 4413},
		// 		{Category: "Bonds", Name: "", Value: 2563}
		// 	],
		// 	Max: 90,
		// 	Min: 30
		// };

		var dummyData = [
						{
							Category: "Total", 
							Name: "", 
							Value1: 4413, 
							Value2: 2563,  
							value3: 0
						},
						{
							Category: "Loan", 
							Name: "",
							Value1: 4413, 
							Value2: 0,  
							value3: 0
						},
						{
							Category: "Bonds", 
							Name: "", 
							Value1: 0, 
							Value2: 2563,  
							value3: 0
						},
						 
					];

		var series = [
						{
							categoryField:'Category',
							field : "Value1",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#4ba543"
						},
						{
							categoryField:'Category',
							field : "Value2",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#0e678d",
							labels: {
				                template: "#= stackValue #",
				                visible: true,
				                font: ds.font('10px'),
	   							color: "#0e678d",
				            } 
						},
						{
							categoryField:'Category',
							field : "Value3",
							type  : "bar",
							stack : true,
							data  : dummyData,
							color : "#fff"
						}, 

					]; 

	 

		$sel = $("#"+id).find(".contentWidget");
		$sel.html("");
		loading(false);		 
 
		$sel.kendoChart({ 

			theme: "flat",
			series:series,
	        legend: {
	            visible: false
	        },
	        chartArea:{
	        	height : 220,
	            background: "#f4f4f9",
	            margin:20
	        },
	      
	        seriesDefaults: {
				overlay: {
					gradient: "none"
				},
				gap:  0.3,
				border:{
					width:0
				},
				 
			},
	        valueAxis: {
				labels: {
					font: ds.font('10px'),
	    			color: "#0e678d",
					visible: false,
				},
				line: {
					visible: false
				},
				majorGridLines: {
					visible: false
		        },
	        },
	        categoryAxis: {
				labels: {
					font: ds.font('10px'),
	   				color: "#0e678d",
					visible: true,
					background: "transparent",
				},
				majorGridLines: {
					visible: false
				},
				line:{
					visible: false
				}
	        },
	        tooltip: {
	            visible: true,
	            template: " #= value #"
	        }
	    });

		// var payload = creditProfile.getPayload()
		// ajaxPost(url, payload, function(res){
		// var dummyData = {
		// 	Datasource: [
		// 		{Category: "Total", Name: "", Value: 6976},
		// 		{Category: "Loan", Name: "", Value: 4413},
		// 		{Category: "Bonds", Name: "", Value: 2563}
		// 	],
		// 	Max: 90,
		// 	Min: 30
		// };


		// $sel = $("#"+id).find(".contentWidget");
		// $sel.html("");
		// loading(false);		 
		// // if(res.IsError)
		// // 	return; 

		// creditProfile.drawChartBar($sel, [
		// 							{
		// 								categoryField:'Category',
		// 								field:  "Value",
		// 								type: "bar",
		// 								data: dummyData.Datasource,
		// 								color : "url(#svg-radialgradient-darkblue-darkgreen)"
		// 							}
		// 						]
		// 				);
			
		// });
	};
};
creditProfile.widget.maturityProfile.Render = function(){
	// with(creditProfile.widget.assetQuality){ 
	// 	loading(true);
	// 	$("#"+id).find(".contentWidget").html("");;
	// 	var payload = creditProfile.getPayload()
	// 	ajaxPost(url, payload, function(res){
	// 		$sel = $("#"+id).find(".contentWidget");
	// 		$sel.html("");
	// 		loading(false);		 
	// 		if(res.IsError)
	// 			return; 
	// 		$("#"+id).find(".contentWidget").kendoChart({
	// 			seriesColors: ds.chartSeriesColor,
	// 			theme: "flat",
	// 			series:[{
	// 				categoryField:'Category',
	// 				field:  "Value",
	// 				type: "column",
	// 				data: res.Data.Datasource.Bar,
	// 			},{
	// 				categoryField:'Category',
	// 				field:  "Value",
	// 				type: "line",
	// 				name:"line",
	// 				data: res.Data.Datasource.Line, 
	// 			}],
	//             legend: {
	//                 visible: false
	//             },
	//             seriesDefaults: {
	// 				overlay: {
	// 					gradient: "none"
	// 				},
	// 				gap: 0.1,
	// 			},
	//             valueAxis: [
					
	// 				{
	// 					max: (res.Data.Max.Bar == 0) ? 0 : res.Data.Max.Bar * 1.2,
	// 					line: {
	// 						visible: true,
	// 						color: '#f1f1f1'
	// 					},
	// 					majorGridLines: {
	// 						visible: false
	// 					},
	// 					labels: {
	// 						color: "#4c5356",
	// 						font: ds.font('9px'),
	// 						visible: true,
	// 						background: "transparent",
	// 					},
	// 				},
	// 				{ 
	// 					min:0,
	// 					max: (res.Data.Max.Line == 0 ) ? 0 : res.Data.Max.Line * 1.25,
	// 					name:"line", 
	// 					line: {
	// 						visible: true,
	// 						color: '#f1f1f1'
	// 					},
						 
	// 					majorGridLines: {
	// 						visible: false
	// 					},
	// 					labels: {
	// 						color: "#4c5356",
	// 						font: ds.font('9px'),
	// 						visible: true,
	// 						background: "transparent",
	// 					},
	// 				}

	// 			],
	//             categoryAxis: {
	// 				labels: {
	// 					color: "#4c5356",
	// 					font: ds.font('9px'),
	// 					visible: true,
	// 					background: "transparent",
	// 				},
	// 				majorGridLines: {
	// 					visible: false
	// 				},
	// 				line:{
	// 					visible: true
	// 				},
	// 				axisCrossingValue:[0,10]
	//             },
	//             tooltip: {
	//                 visible: true,
	//                 template: "  #= value #"
	//             }
	//         })
	// 	});
	
	// };


	with(creditProfile.widget.maturityProfile){
		loading(true);

		// var payload = creditProfile.getPayload()
		// ajaxPost(url, payload, function(res){
		var dummyData = {
			Datasource: [
				{Category: ">2Y, <5Y", Name: "", Value: 2929},
				{Category: "<1Y", Name: "", Value: 1844},
				{Category: ">1Y, <2Y", Name: "", Value: 1519},
				{Category: ">5Y", Name: "", Value: 684},
			],
			Max: 90,
			Min: 30
		};


		$sel = $("#"+id).find(".contentWidget");
		$sel.html("");
		loading(false);		 
		// if(res.IsError)
		// 	return; 

		creditProfile.drawChartBar($sel, [
									{
										categoryField:'Category',
										field:  "Value",
										type: "bar",
										data: dummyData.Datasource,
										color : "#0e678d"
									}
								]
						);
			
		// });
	};
};
creditProfile.widget.revenueEbitda.Render = function(){
	// with(creditProfile.widget.revenueBytype){
	// 	loading(true);
		 
	// 	var payload = creditProfile.getPayload()
	// 	ajaxPost(url, payload, function(res){
	// 		$sel = $("#"+id).find(".contentWidget");
	// 		$sel.html("");
			
	// 		loading(false);		 
	// 		if(res.IsError)
	// 			return; 
			
	// 		ds.drawChartBar($sel, [
	// 									{
	// 										categoryField:'Category',
	// 										field:  "Value",
	// 										type: "bar", 
	// 										data: res.Data.Datasource,
	// 									}
	// 								]
	// 						);
	// 	})
	// };

	with(creditProfile.widget.revenueEbitda){
		loading(true);

		// var payload = creditProfile.getPayload()
		// ajaxPost(url, payload, function(res){
		var dummyData = {
			Datasource: [

				{Category: "FY2014A", Name: "", Value: 1517},
				{Category: "FY2015A", Name: "", Value: 958}, 
				{Category: "FY2016A", Name: "", Value: 2606},
			],
			Max: 4000,
			Min: 100
		};


		$sel = $("#"+id).find(".contentWidget");
		$sel.html("");
		loading(false);		 
		// if(res.IsError)
		// 	return; 

	 	$sel.kendoChart({
		 	// color: ds.chartGradientColor,
			theme: "flat",
			series:[
						{
							categoryField:'Category',
							field:  "Value",
				            name: "Revenue",
							type: "column",
							data: dummyData.Datasource,
							color : "#0e678d",
							gap: 1.5,
							labels:{
								visible:true,
								template: function(e){
									return kendo.toString(e.value, 'n0');

								},
								font: ds.font('10px'),
				    			color: "#0e678d",
							}
						},
						{
				            type: "line",
				            data: [15.24,  24.46, 27.55],
				            name: "EBITDA Margin",
				            color: "#002951",
				            axis: "ebitda"
				        }
					],
	        legend: {
	            visible: false
	        },
	        chartArea:{
	        	height : 220,
	            background: "#f4f4f9",
	            margin:20
	        },
	      
	        seriesDefaults: {
				overlay: {
					gradient: "none"
				},
				gap:  0.3,
				border:{
					width:0
				},
				
			},
			 valueAxes: [{
	          	name: "revenue",
	            color: "#f1f1f1",
	            visible: true,
	            labels: {
	                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	                step: 2,
	                color: "#000"
	            },
	          	majorGridLines: {
					visible: false
				},
	        }, {
	            name: "ebitda",
	            color: "#f1f1f1",
	          	visible: true,
	          	labels: {
	        		font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	                position:"insideEnd",
	             	step: 2,
	                color: "#000"
	    		},
	          	majorGridLines: {
					visible: false
				},
	        }],
	        valueAxis: {
				labels: {
					font: ds.font('10px'),
	    			color: "#0e678d",
					visible: true,
				}, 
				line: {
					visible: true
				},
				majorGridLines: {
					visible: false
		        },
		        majorUnit: parseInt( ( dummyData.Max /  4).toFixed() )
	        },
	        categoryAxis: {
				labels: {
					font: ds.font('10px'),
	   				color: "#0e678d",
					visible: true,
					background: "transparent",
				},
				majorGridLines: {
					visible: false
				},
				line:{
					visible: true
				}
	        },
	        tooltip: {
	            visible: true,
	            template: " #= value #"
	        }
	    });
			
		// });
	};
};


creditProfile.widget.summaryFinancial.Render = function(){
	with(creditProfile.widget.summaryFinancial){
		var payload = creditProfile.getPayload()
	}
};


creditProfile.widget.loanByborrower.Render = function(){
	with(creditProfile.widget.loanByborrower){
		loading(true);

		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			loading(false);		 
			if(res.IsError)
				return; 

			creditProfile.drawChartBar($sel, [
										{
											categoryField:'Category',
											field:  "Value",
											type: "bar",
											data: res.Data.Datasource,
											color : "url(#svg-radialgradient-darkblue-darkgreen)"
										}
									]
							);
			
		});
	};
};

creditProfile.widget.fundingMix.Render = function(){
	with(creditProfile.widget.fundingMix){ 
		loading(true); 

		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			loading(false);		 
			if(res.IsError)
				return; 

		 	creditProfile.drawChartBar2(
		 							$sel, 
		 							ds.generateSeriesStackBar(res.Data.TotalStuck,  res.Data.Datasource));
		});	 	 
	};
};
creditProfile.widget.nimAndAverage.Render = function(){
	with(creditProfile.widget.nimAndAverage){
		loading(true); 

		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			loading(false);		 
			if(res.IsError)
				return; 

			creditProfile.drawChartBar($sel, [
										{
											categoryField:'Category',
											field:  "Value",
											type: "line", 
											data: res.Data.Datasource,
										}
									]
							);
			
		});
	};
};
creditProfile.widget.assetQuality.Render = function(){
	with(creditProfile.widget.assetQuality){ 
		loading(true);
		$("#"+id).find(".contentWidget").html("");;
		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			loading(false);		 
			if(res.IsError)
				return; 
			$("#"+id).find(".contentWidget").kendoChart({
				seriesColors: ds.chartSeriesColor,
				theme: "flat",
				chartArea:{
					height : 220,
					background: "#f4f4f9",
					margin:20
				},
				series:[{
					categoryField:'Category',
					field:  "Value",
					type: "column",
					data: res.Data.Datasource.Bar,
				},{
					categoryField:'Category',
					field:  "Value",
					type: "line",
					name:"line",
					data: res.Data.Datasource.Line, 
				}],
	            legend: {
	                visible: false
	            },
	            seriesDefaults: {
					overlay: {
						gradient: "none"
					},
					gap: 0.1,
				},
	            valueAxis: [
					
					{
						max: (res.Data.Max.Bar == 0) ? 0 : res.Data.Max.Bar * 1.2,
						line: {
							visible: true,
							color: '#f1f1f1'
						},
						majorGridLines: {
							visible: false
						},
						labels: {
							font: ds.font('10px'),
							color: "#0e678d",
							visible: true,
							background: "transparent",
						},
					},
					{ 
						min:0,
						max: (res.Data.Max.Line == 0 ) ? 0 : res.Data.Max.Line * 1.25,
						name:"line", 
						line: {
							visible: true,
							color: '#f1f1f1'
						},
						 
						majorGridLines: {
							visible: false
						},
						labels: {
							font: ds.font('10px'),
							color: "#0e678d",
							visible: true,
							background: "transparent",
						},
					}

				],
	            categoryAxis: {
					labels: {
						font: ds.font('10px'),
						color: "#0e678d",
						visible: true,
						background: "transparent",
					},
					majorGridLines: {
						visible: false
					},
					line:{
						visible: true
					},
					axisCrossingValue:[0,10]
	            },
	            tooltip: {
	                visible: true,
	                template: "  #= value #"
	            }
	        })
		});
	
	};
};
creditProfile.widget.loanByIndustry.Render = function(){
	with(creditProfile.widget.loanByIndustry){
		loading(true);
		 
		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			
			loading(false);		 
			if(res.IsError)
				return; 
			
			creditProfile.drawChartBar($sel, [
										{
											categoryField:'Category',
											field:  "Value",
											type: "bar", 
											data: res.Data.Datasource, 
											color : "url(#svg-radialgradient-darkblue-darkgreen)"
										}
									]
							);
		});
	};
};

creditProfile.widget.capitalAdquaecy.Render = function(){
	with(creditProfile.widget.capitalAdquaecy){ 
		loading(true);
		 
		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");

			loading(false);		 
			if(res.IsError)
				return; 
			
			var series = [];
			series = series.concat(ds.generateSeriesStackBar(res.Data.TotalStuck, res.Data.Datasource.Bar));
	 		series.push({
				categoryField:'Category',
				field : "Value",
				type  : "line", 
				name  : "line",
				data  : res.Data.Datasource.Line,
			})
			$("#"+id).find(".contentWidget").kendoChart({
				seriesColors: ["#1E88E5","#4ba543","#65B7F5","#559f5c"],
				theme: "flat",
				chartArea:{
					height : 220,
					background: "#f4f4f9",
					margin:20
				},
				series:series,
	            legend: {
	                visible: false
	            },
	            seriesDefaults: {
					overlay: {
						gradient: "none"
					},
					gap: 0.1,
				},
	            valueAxis: [
					
					{
						max: (res.Data.TotalValueStack == 0) ? 0 : res.Data.TotalValueStack * 1.2,
						line: {
							visible: true,
							color: '#f1f1f1'
						},
						majorGridLines: {
							visible: false
						},
						labels: {
							font: ds.font('10px'),
							color: "#0e678d",
							visible: true,
							background: "transparent",
						},
					},
					{ 
						min:0,
						max: (res.Data.Max.Line == 0 ) ? 0 : res.Data.Max.Line * 1.25,
						name:"line", 
						line: {
							visible: true,
							color: '#f1f1f1'
						},
						 
						majorGridLines: {
							visible: false
						},
						labels: {
							font: ds.font('10px'),
							color: "#0e678d",
							visible: true,
							background: "transparent",
						},
					}

				],
	            categoryAxis: {
					labels: {
						font: ds.font('10px'),
						color: "#0e678d",
						visible: true,
						background: "transparent",
					},
					majorGridLines: {
						visible: false
					},
					line:{
						visible: true
					},
					axisCrossingValue:[0,10]
	            },
	            tooltip: {
	                visible: true,
	                template: " #= value #"
	            }
	        })
		});	 	 
	};
};
creditProfile.widget.revenueBytype.Render = function(){
	with(creditProfile.widget.revenueBytype){
		loading(true);
		 
		var payload = creditProfile.getPayload()
		ajaxPost(url, payload, function(res){
			$sel = $("#"+id).find(".contentWidget");
			$sel.html("");
			
			loading(false);		 
			if(res.IsError)
				return; 
			
			creditProfile.drawChartBar($sel, [
										{
											categoryField:'Category',
											field:  "Value",
											type: "bar", 
											data: res.Data.Datasource,
											
											color : "url(#svg-radialgradient-darkblue-darkgreen)"
										}
									]
							);
		})
	};
};










creditProfile.init =  function(){
	if(ds.search() == 'Shui On Land Ltd'){
		setTimeout(function(){ creditProfile.widget.currency.Render()}, 10);
		setTimeout(function(){ creditProfile.widget.fixedFloating.Render()}, 10); 
		setTimeout(function(){ creditProfile.widget.loanBond.Render()}, 10);
		setTimeout(function(){ creditProfile.widget.maturityProfile.Render()}, 10);
		setTimeout(function(){ creditProfile.widget.revenueEbitda.Render()}, 10);
	}else{
		// setTimeout(function(){ creditProfile.widget.summaryFinancial.Render()}, 10);
		// setTimeout(function(){ creditProfile.widget.loanByborrower.Render()}, 10);
		// setTimeout(function(){ creditProfile.widget.fundingMix.Render() }, 10);
		// setTimeout(function(){ creditProfile.widget.nimAndAverage.Render() }, 10); 
		// setTimeout(function(){ creditProfile.widget.assetQuality.Render() }, 10);
		// setTimeout(function(){ creditProfile.widget.loanByIndustry.Render() }, 10); 
		// setTimeout(function(){ creditProfile.widget.capitalAdquaecy.Render() }, 10);
		// setTimeout(function(){ creditProfile.widget.revenueBytype.Render() }, 10);
	}
	 
};