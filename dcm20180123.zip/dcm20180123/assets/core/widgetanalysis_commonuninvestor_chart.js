var wa_CommonUnInvChart = {

	title: "Common Un Investor",
	menuTitle: 'commonuninvestor',
	f:{
		commonInvestorsList: ko.observableArray([]),
		commonInvestedList: ko.observableArray([]),
		val: {
			Issuerdetail: ko.observableArray([]),
			Issuerdetail2: ko.observableArray([]),
		}
	}
};

wa_CommonUnInvChart.RenderGrid = function(url, payload, $selector){
	var $selector = $($selector).find("#grid");
	var maxAllocated = 0;

	$selector.html("");
	$selector.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					payload.skip = option.data.skip
					payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
					payload.take = option.data.take
					ajaxPost(url, payload, function(res){
					//        	var datas = res;
					// var sortDatas = sortBarChart(datas)
					// console.log('sss',sortDatas)
						wa_DefChart.pullRequest(wa_DefChart.pullRequest() - 1);
						maxAllocated = res.Data.max;
						option.success({ Records: _.sortBy(res.Data.data, 'allocated').reverse(), Count: res.Total });
					})
	      	},
		},
		schema: {
			data: function(data) {
                return data.Records;
			},
			total: "Count",
		},
	    pageSize: 20,
		serverPaging: true,
		serverSorting: true,
		serverFiltering: true,
		},
		sortable: true,
		pageable: {
			numeric: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns:(function(){
			var column =  [
							{
								title: "Investor Name",
								field: "_id",
								width: 300,
							 	attributes: {
					                "class": "align-left"
					            },
					            headerAttributes: {
									"class": "align-left"
					            },
							},
						  ];
			_.map(wa.activeProp.template().mainPage.filter.Issuerdetail, function(d){
				column.push({
					title: "<div class='field-ellipsis'>"+d+"</div>",
	  				field: d,
	  				width: 100,
	  				attributes: {
	  					"class": "text-center"
	  				},
	  				headerAttributes: {
	  					"class": "text-center"
	  				},
	  				template: function(dataItem) {
	  					return "<span class='fa fa-check green' ></span>"
	  				}
				});
			});
			_.map(wa.activeProp.template().mainPage.filter.Issuerdetail2, function(d){
				column.push({
					title:  "<div class='field-ellipsis'>"+d+"</div>",
	  				field: d,
	  				width: 100,
	  				attributes: {
	  					"class": "text-center"
	  				},
	  				headerAttributes: {
	  					"class": "text-center"
	  				},
	  				template: function(dataItem) {
	  					return "<span class='fa fa-times red' ></span>"
	  				}
				});
			});
			column.push({
				title: "Firm",
				field: "firm",
				width: 100,
				attributes: {
	                "class": "align-center"
	            },
	            headerAttributes: {
	                "class": "align-center"
	            },
	            template: "#: kendo.toString(firm,'n0') #"
			},
			{
				title: "Allocation Amount",
				field: "allocated",
				attributes: {
					"class": "progressbar-cel"
				},
				headerAttributes: {
	                "class": "align-center"
	            },
				template: function(e){

					var percentage = ( maxAllocated == 0 ) ? 0 : 92 / ( maxAllocated / e.allocated );
					return  "<div class='pull-left series-bar' style='margin:2px 0;padding-top:3px;color:#fff;width: "+ percentage +"%'>"+kendo.toString(e.percentage,'n1')+"%</div>" +
							"<div class='pull-left number' style='padding-top:5px;'>" + kendo.toString(e.allocated,'n0') + "</div>";
				}
			});
			console.log(column);
			return column;
		})()
		// columns: [
		// 	{
		// 		title: "Investor Name",
		// 		field: "_id",
		// 		width: 300,
		// 	 	attributes: {
	 //                "class": "align-left"
	 //            },
	 //            headerAttributes: {
		// 			"class": "align-left"
	 //            },
		// 	},
		// 	{
		// 		title: "Firm",
		// 		field: "firm",
		// 		width: 100,
		// 		attributes: {
	 //                "class": "align-center"
	 //            },
	 //            headerAttributes: {
	 //                "class": "align-center"
	 //            },
	 //            template: "#: kendo.toString(firm,'n0') #"
		// 	},
		// 	{
		// 		title: "Allocation Amount",
		// 		field: "allocated",
		// 		attributes: {
		// 			"class": "progressbar-cel"
		// 		},
		// 		headerAttributes: {
	 //                "class": "align-center"
	 //            },
		// 		template: function(e){

		// 			var percentage = ( maxAllocated == 0 ) ? 0 : 92 / ( maxAllocated / e.allocated );
		// 			return  "<div class='pull-left series-bar' style='margin:2px 0;padding-top:3px;color:#fff;width: "+ percentage +"%'>"+kendo.toString(e.percentage,'n1')+"%</div>" +
		// 					"<div class='pull-left number' style='padding-top:5px;'>" + kendo.toString(e.allocated,'n0') + "</div>";
		// 		}
		// 	}
		// ]
	});
};
wa_CommonUnInvChart.insertFilter =  function(){
  var filterMainPage = wa.activeProp.mainPage().filter;
      filterMainPage.Issuerdetail =  wa_CommonUnInvChart.f.val.Issuerdetail();
      filterMainPage.Issuerdetail2 =  wa_CommonUnInvChart.f.val.Issuerdetail2(); 
}
wa_CommonUnInvChart.generateDataViz =  function(){
 	$("#commonUnInvestorModal").modal("hide");

	var $selector = wa.activeProp.selectorPage().find(".wa_CommonUnInvChart");
	var template = wa.activeProp.template();
	template.mainPage.mode('preview');
	template.mainPage.type('wa_CommonUnInvChart');
	wa_CommonUnInvChart.insertFilter()
	var payload = _.clone( wa.activeProp.payload() );
	payload['Flag'] = 'Uninvestor';
	payload['Issuerdetail'] =  wa_CommonUnInvChart.f.val.Issuerdetail();
	payload['Issuerdetail2'] = wa_CommonUnInvChart.f.val.Issuerdetail2();
	wa_CommonUnInvChart.RenderGrid("/widgetanalysis/getgridcommon", payload, $selector);
};

wa_CommonUnInvChart.GetDatacommonUnInv = function(){
	var payload = _.clone( wa.activeProp.payload() );
	payload["Flag"] = "issuer";
	getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonUnInvChart.f.commonInvestorsList);
	payload["Flag"] = "issuer";
	getFilter("/widgetanalysis/getcountrydetail", payload, wa_CommonUnInvChart.f.commonInvestedList);
}

wa_CommonUnInvChart.Reload =  function(){
	var filterMainPage = wa.activeProp.mainPage().filter;
    wa_CommonUnInvChart.f.val.Issuerdetail(filterMainPage.Issuerdetail);
    wa_CommonUnInvChart.f.val.Issuerdetail2(filterMainPage.Issuerdetail2);
	wa_CommonUnInvChart.generateDataViz();
};
wa_CommonUnInvChart.Render = function() {
	wa_CommonUnInvChart.initFilter("open");
	wa_CommonUnInvChart.generateDataViz();
}
wa_CommonUnInvChart.Close = function(){
	wa_CommonUnInvChart.initFilter("close");
	var template = wa.activeProp.template();
 		template.mainPage.mode("chooseData");
 		template.mainPage.type("");
}
wa_CommonUnInvChart.init =  function(){
	wa_CommonUnInvChart.GetDatacommonUnInv();
	$("#commonUnInvestorModal").modal("show");
};



wa_CommonUnInvChart.initFilter =  function(mode){
  var payload = wa.activeProp.payload();
  if(mode == "open")
    payload  = wa_CommonUnInvChart.extendPayload( _.clone(payload) );
  wa.GetDataDefaultFilters(wa.activeProp.filter(), "", payload);
};
wa_CommonUnInvChart.extendPayload =  function(payload){
	payload['Box'] = 'Common Un Investor';
	payload['Flag'] = 'Uninvestor';
	payload['Issuerdetail'] = wa_CommonUnInvChart.f.val.Issuerdetail();
	payload['Issuerdetail2'] =  wa_CommonUnInvChart.f.val.Issuerdetail2();
	return payload;
};