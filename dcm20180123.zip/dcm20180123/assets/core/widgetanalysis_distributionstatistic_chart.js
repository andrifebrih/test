var wa_DSChart = {
  title: "Distribution Statistic",
  menuTitle: 'distributionstatistic',
  avgTight: ko.observable(),
  avgOversubscription: ko.observable(),
  filter:{
    geographic : ko.observableArray([{text:"US",value:"us_value"},{text:"EMEA",value:"emea_value"},{text:"ASIA",value:"asia_value"}]),
    investor : ko.observableArray([{text:"Banks",value:"banks_value"},{text:"PB",value:"pb_value"},{text:"FM",value:"fm_value"},{text:"Insurance",value:"insurance_value"},{text:"Others",value:"others_value"}]),
    val:{
      geographicType : ko.observable(""),
      investorType : ko.observable(""),
      geographicVal : ko.observable(0),
      investorVal : ko.observable(0),
    }
  },
  leftFilter: function(){
    var filter =  [
      {
        payload : "Issuer",
        id: 'IssuerDistributionStatic', 
        title: 'Issuer Name',
        flag: 'issuer',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Parentcompanyname",
        id: 'ParentcompanynameDistributionStatic', 
        title: 'Parent Company Name',
        flag: 'parent_company_name',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Continent",
        id: 'ContinentDistributionStatic', 
        title: 'Continent',
        flag: 'continent',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Region",
        id: 'RegionDistributionStatic', 
        title: 'Region',
        flag: 'region',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Country",
        id: 'CountryDistributionStatic', 
        title: 'Country',
        flag: 'country',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Superindustry",
        id: 'SuperindustryDistributionStatic', 
        title: 'Super Industry',
        flag: 'super_industry',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Ownership",
        id: 'OwnershipDistributionStatic', 
        title: 'Ownership',
        flag: 'ownership',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Currency", 
        id: 'CurrencyDistributionStatic', 
        title: 'Currency',
        flag: 'currency',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Ranking", 
        id: 'RankingDistributionStatic', 
        title: 'Ranking',
        flag: 'ranking',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Product",
        id: 'ProductDistributionStatic', 
        title: 'Product',
        flag: 'product',
        type: 'multiselect',
        ajax: 'true',
      },
      {
        payload : "Distributionsformat",
        id: 'DistributionformatDistributionStatic', 
        title: 'Distribution Format',
        flag: 'distributions_format',
        type: 'multiselect',
        ajax: 'true',
      },
      // {
      //   payload : "Onefourfour",
      //   id: 'OnefourfourDistributionStatic', 
      //   title: '144A',
      //   flag: 'one_four_four',
      //   type: 'multiselect',
      //   ajax: 'true',
      // },
      // {
      //   payload : "Regs",
      //   id: 'RegsDistributionStatic', 
      //   title: 'Reg s',
      //   flag: 'regs',
      //   type: 'multiselect',
      //   ajax: 'true',
      // },
      {
        payload : "Specialcharacter",
        id: 'SpecialcharacterDistributionStatic', 
        title: 'Special Character',
        flag: 'special_caracters',
        type: 'multiselect',
        ajax: 'true',
      }
    ];
    return filter;
  },
};
wa_DSChart.filter.val.geographicType.subscribe(function(){
    wa_DSChart.generateDataViz();
    var template = wa.activeProp.template(); 
        template.payload = wa.createPayload( wa.filterProperties(), wa_DSChart.leftFilter() );
        wa_DSChart.GetDataDefaultFilters( template.filter, "", _.clone( template.payload ) ); 
});
wa_DSChart.filter.val.investorType.subscribe(function(){
    wa_DSChart.generateDataViz();
    var template = wa.activeProp.template(); 
        template.payload = wa.createPayload( wa.filterProperties(), wa_DSChart.leftFilter() );
        wa_DSChart.GetDataDefaultFilters( template.filter, "", _.clone( template.payload ) ); 
});

wa_DSChart.filter.val.geographicVal.subscribe(function(n){
  var newVal = !
  wa_DSChart.filter.val.geographicVal( isNaN( parseInt( wa_DSChart.filter.val.geographicVal() ) ) ? 0 : parseInt( wa_DSChart.filter.val.geographicVal() ) );
  var template = wa.activeProp.template(); 
      template.payload = wa.createPayload( wa.filterProperties(), wa_DSChart.leftFilter() );
      wa_DSChart.GetDataDefaultFilters( template.filter, "", _.clone( template.payload ) ); 
  
  wa_DSChart.generateDataViz();
});

wa_DSChart.filter.val.investorVal.subscribe(function(n){
  var newVal = ! isNaN( parseInt(n) ) ? 0 : parseInt(n);
  wa_DSChart.filter.val.investorVal( isNaN( parseInt( wa_DSChart.filter.val.investorVal() ) ) ? 0 : parseInt( wa_DSChart.filter.val.investorVal() ) );
  var template = wa.activeProp.template(); 
      template.payload = wa.createPayload( wa.filterProperties(), wa_DSChart.leftFilter() );
      wa_DSChart.GetDataDefaultFilters( template.filter, "", _.clone( template.payload ) ); 
  wa_DSChart.generateDataViz();
});

wa_DSChart.config = {
  loading: ko.observable(true),
}

wa_DSChart.createDonut = function($selector, title, dataSource) {
  var idx = -1;
  var total = 0;
  var series = [];
 
  _.each(dataSource, function(o, i) {
    if(i != "_id") {
      idx+=1;
      total += parseFloat(o);
      series.push({
        category: i.substr(0,i.indexOf("_")).toUpperCase(),
        value: o,
        color: ecisColors[idx]
      })
    }
  })
  _.each(series, function(o) {
    o.value = parseFloat(o.value / total * 100).toFixed(2)
  })
  $selector.kendoChart({
    legend: {
      visible: true,
      position: "bottom",
    },
    seriesDefaults: {
        type: "donut",
      holeSize: 50,
    },
    series: [{
      overlay: { gradient: "none"},
      name: title,
      data: series
    }],
    tooltip: {
      visible: true,
      template: "#= category # : #= value #%",
    }
  })
}

wa_DSChart.createGrid = function($selector, url, payload) {
  $selector.html("");
  $selector.kendoGrid({
    dataSource: {
      transport: {
        read: function(option) {
          payload.skip = option.data.skip;
          payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : '';
          payload.take = option.data.take
          ajaxPost(url, payload, function(res) {
            wa_DSChart.avgTight(kendo.toString( res.Data.Avg1, 'n1') );
            wa_DSChart.avgOversubscription(kendo.toString(  res.Data.Avg2, 'n1') );
            option.success({ Records: res.Data.data, Count: res.Total });
          })
        }
      },
      schema: {
        data: function(d) {
          return d.Records
        },
				total: "Count"
      },
      serverPaging: true,
      serverFiltering: true,
      serverSorting: true,
      pageSize: 10,
    },
    scrollable: true,
    sortable: true,
    // filterable: {
    //   extra:false,
      // operators: {
      //   string: {
      //     contains: "Contains",
      //     startswith: "Starts with",
      //     eq: "Is equal to",
      //     neq: "Is not equal to",
      //     doesnotcontain: "Does not contain",
      //     endswith: "Ends with"
      //   },
      // }
    // },
    pageable: {
      number: true,
      previousNext: true,
      messages: {
          display: "Showing {2} data items"
      }
    },
    columns: [
      {field: "security", width: 150, title: "Ticker"},
      {field: "issuer", width: 150, title: "Issue Name"},
      {field: "issue_date", width: 200, title: "issue Date"},
      {field: "size", width: 100, title: "Size", template: "#: kendo.toString(size,'n0') #"},
      {field: "orderbook", width: 100, title: "Orderbook Size", template: "#: kendo.toString(orderbook,'n0') #"},
      {field: "subscription", width: 100, title: "<div class='field-ellipsis'> Orderbook Oversubscription </div>", 
              template: "#: kendo.toString(subscription,'n1') #x"},
      {field: "tightening_ipg", width: 100, title: "Price Tightening", template: "#: kendo.toString(tightening_ipg,'n0') #"},
      // {field: "distributions_stats", title: "Distribution stats", template: "#: kendo.toString(distributions_stats,'n0') #"},
      {
          title: "Geographic",
          headerAttributes: {
            "class": "align-center"
          },
          columns: [
            {
              title: "US %",
              field: "us",
              attributes: {
                "class": "align-center"
              },

              width: 100,
              headerAttributes: {
                "class": "align-center"
              },
              template: "#= kendo.toString(us,'N0' )#"
            },
            {
              title: "EMEA %",
              field: "emea",
              attributes: {
                "class": "align-center"
              },

              width: 100,
              headerAttributes: {
                "class": "align-center"
              },
              template: "#= kendo.toString(emea,'N0') #"
            },
            {
              title: "ASIA %",
              field: "asia",
              attributes: {
                "class": "align-center"
              },

              width: 100,
              headerAttributes: {
                "class": "align-center"
              },
              template: "#= kendo.toString(asia,'N0') #"
            },
          ]
      },
      {
          title: "Investor",
          headerAttributes: {
            "class": "align-center"
          },
          columns: [
            {
              title: "Banks %",
              field: "banks",
              attributes: {
                "class": "align-center"
              },
              width: 100,
              headerAttributes: {
                "class": "align-center"
              },
              template: "#= kendo.toString(banks,'N0') #"
            },
            {
              title: "PB %",
              field: "pb",
              attributes: {
                "class": "align-center"
              },
              width: 100,
              headerAttributes: {
                "class": "align-center"
              },
              template: "#= kendo.toString(pb,'N0') #"
            },
            {
              title: "FM %",
              field: "fm",
              attributes: {
                "class": "align-center"
              },
              width: 100,
              headerAttributes: {
                "class": "align-center"
              },
              template: "#= kendo.toString(fm,'N0') #"
            },
            {
              title: "Insurance %",
              field: "insurance",
              attributes: {
                "class": "align-center"
              },
              width: 100,
              headerAttributes: {
                "class": "align-center"
              },
              template: "#= kendo.toString(insurance,'N0') #"
            },
            {
              title: "Others %",
              field: "others",
              attributes: {
                "class": "align-center"
              },
              width: 100,
              headerAttributes: {
                "class": "align-center"
              },
              template: "#= kendo.toString(others,'N0') #"
            },
          ]
      },


      // {field: "size", title: "Size" ,
      //           template: "#: kendo.toString(size,'n0') #"},
    ]
  });
}

wa_DSChart.generateDonutDataViz = function($selector, payload) {
  payload["Flag"] = "Geography";
  ajaxPost("/widgetanalysis/getdonutdistributionstatistic", payload, function(res) {
    wa_DSChart.config.loading(false);
    wa_DSChart.createDonut($selector.find("#wa-ds-donut-1"), "Industry", res.Data[0]);
  })
  payload["Flag"] = "InvestorType";
  ajaxPost("/widgetanalysis/getdonutdistributionstatistic", payload, function(res) {
    wa_DSChart.config.loading(false);
    wa_DSChart.createDonut($selector.find("#wa-ds-donut-2"), "Ranking", res.Data[0]);
  })
}
wa_DSChart.ChangeFilter = function( e, idFilter, idPayload ) {
  
  var template = wa.activeProp.template();
  var filter = template.filter;
      filter[idFilter].value(e._old);
  
  var payload = template.payload;
      payload[idPayload] = e._old;
  wa_DSChart.GetDataDefaultFilters(filter, idFilter, _.clone( payload) );
  wa.reloadPage2();
};
wa_DSChart.generateDataViz = function() {

  var template = wa.activeProp.template();
  template.mainPage.mode('preview');
  template.mainPage.type('wa_DSChart');

  var payload = _.clone( wa_DSChart.extendPayload( wa.activeProp.payload() ) );

  wa.config.caption("Page of Investors");
  var $selector = wa.activeProp.selectorPage();
  wa_DSChart.generateDonutDataViz($selector, payload);
  wa_DSChart.createGrid($selector.find("#wa-ds-grid"), "/widgetanalysis/getgriddistributionstatistics", payload);
}
wa_DSChart.Reload = function(){
    wa_DSChart.generateDataViz();
}
wa_DSChart.Close = function(){
   var template =wa.activeProp.template();
    template.mainPage.mode("chooseData");
    template.mainPage.type("");
}

wa_DSChart.GetDataDefaultFilters =  function(filter, exceptFilter, payload){
  _.each(wa_DSChart.leftFilter(), function(o,i){
    var p = _.clone(payload);
    if(!o.ajax )
      return;
    p["Flag"] = o.flag;
    p = wa_DSChart.extendPayload(p); 
    // if( exceptFilter != "" && exceptFilter == o.id ) 
    p[o.payload]  = [];
    getFilter("/widgetanalysis/getfilterwidget", p, filter[o.id].data);
  });
};

wa_DSChart.createPayload = function(){
  var template = wa.activeProp.template(); 
      template.payload = wa.createPayload( wa.filterProperties(), wa_DSChart.leftFilter() );
  wa_DSChart.GetDataDefaultFilters( template.filter, "", _.clone( template.payload ) ); 
}

wa_DSChart.init =  function(){


  wa_DSChart.createPayload();
  wa_DSChart.generateDataViz();
};
wa_DSChart.initFilter =  function(mode){
    var payload = wa.activeProp.payload();
        payload = wa_DSChart.extendPayload( _.clone(payload) );
    console.log(payload);
}

wa_DSChart.extendPayload =  function(payload){ 
  payload["Geographytype"] = wa_DSChart.filter.val.geographicType()
  payload["Geographyvalue"] = wa_DSChart.filter.val.geographicVal()
  payload["Investortype"] = wa_DSChart.filter.val.investorType()
  payload["Investorvalue"] = wa_DSChart.filter.val.investorVal()
  payload["Box"] = "Distribution Statistic";
  return payload;
};
