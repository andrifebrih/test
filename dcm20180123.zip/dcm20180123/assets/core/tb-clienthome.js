var clienthome 	= {};
clienthome.gam = ko.observable('Rosalyn Chan')
clienthome.fmsales = ko.observable('Rosalyn Chan')
clienthome.dcm = ko.observable('Rosalyn Chan')
clienthome.pbrm = ko.observable('Theodre Mak')

clienthome.cat1 = ko.observable('USD 784mn')
clienthome.cat2 = ko.observable('USD 100mn')
clienthome.total = ko.observable('USD 884mn')

clienthome.chairman = ko.observable('Vincent Lo')
clienthome.ceo = ko.observable('Frankie Wang')
clienthome.cfo = ko.observable('Daniel Wan/ Raymond Wong')
clienthome.fc = ko.observable('Eric Tam')

clienthome.clienttier = ko.observable('Top 100')
clienthome.mtnprogram = ko.observable('No')
clienthome.scbid = ko.observable('99001964')
clienthome.scbdealer = ko.observable('No')
clienthome.valifcdd = ko.observable('No')
clienthome.isda = ko.observable('No')
clienthome.cdddate = ko.observable('8-June-2016')
clienthome.csa = ko.observable('No')
clienthome.documentation = ko.observable('No')


clienthome.product = ko.observable("");
clienthome.aliasname = ko.observable("");
clienthome.security = ko.observable("");
clienthome.sp = ko.observable("");
clienthome.moody = ko.observable("");
clienthome.fitch = ko.observable("");


clienthome.init =  function(){
	clienthome.product(ds.issuerSelected.product) 

	clienthome.aliasname(ds.issuerSelected.aliasname) 
	clienthome.security(ds.issuerSelected.security) 
	clienthome.sp(ds.issuerSelected.moodys_issuer_rating) 
	clienthome.moody(ds.issuerSelected.sp_issuer_rating) 
	clienthome.fitch(ds.issuerSelected.fitch_issuer_rating) 
};