var wg = {}

wg.activePageList = ko.observableArray([{text: 1, value:0}])
wg.activePage     = ko.observable(0)
wg.activeIndexSummary = ko.observable(0)
wg.activeIndexChart   = ko.observable(0)
wg.totalPage    = ko.observable(1);
wg.popupChartId = ko.observable('');

wg.template     = ko.observable('');
wg.templateName = ko.observable('');
wg.templateList = ko.observableArray([])

wg.templateList2 = ko.observableArray([])
wg.tempateFilterValueList = {
                                            receivingCountryList:ko.observableArray([]),
                                            receivingLegalEntityList:ko.observableArray([]),
                                            supplycountryList : ko.observableArray([]),
                                            supplylegalentityList:ko.observableArray([]),
                                            LegalSignatoryList: ko.observableArray([]),
                                            categorynameList:ko.observableArray([]),
                                            supplytypeList : ko.observableArray([]),
                                            productList : ko.observableArray([])
                                        }
wg.filtervalueList = ko.observableArray([wg.tempateFilterValueList]);

wg.filterChartDonutList = ko.observableArray([
                                            {value:"% of Services by Service Type",text:"% of Services by Service Type"},
                                            {value:"In-Entity vs Intra-Group",text:"% Services Performed In-Entity Vs Intra-Group"},
                                            {value:"In-Entity vs Intra-Group FTE",text:"FTE Utilized by In-Entity Vs Intra-Group"}
                                            ]);
wg.searchresultBar = ko.observable(false);
wg.inputsearchBar = ko.observable('');
wg.filterChartBarList = ko.observableArray([])
wg.datafilterChartBarList = ko.observableArray([]);
wg.filterChartBarProcesses = ko.observableArray([]);
wg.filterChartBarResources = ko.observableArray([]);
wg.filterChartBarAssets = ko.observableArray([]);
wg.filterChartBarCEF = ko.observableArray([]);
wg.filterChartBarMapTeam = ko.observableArray([]); 
wg.filterChartGridList = ko.observableArray([
                            {value:"Products",text:"Products"},
                            {value:"validated",text:"For Validated Service by Country"},
                            {value:"enriched",text:"For Confirmed Service by Country"},
                            {value:"businnessvalidated",text:"For Validated Service by Business"},
                            {value:"businnessenriched",text:"For Confirmed Service by Business"},
                            {value:"countrybusinnessvalidated",text:"% Validated Service by Country and Business"},
                            {value:"countrybusinnessenriched",text:"% Confirmed Service by Country and Business"},

                            {value:"countryValidated",text:"Daily Stats Validated by Country"},
                            {value:"businessvalidated",text:"Daily Stats Validated by Business"},
                            {value:"countryConfirmed",text:"Daily Stats Confirmed  by Country"},
                            {value:"businessConfirmed",text:"Daily Stats Confirmed by Business"}

                          ])

wg.summaryOneBoxList = ko.observableArray([]);
wg.summaryDataFilter = ko.observableArray([]);
wg.inputsearch = ko.observable('');

wg.summaryprocessesList = ko.observableArray([]);
wg.summarydocumentsList = ko.observableArray([]);
wg.summaryassetsList = ko.observableArray([]);
wg.summarydependenciesList = ko.observableArray([]);
wg.summaryothersList = ko.observableArray([]);
wg.summaryresourcesList = ko.observableArray([]);

wg.searchresult = ko.observable(false);
wg.summaryresprocessesList = ko.observableArray([]);
wg.summaryresdocumentsList = ko.observableArray([]);
wg.summaryresassetsList = ko.observableArray([]);
wg.summaryresdependenciesList = ko.observableArray([]);
wg.summaryresothersList = ko.observableArray([]);
wg.summaryresresourcesList = ko.observableArray([]);
wg.disabledExportPdf = ko.observable(false)
wg.statusTemplate = ko.observable('')
wg.filter = {
              Region:ko.observableArray([]), RegionList:ko.observableArray([]),
              Cefcritical:ko.observableArray([]),
              Pfpcritical:ko.observableArray([]),
              ReceiverCountry:ko.observableArray([]),ReceiverCountryList:ko.observableArray([]),
              ReceiverLegalEntity:ko.observableArray([]),ReceiverLegalEntityList:ko.observableArray([]),
              SupplierCountry:ko.observableArray([]),supplycountryList:ko.observableArray([]),
              SupplierLegalEntity:ko.observableArray([]),supplylegalentityList:ko.observableArray([]),
              LegalSignatory: ko.observableArray([]),LegalSignatoryList:ko.observableArray([]),   
              Categoryname:ko.observableArray([]),categorynameList:ko.observableArray([]),   
              Suppliertype:ko.observableArray([]),supplytypeList:ko.observableArray([]),   
              Productfunction:ko.observableArray([]),productList:ko.observableArray([]),
              Functiontype:ko.observableArray([]),functionTypeList:ko.observableArray([]),
              Parentprocessname:ko.observableArray([]),parentprocessnameList:ko.observableArray([]),
              GPO:ko.observableArray([]),globalprocessownerList:ko.observableArray([]),
              dailystatus: ko.observable(false)
            }
wg.defaultChart =   [{page:1,   filters:wg.filter,  
                                summaries:[{keyID:'1-1', type:'',filter:''},{keyID:'1-2', type:'',filter:''},{keyID:'1-3', type:'',filter:''},{keyID:'1-4', type:'',filter:''},{keyID:'1-5', type:'',filter:''},{keyID:'1-6', type:'',filter:''},{keyID:'1-7', type:'',filter:''},{keyID:'1-8', type:'',filter:''}],
                                charts:[{keyID:'1-1', type:'',filter:''},{keyID:'1-2',type:'',filter:''},{keyID:'1-3',type:'',filter:''}]                                    
                            }];

wg.templateChart = ko.mapping.fromJS(wg.defaultChart) 
wg.templateChartCurrent = ko.mapping.fromJS(wg.defaultChart) 
wg.templateFilter = ko.mapping.fromJS([wg.filter]) 

wg.valueProductFunctionName = ko.observable();
wg.popupvalue = ko.observable(true);
wg.loading = ko.observable(false);

wg.summaries = []
wg.summaries[0] = [{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false}]
wg.charts = []
wg.charts[0] = [{value:'',status:false},{value:'',status:false},{value:'',status:false}]

wg.loadingFilter = {Region:false,ReceiverCountry:false,ReceiverLegalEntity:false,supplycountry:false,supplylegalentity:false,categoryname:false,supplytype:false,product:false,Functiontype:false,Parentprocessname:false,GPO:false}

wg.useTemplateStatus = ko.observable(false);
wg.reloadPageStatus  = []
wg.reloadPageStatus[0]  = false
wg.pageValue = ko.observable(0)  
wg.listEmail = ko.observableArray([])
wg.emailValue = ko.observable({mailsubject:"[OCIR Reporting]", mailmsg:"", mailto:[], mailcc:[]});
wg.disableValTemplate = ko.observable(true);
wg.disableValPage = ko.observable(true)


// GET DATA  FILTER //
wg.getReceivingCountry = function(index,payload){
    var url = "/ociranalysis/getreceivercountry";
    ajaxPost(url,payload, function (res){
      var receivingCountries = [];
      $.each(res, function(i,v){
        receivingCountries.push({text:v._id, value:v._id})
      });
      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.ReceiverCountryList = receivingCountries;
      ko.mapping.fromJS(config,wg.templateChartCurrent)
        
      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].ReceiverCountryList = receivingCountries
      ko.mapping.fromJS(filters,wg.templateFilter) 
       
      wg.loadingFilter.ReceiverCountry = false
    })
};
wg.getReceivingLegalEntity = function(index,payload){
    var url = "/ociranalysis/getlegalentityreceiver";
    ajaxPost(url,payload, function (res){
      var legalEntities = [];
      $.each(res, function(i,v){
        legalEntities.push({text:v._id, value:v._id})
      });
      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.ReceiverLegalEntityList = legalEntities;
      ko.mapping.fromJS(config,wg.templateChartCurrent) 

      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].ReceiverLegalEntityList = legalEntities
      ko.mapping.fromJS(filters,wg.templateFilter) 

      wg.loadingFilter.ReceiverLegalEntity = false;
    });
};
wg.getSupplyCountry = function(index,payload){
    var url = "/ociranalysis/getsuppliercountry";
    ajaxPost(url,payload, function (res){
      var country = []
      $.each(res, function(index, result){
        country.push({text:result._id, value:result._id});
      }); 
      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.supplycountryList = country;
      ko.mapping.fromJS(config,wg.templateChartCurrent)
        

      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].supplycountryList = country
      ko.mapping.fromJS(filters,wg.templateFilter)  

      wg.loadingFilter.SupplierCountry = false
    });
};
wg.getSupplyLegalEntity = function(index,payload){
    var url = "/ociranalysis/getlegalentitysupplier";
    ajaxPost(url,payload, function (res){
      var entity = []
      $.each(res, function(index, result){
        entity.push({text:result._id, value:result._id});
      });
            
      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.supplylegalentityList = entity;
      ko.mapping.fromJS(config,wg.templateChartCurrent)
            
      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].supplylegalentityList = entity;
      ko.mapping.fromJS(filters,wg.templateFilter);

      wg.loadingFilter.SupplierLegalEntity = false
    });
};
wg.getSupplyType = function(index,payload){
    var url = "/ociranalysis/getsuppliertype";
    ajaxPost(url,payload, function (res){
      var supplier = []
      $.each(res, function(index, result){
        var results;
        if(result._id == 'IGS'){
          results = "Intra-Group"
        } else if(result._id == 'FMI'){
          results = "FMI"
        } else if(result._id == 'FMI_System'){
          results = "FMI Systems"
        } else if(result._id == 'FMI_TPS'){
          results = "FMI External"
        } else if(result._id == 'TPS'){
          results = "External"
        } else if(result._id == 'Teams'){
          results = "In-Entity"
        } else {
          results = "Systems"
        }
        supplier.push({text:results, value:result._id});
      }); 
      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.supplytypeList = supplier;
      ko.mapping.fromJS(config,wg.templateChartCurrent)
       
      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].supplytypeList = supplier;
      ko.mapping.fromJS(filters,wg.templateFilter);
      wg.loadingFilter.Suppliertype = false;
    });
};
wg.getCategoryName = function(index,payload){
    var url = "/ociranalysis/getcategory";
    ajaxPost(url,payload, function (res){
      var category = []
      $.each(res, function(index, result){
        category.push({"name" : result._id,"text": result._id});
      }); 
      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.categorynameList = category;
      ko.mapping.fromJS(config,wg.templateChartCurrent)
        
      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].categorynameList = category;
      ko.mapping.fromJS(filters,wg.templateFilter)
      wg.loadingFilter.Categoryname = false;
    });
};
wg.getProduct = function(index,payload){
    var url = "/ociranalysis/getproductfunction";
    ajaxPost(url,payload, function (res){
      var product = []
      $.each(res, function(index, result){
        product.push({"name" : result._id,"text": result._id});
      });
      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.productList = product;
      ko.mapping.fromJS(config,wg.templateChartCurrent);

      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].productList = product
      ko.mapping.fromJS(filters,wg.templateFilter)
      wg.loadingFilter.Productfunction = false;
    });
};
wg.getRegion = function(index, payload){
  var url = "/ociranalysis/getregion";
    ajaxPost(url,payload, function (res){
      var regions = [];
      $.each(res, function(i,v){
        regions.push({text:v._id, value:v._id})
      });

      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.RegionList = regions;
      ko.mapping.fromJS(config,wg.templateChartCurrent)
        
      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].RegionList = regions
      ko.mapping.fromJS(filters,wg.templateFilter) 
       
      wg.loadingFilter.Region = false
    })
};
wg.getFunction = function(index, payload){
  var url = "/ociranalysis/getfunctiontype";
    ajaxPost(url,payload, function (res){
      var regions = [];
      $.each(res, function(i,v){
        regions.push({text:v._id, value:v._id})
      });

      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.functionTypeList = regions;
      ko.mapping.fromJS(config,wg.templateChartCurrent)
        
      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].functionTypeList = regions
      ko.mapping.fromJS(filters,wg.templateFilter) 
       
      wg.loadingFilter.Functiontype = false
    })
};
wg.getParentProcessName = function(index,payload){
    var url = "/ociranalysis/getparentprocessname";
    ajaxPost(url,payload, function (res){
      var parentprocessname = [];
      $.each(res, function(i,v){
        parentprocessname.push({text:v._id, value:v._id})
      });
      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.parentprocessnameList = parentprocessname;
      ko.mapping.fromJS(config,wg.templateChartCurrent)
        
      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].parentprocessnameList = parentprocessname
      ko.mapping.fromJS(filters,wg.templateFilter) 
       
      wg.loadingFilter.Parentprocessname = false
    })
};
wg.getGlobalProcessOwner = function(index,payload){
    var url = "/ociranalysis/getgpo";
    ajaxPost(url,payload, function (res){
      var globalprocessowner = [];
      $.each(res, function(i,v){
        globalprocessowner.push({text:v._id, value:v._id})
      });
      config = ko.mapping.toJS(wg.templateChartCurrent);
      config[index].filters.globalprocessownerList = globalprocessowner;
      ko.mapping.fromJS(config,wg.templateChartCurrent)
        
      filters = ko.mapping.toJS(wg.templateFilter);
      filters[index].globalprocessownerList = globalprocessowner
      ko.mapping.fromJS(filters,wg.templateFilter) 
       
      wg.loadingFilter.GPO = false
    })
};

// GET DATA OTHER //
wg.getSummaryListBox = function(){
    ajaxPost("/widgetanalysis/getlistsummarybox",{} , function (res){
        var datas = []
        var dataFilter = []
        $.each(res.Data, function(index, result){
            datas.push({"text" : result.desc,"value": result.id,"type":result.type});
            dataFilter.push(result.desc)
        });
        wg.summaryOneBoxList(datas)
        wg.summaryDataFilter(dataFilter);
    })
    wg.search();
};
wg.getTemplate = function(){
    ajaxPost("/widgetanalysis/gettemplatename",{}, function (res){
        var datas = []
        $.each(res.Data, function(i,v){

          // if(parseInt(i) == 0){
          datas.push({text:v._id,value:v._id, status:v.status})
          
          // }else{
          //   datas.push({text:v._id,value:v._id, status:'Private'})
          // }
        })
       wg.templateList(datas)
       wg.templateList2(datas)
    })
};

// GENERATE SUMMARY//
wg.addSummary = function(filter,type){
    return function(){
        $('#summarymodal').modal('toggle');
        var config = ko.mapping.toJS(wg.templateChartCurrent);
        id = config[wg.activePage()].summaries[wg.activeIndexSummary()].keyID;
        wg.settingTemplate('summaries',wg.activePage(),wg.activeIndexSummary(),type)
        wg.generateSummary(filter,id,type,wg.activePage(),wg.activeIndexSummary(),true)
   }
};
wg.generateSummary = function(filter,id,type,pageIndex,index,onchangStatus){ 
    config = ko.mapping.toJS(wg.templateChartCurrent);
     var filters = config[pageIndex].filters
    config[pageIndex].summaries[index].filter = filter
    ko.mapping.fromJS(config, wg.templateChartCurrent)
   
    payload = wg.parsetFilter(filters);
    
    $.extend( payload, {BoxType:filter});
     
    if(index <= 3){
        var position = 'left';
    }else{
         var position = 'right';
    }
    if(wg.summaries[pageIndex][index].status && !onchangStatus){
       if ($('.'+position+'-text_summary-'+id).css('display') != 'none') {
          $('.'+position+'-text_summary-'+id).hide('slow')
        }
       
        $('#'+position+'-box_summary-'+id).css( "border-width", "0px" );
        $('.'+position+'-container_summary-'+id).show('slow');
        $('.'+position+'-close_summary-'+id).show('slow');
        $('#'+position+'-total_summary-'+id).show('slow');
        $('#'+position+'-desc_summary-'+id).show('slow');
        $('#'+position+'-total_summary-'+id).text(wg.summaries[pageIndex][index].value);
        $('#'+position+'-desc_summary-'+id).text(type); 
    }else{
      ajaxPost("/widgetanalysis/getwidgetsummarybox",payload , function (res){
          if ($('.'+position+'-text_summary-'+id).css('display') != 'none') {
            $('.'+position+'-text_summary-'+id).hide('slow')
          }
          var total = kendo.toString(res.Data, "n0");
          wg.summaries[pageIndex][index].value = total 
          wg.summaries[pageIndex][index].status = true 
          $('#'+position+'-box_summary-'+id).css( "border-width", "0px" );
          $('.'+position+'-container_summary-'+id).show('slow');
          $('.'+position+'-close_summary-'+id).show('slow');
          $('#'+position+'-total_summary-'+id).show('slow');
          $('#'+position+'-desc_summary-'+id).show('slow');
          $('#'+position+'-total_summary-'+id).text(total);
          $('#'+position+'-desc_summary-'+id).text(type); 
      }) 
    }  
};
 
// GENERATE CHART //
wg.addChart =  function(type,id,typeChart,page,index){
    return function(){
        pageIndex = page - 1;
        wg.settingTemplate(type,pageIndex,index,typeChart)
        wg.activeIndexChart(index)
        switch(typeChart){
            case'bar':
              $("#bar-filter-modal").modal('show'); 
            break;
            case'donut':
              $("#donut-filter-modal").modal('show'); 
            break;
            default:
              $("#grid-filter-modal").modal('show'); 
        }  
    }
};
wg.createChart = function(typeChart,filterValue){
  return function(){
    switch(typeChart){
        case'bar':
          $("#bar-filter-modal").modal('toggle'); 
        break;
        case'donut':
          $("#donut-filter-modal").modal('toggle'); 
        break;
        default:
          $("#grid-filter-modal").modal('toggle'); 
    }
    config = ko.mapping.toJS(wg.templateChartCurrent)
    id ='chart-'+config[wg.activePage()].charts[wg.activeIndexChart()].keyID; 
    
    if(config[wg.activePage()].charts[wg.activeIndexChart()].filter === '% Validated all Countries' || config[wg.activePage()].charts[wg.activeIndexChart()].filter === '% Enriched all Countries'){
      $('#container-full-chart-'+wg.activePage()).hide('fast')
      $('#container-normal-chart-'+wg.activePage()).show('slow')
 
      $(".container-filter-"+id).hide('slow');
      $("#legend-donut_"+id).remove('');
      $('.close_'+id).hide('fast');
      $('.text_'+id).show('slow');
      $('#icon-plus_'+id).show( "fast" )
      $('#'+id).remove('')
      $('#legend-donut_'+id).remove('')
      $('#box_'+id).css( "border-width", "2px" );
      $('.container_'+id).append('<div id="'+id+'"></di>')

    }else if( config[wg.activePage()].charts[wg.activeIndexChart()].filter == 'Comparison Region [% Validated Service]' ||  config[wg.activePage()].charts[wg.activeIndexChart()].filter == 'Comparison Region [% Confirmed Service]' ){
      if(wg.charts[wg.activePage()][wg.activeIndexChart()].value.length >=  19){
        $('#container-full-chart-'+wg.activePage()).hide('fast')
        $('#container-normal-chart-'+wg.activePage()).show('slow')
        $(".container-filter-"+id).hide('slow');
        $("#legend-donut_"+id).remove('');
        $('.close_'+id).hide('fast');
        $('.text_'+id).show('slow');
        $('#icon-plus_'+id).show( "fast" )
        $('#'+id).remove('')
        $('#legend-donut_'+id).remove('')
        $('#box_'+id).css( "border-width", "2px" );
        $('.container_'+id).append('<div id="'+id+'"></di>')
      }
    } 
    config[wg.activePage()].charts[wg.activeIndexChart()].filter = filterValue;
    ko.mapping.fromJS(config , wg.templateChartCurrent) 
    wg.generateChart(id,typeChart,wg.activePage(),wg.activeIndexChart(),true)
  }
};
wg.generateChart = function(id,type,page,index,onchangStatus){ 
    if($('.text_'+id).is(':visible') == true){
      $('.text_'+id).hide('fast');
    }
    $('.text_'+id).hide('fast');
    $('#icon-plus_'+id).hide('fast');
    $('.messege-pop-up_'+id).hide('fast');
    $('#box_'+id).css( "border-width", "0px" );
    $('.close_'+id).show('slow');
    $(".container-filter-"+id).show('slow');  
    switch(type){
        case'bar':
            wg.createBar(id,page,index,onchangStatus)
        break;
        case'donut':
            wg.createDonut(id,page,index,onchangStatus)
        break;
        default: 
            wg.createGrid(id,page,index,onchangStatus)
    } 
};

// GENERATE TEMPLATE AND FILTER //
wg.generateTemplate =  function(index){
  wg.loading(true)
  wg.loadingFilter = {Region:true,ReceiverCountry:true,ReceiverLegalEntity:true,SupplierCountry:true,SupplierLegalEntity:true,Categoryname:true,Suppliertype:true,Productfunction:true,Functiontype:true,Parentprocessname:true,GPO:true}
  wg.reloadPageStatus[index] = true;
  var config = ko.mapping.toJS(wg.templateChartCurrent) 
  var filter = ko.mapping.toJS(wg.templateFilter)
  payload  = wg.parsetFilter(config[index].filters)
  delete payload['Cefcritical']
  delete payload['Pfpcritical']

  if(config[index].filters.Region.length > 0){
    value = config[index].filters.Region;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.RegionList = datas
    filter[index].RegionList = datas
    wg.loadingFilter.Region = false;
  }else{
     wg.getRegion(index,payload)
  }

  if(config[index].filters.ReceiverCountry.length > 0){
    value = config[index].filters.ReceiverCountry;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.ReceiverCountryList = datas
    filter[index].ReceiverCountryList = datas
    wg.loadingFilter.ReceiverCountry = false;
  }else{
     wg.getReceivingCountry(index,payload)
  }

  if(config[index].filters.ReceiverLegalEntity.length > 0){
    value = config[index].filters.ReceiverLegalEntity;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.ReceiverLegalEntityList = datas
    filter[index].ReceiverLegalEntityList = datas
    wg.loadingFilter.ReceiverLegalEntity = false
  }else{
     wg.getReceivingLegalEntity(index,payload)
  }

  if(config[index].filters.SupplierCountry.length > 0){
    value = config[index].filters.SupplierCountry;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.supplycountryList = datas
    filter[index].supplycountryList = datas
    wg.loadingFilter.SupplierCountry = false
  }else{
     wg.getSupplyCountry(index,payload)
  }

  if(config[index].filters.SupplierLegalEntity.length > 0){
    value = config[index].filters.SupplierLegalEntity;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.supplylegalentityList = datas

    filter[index].supplylegalentityList = datas
    wg.loadingFilter.SupplierLegalEntity = false
  }else{
     wg.getSupplyLegalEntity(index,payload)
  }

  if(config[index].filters.Categoryname.length > 0){
    value = config[index].filters.Categoryname;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.categorynameList = datas

    filter[index].categorynameList = datas
    wg.loadingFilter.Categoryname = false
  }else{
     wg.getCategoryName(index,payload)
  }

  if(config[index].filters.Suppliertype.length > 0){
    value = config[index].filters.Suppliertype;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.supplytypeList = datas

    filter[index].supplytypeList = datas
     wg.loadingFilter.Suppliertype = false
  }else{
     wg.getSupplyType(index,payload)
  }

  if(config[index].filters.Productfunction.length > 0){
    value = config[index].filters.Productfunction;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.productList = datas

    filter[index].productList = datas
    wg.loadingFilter.Productfunction = false
  }else{
     wg.getProduct(index,payload)
  }

  if(config[index].filters.Parentprocessname.length > 0){
    value = config[index].filters.Parentprocessname;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.parentprocessnameList = datas
    filter[index].parentprocessnameList = datas
    wg.loadingFilter.Parentprocessname = false;
  }else{
     wg.getParentProcessName(index,payload)
  }

  if(config[index].filters.GPO.length > 0){
    value = config[index].filters.GPO;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.GlobalprocessownerList = datas
    filter[index].GlobalprocessownerList = datas
    wg.loadingFilter.GPO = false;
  }else{
     wg.getGlobalProcessOwner(index,payload)
  }

  if(config[index].filters.Functiontype.length > 0){
    value = config[index].filters.Productfunction;
    var datas = []
    for(var x in value){
      datas.push({text : value[x], value : value[x]})
    } 
    config[index].filters.functionTypeList = datas

    filter[index].productList = datas
    wg.loadingFilter.Functiontype = false
  }else{
     wg.getFunction(index,payload)
  }
  
  ko.mapping.fromJS(filter,wg.templateFilter)
  ko.mapping.fromJS(config,wg.templateChartCurrent)
  
  for(var i in config[index].summaries){
    var id =  config[index].summaries[i].keyID;
    if(config[index].summaries[i].type != ''){
      wg.generateSummary(config[index].summaries[i].filter,id, config[index].summaries[i].type,index,i, false)    
    }
  }

  for(var i in config[index].charts){
    var id = 'chart-'+  config[index].charts[i].keyID;
    if(config[index].charts[i].type != ''){
      wg.generateChart(id,config[index].charts[i].type,index,i,false)   
    }
  }
  var checkStatusFilter  = setInterval(function(){ 
      if(!wg.loadingFilter['Region'] && !wg.loadingFilter['ReceiverCountry'] && !wg.loadingFilter['ReceiverLegalEntity'] && !wg.loadingFilter['SupplierCountry'] && !wg.loadingFilter['SupplierLegalEntity']     && !wg.loadingFilter['Categoryname'] && !wg.loadingFilter['Suppliertype']&& !wg.loadingFilter['Productfunction']&& !wg.loadingFilter['Parentprocessname']&& !wg.loadingFilter['GPO'] ){
        wg.loading(false) 
        clearInterval(checkStatusFilter)
      }
    }, 500); 
};
wg.parsetFilter = function(filters){
    // console.log(filters);
    payload = {}
    var keyPayload  = ['Region','Cefcritical','Pfpcritical','ReceiverCountry','ReceiverLegalEntity','SupplierCountry','SupplierLegalEntity','LegalSignatory','Categoryname','Suppliertype','Productfunction','Functiontype','Parentprocessname','GPO','dailystatus']
    for(i in keyPayload){
      payload[keyPayload[i]] = filters[keyPayload[i]]
    }
    // console.log(payload);
    return payload;
};

wg.generateFilter =  function(value,pageIndex,filterName){
    eventfilters = {
                    ReceiverCountry:'getReceivingCountry',
                    ReceiverLegalEntity:'getReceivingLegalEntity',
                    SupplierCountry:'getSupplyCountry',
                    SupplierLegalEntity:'getSupplyLegalEntity',
                    Categoryname:'getCategoryName',
                    Suppliertype:'getSupplyType',
                    Productfunction:'getProduct',
                    Region:'getRegion',
                    Functiontype:'getFunction',
                    Parentprocessname:'getParentProcessName',
                    GPO: 'getGlobalProcessOwner'
                   }
    config = ko.mapping.toJS(wg.templateChartCurrent)
    var filters = config[pageIndex].filters
    var payload = wg.parsetFilter(filters);
    
    delete payload["Cefcritical"]; 
    delete payload["Pfpcritical"];

    for(var i in eventfilters){
      if(i === filterName){
        if(value === '' || value.length == 0){
          wg[eventfilters[i]](pageIndex,payload)
        }
      }else if(i !== filterName || i !== 'Suppliertype'){
        wg[eventfilters[i]](pageIndex,payload)
      }
    }
};
wg.template.subscribe(function(newValue){
  if(wg.disableValTemplate()){
    if(newValue === ''){
      wg.useTemplateStatus(false);
      wg.template('')
      wg.templateName('')
      wg.activePage(0)    
      wg.activeIndexSummary(0)
      wg.totalPage(1);
      ko.mapping.fromJS(wg.defaultChart ,wg.templateChartCurrent)
      ko.mapping.fromJS(wg.defaultChart ,wg.templateChart)
    }else{

      wg.pageValue(0)
      wg.disabledExportPdf(true)
      wg.templateName(newValue)
      ajaxPost("/widgetanalysis/getdetailstemplatename",{id:newValue}, function (res){
        wg.disableValTemplate(false);
        wg.statusTemplate(res.Data.status)
        wg.useTemplateStatus(true);
       
        ko.mapping.fromJS(res.Data.details, wg.templateChartCurrent)
        ko.mapping.fromJS(res.Data.details, wg.templateChart)
        wg.totalPage(res.Data.details.length);
        
        var datafilters = []
        wg.reloadPageStatus = []
        wg.summaries = []
        wg.charts = []
        var templateFilter = []
        var templateFilter = [];
        
        for(var i in res.Data.details){
          datafilters.push({text: parseInt(i) + 1, value:parseInt(i)}) 
          wg.reloadPageStatus.push(false)  
          wg.summaries.push([{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false},{value:'',status:false}]) 
          wg.charts.push([{value:'',status:false},{value:'',status:false},{value:'',status:false}]) 
          templateFilter.push(res.Data.details[i].filters);

          for(x in res.Data.details[i].summaries){
            var summary = res.Data.details[i].summaries[x]
            if(summary.type !== ''){ 
              wg.insertValueSummaries(res.Data.details[i].filters, summary.type, summary.filter, i, x);
            }
          }
          for(n in res.Data.details[i].charts){
            var chart = res.Data.details[i].charts[n]
            // console.log(chart)
            // console.log(chart.type)
            if(chart.type !== ''){
              wg.insertValueCharts(res.Data.details[i].filters, chart.type, chart.filter, i, n);
            }
          }
        }
        ko.mapping.fromJS(ko.mapping.fromJS(templateFilter),wg.templateFilter) 
        wg.activePageList(datafilters)
        wg.activePage(0)
        wg.generateTemplate(0)
        var checkAjaxDone =  setInterval(function(){
                              notDoneStatus = 0;
                              for(var i in res.Data.details){
                                for(x in res.Data.details[i].summaries){
                                  var summary = res.Data.details[i].summaries[x]
                                  if(summary.type !== '' && wg.summaries[i][x].status === false ){ 
                                    notDoneStatus += 1
                                  }
                                }
                                for(n in res.Data.details[i].charts){
                                  var chart = res.Data.details[i].charts[n]
                                  if(chart.type !== '' && wg.charts[i][n].status === false){
                                      notDoneStatus += 1  
                                  }
                                }
                              }
                              if(parseInt(notDoneStatus) === 0){
                                wg.disabledExportPdf(false)
                                clearInterval(checkAjaxDone)
                              }
                            },1000)
      })
    }
  }
  wg.disableValTemplate(true) 
});

// CREATE BAR CHART //
wg.createBar = function(id,pageIndex,index,onchangeStatus){
    config = ko.mapping.toJS(wg.templateChartCurrent);
    var filters = config[pageIndex].filters
    var type = config[pageIndex].charts[index].filter

    var titleButton;
    $.each(wg.filterChartBarList(), function(i, v){
        if (v.value == type){
          titleButton = v.text      
        }
    })

    $("#button-filter_"+id).text(titleButton) 
    
    var payload = wg.parsetFilter(filters);
    $.extend(payload,{Flag:type}) 
    if(wg.charts[pageIndex][index].status && !onchangeStatus){
     
      if(type == 'Comparison Region [% Validated Service]' || type == 'Comparison Region [% Confirmed Service]'){
        if(wg.charts[pageIndex][index].value.length >=  19){
          $('#container-normal-chart-'+ pageIndex).hide('fast')
          $('#container-full-chart-'+ pageIndex).show('slow')
          $("#button-filter-full-chart-"+ pageIndex).text(titleButton) 
          $("#full-chart-" + pageIndex).html('')
          wg.barFull(wg.charts[pageIndex][index].value,type,pageIndex);
          checkStatusFilter = setInterval(function(){ 
            if(!wg.loading()){
              clearInterval(checkStatusFilter)
              setTimeout(function(){
                kendo.resize($("#full-chart-" + pageIndex));
              },200)
            }
          }, 500); 
         
        }else{
          wg.bar(wg.charts[pageIndex][index].value,type,id,index);
        }
      }else if(type == 'Worst 10% Validated' || type == 'Worst 10% Enriched' || type == 'Worst 10% Validated by Business/Function' || 
         type == 'Worst 10% Enriched by Business/Function' ||  type == 'Best 10 [% Validated]' || type == 'Best 10 [% Enriched]' || type == 'Pending Best 10 [% Validated]' || type == 'Pending Best 10 [% Enriched]' ||
         type == 'Pending Worst 10 [% Validated]' || type == 'Pending Worst 10 [% Enriched]'  ){
         wg.bar(wg.charts[pageIndex][index].value,type,id,index);
       
      }else if(type == '% Enriched all Countries' || type == '% Validated all Countries'){
        $('#container-normal-chart-'+ pageIndex).hide('fast')
        $('#container-full-chart-'+ pageIndex).show('slow')
        $("#button-filter-full-chart-"+ pageIndex).text(titleButton) 
        $("#full-chart-" + pageIndex).html('')

        wg.barFull(wg.charts[pageIndex][index].value,type,pageIndex);
        
        checkStatusFilter = setInterval(function(){ 
          if(!wg.loading()){
            clearInterval(checkStatusFilter)
            setTimeout(function(){
              kendo.resize($("#full-chart-" + pageIndex));
            },200)
          }
        }, 500); 
      }else if(type == 'Systems per business/function'){
        wg.barStacked(wg.charts[pageIndex][index].value, type, id, index) 
      }else if(type == 'Processes per critical service provider' || type == 'Critical Service Providers by FTE' || type == 'Location by FTE'){
         wg.barStackedCategory(wg.charts[pageIndex][index].value, type, id, index) 
      }else{
        var sortDatas = sortBarChart(wg.charts[pageIndex][index].value)
        wg.bar(sortDatas,type,id,index);
      }
    }else{  
      switch(type){

          case 'Service FTE':
              ajaxPost("/ociranalysis/servicefte", payload , function (res){
                  var datas = res;
                  var sortDatas = sortBarChart(datas)
                  wg.bar(sortDatas,type,id,index)

                  wg.charts[pageIndex][index].value = sortDatas
                  wg.charts[pageIndex][index].status = true            
              });
          break;
          case 'Fte by Country':
              if ( payload.SupplierCountry.length == 0){
                  ajaxPost("/ociranalysis/ftebycountry", payload , function (res){
                      var datas = res;
                      var sortDatas = sortBarChart(datas); 
                      wg.bar(sortDatas,type,id,index)
                      wg.charts[pageIndex][index].value = sortDatas
                      wg.charts[pageIndex][index].status = true            
                  })
              }else {
                  ajaxPost("/ociranalysis/ftebycountrylegal", payload , function (res){
                      var datas = res;
                      var sortDatas = sortBarChart(datas);  
                      wg.bar(sortDatas,type,id,index)   
                      wg.charts[pageIndex][index].value = sortDatas
                      wg.charts[pageIndex][index].status = true    
                  })        
              }  
          break;
          case 'level 1 by country':
              ajaxPost("/ociranalysis/levelbycountry", payload , function (res){
                
                  datas = []
                  max = 10;
                  if(res.length < 10){
                    max = res.length
                  }
                  for(i=0; i<max; i++){
                    datas.push({Count:res[i].Count,_id:res[i]._id})
                  }
           
                  var sortDatas = sortBarChart(datas);  
                  wg.bar(sortDatas,type,id,index)       
                  wg.charts[pageIndex][index].value = sortDatas
                  wg.charts[pageIndex][index].status = true    
              
              })
          break;
          case 'Assets Utilized':
              ajaxPost("/ociranalysis/getassetsutilized", payload , function (res){
                  var datas = res;
                  var sortDatas = sortBarChart(datas);  
                  wg.bar(sortDatas,type,id,index,index)
                  wg.charts[pageIndex][index].value = sortDatas
                  wg.charts[pageIndex][index].status = true    
                     
              })
          break;
          case 'Biggest': 
            ajaxPost("/ociranalysis/receivercategoryproduct", payload , function (res){
                   
                data = []
                max = 10;
                if(res.length < 10){
                  max = res.length
                }
                     
                for(i=0; i<max; i++){
                  data.push({Count:res[i].Value,_id:res[i].Country})
                }
                wg.bar(data,type,id,index)    
                wg.charts[pageIndex][index].value = data
                wg.charts[pageIndex][index].status = true    
              
            });       
          break;
          case 'Process by GBS and Others':
            ajaxPost("/ociranalysis/processbygbs", payload , function (res){
              var datas = res;
              var sortDatas = sortBarChart(datas);
              data = []
              max = 10;
              if(sortDatas.length < 10){
                max = sortDatas.length
              }
                   
              for(i=0; i<max; i++){
                data.push({Count:res[i].Count,_id:res[i]._id,Color:res[i].Color})

              }
              wg.bar(data,type,id,index)    
              wg.charts[pageIndex][index].value = data
              wg.charts[pageIndex][index].status = true

            })
          break;
          case 'Worst 10 [% Validated]' :
            var newPayload = $.extend(payload,{WorstType : "validated"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
              
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true 
            });
          break;
          case 'Worst 10 [% Enriched]':
              var newPayload = $.extend(payload,{WorstType : "enriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)     
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true 
              });
          break;
          case 'Worst 10% Validated by Business/Function':
              var newPayload = $.extend(payload,{WorstType : "businnessvalidated"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true 
              });
          break;
          case 'Worst 10% Enriched by Business/Function':
              var newPayload = $.extend(payload,{WorstType : "businnessenriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true   
              });
          break;
          case '% Validated all Countries': 
            $('#container-normal-chart-'+pageIndex).hide('fast')
            $('#container-full-chart-'+pageIndex).show('slow')
            $("#button-filter-full-chart-"+pageIndex).text(titleButton) 
            $("#full-chart-" + pageIndex).html('')
            var newPayload = $.extend(payload,{WorstType : "validated"});
            ajaxPost("/ociranalysis/percentvalidated", newPayload , function (res){
              wg.barFull(res,type,pageIndex);

                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true 
            });
          break;
          case '% Enriched all Countries':
            $('#container-normal-chart-'+pageIndex).hide('fast')
            $('#container-full-chart-'+pageIndex).show('slow')
            $("#button-filter-full-chart-"+pageIndex).text(titleButton)
            $("#full-chart-" + pageIndex).html('')
            var newPayload = $.extend(payload,{WorstType : "enriched"});
                
            ajaxPost("/ociranalysis/percentvalidated", newPayload , function (res){
              wg.barFull(res,type,pageIndex);

                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true 
            });
          break;
          case 'Best 10 [% Validated]' :
              var newPayload = $.extend(payload,{WorstType : "reversevalidated"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                 wg.bar(res,type,id,index) 
                 wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true   
              });
          break;
          case 'Best 10 [% Enriched]':
              var newPayload = $.extend(payload,{WorstType : "reverseenriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true
              });
          break;
          case 'Pending Best 10 [% Validated]':
              var newPayload = $.extend(payload,{WorstType : "pendingbestvalidated"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                 wg.bar(res,type,id,index) 
                 wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true   
              });
          break;
          case 'Pending Best 10 [% Enriched]':
              var newPayload = $.extend(payload,{WorstType : "pendingbestenriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true
              });
          break;
          case 'Pending Worst 10 [% Validated]':
              var newPayload = $.extend(payload,{WorstType : "pendingworstvalidated"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                 wg.bar(res,type,id,index) 
                 wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true   
              });
          break;
          case 'Pending Worst 10 [% Enriched]':
              var newPayload = $.extend(payload,{WorstType : "pendingworstenriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true
              });
          break;
          case 'Comparison Region [% Validated Service]':
            var newPayload = $.extend(payload,{WorstType : "validated"});
       
            ajaxPost("/ociranalysis/comparisonregion", newPayload , function (res){
            
              if (res.length >= 19) { 
                $('#container-normal-chart-'+pageIndex).hide('fast')
                $('#container-full-chart-'+pageIndex).show('slow')
                $("#button-filter-full-chart-"+pageIndex).text(titleButton) 
                $("#full-chart-" + pageIndex).html('')
                setTimeout(function(){
                    wg.barFull(res,type,pageIndex);    
                },1000);
              }else{
                if(wg.charts[pageIndex][index].value.length >=  19){
                   id ='chart-'+config[pageIndex].charts[index].keyID;  
                   $('#container-full-chart-'+ pageIndex).hide('fast')
                   $('#container-normal-chart-'+ pageIndex).show('slow')
                }
                wg.bar(res,type,id,index)    
              };
              wg.charts[pageIndex][index].value = res
              wg.charts[pageIndex][index].status = true
            });
          break;
          case 'Comparison Region [% Confirmed Service]':
            var newPayload = $.extend(payload,{WorstType : "enriched"});
            if(wg.charts[pageIndex][index].value.length >=  19){
             id ='chart-'+config[pageIndex].charts[index].keyID;  
             $('#container-full-chart-'+ pageIndex).hide('fast')
             $('#container-normal-chart-'+ pageIndex).show('slow')
             
    
            }
            ajaxPost("/ociranalysis/comparisonregion", newPayload , function (res){
               
              if (res.length >= 19) {
                      
                $('#container-normal-chart-'+ pageIndex).hide('fast')
                $('#container-full-chart-'+ pageIndex).show('slow')
                $("#button-filter-full-chart-"+ pageIndex).text(titleButton) 
                $("#full-chart-" + pageIndex).html('')
                setTimeout(function(){
                    wg.barFull(res,type,pageIndex);    
                },1000);
              }else{
               
                if(wg.charts[pageIndex][index].value.length >=  19){
                   id ='chart-'+config[pageIndex].charts[index].keyID;  
                   $('#container-full-chart-'+ pageIndex).hide('fast')
                   $('#container-normal-chart-'+ pageIndex).show('slow')
                }
                wg.bar(res,type,id,index)    
              }; 
              wg.charts[pageIndex][index].value = res
              wg.charts[pageIndex][index].status = true
            });
          break;
          case 'Worst 10 by Process Owner [% Validated Service]':
            var newPayload = $.extend(payload,{WorstType : "worstownervalidated"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true
            });
          break;
          case 'Worst 10 by Process Owner [% Confirmed Service]':
           var newPayload = $.extend(payload,{WorstType : "worstownerenriched"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true
            });
          break;
          case 'Best 10 by Process Owner [% Validated Service]':
            var newPayload = $.extend(payload,{WorstType : "bestownervalidated"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true
            });
          break;
          case 'Best 10 by Process Owner [% Confirmed Service]':
            var newPayload = $.extend(payload,{WorstType : "bestownerenriched"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.bar(res,type,id,index)    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true
            });
          break;
          case 'Systems per business/function': //here
            var newPayload = $.extend(payload,{WorstType : ""});
            ajaxPost("/ociranalysis/systemsperbusiness", newPayload , function (res){
              var internal = []
              var external = []
              var total = []
              var underreview = []

              max = 10;
              if(res.internal.length < 10){
               max = res.internal.length
              }
              var tenPercent = Enumerable.From(res.internal).Max("$.Value") + ((10 * Enumerable.From(res.internal).Max("$.Value")) / 100) 
        
              for(i=0; i<max; i++){ 
                internal.push({Count:res.internal[i].Count,_id:res.internal[i].Country,Value:res.internal[i].Value})
                external.push({Count:res.external[i].Count,_id:res.external[i].Country,Value:res.external[i].Value})
                underreview.push({Count:res.underreview[i].Count,_id:res.underreview[i].Country,Value:res.underreview[i].Value})
                total.push(({Count:tenPercent - res.external[i].Value, _id:'', Value:res.external[i].Value}))
              }
         
            
              data = {internal:'',external:'',underreview:'',total:''};
              data.internal = internal;
              data.external = external;
              data.underreview = underreview;
              data.total = total;
        
             
              wg.barStacked(data,type,id,index)    

              wg.charts[pageIndex][index].value = data
              wg.charts[pageIndex][index].status = true    
            });
          break;
          case 'Buildings by country':
            var newPayload = $.extend(payload,{WorstType : ""});
            ajaxPost("/ociranalysis/buildingbycountry", newPayload , function (res){
              data = []
              max = 10;
              if(res.length < 10){
                max = res.length
              }
                   
              for(i=0; i<max; i++){
                data.push({Count:res[i].Value,_id:res[i].Country})
              }
              wg.bar(data,type,id,index)    

              wg.charts[pageIndex][index].value = data
              wg.charts[pageIndex][index].status = true    
            });
          break;
          case 'Processes per critical service provider': //here
            var newPayload = $.extend(payload,{WorstType : ""});
            ajaxPost("/ociranalysis/getcriticalprovider", newPayload , function (res){
             

              data = {gbs:'',inentity:'',intra:'',other:''}
              var gbs = []
              var inentity = []
              var intra = []
              var other = []
               var total = []
              max = 10;
              if(res.intra.length < 10){
                max = res.intra.length
              }
              var tenPercent = Enumerable.From(res.intra).Max("$.Value") + ((10 * Enumerable.From(res.intra).Max("$.Value")) / 100) 

              for(i=0; i<max; i++){
                intra.push({Count:res.intra[i].Count,_id:res.intra[i].Country,Value:res.intra[i].Value})
                inentity.push({Count:res.inentity[i].Count,_id:res.inentity[i].Country,Value:res.inentity[i].Value})
                gbs.push({Count:res.gbs[i].Count,_id:res.gbs[i].Country,Value:res.gbs[i].Value})
                other.push({Count:res.other[i].Count,_id:res.other[i].Country,Value:res.other[i].Value})
                total.push(({Count:tenPercent - res.other[i].Value, _id:'', Value:res.other[i].Value}))
              }

              

              data.gbs = gbs
              data.intra = intra
              data.inentity = inentity
              data.other = other
               data.total = total

              wg.barStackedCategory(data,type,id,index)   
              wg.charts[pageIndex][index].value = data
              wg.charts[pageIndex][index].status = true    
            
              // oa.chartStackedCategory(intra,gbs,inentity,other);
            });
          break;
          case 'Critical Service Providers by FTE': //here
            var newPayload = $.extend(payload,{WorstType : ""});
            ajaxPost("/ociranalysis/getcriticalproviderfte", newPayload , function (res){
              // $.each(res.intra,function(index,value){
              //   for(var i=0; i<(res.intra.length-1); i++){
 
              //     noWTotal = parseInt(res.intra[i].Count) + parseInt(res.inentity[i].Count) + parseInt(res.gbs[i].Count) + parseInt(res.other[i].Count);
              //     afterTotal = parseInt(res.intra[i+1].Count) + parseInt(res.inentity[i+1].Count) + parseInt(res.gbs[i+1].Count) + parseInt(res.other[i+1].Count);
               
              //     if(noWTotal < afterTotal){
              //       var oldIntra = res.intra[i+1];
              //       var oldInentity = res.inentity[i+1];
              //       var oldGbs = res.gbs[i+1];
              //       var oldOther = res.other[i+1];

              //       res.intra[i+1] = res.intra[i]
              //       res.intra[i] = oldIntra
                    
              //       res.inentity[i+1] = res.inentity[i]
              //       res.inentity[i] =  oldInentity

              //       res.gbs[i+1] = res.gbs[i]
              //       res.gbs[i] = oldGbs


              //       res.other[i+1] = res.other[i]
              //       res.other[i] = oldOther


              //     }
              //   }
              // })

              data = {gbs:'',inentity:'',intra:'',other:''}
              var gbs = []
              var inentity = []
              var intra = []
              var other = []
              var total = []

              max = 10;
              if(res.intra.length < 10){
                max = res.intra.length
              }

              var tenPercent = Enumerable.From(res.intra).Max("$.Value") + ((10 * Enumerable.From(res.intra).Max("$.Value")) / 100) 

              for(i=0; i<max; i++){
                intra.push({Count:res.intra[i].Count,_id:res.intra[i].Country,Value:res.intra[i].Value})
                inentity.push({Count:res.inentity[i].Count,_id:res.inentity[i].Country,Value:res.inentity[i].Value})
                gbs.push({Count:res.gbs[i].Count,_id:res.gbs[i].Country,Value:res.gbs[i].Value})
                other.push({Count:res.other[i].Count,_id:res.other[i].Country,Value:res.other[i].Value})
                total.push(({Count:tenPercent - res.other[i].Value, _id:'', Value:res.other[i].Value}))
              }

              

              data.gbs = gbs
              data.intra = intra
              data.inentity = inentity
              data.other = other
              data.total = total
             
              wg.barStackedCategory(data,type,id,index)   
              wg.charts[pageIndex][index].value = data
              wg.charts[pageIndex][index].status = true    
            
            });
          break;  
          case 'Location by FTE': //here
            var newPayload = $.extend(payload,{WorstType : ""});
            ajaxPost("/ociranalysis/getlocationfte", newPayload , function (res){
              // $.each(res.intra,function(index,value){
              //   for(var i=0; i<(res.intra.length-1); i++){
 
              //     noWTotal = parseInt(res.intra[i].Count) + parseInt(res.inentity[i].Count) + parseInt(res.gbs[i].Count) + parseInt(res.other[i].Count);
              //     afterTotal = parseInt(res.intra[i+1].Count) + parseInt(res.inentity[i+1].Count) + parseInt(res.gbs[i+1].Count) + parseInt(res.other[i+1].Count);
               
              //     if(noWTotal < afterTotal){
              //       var oldIntra = res.intra[i+1];
              //       var oldInentity = res.inentity[i+1];
              //       var oldGbs = res.gbs[i+1];
              //       var oldOther = res.other[i+1];

              //       res.intra[i+1] = res.intra[i]
              //       res.intra[i] = oldIntra
                    
              //       res.inentity[i+1] = res.inentity[i]
              //       res.inentity[i] =  oldInentity

              //       res.gbs[i+1] = res.gbs[i]
              //       res.gbs[i] = oldGbs


              //       res.other[i+1] = res.other[i]
              //       res.other[i] = oldOther


              //     }
              //   }
              // })

              data = {gbs:'',inentity:'',intra:'',other:''}
              var gbs = []
              var inentity = []
              var intra = []
              var other = []
              var total = []

              max = 10;
              if(res.intra.length < 10){
                max = res.intra.length
              }

              var tenPercent = Enumerable.From(res.intra).Max("$.Value") + ((10 * Enumerable.From(res.intra).Max("$.Value")) / 100)
              
              for(i=0; i<max; i++){
                intra.push({Count:res.intra[i].Count,_id:res.intra[i].Country,Value:res.intra[i].Value})
                inentity.push({Count:res.inentity[i].Count,_id:res.inentity[i].Country,Value:res.inentity[i].Value})
                gbs.push({Count:res.gbs[i].Count,_id:res.gbs[i].Country,Value:res.gbs[i].Value})
                other.push({Count:res.other[i].Count,_id:res.other[i].Country,Value:res.other[i].Value})
                total.push(({Count:tenPercent - res.other[i].Value, _id:'', Value:res.other[i].Value}))
              }

              

              data.gbs = gbs
              data.intra = intra
              data.inentity = inentity
              data.other = other
              data.total = total

              wg.barStackedCategory(data,type,id,index)   
              wg.charts[pageIndex][index].value = data
              wg.charts[pageIndex][index].status = true    
            
            });
          break;  

          case 'Third party suppliers':
            var newPayload = $.extend(payload,{WorstType : ""});
            ajaxPost("/ociranalysis/thirdpartysuppliers", newPayload , function (res){
              data = []
              max = 10;
              if(res.length < 10){
                max = res.length
              }
                   
              for(i=0; i<max; i++){
                data.push({Count:res[i].Value,_id:res[i].Country})
              }
              wg.bar(data,type,id,index)    
              wg.charts[page][index].value = data
              wg.charts[page][index].status = true    
            });
          break;
          case 'Third party suppliers by business':
              var newPayload = $.extend(payload,{WorstType : ""});
              ajaxPost("/ociranalysis/tpsbybusiness", newPayload , function (res){
                data = []
                max = 10;
                if(res.length < 10){
                 max = res.length
                }
                for(i=0; i<max; i++){
                  data.push({Count:res[i].Value,_id:res[i].Country})
                }
                wg.bar(data,type,id,index)    
                wg.charts[pageIndex][index].value = data
                wg.charts[pageIndex][index].status = true
              });
          break;
          case 'Third party suppliers by country':
              var newPayload = $.extend(payload,{WorstType : ""});
              ajaxPost("/ociranalysis/tpsbycountry", newPayload , function (res){
                data = []
                max = 10;
                if(res.length < 10){
                 max = res.length
                }
                for(i=0; i<max; i++){
                  data.push({Count:res[i].Value,_id:res[i].Country})
                }
                wg.bar(data,type,id,index)    
                wg.charts[pageIndex][index].value = data
                wg.charts[pageIndex][index].status = true
              });
          break;
          default:
              ajaxPost("/ociranalysis/cefassessmentchart", payload , function (res){
                  var datas = res;
                  var sortDatas = sortBarChart(datas);  
                  wg.bar(sortDatas,type,id,index)     
                  wg.charts[pageIndex][index].value = sortDatas
                  wg.charts[pageIndex][index].status = true    
              
              })
      }
    }
};
wg.bar = function(dataSource,type,id,index){
    // console.log(type)
    var data = []
    config = ko.mapping.toJS(wg.templateChartCurrent)
    receivercountry =  config[wg.activePage()].filters.ReceiverCountry[0]
    filters = config[wg.activePage()].filters;
    var flags = []
    $.each(dataSource, function(i, v){
      if (v.Count !== 0){
     
        if(type == 'Comparison Region [% Confirmed Service]' || type == 'Comparison Region [% Validated Service]'){
          flags[v._id] = v.Flag 
          v.Flag
        }
        data.push(v) 
      }

    })
 
    maxValueAxis = 0
    if(data.length > 0 ){
      var max = Enumerable.From(data).Max("$.Count");
      var min = Enumerable.From(data).Min("$.Count");
    
     
     
      if(type == 'Comparison Region [% Confirmed Service]' || type == 'Comparison Region [% Validated Service]' || type == 'Comparison Region [% Confirmed Service]' || type == 'Comparison Region [% Validated Service]' || type == 'Worst 10 [% Validated]' || type == 'Worst 10 [% Enriched]' || type == 'Worst 10% Validated by Business/Function' || type == 'Worst 10% Enriched by Business/Function' || type == 'Best 10 [% Validated]' || type == 'Best 10 [% Enriched]' || type == 'Pending Best 10 [% Validated]' || type == 'Pending Best 10 [% Enriched]' || type == 'Pending Worst 10 [% Validated]' || type == 'Pending Worst 10 [% Enriched]'
       || type == 'Worst 10 by Process Owner [% Validated Service]' || type == 'Worst 10 by Process Owner [% Confirmed Service]' || type == 'Best 10 by Process Owner [% Validated Service]' || type == 'Best 10 by Process Owner [% Confirmed Service]'){  
        lengthCharMax = (String(max.toFixed(2)).length) + 1;
        n = 5.5;
      }else{
        lengthCharMax =  String(max.toFixed(0)).length;
          n = 5.2;
      }  
     
      percentage =  (max * (lengthCharMax * n)) / 100 ;
      maxValueAxis = max + percentage; 
    
        if ( data.length == 1){
          $("#"+id).replaceWith('<div id='+id+'></div>')
          $("#"+id).css('height', (data.length * 60) + 'px') 
        }
        else if (data.length <= 7){
          $("#"+id).replaceWith('<div id='+id+'></div>')
          $("#"+id).css('height', (data.length * 52) + 'px') 
        }else {
          $("#"+id).css('height','370px')  
        }
    }



    barChartType = 0;
    eventClick = onSeriesClick; 
    if( type == 'Worst 10 [% Validated]' ||   type == 'Worst 10 [% Enriched]' || 
      type == 'Pending Best 10 [% Validated]' || type == 'Pending Best 10 [% Enriched]' || 
      type == 'Pending Worst 10 [% Validated]' || type == 'Pending Worst 10 [% Enriched]' || type == 'Worst 10 by Process Owner [% Validated Service]' || 
      type == 'Worst 10 by Process Owner [% Confirmed Service]' || type == 'Best 10 by Process Owner [% Validated Service]' || type == 'Best 10 by Process Owner [% Confirmed Service]'  || 
      type == 'Comparison Region [% Confirmed Service]' || type == 'Comparison Region [% Validated Service]'){
      
      eventClick = onSeriesClick2;
      barChartType =  1
    }else if( type == 'Best 10 [% Validated]' || 
              type == 'Best 10 [% Enriched]'  || 
              type == 'Worst 10% Validated by Business/Function'  || 
              type == 'Worst 10% Enriched by Business/Function' ){
      eventClick = onSeriesClick2;
      barChartType = 2 
    }else if(type == 'Buildings by country' || type == 'Third party suppliers' || type == 'Third party suppliers by business' || type == 'Third party suppliers by country'){
      eventClick = undefined;
      barChartType = 0
    }
  
    // }else{
      // even
    // }
    $("#"+id).html('');
    $("#"+id).kendoChart({
        dataSource: {
            data:data,
            dataType: "json"
        },
        legend :{
            position :"top",
            margin:{
                visible:true,
                top:40
            },
            font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
        },
        chartArea: { 
          width:331,
        },
        transitions: false,
        seriesDefaults: {
            type: "bar",
            overlay: {
              gradient: "none"
            },
            tooltip: {
              visible: false,
              template: "#:kendo.toString(value,'N0')#"
            },
            labels: {
              font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
              // color: "#FFFFFF",
              color: "#0075B2",
              visible: true,
              // position:"insideEnd",
              position:"outsideEnd",
              template : function(e){
                if (type == 'Worst 10 [% Validated]' || type == 'Worst 10 [% Enriched]' || type == 'Worst 10% Validated by Business/Function' || type == 'Worst 10% Enriched by Business/Function' || type == 'Best 10 [% Validated]' || type == 'Best 10 [% Enriched]' || type == 'Pending Best 10 [% Validated]' || type == 'Pending Best 10 [% Enriched]'|| type == 'Pending Worst 10 [% Validated]' || type == 'Pending Worst 10 [% Enriched]' || type == 'Best 10 by Process Owner [% Validated Service]' || type == 'Best 10 by Process Owner [% Confirmed Service]' || type == 'Worst 10 by Process Owner [% Validated Service]' || type == 'Worst 10 by Process Owner [% Confirmed Service]') {
                  return  '<tspan style="font:9px Helvetica Neue, Helvetica, Arial, sans-serif;" class="top1-'+id+'">' + e.value.toFixed(2) + "%" +
                  '\n <tspan style="font:9px Helvetica Neue, Helvetica, Arial, sans-serif;" class="top2-'+id+'">' + parseInt(e.dataItem.Value.toFixed(0)).toLocaleString()+ '</tspan>'+
                  '\n <tspan style="font:10px Helvetica Neue, Helvetica, Arial, sans-serif;" class="centerize-'+id+'">Rank ' + e.dataItem.Rank+ '</tspan>'
                }else if (type == '% Validated all Countries' || type == '% Enriched all Countries' || type == 'Comparison Region [% Validated Service]' || type == 'Comparison Region [% Confirmed Service]'){
                  return  '<tspan style="font:9px Helvetica Neue, Helvetica, Arial, sans-serif;">' + e.value.toFixed(2) + "%" +
                  '\n <tspan style="font:9px Helvetica Neue, Helvetica, Arial, sans-serif;">' + parseInt(e.dataItem.Value.toFixed(0)).toLocaleString()+ '</tspan>'
                }else{
                  return parseInt(e.value.toFixed(0)).toLocaleString()
                }
              },
              // template: "#:kendo.toString(value,'N0')#",
              background: "transparent"
            },
            // color: "#28b1c2"
            gap: 0.3,
           
        },
        render: function(){
     
        },
        series: [{
            field: "Count",
            border: {
                width: 1,
                color: "transparent"
            },
            color: function(e){
              if(type == 'Comparison Region [% Confirmed Service]' || type == 'Comparison Region [% Validated Service]'){
                if(flags[e.category] == 'Global'){
                  return "#005C84"
                }else if(flags[e.category] == 'Region'){
                  return "#3C95B9"
                }else{
                  return "#8ADFFF"
                }
              }else if (type.indexOf('[%') > 1 && receivercountry == e.category) {
                return "#8ADFFF"
              }else if(type == 'Process by GBS and Others'){
                if(e.dataItem.Color == 'gbs'){
                  return "#2F7528"
                }else{
                  return "#005C84"
                }
              }else{
                return "#005C84"
              }
            }
        }],
        categoryAxis :{
            field : "_id",
            labels: {
                template: labelTemplate,
                font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
                // template: "#= shortLabels(value)#",
            },
            majorGridLines: {
                visible: false
            },
            line:{
                visible:false
            }
        },
        valueAxis:{
            min:0,
            max: maxValueAxis,
            majorGridLines: {
              visible: false,
            },
        
            line: {
              visible: false
            },
           
            labels:{
              visible:false,
            },
        },
        tooltip: {
            visible: true,
            format: "n0",
        },
        seriesClick: eventClick,
        seriesColors: ["#66DBFF"],
        render: function(){

          var chart = $("#"+id).data("kendoChart");
          if(chart._plotArea.axisY.children.length == 0) return;
          padding = 5
          newX = parseInt(chart._plotArea.axisY.children[0].box['x2']) + 9.5 + padding
          $('.centerize-'+id).each(function (idx){
                newY = $(this).parent().parent().attr('Y') - 14 
                $(this).parent().parent().attr('fill','#fff').attr('x',newX).attr('y',newY)
          });

          $('.top1-'+id).each(function (idx){
                newY = parseInt($(this).parent().parent().attr('Y')) + 6
                $(this).parent().parent().attr('y',newY)
          });
           $('.top2-'+id).each(function (idx){
              newY = parseInt($(this).parent().parent().attr('Y')) + 6
              $(this).parent().parent().attr('y',newY)
          });
          setTimeout(function(){ 
              alignLegendLeft(id);
          },200)

        },
        seriesHover: function(e) { 
            if(eventClick){
              $('#'+id).css("cursor","pointer");
            }else{
              $('#'+id).css("cursor","default");
            }
            setTimeout(function(){
            $('#'+id+" g path").each(function (idx){
                var op = $(this).attr('stroke-opacity');
              if (op == 0.2){
                // console.log(e)
                if((barChartType == 1 || barChartType == 2) && receivercountry == e.category){
                  $(this)
                    .attr('fill','#50D0FF')
                    .attr('fill-opacity', 1)
                }else if(type == 'Process by GBS and Others'){
                  if(e.dataItem.Color == 'gbs'){
                      $(this)
                      .attr('fill','#1f4f1a')
                      .attr('fill-opacity', 1)
                    }else{
                      $(this)
                      .attr('fill','#002951')
                      .attr('fill-opacity', 1)
                    }
                }else{
                  $(this)
                    .attr('fill','#002951')
                    .attr('fill-opacity', 1)
                }
              
              }
            }); 
          },100);
        }
    });
    var isFound = false
        jQuery('#'+id+' g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
            if (isFound) return
            if ($(e).html() == '') isFound = true
            $(e).find('text').attr('x', 0)
          })
    function labelTemplate(e) {
        var finalStm = "";
        var maxlen = 14;
        var Spl = e.value.split(" ");
        var lenStm = 0;
        $.each(Spl, function(i, o){
            lenStm = lenStm + o.length + 1;
            var tb = "";
            if (lenStm <= maxlen) {
                tb = " ";
            } else {
                lenStm = o.length;
                tb = "\n";
            }
            if (i == 0) {
                tb = "";
            }
            finalStm = finalStm + tb + o;
        });

        return finalStm
    }
    function onSeriesClick(e){
        var config = ko.mapping.toJS(wg.templateChartCurrent);
        var title = config[wg.activePage()].charts[index].filter;
        filter = wg.parsetFilter(config[wg.activePage()].filters)
console.log(seriesColoumns);
 console.log(title.toLowerCase());

        if(title.toLowerCase() === "service fte"){
          console.log("service fte")
            var url = "/ociranalysis/modalforfte";
            var supplier = filter.SupplierCountry;
            var category = [e.category];
            var seriesColoumns = [{
              field:"_id",
              title:'Function Name',
              width:200,
              // filterable: false,
              attributes: {
                  "class": "field-ellipsis"
              }
            },
            {
              field:"Count",
              title:'FTE',
              width:100,
              // filterable: false,
              attributes: {
                  "class": "field-ellipsis align-right"
              },
              template: "#:kendo.toString(Count,'N2')#",
              headerAttributes: {
                  "class": "align-right"
              },
            }]
        }else if(title.toLowerCase() === "fte by country"){
            console.log("fte by country")
            var url = "/ociranalysis/modalforfte";
            var supplier
            var entity 
            if ( filter.SupplierCountry.length === 0 ){
              supplier = [e.category];
              entity = filter.SupplierLegalEntity;  
            }else {
              supplier =  filter.SupplierCountry; 
              entity =  [e.category]  
            }
              
            var seriesColoumns = [{
              field:"_id",
              title:'Function Name',
              width:200,
              // filterable: false,
              attributes: {
                  "class": "field-ellipsis"
              }
            },
            {
              field:"Count",
              title:'FTE',
              width:100,
              // filterable: false,
              attributes: {
                  "class": "field-ellipsis align-right"
              },
              headerAttributes: {
                  "class": "align-right"
              },
              template: "#:kendo.toString(Count,'N2')#"
            }]
        }else if(title.toLowerCase() === "level 1 by country"){
            console.log("level 1 by country")
            var url = "/ociranalysis/getdetailchart";
            var supplier = [e.category];
            var seriesColoumns = [{
                field:"_id.Parentprocessname",
                title:'Level 1 Process',
                width:200,
                // filterable: false,
                attributes: {
                    "class": "field-ellipsis"
                }
            }]
        }else if (title.toLowerCase() === "assets utilized"){
          console.log("assets utilized")
          var url = "/ociranalysis/getdetailassetutilized";
          var supplier = filter.SupplierCountry
          var category = [e.category];
          var Typebar = "";
          var seriesColoumns;
          switch(e.category){
            case 'Buildings':
              Typebar = "BLD";
              seriesColoumns = [{
                field:"_id.buildingid",
                title:'Building ID',
                // filterable: false,
                width: 50,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                  "class": "align-left"
                }
              },{
                field:"_id.buildingname",
                title:'Building Name',
                // filterable: false,
                width: 150,
                attributes: {
                    "class": "field-ellipsis"
                }
              }]
            break;
            case 'External Systems':
              Typebar = "ES";
              seriesColoumns = [{
                field:"_id.supplierid",
                title:'Supplier ID',
                // filterable: false,
                width: 50,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                  "class": "align-left"
                }
              },{
                field:"_id.suppliername",
                title:'Name',
                // filterable: false,
                width: 150,
                attributes: {
                    "class": "field-ellipsis"
                }
              }]
            break;
            case 'Internal Systems':
              Typebar = "IS";
              seriesColoumns = [{
                field:"_id.supplierid",
                title:'Supplier ID',
                // filterable: false,
                width: 50,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                  "class": "align-left"
                }
              },{
                field:"_id.suppliername",
                title:'Name',
                // filterable: false,
                width: 150,
                attributes: {
                    "class": "field-ellipsis"
                }
              }]
            break;
            case 'Data Centers':
              Typebar = "DC";
              seriesColoumns = [{
                field:"_id.hublocationcountry",
                title:'Hub Location',
                // filterable: false,
                width: 50,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                  "class": "align-left"
                }
              },{
                field:"_id.systemshublocation",
                title:'Hub Location Country',
                // filterable: false,
                width: 150,
                attributes: {
                    "class": "field-ellipsis"
                }
              }]
            break;
           } 
          }else{
            var url = "/ociranalysis/getdetailchart";
            var supplier = filter.SupplierCountry;
            var product = [e.category]
            var seriesColoumns = [{
                field:"_id.Parentprocessname",
                title:'Level 1 Process',
                width:200,
                // filterable: false,
                attributes: {
                    "class": "field-ellipsis"
                }
            }]
        }
console.log(seriesColoumns);
        if (title.toLowerCase() === "assets utilized"){
          var payload = {
            ReceiverCountry     : filter.ReceiverCountry,
            ReceiverLegalEntity : filter.ReceiverLegalEntity,
            SupplierCountry     : supplier,
            SupplierLegalEntity : entity,
            Suppliertype        : filter.Suppliertype,
            Categoryname        : filter.Categoryname,
            Productfunction     : filter.Productfunction,
            Pfpcritical         : filter.Pfpcritical,
            Cefcritical         : filter.Cefcritical,
            Typebar             : Typebar,
            GPO                 : filter.GPO,
            Parentprocessname   : filter.Parentprocessname
          };
        }else if (title.toLowerCase() === "level 1 by country") {
          var payload = {
            ReceiverCountry :  filter.ReceiverCountry,
            ReceiverLegalEntity :filter.ReceiverLegalEntity,
            SupplierCountry : supplier,
            SupplierLegalEntity : filter.SupplierLegalEntity,
            Suppliertype: filter.Suppliertype,
            Categoryname : '',
            Productfunction : filter.Productfunction,
            Pfpcritical : filter.Pfpcritical,
            Cefcritical : filter.Cefcritical,       
            GPO         : filter.GPO, 
            Parentprocessname   : filter.Parentprocessname
          }; 
        }else if (title.toLowerCase() === "biggest"){
            
            if (filter.Categoryname.length == 0 ){
                Productfunction = [e.category]
            }else{
                Productfunction = filter.Categoryname;
            }
            var payload = {
                    ReceiverCountry : filter.ReceiverCountry,
                    ReceiverLegalEntity : filter.ReceiverLegalEntity,
                    SupplierCountry : filter.SupplierCountry,
                    SupplierLegalEntity :filter.SupplierLegalEntity,
                    Suppliertype: filter.Suppliertype,
                    Categoryname : Productfunction,
                    Productfunction : [],
                    Pfpcritical : filter.Pfpcritical,
                    Cefcritical :filter.Cefcritical,      
                    GPO         : filter.GPO,     
                    Parentprocessname   : filter.Parentprocessname      
            };
        }else{
            var payload = {
                    ReceiverCountry : filter.ReceiverCountry,
                    ReceiverLegalEntity : filter.ReceiverLegalEntity,
                    SupplierCountry : supplier,
                    SupplierLegalEntity :filter.SupplierLegalEntity,
                    Suppliertype: filter.Suppliertype,
                    Categoryname : [],
                    Productfunction : product,
                    Pfpcritical : filter.Pfpcritical,
                    Cefcritical :filter.Cefcritical,   
                    GPO         : filter.GPO,         
                    Parentprocessname   : filter.Parentprocessname    
            };
        }

        console.log(title);

        console.log(seriesColoumns);
        $("#barchart").html('')
        $("#barchart").kendoGrid({
                dataSource: {
                    transport: {
                       read:function(option){
                            ajaxPost(url, payload, function(datas){
                              option.success(datas);
                               $('#modalbarchart').modal('show');
                              setTimeout(function() {
                                $('#barchart .k-grid-content').height(310);
                              }, 300);
                            })
                        },
                    parameterMap: function(data) {
                       return JSON.stringify(data);
                    },
                },
                // pageSize: 10,
                sort: [
                    {field:"_id.Parentprocessname",dir:"asc"},
                    {field:"_id",dir:"asc"},
                    {field:"_id.buildingid",dir:"asc"},
                    {field:"_id.buildingname",dir:"asc"},
                    {field:"_id.supplierid",dir:"asc"},
                    {field:"_id.hublocationcountry",dir:"asc"},
                    {field:"_id.systemshublocation",dir:"asc"},
                ]
                },
                excel: {
                    fileName: "Level 1 Processes.xlsx",
                    allPages: true
                },
                columns: seriesColoumns,
                sortable: true,
                filterable: {
                    extra:false, 
                    operators: {
                        string: {
                            contains: "Contains",
                            startswith: "Starts with",
                            eq: "Is equal to",
                            neq: "Is not equal to",
                            doesnotcontain: "Does not contain",
                            endswith: "Ends with"
                        },
                    }
                },
                pageable: {
                  numeric: false,
                  previousNext: false,
                  messages: {
                      display: "Showing {2} data items"
                  }
                },
                height: 380,
        });
    }
    function onSeriesClick2(e){
      var dataItemFlag;
      var worstType;
      filter = wg.parsetFilter(config[wg.activePage()].filters)
      wg.titleFile =  type
      switch (type){
      
        case"Worst 10 [% Validated]":
          region        = filter.Region;
          country       = [e.category];
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          
          worstType     = 'validated'
          tabFirstName  = 'Validated';
          tabSecondName =  'Pending Item';
          wg.tabFirst(false)
          flagfirst     = 'validated';
          flagSecond    = 'pendingvalid';
        break;
        case"Worst 10 [% Enriched]":
          region        = filter.Region;
          country       = [e.category];
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          
          worstType     = 'enriched'
          tabFirstName  = 'Enriched';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst     = 'enriched';
          flagSecond    = 'pendingenriched';
        break;
        case 'Worst 10% Validated by Business/Function':
          region = filter.Region;
          country = filter.ReceiverCountry;
         
          if (filter.Categoryname.length === 0){
            categoryname = [e.category];
            product = filter.Productfunction;
          }else{
            categoryname = filter.Categoryname;
            product = [e.category];
          }
         
          worstType    = 'businnessvalidated'
          tabFirstName = 'Validated';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst = 'validated';
          flagSecond = 'pendingvalid';
        break;
        case 'Worst 10% Enriched by Business/Function':
          region = filter.Region;
          country = filter.ReceiverCountry;
          if (filter.Categoryname.length === 0){
            categoryname = [e.category];
            product = filter.Productfunction;
          }else{
            categoryname = filter.Categoryname;
            product = [e.category];
          }
       
          worstType      = 'businnessenriched'
          tabFirstName = 'Enriched';
          tabSecondName =  'Pending Item';
          wg.tabFirst(false)
          flagfirst = 'Enriched';
          flagSecond = 'pendingvalid';
        break;
        case"Best 10 [% Validated]":
          region = filter.Region;
          country       = [e.category];
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType     = 'reversevalidated'
          tabFirstName  = 'Validated';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst     = 'Validated';
          flagSecond    = 'pendingvalid';
        break;
        case"Best 10 [% Enriched]":
          region = filter.Region;
          country       = [e.category];
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType = 'reverseenriched'
          tabFirstName  = 'Enriched';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst     = 'enriched';
          flagSecond    = 'pendingenriched';
        break;


        case"Pending Best 10 [% Validated]":
          region = filter.Region;
          country       = [e.category];
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType = 'pendingbestvalidated'
          
          tabFirstName = 'Validated';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst = 'validated';
          flagSecond = 'pendingvalid';

        break;
        case"Pending Best 10 [% Enriched]":
          region = filter.Region;
          country       = [e.category];
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType = 'pendingbestenriched'



          tabFirstName = 'Enriched';
          tabSecondName = 'Pending Item';
          wg.tabFirst(false)
          flagfirst = 'enriched';
          flagSecond = 'pendingenriched';
        break;
        case"Pending Worst 10 [% Validated]":
          region = filter.Region;
          country       =[e.category];
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType = 'pendingworstvalidated'

          tabFirstName = 'Validated';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst = 'validated';
          flagSecond = 'pendingvalid';

        break;
        case"Pending Worst 10 [% Enriched]":
          region = filter.Region;
          country       =[e.category];
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType     = 'pendingworstenriched'


          tabFirstName = 'Enriched';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst = 'enriched';
          flagSecond = 'pendingenriched';
        break;
        case"Worst 10 by Process Owner [% Validated Service]":
          region        = filter.Region;
          country       = filter.ReceiverCountry;
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType     = 'worstownervalidated'
         

          tabFirstName = 'Validated';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst = 'validated';
          flagSecond = 'pendingvalid';
        break;
        case"Worst 10 by Process Owner [% Confirmed Service]":
          region        = filter.Region;
          country       = filter.ReceiverCountry;
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType = 'worstownerenriched'
          
          tabFirstName = 'Enriched';
          tabSecondName = 'Pending Item';
         wg.tabFirst(false)
          flagfirst = 'enriched';
          flagSecond = 'pendingenriched';
        break;
        case"Best 10 by Process Owner [% Validated Service]":
          region        = filter.Region;
          country       = filter.ReceiverCountry;
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType = 'bestownervalidated'
          
          tabFirstName = 'Validated';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst = 'validated';
          flagSecond = 'pendingvalid';
        break;
        case"Best 10 by Process Owner [% Confirmed Service]":
          region        = filter.Region;
          country       = filter.ReceiverCountry;
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          worstType = 'bestownerenriched'
          
          tabFirstName = 'Enriched';
          tabSecondName = 'Pending Item';
          wg.tabFirst(false)
          flagfirst = 'enriched';
          flagSecond = 'pendingenriched'; 
        break;

        case"Comparison Region [% Validated Service]":
          categoryname  = filter.Categoryname;
           product       = filter.Productfunction;
          if (filter.Region === 0) {
            region = [e.category]
          }else{
            if(e.dataItem.Flag == 'Global'){
              region = filter.Region
              country =filter.ReceiverCountry;
            }else if(e.dataItem.Flag == 'Region'){
              region =  [e.category]
              country =filter.ReceiverCountry;
            }else{
              region = filter.Region;
              country = [e.category]
            }
          }
          
          dataItemFlag = e.dataItem.Flag;
          worstType = 'comparisonvalidated'
    

          tabFirstName = 'Validated';
          tabSecondName = 'Pending Item';
           wg.tabFirst(false)
          flagfirst = 'validated';
          flagSecond = 'pendingvalid';
        break;
        case"Comparison Region [% Confirmed Service]":
          categoryname  = filter.Categoryname;
          product       = filter.Productfunction;
          if (filter.Region === 0) {
            region = [e.category]
          }else{
            if(e.dataItem.Flag == 'Global'){
              region = filter.Region
              country =filter.ReceiverCountry;
            }else if(e.dataItem.Flag == 'Region'){
              region =  [e.category]
              country =filter.ReceiverCountry;
            }else{
               region = filter.Region;
              country = [e.category]
            }
          }
          dataItemFlag = e.dataItem.Flag;
          worstType = 'comparisonenriched'
      

          tabFirstName = 'Enriched';
          tabSecondName = 'Pending Item';
         wg.tabFirst(false)
          flagfirst = 'enriched';
          flagSecond = 'pendingenriched';
        break;
      }
     wg.tabFirstName  =  tabFirstName;
     wg.tabSecondName =  tabSecondName;
     
     filter = wg.parsetFilter(config[wg.activePage()].filters)
     filter.Region          = region
     filter.ReceiverCountry = country 
     filter.Categoryname    = categoryname 
     filter.Productfunction = product 
     filter.worstType       = worstType
     filter.Global          = ''
    if (type == 'Worst 10 by Process Owner [% Validated Service]' || 
        type == 'Worst 10 by Process Owner [% Confirmed Service]' ||
        type == 'Best 10 by Process Owner [% Validated Service]' ||
        type == 'Best 10 by Process Owner [% Confirmed Service]') {
      filter.Pfpprocessowner = [e.category];
      // var payload = $.extend(payload,{Pfpprocessowner : [e.category]});
    };
    if (type == 'Comparison Region [% Validated Service]' || type == 'Comparison Region [% Confirmed Service]') {
      if([e.dataItem.Flag] == 'Global'){
        filter.Global = 'Y'; 
      }else{
        filter.Global = 'N'; 
      }
    };
  
      ajaxPost("/ociranalysis/popupnewbar",filter , function (res){
          $("#modaltab .nav-pills a").removeData("cache.tabs");
          $('#modaltab').modal('show');
          setTimeout(function() {
            $('#modaltab .k-grid-content').height(300);
          },300)
          $('#modaltab-name-first').text(tabFirstName);
          $('#modaltab-name-second').text(tabSecondName);
          if (tabFirstName == 'Pending Item') {
            $("#pendingtab ul").find('li').removeClass('active')
            $("#pendingtab ul li:eq(0)").addClass('active')
            $("#pendingtab").tabs({active:0});
          }else{
            $("#pendingtab ul").find('li').removeClass('active')
            $("#pendingtab ul li:eq(1)").addClass('active')
            $("#pendingtab").tabs({active:1});
          };
          $("#grid-chart-1").html("");
          $("#grid-chart-1").kendoGrid({
            dataSource: {
              transport: {
                 read:function(option){
                

                 res.tab1.forEach(function (d) {
                      d.type = type
                    d.Global    = filter.Global 
                    d.worstType = worstType
                    d.receiverCountry = e.category
                    d.index = index
                    d.flag = flagfirst
                    d.flagRegion = dataItemFlag
                  })
                  option.success(res.tab1); 
                 
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
              },
            }, 
            columns: [
                  {
                          field:"Country",
                          title:'PFP Process Name',
                          width:100,
                          // filterable: false,
                          attributes: {
                              "class": "field-ellipsis"
                          },
                          headerAttributes: {
                              "class": "align-left"
                          },
                        },
                        {
                          field:"Count",
                          title:'Total',
                          width:50,
                          // filterable: false,
                          attributes: {
                              "class": "field-ellipsis align-right"
                          },
                          template: "#if(Count !== 0){# <a href=\"\\#\" onclick='popUpchartBarlv2(\"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\", \"#:worstType#\",\"#:receiverCountry#\",\"#:flag#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
                          headerAttributes: {
                              "class": "align-right"
                          },
                        }
                      ],
            sortable: true,
            filterable: {
              extra:false, 
              operators: {
                string: {
                  contains: "Contains",
                  startswith: "Starts with",
                  eq: "Is equal to",
                  neq: "Is not equal to",
                  doesnotcontain: "Does not contain",
                  endswith: "Ends with"
                },
              }
            },
            pageable: {
                  numeric: false,
                  previousNext: false,
                  messages: {
                      display: "Showing {2} data items"
                  }
            },
            height: 380
            // ,
            // excelExport: function(e) {
            //   e.preventDefault();
            //   promises[0].resolve(e.workbook);
            // }

          });
          $("#grid-chart-2").html("");
          $("#grid-chart-2").kendoGrid({
            dataSource: {
              transport: {
                 read:function(option){
                  res.pending.forEach(function (d) {
                    d.type = type
                    d.worstType = worstType
                    d.receiverCountry = e.category
                    d.index = index
                    d.flag = flagSecond
                    d.Global    = filter.Global
                    d.flagRegion = dataItemFlag 
                  })
                  option.success(res.pending); 

                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
              },
            }, 
            columns: [
                  {
                          field:"Country",
                          title:'PFP Process Name',
                          width:100,
                          // filterable: false,
                          attributes: {
                              "class": "field-ellipsis"
                          },
                          headerAttributes: {
                              "class": "align-left"
                          },
                        },
                        {
                          field:"Count",
                          title:'Total',
                          width:50,
                          // filterable: false,
                          attributes: {
                              "class": "field-ellipsis align-right"
                          },
                           template: "#if(Count !== 0){# <a href=\"\\#\" onclick='popUpchartBarlv2(\"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\", \"#:worstType#\",\"#:receiverCountry#\",\"#:flag#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
                         headerAttributes: {
                              "class": "align-right"
                          },
                        }
                      ],
            sortable: true,
            filterable: {
              extra:false, 
              operators: {
                string: {
                  contains: "Contains",
                  startswith: "Starts with",
                  eq: "Is equal to",
                  neq: "Is not equal to",
                  doesnotcontain: "Does not contain",
                  endswith: "Ends with"
                },
              }
            },
             pageable: {
                numeric: false,
                previousNext: false,
                messages: {
                    display: "Showing {2} data items"
                }
            },
            height: 380
            // ,
            // excelExport: function(e) {
            //   e.preventDefault();
            //   promises[1].resolve(e.workbook);
            // }
          });
      })
    }

    var chart = $("#"+id).data("kendoChart"),
    firstSeries = chart.options.series;
    firstSeries[0].gap = parseFloat(0.3, 10);
    chart.redraw();
};
wg.barStacked = function(dataSource,type,id,index){
 
  if ( dataSource.internal.length == 1){
      $("#"+id).replaceWith('<div id='+id+'></div>')
      $("#"+id).css('height', (dataSource.internal.length * 87) + 'px') 
    }else if (dataSource.internal.length <= 7){
      $("#"+id).replaceWith('<div id='+id+'></div>')
      $("#"+id).css('height', (dataSource.internal.length * 64) + 'px') 
  }else {
      $("#"+id).css('height','370px')  
    }  

  $("#"+id).html('');
  $("#"+id).kendoChart({
    legend :{
      position :"bottom",
      font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
    },
      chartArea: { 
          width:331,
        },
    transitions: false,
    seriesDefaults: {
      type: "bar",
      stack:true,
      overlay: {
        gradient: "none"
      },
      gap: 0.5,
      color: "transparent",
    },
    series: [{
     name: "Internal",
      data:dataSource.internal,
      categoryField: "_id",
      field: "Count",
      border: {
        width: 1.7,
        color: "transparent"
      },
      color: "#00506D",
      
      tooltip: {
        visible: true,
        template: "#= kendo.toString(value,'N0') #"
      },
      labels: {
        font: "9px Helvetica Neue, Helvetica, Arial, sans-serif",
        color: "#fff",
        visible: false,
        background: "transparent"
      },
    },{
      name: "External",
      data: dataSource.external,
      field: "Count", 
      color: "#2F7528",
      border: {
        width: 1.7,
        color: "transparent"
      },
      tooltip: {
        visible: true,
        template: "#= kendo.toString(value,'N0') #"
      },
    },{
      name: "Under Review",
      data: dataSource.underreview,
      field: "Count", 
      color: "#939598",
      border: {
        width: 0,
      },
      tooltip: {
        visible: true,
        template: "#= kendo.toString(value,'N0') #"
      },
    },{
      data: dataSource.total,
      field: "Count", 
      color: "#fff",
      border: {
          width: 0,
      },
      labels: { 
        position:"insideEnd ",
        template: "#= kendo.toString(dataItem.Value,'N0') #",
        visible: true
      }
    }],
    categoryAxis :{ 
      labels: {
        font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: labelTemplate,
        visible: true,
        background: "transparent",
      },
      majorGridLines: {
        visible: false
      },
      line:{
        visible:false
      }
    },
    valueAxis:{
      majorGridLines: {
        visible: false,
      },
      line: {
        visible: false
      },
      labels:{
        visible:false,
      },
    },
 
    seriesColors: ["#66DBFF"],
  
  });
  function labelTemplate(e) {
    var finalStm = "";
    var maxlen = 14;
    var Spl = e.value.split(" ");
    var lenStm = 0;
    $.each(Spl, function(i, o){
      lenStm = lenStm + o.length + 1;
      var tb = "";
      if (lenStm <= maxlen) {
        tb = " ";
      } else {
        lenStm = o.length;
        tb = "\n";
      }
      if (i == 0) {
        tb = "";
      }
      finalStm = finalStm + tb + o;
    });  
    return finalStm  
  }
  alignLegendLeft (id);
}
wg.barStackedCategory = function(dataSource,type,id,index){
  if ( dataSource.intra.length == 1){
    $("#"+id).replaceWith('<div id='+id+'></div>')
    $("#"+id).css('height', (dataSource.intra.length * 87) + 'px') 
  }else if (dataSource.intra.length <= 7){
    $("#"+id).replaceWith('<div id='+id+'></div>')
    $("#"+id).css('height', (dataSource.intra.length * 64) + 'px') 
  }else {
    $("#"+id).css('height','370px')  
  } 

    $("#"+id).html('');
  $("#"+id).kendoChart({
   legend :{
      position :"bottom",
      font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
    },
      chartArea: { 
          width:331,
        },
    transitions: false,
    seriesDefaults: {
      type: "bar",
      stack:true,
      overlay: {
        gradient: "none"
      },
      gap: 0.5,
      color: "transparent",
    },
    series: [{
       name: "Hub",
      data:dataSource.intra,
      categoryField: "_id",
      field: "Count",
      border: {
        width: 0,
      },
      color: "#0075B0",
 
      labels: {
        font: "9px Helvetica Neue, Helvetica, Arial, sans-serif",
        color: "#fff",
        visible: false,
        background: "transparent"
      },
      tooltip: {
        visible: true,
        template: "#= kendo.toString(value,'N0') #"
      },
    },{
          name: "In-Entity",
            data: dataSource.inentity,
          field: "Count", 
            color: "#009FDA",
            border: {
                width: 0,
            },
            tooltip: {
              visible: true,
              template: "  #= kendo.toString(value,'N0') #"
            },
        },{
        name: "GBS",
            data: dataSource.gbs,
          field: "Count", 
            color: "#3F9C35",
            border: {
                width: 0,
            },
            tooltip: {
              visible: true,
              template: "   #= kendo.toString(value,'N0') #"
            },

        },{
          name: "Other",

            data: dataSource.other,
          field: "Count", 
            color: "#A6A6A6",
            border: {
                width: 0,
            },
            tooltip: {
              visible: true,
              template: "  #= kendo.toString(value,'N0') #"
            },
        },{
            data:dataSource.total,
          field: "Count", 
            color: "#fff",
            border: {
                width: 0,
            },
      labels: { 
        position:"insideEnd ",
                template: "#= kendo.toString(dataItem.Value,'N0') #",
                visible: true
            },
        }],
    categoryAxis :{ 
      labels: {
        font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
  
        template: labelTemplate,
        visible: true,
        background: "transparent",
      },
      majorGridLines: {
        visible: false
      },
      line:{
        visible:false
      }
    },
    valueAxis:{
      majorGridLines: {
        visible: false,
      },
      line: {
        visible: false
      },
      labels:{
        visible:false,
      },
    }, 
    seriesColors: ["#66DBFF"],
    
  });
  function labelTemplate(e) {
    var finalStm = "";
    var maxlen = 14;
    var Spl = e.value.split(" ");
    var lenStm = 0;
    $.each(Spl, function(i, o){
      lenStm = lenStm + o.length + 1;
      var tb = "";
      if (lenStm <= maxlen) {
        tb = " ";
      } else {
        lenStm = o.length;
        tb = "\n";
      }
      if (i == 0) {
        tb = "";
      }
      finalStm = finalStm + tb + o;
    });  
    return finalStm  
  }
  alignLegendLeft (id);
}
wg.barFull =  function(dataSource,type,index){
  receivercountry =  config[wg.activePage()].filters.ReceiverCountry[0]
  var data = []
  var flags = []

  var total
  var maxCountDS = Enumerable.From(dataSource).Max("$.Count");
  var dataSeriesSecond = []
  $.each(dataSource, function(i, v){
    if (v.Count !== 0){
    var tenPercent = (maxCountDS == 0)?0:maxCountDS / ( 100/20 );
    dataSeriesSecond.push({_id:null,Count:(maxCountDS + tenPercent) - v.Count, label:v.Count});
    data.push(v);
    if(type == 'Comparison Region [% Confirmed Service]' || type == 'Comparison Region [% Validated Service]'){
      flags[v._id] = v.Flag 
    }
    }
  })
  total = dataSource.total;

  $("#full-chart-" + index).html('');
  $("#full-chart-" + index).kendoChart({
    // dataSource: {
    //   data:data,
    //   dataType: "json"
    // },
    legend :{
      position :"top",
      margin:{
        visible:true,
        top:40
      },
      font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
    },
    transitions: false,
    seriesDefaults: {
      stack: {
        type: "100%"
      },
      overlay: {
        gradient: "none"
      },
       
      gap: 0.5,
      // color: "transparent",
      color: "#36BC9B",
    },
    series: [{
      data:data,
      categoryField: "_id",
      field: "Count", 
      border: {
        width: 1.7,
        color: "transparent"
      },
      color: function(e){
        if(type == 'Comparison Region [% Confirmed Service]' || type == 'Comparison Region [% Validated Service]'){
          if(flags[e.category] == 'Global'){
            return "#005C84"
          }else if(flags[e.category] == 'Region'){
            return "#3C95B9"
          }else{
            return "#8ADFFF"
          }
        }else if (receivercountry == e.category) {
          return "#8ADFFF"
        }else{
         return "#36BC9B"
        }
      },
      labels: {
        font: "8px Helvetica Neue, Helvetica, Arial, sans-serif",
        color: "#fff",
        rotation: -90,
        visible: false,
        position:"insideEnd",
        template: function(e){
          if(e.value === 0){
            return 0;
          }else{
            return e.value.toFixed(1) + "%";
          }
        },
        background: "transparent"
      },
     }, 
     { 
        data: dataSeriesSecond,
              field: "Count", 
        color: "#F2F2F2",
        border: {
            width: 1.7,
            color: "transparent"
        },
        labels: {
          font: "bold 8px Helvetica Neue, Helvetica, Arial, sans-serif",
          color: "#00506D",
          rotation: -90,
          visible: true,
          position:"insideEnd",
          template: function(e){
          
            if(e.dataItem.label === 0){
              return 0;
            }else{
              return e.dataItem.label.toFixed(1) + "%";
            }
          },
          background: "transparent"
        },
      }
    ],
    categoryAxis :{
   
      labels: {
        font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
        color: "#fff",
        visible: true,
        mirror: true,
        rotation: -90,
        background: "transparent",
      },
      majorGridLines: {
        visible: false
      },
      line:{
        visible:false
      }
    },
    valueAxis:{
      majorGridLines: {
        visible: false,
      },
    
      line: {
        visible: false
      },
       
      labels:{
        visible:false,
      },
    },     
    seriesClick: onSeriesClick,
    seriesColors: ["#66DBFF"],
    render: function(){
      setTimeout(function(){
        kendo.resize($("#full-chart-" + index));
      },400)
    },
    seriesHover: function(e) { 
      setTimeout(function(){
        $("#full-chart-" + index+" g path").each(function (idx){
          var op = $(this).attr('stroke-opacity');
          if (op == 0.2){
            var display = $(this).attr('d')
            var hover;
            if (receivercountry == e.category) {
              mainColor = "#8ADFFF"
              mainColorHover = "#50D0FF"
            
            }else if(type == 'Comparison Region [% Confirmed Service]' || type == 'Comparison Region [% Validated Service]'){
              if(flags[e.category] == 'Global'){
                mainColor = "#005C84"
                mainColorHover = "#002951"
           
              }else if(flags[e.category] == 'Region'){
                mainColor = "#3C95B9"
                mainColorHover = "#23576C"
              }else{
                 mainColor = "#8ADFFF"
                mainColorHover = "#50D0FF"
              }
            }else{
               mainColor = "#36BC9B"
                mainColorHover = "#206F5B"
          
            }
            var fillOp;
            $("#full-chart-" + index+" g path[d='"+ display +"']").each(function (idx){                       
              var defColor = ($(this).attr('fill'))  

              if(defColor == mainColor){                 
                hover  = mainColorHover    
                fillOp = 1;                 
              }else if(defColor == "#F2F2F2"){
                hover  = '#F2F2F2'                   
                fillOp = 0;
              }
            })
           
              $(this)
              .attr('fill',hover)
              .attr('fill-opacity', fillOp)
         
          }
        }); 
      },10);
    }
  });
  function onSeriesClick(e){
      // console.log(e.category)
    var dataItemFlag;
    var worstType;
    filter = wg.parsetFilter(config[wg.activePage()].filters)
    wg.titleFile =  type
    
    switch (type){
      case"% Validated all Countries":
        region = filter.Region
        country = [e.category];
        categoryname = filter.Categoryname;
        product = filter.Productfunction;
        worstType = 'validated'
        tabFirstName = 'Validated';
        tabSecondName = 'Pending Item';
        wg.tabFirst(false);
        flagfirst = 'validated';
        flagSecond = 'pendingvalid';
      break;
      case"% Enriched all Countries":
        region = filter.Region;
        country = [e.category];
        categoryname = filter.Categoryname;
        product = filter.Productfunction;
        worstType = 'enriched'
        tabFirstName = 'Enriched';
        tabSecondName = 'Pending Item';
        wg.tabFirst(false);
        flagfirst = 'enriched';
        flagSecond = 'pendingenriched';
      break;
      case"Comparison Region [% Validated Service]":
        categoryname = filter.Categoryname;
        product = filter.Productfunction;
        if (filter.region === 0) {
          region = [e.category]
        }else{
          if(e.dataItem.Flag == 'Global'){
            region =  filter.Region
            country = filter.ReceiverCountry;
          }else if(e.dataItem.Flag == 'Region'){
            region =  [e.category]
            country = filter.ReceiverCountry;
          }else{
            region = filter.Region
            country = [e.category]
          }
        }
         dataItemFlag = e.dataItem.Flag;
        worstType = 'comparisonvalidated'

        tabFirstName = 'Validated';
        tabSecondName = 'Pending Item';
        wg.tabFirst(false);
        flagfirst = 'validated';
        flagSecond = 'pendingvalid';

       
      break;
      case"Comparison Region [% Confirmed Service]":
        categoryname =  filter.Categoryname;
        product = filter.Productfunction;
        if (filter.region  === 0) {
          region = [e.category]
        }else{
          if(e.dataItem.Flag == 'Global'){
            country = filter.ReceiverCountry;
            region = filter.region 
          }else if(e.dataItem.Flag == 'Region'){
            region =  [e.category]
            country =  filter.ReceiverCountry;
          }else{
            region = filter.region 
            country = [e.category]
          }
        }
         dataItemFlag = e.dataItem.Flag;
        worstType = 'comparisonenriched'

        tabFirstName = 'Enriched';
        tabSecondName = 'Pending Item';
        wg.tabFirst(false);
        flagfirst = 'enriched';
        flagSecond = 'pendingenriched';
      break; 
    }
    wg.tabFirstName =  tabFirstName;
    wg.tabSecondName =  tabSecondName;
     
    filter = wg.parsetFilter(config[wg.activePage()].filters)
    filter.Region          = region
    filter.ReceiverCountry = country 
    filter.Categoryname    = categoryname 
    filter.Productfunction = product 
    filter.worstType       = worstType
    filter.Global          = ''
    if (type == 'Worst 10 by Process Owner [% Validated Service]' || type == 'Worst 10 by Process Owner [% Confirmed Service]' || type == 'Best 10 by Process Owner [% Validated Service]' || type == 'Best 10 by Process Owner [% Confirmed Service]') {
      filter.Pfpprocessowner = [e.category];
      // var payload = $.extend(payload,{Pfpprocessowner : [e.category]});
    };
    if (type == 'Comparison Region [% Validated Service]' || type == 'Comparison Region [% Confirmed Service]') {
      if([e.dataItem.Flag] == 'Global'){
        filter.Global = 'Y'; 
      }else{
        filter.Global = 'N'; 
      }
    };
    ajaxPost("/ociranalysis/popupnewbar",filter , function (res){
          $("#modaltab .nav-pills a").removeData("cache.tabs");
          $('#modaltab').modal('show');
          setTimeout(function() {
            $('#modaltab .k-grid-content').height(300);
          },300)
          $('#modaltab-name-first').text(tabFirstName);
          $('#modaltab-name-second').text(tabSecondName);
          // if (tabFirstName == 'Pending Item') {
          //   $("#pendingtab ul").find('li').removeClass('active')
          //   $("#pendingtab ul li:eq(0)").addClass('active')
          //   $("#pendingtab").tabs({active:0});
          // }else{
          //   $("#pendingtab ul").find('li').removeClass('active')
          //   $("#pendingtab ul li:eq(1)").addClass('active')
          //   $("#pendingtab").tabs({active:1});
          // };
          $("#pendingtab ul").find('li').removeClass('active')
          $("#pendingtab ul li:eq(0)").addClass('active')
          $("#pendingtab" ).tabs( {active:0});
          $("#grid-chart-1").html("");
          $("#grid-chart-1").kendoGrid({
            dataSource: {
              transport: {
                 read:function(option){
                

                 res.tab1.forEach(function (d) {
                      d.type = type
                    d.Global    = filter.Global 
                    d.worstType = worstType
                    d.receiverCountry = e.category
                    d.index = index
                    d.flag = flagfirst
                    d.flagRegion = dataItemFlag
                  })
                  option.success(res.tab1); 
                 
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
              },
            }, 
            columns: [
                  {
                          field:"Country",
                          title:'PFP Process Name',
                          width:100,
                          // filterable: false,
                          attributes: {
                              "class": "field-ellipsis"
                          },
                          headerAttributes: {
                              "class": "align-left"
                          },
                        },
                        {
                          field:"Count",
                          title:'Total',
                          width:50,
                          // filterable: false,
                          attributes: {
                              "class": "field-ellipsis align-right"
                          },
                          template: "#if(Count !== 0){# <a href=\"\\#\" onclick='popUpchartBarlv2(\"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\", \"#:worstType#\",\"#:receiverCountry#\",\"#:flag#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
                          headerAttributes: {
                              "class": "align-right"
                          },
                        }
                      ],
            sortable: true,
            filterable: {
              extra:false, 
              operators: {
                string: {
                  contains: "Contains",
                  startswith: "Starts with",
                  eq: "Is equal to",
                  neq: "Is not equal to",
                  doesnotcontain: "Does not contain",
                  endswith: "Ends with"
                },
              }
            },
            pageable: {
                  numeric: false,
                  previousNext: false,
                  messages: {
                      display: "Showing {2} data items"
                  }
              },
            height: 380,
            excelExport: function(e) {
              e.preventDefault();
              promises[0].resolve(e.workbook);
            }

          });
          $("#grid-chart-2").html("");
          $("#grid-chart-2").kendoGrid({
            dataSource: {
              transport: {
                 read:function(option){
                  res.pending.forEach(function (d) {
                    d.type = type
                    d.worstType = worstType
                    d.receiverCountry = e.category
                    d.index = index
                    d.flag = flagSecond
                    d.Global    = filter.Global 
                    
                    d.flagRegion = dataItemFlag
                  })
                  option.success(res.pending); 

                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
              },
            }, 
            columns: [
                  {
                          field:"Country",
                          title:'PFP Process Name',
                          width:100,
                          // filterable: false,
                          attributes: {
                              "class": "field-ellipsis"
                          },
                          headerAttributes: {
                              "class": "align-left"
                          },
                        },
                        {
                          field:"Count",
                          title:'Total',
                          width:50,
                          // filterable: false,
                          attributes: {
                              "class": "field-ellipsis align-right"
                          },
                           template: "#if(Count !== 0){# <a href=\"\\#\" onclick='popUpchartBarlv2(\"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\",\"#:worstType#\",\"#:receiverCountry#\",\"#:flag#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
                         headerAttributes: {
                              "class": "align-right"
                          },
                        }
                      ],
            sortable: true,
            filterable: {
              extra:false, 
              operators: {
                string: {
                  contains: "Contains",
                  startswith: "Starts with",
                  eq: "Is equal to",
                  neq: "Is not equal to",
                  doesnotcontain: "Does not contain",
                  endswith: "Ends with"
                },
              }
            },
             pageable: {
                numeric: false,
                previousNext: false,
                messages: {
                    display: "Showing {2} data items"
                }
            },
            height: 380,
            excelExport: function(e) {
              e.preventDefault();
              promises[1].resolve(e.workbook);
            }
          });
    })
  }
};
function popUpchartBarlv2(flagRegion, type, Global, Country, worstType, receivercountry , flagTab){
  var payload = wg.parsetFilter(config[wg.activePage()].filters)
 
  payload.WorstType = worstType
  payload.Owner = Country
  payload.FlagTab = flagTab
  payload.Global = '';

  if(type == 'Comparison Region [% Validated Service]' || type == 'Comparison Region [% Confirmed Service]'){
    if(flagRegion == 'Global'){
  
    }else if(flagRegion == 'Region'){
      payload.Region =  [receivercountry] 
    }else{ 
      payload.ReceiverCountry = [receivercountry]
    }
    payload.Global      = Global 
  }else if(type == 'Worst 10% Validated by Business/Function' || type == 'Worst 10% Enriched by Business/Function'){
    
    payload.Categoryname  = [receivercountry]
  }else if (type == 'Worst 10 by Process Owner [% Validated Service]' || type == 'Worst 10 by Process Owner [% Confirmed Service]' || type == 'Best 10 by Process Owner [% Validated Service]' || type == 'Best 10 by Process Owner [% Confirmed Service]') {
   
  }else if(type == '% Validated all Countries' || type == '% Enriched all Countries'){
    payload.ReceiverCountry = [receivercountry]
    payload.FlagTab = flagTab
  }else{
    payload.ReceiverCountry = [receivercountry]
  
  }
  ajaxPost("/ociranalysis/popupnewbar2",payload , function (res){
    $('#modaltab').modal('hide');
    $('#modaldetail').modal('show');
    setTimeout(function() {
      $('#modaldetail .k-grid-content').height(300);
    },300)
    $("#grid-chart-detail").html("");
    $("#grid-chart-detail").kendoGrid({
      dataSource: {
        transport: {
          read:function(option){
            option.success(res);
          },
          parameterMap: function(data) {
            return JSON.stringify(data);
          },
        },
      },
      columns: [
      {
        field:"phpowner",
        title:'PFP Owner',
        width:100,
        // filterable: false,
        attributes: {
          "class": "field-ellipsis"
        },
        headerAttributes: {
          "class": "align-left"
        },
      },
      {
        field:"processname",
        title:'Process Name',
        width:100,
        // filterable: false,
        attributes: {
          "class": "field-ellipsis"
        },
        headerAttributes: {
          "class": "align-left"
        },
      },
      {
        field:"status",
        title:'Status',
        width:50,
        // filterable: false,
        attributes: {
          "class": "align-center"
        },
        headerAttributes: {
          "class": "align-center"
        },
      }
      ],
      sortable: true,
      filterable: {
        extra:false,
        operators: {
          string: {
            contains: "Contains",
            startswith: "Starts with",
            eq: "Is equal to",
            neq: "Is not equal to",
            doesnotcontain: "Does not contain",
            endswith: "Ends with"
          },
        }
      },
      pageable: {
        numeric: false,
        previousNext: false,
        messages: {
          display: "Showing {2} data items"
        }
      },
      height: 380,
    });
  })
 
}
// CREATE BAR DONUT //
wg.createDonut = function(id,pageIndex,index,onchangStatus){ 
    config = ko.mapping.toJS(wg.templateChartCurrent);
    var filters = config[pageIndex].filters

    type = config[pageIndex].charts[index].filter
    var titleButton = '';
    $.each(wg.filterChartDonutList(), function(i , v){
      if (v.value == type){
        titleButton = v.text
      }
    })

    $("#button-filter_"+id).text(titleButton)
    $("#button-filter-pdf_"+id).text(titleButton)
    switch(type){
      case 'In-Entity vs Intra-Group':
        url = "/ociranalysis/getdonutservices";
        title = 'In-Entity vs Intra-Group';
      break;
      case 'In-Entity vs Intra-Group FTE':
        url = "/ociranalysis/getdonutservicesfte";
        title = 'In-Entity vs Intra-Group FTE';
      break;
      default:
        url = "/ociranalysis/getdonutl3processes";
        title = 'Services by ST';
    }
    ko.mapping.fromJS(config, wg.templateChartCurrent)
    payload = wg.parsetFilter(filters);
    
    if(wg.charts[pageIndex][index].status && !onchangStatus){
      wg.donut(wg.charts[pageIndex][index].value,title,id);
    }else{
      ajaxPost(url, payload , function (res){
        wg.donut(res,title,id);
        wg.charts[pageIndex][index].value = res;
        wg.charts[pageIndex][index].status = true;  
      }); 
    }
};
wg.donut = function(dataSource,title,id){
    var colours = ["#00506D","#0077A3","#50D0FF","#8ADFFF","#E6E7E8", "#BCBEC0"];   
    $("#legend-donut_"+id).remove('')
    $("#box_"+id).append("<div id='legend-donut_"+id+"' class='container-legend-donut'><table width='100%'></table></div>")
    var datas = [];
    for(var i in dataSource.Donut){
        datas.push(dataSource.Donut[i]);
        $.extend(true, datas[i], {"color" : colours[i], visible:true} );
        switch(dataSource.Donut[i].category){
        case'FMI':
          var dataItem = 'FMI'
        break;
        case'FMI_System':
          var dataItem = 'FMI Systems'
        break;
        case'FMI_TPS':
          var dataItem = 'FMI External'
        break;
        case'Systems':
          var dataItem = 'Systems'
        break;
        case'IGS':
          var dataItem = 'Intra-Group'
        break;
        default:
          var dataItem = 'In-Entity'
        } 
        var percentage = (Math.abs(dataSource.Donut[i].value) != 0) ? 100 / (dataSource.Total / dataSource.Donut[i].value) : 0; 
        var mod = i % 2;
        var indexTr =  Math.floor(i / 2)

        if(mod  == 0) {
            $("#legend-donut_"+id).find("table").append("<tr>")
        }
        $("#legend-donut_"+id).find("table").find("tr").eq(indexTr).append("<td style='width=50%;height:25px;padding:0 10px;' align='left'><a onClick='wg.configDonutSeries("+i+",\""+id+"\")'><div class='square' style='background:"+colours[i]+";'></div>"+dataItem+"<span style='float:right; padding-right:10px;' id='legend-donut-percentage_"+id+"-"+i+"' class=''><span></a></td>");
        $("#legend-donut-percentage_"+id+"-"+i).text(percentage.toFixed(0)+"%");
    }

    $("#"+id).html('')
    $("#"+id).kendoChart({
        legend: {
            visible:false,
            labels: {
                font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
                template: "#if(dataItem.category==='FMI_Systems'){# #: 'FMI Systems' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'Intra-Group' # #}else if(dataItem.category=='FMI_TPS'){# #: 'FMI External' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='FMI'){# #: 'FMI' # #}else{# #: 'In-Entity' #&nbsp;# # #}# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; #= removeSpace(kendo.toString(percentage,'P0'))# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                color: "#0075B2"
            },
            margin:{
                visible:true,
                left:40,
                top:-30
            },
            position: "bottom",
        },
        chartArea: {
            height : 310,
            background: "transparent",
            width : 360,
            margin:{
                left:-50,
                top:-40
            },
        },
        seriesDefaults: {
            holeSize: 60,
            labels: {
                visible: false,
                template: "#= removeSpace(kendo.toString(percentage,'P0'))#", 
                background: "transparent"
            }
        },
        // seriesColors:seriesColors,
        series: [{
            type: "donut",
            data: datas ,
            overlay:{gradient:"none"},
        }],
        valueAxis:{
            visible:false,
            labels: {
                font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                visible: false,
                format:"{0:P0}",
            },
            majorGridLines: {
                visible: false
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#=kendo.toString(value,'N0')#"
        }
    });
    
    $("#inner-content").html('');
};
wg.configDonutSeries =function(index,id){
    var colours = ["#00506D","#0077A3","#50D0FF","#8ADFFF"];
    var chartID = $("#"+id)
    var visibleData   = chartID.getKendoChart().options.series[0].data[index].visible
    chartID.getKendoChart().options.series[0].data[index].visible = !visibleData
    chartID.getKendoChart().redraw();
    
    color = (!visibleData)?colours[index]: '#9b9898';
    var datas = chartID.getKendoChart().options.series[0].data
    $("#legend-donut_"+id).find("td").eq(index).find(".square").css('background',color)
    
    var totalDataTrue = 0 
    $.each(datas, function(i, val){
        if(val.visible == true){
            totalDataTrue += val.value
        } 
    })

    $.each(datas, function(i, val){            
        var percentage = 100 / (totalDataTrue / val.value) 
        if(val.visible == true){
          $("#legend-donut-percentage_"+id+"-"+i).text(String(percentage.toFixed(0)) +"%")
        }else{
           $("#legend-donut-percentage_"+id+"-"+i).text('')
        }
    }) 
};
 
// CREATE GRID //
wg.grid = function(id,payload ,pageIndex,index,onchangStatus){

    var url = "/ociranalysis/getproductnamecef"
    $("#"+id).html('')
    $("#"+id).removeClass('grid-two')
    
    $("#"+id).kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                  if(wg.charts[pageIndex][index].status && !onchangStatus){ 
                     option.success(wg.charts[pageIndex][index].value);
                  }else{
                    ajaxPost(url, payload, function(datas){
                      if (datas.length <= 19) {
                        $('.k-grid-header').attr('style', 'padding-right: 0px !important');
                      };
                      option.success(datas);
                      wg.charts[pageIndex][index].value = datas
                      wg.charts[pageIndex][index].status = true
                    })
                  }
                },
                parameterMap: function(data) {
                   
                   return JSON.stringify(data);

                },
            },
            schema: {
                data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data; 
                    } 
                },
                // total: "Data.Count",
            },
            // pageSize: 20
        },
        columns: [
            {
                field:"_id.productfunction",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"Product Name",
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                template: "#if(wg.popupvalue()==true){# <a href=\"\\#\" onclick='oa.showDetailProductNameCEF(\"#:_id.productfunction#\",\"#:_id.receivercountry#\",\"#:_id.subgroupid#\",\"#:_id.cefcritical#\")'>#:_id.productfunction#</a> #}else{# #: _id.productfunction # #}#"
                // template:"<a href=\"\\#\" onclick='wg.showDetailProductNameCEF(\"#:_id.productfunction#\",\"#:_id.receivercountry#\",\"#:_id.subgroupid#\",\"#:_id.cefcritical#\")'>#:_id.productfunction#</a>"
            },
            {
                field:"_id.receivercountry",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"Country",
                width:100,
                attributes: {
                    "class": "field-ellipsis"
                },
            },
            {
                field:"_id.cefcritical",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"CEF?",
                width:70,
                attributes: {
                    "class": "field-ellipsis"
                },
                template: "#if(_id.cefcritical=='Y'){# #: 'Yes' # #}else{# #: 'No' # #}#",
            },
        ],
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
   
        height: 340,
    });
};
wg.grid2 = function(id,payload ,pageIndex,index,onchangStatus){

    var url = "/ociranalysis/dgmappingteam"
    $("#"+id).html('')
    $("#"+id).addClass('grid-two')
    $("#"+id).kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                  if(wg.charts[pageIndex][index].status && !onchangStatus){ 
                     option.success(wg.charts[pageIndex][index].value);
                  }else{
                    ajaxPost(url, payload, function(datas){
                      if (datas.length <= 19) {
                        $('.k-grid-header').attr('style', 'padding-right: 0px !important');
                      };
                      option.success(datas);
                      wg.charts[pageIndex][index].value = datas
                      wg.charts[pageIndex][index].status = true
                    })
                  }
                },
                parameterMap: function(data) {
                   
                   return JSON.stringify(data);

                },
            },
            schema: {
                data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data; 
                    } 
                },
                // total: "Data.Count",
            },
            // pageSize: 20
        },
       columns: [
          // {
          //         title: "No",
          //         template: "#= ++record #",
          //         width: 40,
          //         headerAttributes: {
          //          "class": "align-center header-grid"
          //         }, attributes: {
          //           "class": "align-center"
          //         }
          //     },
          {
            field:"Rank",
            headerAttributes: {
              "class": "align-left"
            },
            title:"Rank",
            width:75,
            attributes: {
              "class": "field-ellipsis rank"
            },
          },
          {
            field:"Country",
            headerAttributes: {
              "class": "align-left"
            },
            title:"Country",
            width:130,
            attributes: {
              "class": "field-ellipsis"
            },
            // template: "#if(oa.popupvalue()==true){# <a href=\"\\#\" onclick='oa.showDetailProductNameCEF(\"#:_id.productfunction#\",\"#:_id.receivercountry#\",\"#:_id.subgroupid#\",\"#:_id.cefcritical#\")'>#:_id.productfunction#</a> #}else{# #: _id.productfunction # #}#"
          },
          {
            field:"Count",
            headerAttributes: {
              "class": "align-left"
            },
            title:"% Validated",
            width:105,
            attributes: {
              "class": "field-ellipsis"
            },
          },
        ],
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
   
        height: 340,
        dataBinding: function() {
            record =  0
        }
    });
};
wg.gridFUll = function(payload,pageIndex,index,onchangStatus){
  $("#full-chart-" + pageIndex).addClass('fullgrid')
  $("#full-chart-" + pageIndex).html("");
  if(wg.charts[pageIndex][index].status && !onchangStatus){ 
      $("#full-chart-" + pageIndex).kendoGrid({
        dataSource: {
              transport: {
                 read:function(option){
                
                  
                        option.success(wg.charts[pageIndex][index].value.records);
                    
                  
                  },
                  parameterMap: function(data) {
                     
                     return JSON.stringify(data);

                  },
              },
             schema: {
                data: function(data) {
                  if (data.Count == 0) {
                    return dataSource;
                  } else {
                    return data.Data.Records;
                  }
                },
                total: "Data.Count",
              }, 
              serverPaging: false,
              serverSorting: false,
          // sort: sorting
        },
        height: 400,
        resizable: true,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        sortable: true,
        pageable: {
          numeric: false,
          previousNext: false,
          messages: {
            display: "Showing {2} data items"
          }
        },
        // selectable: "multiple, cell",
        // columnMenu: false,
        columns:  wg.charts[pageIndex][index].value.coloumn
      });
  }else{
     wg.charts[pageIndex][index].value = {coloumn:'',records:''}
     ajaxPost("/ociranalysis/dgvalidatedcountryfield",payload , function (res){
      var dataSource = [];
      var url = "/ociranalysis/dgvalidatedcountry";
      var records = []
      if(res.Data.Records.length > 0 ){
          records.push(res.Data.Records[0]);
          res.Data.Records.splice(0,1);
          r = Enumerable.From(res.Data.Records) 
                  .OrderBy(function (x) { return x.title }) 
                  .ToArray();
 
          records = records.concat(r);
      }
      wg.charts[pageIndex][index].value.coloumn = records
      $("#full-chart-" + pageIndex).kendoGrid({
        dataSource: {
              transport: {
                 read:function(option){
                
                      ajaxPost(url, payload, function(datas){
                        if (datas.length <= 19) {
                          $('.k-grid-header').attr('style', 'padding-right: 0px !important');
                        };

                        option.success(datas);
                        wg.charts[pageIndex][index].value.records = datas 
                        wg.charts[pageIndex][index].status = true
                      })
                  
                  },
                  parameterMap: function(data) {
                     
                     return JSON.stringify(data);

                  },
              },
             schema: {
                data: function(data) {
                  if (data.Count == 0) {
                    return dataSource;
                  } else {
                    return data.Data.Records;
                  }
                },
                total: "Data.Count",
              }, 
              serverPaging: false,
              serverSorting: false,
              sort: {field:records[0].field,dir:"asc"}
        },
        height: 400,
        resizable: true,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        sortable: true,
        pageable: {
          numeric: false,
          previousNext: false,
          messages: {
            display: "Showing {2} data items"
          }
        },
        // selectable: "multiple, cell",
        // columnMenu: false,
        columns: records  
      });
    })
  }
};
wg.gridDailystatus = function(type,payload,pageIndex,index,onchangStatus){
  // console.log("abdsah")
  var url = "";
  switch(type){
    case"countryValidated":
    case"countryConfirmed":
      url = "/dailystats/reportdailystatscountrysek"; 
    break;
    case"businessvalidated":
    case"businessConfirmed":
      url  = "/dailystats/reportdailystatssek"; 
    break;

  }
  var normalizeDataGrid = function(ds, type){
    var result  = {dataSource:[], column:[]}
    var struct  = 
    {
      AllColumn0:"",AllColumn1:"",AllColumn2:"",
      FMIColumn0:"",FMIColumn1:"",FMIColumn2:"",
      SystemsColumn0:"",SystemsColumn1:"",SystemsColumn2:"",
      TPSColumn0:"",TPSColumn1:"",TPSColumn2:"",
      TeamsColumn0:"",TeamsColumn1:"",TeamsColumn2:""
    }
    switch(type){
      case "countryValidated":
      case "countryConfirmed":  
        _.each(ds, function(v){
        v.region   = v.Label;
        v.level = 0;
        v.country  =  "";
        _.extend( v,_.clone(struct));
        result.dataSource.push(v);
        _.each(v.detail, function(vDetails){
          vDetails.region  = "";
          vDetails.level = 1;

          vDetails.country = vDetails.Label;  
          result.dataSource.push(vDetails);
          result.column =  
          [
            {
              title: "Static",
              headerAttributes: {
                class: "grid-header;"
              },
              columns: [
                {
                  field: "region",
                  title: "Region",  
                  width: 80,
                  attributes: {
                            class:"col-parent align-left"
                        },
                      },  
                  {
                  field: "country",
                  title: "T1 Country",  
                  width: 120,
                  attributes: {
                            class:"  align-left"
                        },
                      },  
                ]
            },
            {
              title: "All",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
              },
              columns: [
                  {
                  field: "AllColumn0",
                  title: "#",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(AllColumn0,'N0')#",
                  attributes: {
                            class: "align-right"
                        },
                      },
                      {
                          field:  "AllColumn1",
                          headerAttributes: {
                        },
                          attributes: {
                              class: "align-right"
                          },

                  template: "#:kendo.toString(AllColumn1,'N0')#",
                          title: "#</br>Mapped", 
                      },
                      {
                          field: "AllColumn2",
                          headerAttributes: {
                        }, 
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.AllColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Mapped", 
                      },    
                ]
              },
              {
              title: "Teams",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
              },
              columns: [
                  {
                  field: "TeamsColumn0",
                  title: "#</br>Mapped",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(TeamsColumn0,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                      },
                      {
                          field: "TeamsColumn1",
                          headerAttributes: {
                        },
                          attributes: {
                              class: "align-right"
                          }, 
                  template: "#:kendo.toString(TeamsColumn1,'N0')#",
                          title: "#</br>Validate",
                         
                      },
                      {
                          field: "TeamsColumn2",
                          headerAttributes: {
                        },
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.TeamsColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Validate",
                         
                      },    
                ]
              },
              {
              title: "Systems",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
              },
              columns: [
                  {
                  field: "SystemsColumn0",
                  title: "#</br>Mapped",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(SystemsColumn0,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                      },
                      {
                        field: "SystemsColumn1",
                      headerAttributes: {
                        },
                  template: "#:kendo.toString(SystemsColumn1,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                          title: "#</br>Validate",
                         
                      },
                      {
                        field: "SystemsColumn2",
                    headerAttributes: {
                        },
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.SystemsColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Validate",
                         
                      },    
                ]
              },
              {
              title: "FMIS",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
                  },
              columns: [
                  {
                  field: "FMIColumn0",
                  title: "#</br>Mapped",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(FMIColumn0,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                      },
                      {
                  field: "FMIColumn1",
                          headerAttributes: {
                        },
                          attributes: {
                              class: "align-right"
                          },
                  template: "#:kendo.toString(FMIColumn1,'N0')#",
                          title: "#</br>Validate",
                         
                      },
                      {
                  field: "FMIColumn2",
                          headerAttributes: {
                        },
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.FMIColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Validate",
                        
                      },    
                ]
              },
              {
              title: "TPS",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
                  },
              columns: [
                  {
                  field: "TPSColumn0",
                  title: "#</br>Mapped",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(TPSColumn0,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                      },
                      {
                  field: "TPSColumn1",
                          headerAttributes: {
                        },
                          attributes: {
                              class: "align-right"
                          },
                  template: "#:kendo.toString(TPSColumn1,'N0')#",
                          title: "#</br>Validate",
                         
                      },
                      {
                  field: "TPSColumn2",
                          headerAttributes: {
                        },
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.TPSColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Validate",
                        
                      },    
                ]
            },
          ]
        })
        });   
      break;
      case "businessvalidated":
      case "businessConfirmed": 
        _.each(ds, function(v){
          v.level =1;
          result.dataSource.push(v); 
          result.column =  
          [
            {
              title: "Static",
              headerAttributes: {
                class: "grid-header;"
              },
              columns: [
                  {
                  field: "Label",
                  title: "Bussines / Function", 
                  width: 200,
                  attributes: {
                            class:" #:data.classTitle#   align-left"
                        },
                      },  
                ]
              },
            {
              title: "All",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
              },
              columns: [
                  {
                  field: "AllColumn0",
                  title: "#",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(AllColumn0,'N0')#",
                  attributes: {
                            class: "align-right"
                        },
                      },
                      {
                          field:  "AllColumn1",
                          headerAttributes: {
                        },
                          attributes: {
                              class: "align-right"
                          },

                  template: "#:kendo.toString(AllColumn1,'N0')#",
                          title: "#</br>Mapped", 
                      },
                      {
                          field: "AllColumn2",
                          headerAttributes: {
                        }, 
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.AllColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Mapped", 
                      },    
                ]
              },
              {
              title: "Teams",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
              },
              columns: [
                  {
                  field: "TeamsColumn0",
                  title: "#</br>Mapped",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(TeamsColumn0,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                      },
                      {
                          field: "TeamsColumn1",
                          headerAttributes: {
                        },
                          attributes: {
                              class: "align-right"
                          }, 
                  template: "#:kendo.toString(TeamsColumn1,'N0')#",
                          title: "#</br>Validate",
                         
                      },
                      {
                          field: "TeamsColumn2",
                          headerAttributes: {
                        },
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.TeamsColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Validate",
                         
                      },    
                ]
              },
              {
              title: "Systems",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
              },
              columns: [
                  {
                  field: "SystemsColumn0",
                  title: "#</br>Mapped",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(SystemsColumn0,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                      },
                      {
                        field: "SystemsColumn1",
                      headerAttributes: {
                        },
                  template: "#:kendo.toString(SystemsColumn1,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                          title: "#</br>Validate",
                         
                      },
                      {
                        field: "SystemsColumn2",
                    headerAttributes: {
                        },
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.SystemsColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Validate",
                         
                      },    
                ]
              },
              {
              title: "FMIS",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
                  },
              columns: [
                  {
                  field: "FMIColumn0",
                  title: "#</br>Mapped",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(FMIColumn0,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                      },
                      {
                  field: "FMIColumn1",
                          headerAttributes: {
                        },
                          attributes: {
                              class: "align-right"
                          },
                  template: "#:kendo.toString(FMIColumn1,'N0')#",
                          title: "#</br>Validate",
                         
                      },
                      {
                  field: "FMIColumn2",
                          headerAttributes: {
                        },
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.FMIColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Validate",
                        
                      },    
                ]
              },
              {
              title: "TPS",
              headerAttributes: {
                style: "vertical-align: middle;text-align: center;"
                  },
              columns: [
                  {
                  field: "TPSColumn0",
                  title: "#</br>Mapped",
                  headerAttributes: {
                        },
                  template: "#:kendo.toString(TPSColumn0,'N0')#",
                          attributes: {
                              class: "align-right"
                          },
                      },
                      {
                  field: "TPSColumn1",
                          headerAttributes: {
                        },
                          attributes: {
                              class: "align-right"
                          },
                  template: "#:kendo.toString(TPSColumn1,'N0')#",
                          title: "#</br>Validate",
                         
                      },
                      {
                  field: "TPSColumn2",
                          headerAttributes: {
                        },
                        template:function(e){
                          if(e.level == 0){
                              return "";
                            }
                          return kendo.toString(e.TPSColumn2,'N1') + "%";
                        
                        },
                          attributes: {
                              class: "align-right  #if(data.level > 0){# col-percentage #}#"
                          },
                          title: "%</br>Validate",
                        
                      },    
                ]
              },
          ];
        }); 
      break;
    }
    return result; 
  };

  ajaxPost(url, payload, function(res){
    var config = normalizeDataGrid(res.Data,type);
    // console.log(config)
    $("#full-chart-" + pageIndex).addClass('fullgrid')
    $("#full-chart-" + pageIndex).html("");
    $("#full-chart-" + pageIndex).kendoGrid({
        dataSource: {
            data: config.dataSource,
        },
        scrollable: true,
        sortable: true,
        filterable: false,
        pageable: false,
        height:400,
        columns:  config.column,
    });
  });
};
wg.filterGridDailystatus = function(page,status){
  status = status || false
  wg.templateFilter()[page].dailystatus(status);
  var config = ko.mapping.toJS(wg.templateChartCurrent)
  config[page].filters.dailystatus =  true 
  ko.mapping.fromJS(config,wg.templateChartCurrent)
};
wg.createGrid = function(id,pageIndex,index,onchangStatus){
    config = ko.mapping.toJS(wg.templateChartCurrent); 

    type = config[pageIndex].charts[index].filter
    var filters = config[pageIndex].filters

    
    payload = wg.parsetFilter(filters);
    wg.filterGridDailystatus(pageIndex)
    if(type  == 'Products'){ 
       $('#container-normal-chart-'+ pageIndex).show('fast')
      $('#container-full-chart-'+ pageIndex).hide('slow')
      $("#button-filter_"+id).text(type) 
      wg.grid(id,payload ,pageIndex,index,onchangStatus)
    }else if(type == 'countrybusinnessvalidated' || type == 'countrybusinnessenriched'){
      $('#container-normal-chart-'+ pageIndex).hide('fast')
      $('#container-full-chart-'+ pageIndex).show('slow')
        $.each(wg.filterChartGridList(), function(i,v){
        if(v.value == type){
           $("#button-filter-full-chart-"+ pageIndex).text(v.text) 
 
        }
      })
     
      $("#full-chart-" + pageIndex).html('')
     
      payload.WorstType = type
       
      wg.gridFUll(payload ,pageIndex,index,onchangStatus)  
    }else if(type == "countryValidated"){
      $('#container-normal-chart-'+ pageIndex).hide('fast')
      $('#container-full-chart-'+ pageIndex).show('slow')
        $.each(wg.filterChartGridList(), function(i,v){
        if(v.value == type){
           $("#button-filter-full-chart-"+ pageIndex).text(v.text) 
 
        }
      })
     
      $("#full-chart-" + pageIndex).html('')
      
      payload.Flag = "validated";
      wg.filterGridDailystatus(pageIndex, true);
      widget.createGridDailyStatusCuntry(type,payload ,pageIndex,index,onchangStatus);
    }else if(type == "businessvalidated"){
      $('#container-normal-chart-'+ pageIndex).hide('fast')
      $('#container-full-chart-'+ pageIndex).show('slow')
        $.each(wg.filterChartGridList(), function(i,v){
        if(v.value == type){
           $("#button-filter-full-chart-"+ pageIndex).text(v.text) 
 
        }
      })
     
      $("#full-chart-" + pageIndex).html('')
   
 
      payload.Flag = "validated";
      wg.filterGridDailystatus(pageIndex, true);
      widget.createGridDailyStatusBusiness(type,payload ,pageIndex,index,onchangStatus);
    }else if(type == "countryConfirmed"){
      $('#container-normal-chart-'+ pageIndex).hide('fast')
      $('#container-full-chart-'+ pageIndex).show('slow')
        $.each(wg.filterChartGridList(), function(i,v){
        if(v.value == type){
           $("#button-filter-full-chart-"+ pageIndex).text(v.text) 
 
        }
      })
     
      $("#full-chart-" + pageIndex).html('')
    
      payload.Flag = "confirmed";
      wg.filterGridDailystatus(pageIndex, true);
      widget.createGridDailyStatusCuntry(type,payload ,pageIndex,index,onchangStatus);
    }else if(type == "businessConfirmed"){
      $('#container-normal-chart-'+ pageIndex).hide('fast')
      $('#container-full-chart-'+ pageIndex).show('slow')
        $.each(wg.filterChartGridList(), function(i,v){
        if(v.value == type){
           $("#button-filter-full-chart-"+ pageIndex).text(v.text) 
 
        }
      })
     
      $("#full-chart-" + pageIndex).html('')
    
      payload.Flag = "confirmed";
      wg.filterGridDailystatus(pageIndex, true);
      widget.createGridDailyStatusBusiness(type,payload ,pageIndex,index,onchangStatus);
    }else{
      $.each(wg.filterChartGridList(), function(i,v){
        if(v.value == type){
           $("#button-filter_"+id).text(v.text) 
        }
      })
      payload.WorstType = type
      wg.grid2(id,payload ,pageIndex,index,onchangStatus)  
    }
    var checkStatusFilter = setInterval(function(){ 
      if(!wg.loading()){
        setTimeout(function(){
          clearInterval(checkStatusFilter)
        
  
          kendo.resize($("#"+id));
        },1000)
      }
    }, 500); 
    // wg.charts[pageIndex][index].value = sortDatas            
};

// TEMPLATE CONFIG //
wg.saveTemplate =  function(){
    return function(){
      if (wg.templateName() == "") {
        swal("", "Please Insert a Template Name", "warning");
      }else{
        configCurrent = ko.mapping.toJS(wg.templateChartCurrent )
        payload = {TemplateName:wg.templateName(), status:wg.statusTemplate(),details:configCurrent}
        ajaxPost("/widgetanalysis/savewidgettemplate",payload , function (res){

          wg.disableValTemplate(false)
          wg.getTemplate() 
          wg.template(payload.TemplateName) 
          swal("Saved!", "", "success");
        })
      }
    }
};

wg.settingTemplate = function(type,pageIndex,index,typeChart){
  config = ko.mapping.toJS(wg.templateChartCurrent)
  config[pageIndex][type][index].type = typeChart
  if(typeChart === 'bar'){
    config[pageIndex][type][index].filter = 'Biggest'
  }else if(typeChart === 'donut'){
    config[pageIndex][type][index].filter = '% of Services by Service Type'
  }else{
    config[pageIndex][type][index].filter = 'Products'
  }
  ko.mapping.fromJS(config,wg.templateChartCurrent)
};

// CLOSE SUMMARY AND CHART //
wg.closeChart = function(category,id,page,index){
    return function(){
       wg.filterGridDailystatus(page)
        type = ''
        if(category == 'charts'){
            $(".container-filter-"+id).hide('slow');
            $("#legend-donut_"+id).remove('');
            $('.close_'+id).hide('fast');
            $('.text_'+id).show('slow');
            $('#icon-plus_'+id).show( "fast" )
            $('#'+id).remove('')
            $('#legend-donut_'+id).remove('')
            $('#box_'+id).css( "border-width", "2px" );
            $('.container_'+id).append('<div id="'+id+'"></di>');

            wg.charts[(page-1)][index].status =  false;
            wg.charts[(page-1)][index].value =  '';
        }else{
            if(index <= 3){
                var position = 'left';
            }else{
                 var position = 'right';
            }
            $('.'+position+'-text_summary-'+id).show('fast');
            $('.'+position+'-container_summary-'+id).hide('fast');
            $('#'+position+'-box_summary-'+id).css( "border-width", "2px" );
            $('.'+position+'-close_summary-'+id).hide('fast');
            $('#'+position+'-total_summary-'+id).hide('fast');
            $('#'+position+'-desc_summary-'+id).hide('fast');
            $('#'+position+'-total_summary-'+id).text('');
            $('#'+position+'-desc_summary-'+id).text('');
            wg.summaries[(page-1)][index].status =  false;
            wg.summaries[(page-1)][index].value =  '';
        }
     
        pageIndex = page - 1;
        wg.settingTemplate(category,pageIndex,index,type)

    }
};
wg.closeFullChart =  function(index){
  return function(){ 
    wg.filterGridDailystatus(index)
    wg.templateFilter()[index].dailystatus(false);
    $('#container-full-chart-'+index).hide('fast')
    $('#container-normal-chart-'+index).show('slow')
    config = ko.mapping.toJS(wg.templateChartCurrent);
    for(var i in config[index].charts){
      // console.log(wg.charts[index][i].status )
      if(wg.charts[index][i].status === true){ 
        chart = config[index].charts[i] 
        id ='chart-'+chart.keyID; 
        $(".container-filter-"+id).hide('slow');
        $("#legend-donut_"+id).remove('');
        if($('.close_'+id).is(":visible")){

          $('.close_'+id).hide('fast');
 
        }
        $('.text_'+id).show('slow');
        $('#icon-plus_'+id).show( "fast" )
        $('#'+id).remove('')
        $('#legend-donut_'+id).remove('')
        $('#box_'+id).css( "border-width", "2px" );
        $('.container_'+id).append('<div id="'+id+'"></di>')
        wg.charts[index][i].status =  false;
        wg.charts[index][i].value =  '';
      }
    }
  }
}
wg.actionCloseFullChart = function (chart,pageIndex,index){
  id = 'chart-'+chart.keyID;
  $(".container-filter-"+id).hide('slow');
  $("#legend-donut_"+id).remove('');
  $('.close_'+id).hide('fast');
  $('.text_'+id).show('slow');
  $('#icon-plus_'+id).show( "fast" )
  $('#'+id).remove('')
  $('#legend-donut_'+id).remove('')
  $('#box_'+id).css( "border-width", "2px" );
  $('.container_'+id).append('<div id="'+id+'"></di>')
  wg.charts[pageIndex][index].status =  false;
  wg.charts[pageIndex][index].value =  '';
  wg.settingTemplate('charts',pageIndex, index, '') 
} 

// SEARCH SUMMARY LIST //
wg.checksearchresult = function(){ 
  wg.searchresult(true);
  wg.search();
}
wg.backsearch = function(){
   wg.searchresult(false);
   wg.search();
   wg.inputsearch(''); 
}
wg.search = function(){
    var val1 = []
    var val2 = []
    var val3 = []
    var val4 = []
    var val5 = []
    var val6 = []
    var valres1 = []
    var valres2 = []
    var valres3 = []
    var valres4 = []
    var valres5 = []
    var valres6 = []
    
    $("#inputsearch").kendoAutoComplete({
        dataSource: wg.summaryDataFilter(),
        filter: "contains",
        placeholder: "Search",
        // separator: ", "
    });
    $.each(wg.summaryOneBoxList(), function(i, v){
        if (v.type == "processes") {
            val1.push({"text" : v.text,"value": v.value});
            wg.summaryprocessesList(val1)
            if(v.text.toLowerCase().indexOf(wg.inputsearch().toLowerCase()) > -1){
                valres1.push({"text" : v.text,"value": v.value});
            }
        }else if (v.type == "documents") {
            val2.push({"text" : v.text,"value": v.value});
            wg.summarydocumentsList(val2)
            if(v.text.toLowerCase().indexOf(wg.inputsearch().toLowerCase()) > -1){
                valres2.push({"text" : v.text,"value": v.value});
            }
        }else if (v.type == "assets") {
            val3.push({"text" : v.text,"value": v.value});
            wg.summaryassetsList(val3)
            if(v.text.toLowerCase().indexOf(wg.inputsearch().toLowerCase()) > -1){
                valres3.push({"text" : v.text,"value": v.value});
            }
        }else if (v.type == "dependencies") {
            val4.push({"text" : v.text,"value": v.value});
            wg.summarydependenciesList(val4)
            if(v.text.toLowerCase().indexOf(wg.inputsearch().toLowerCase()) > -1){
                valres4.push({"text" : v.text,"value": v.value});
            }
        }else if (v.type == "others") {
            val5.push({"text" : v.text,"value": v.value});
            wg.summaryothersList(val5)
            if(v.text.toLowerCase().indexOf(wg.inputsearch().toLowerCase()) > -1){
                valres5.push({"text" : v.text,"value": v.value});
            }
        }else if (v.type == "resources") {
            val6.push({"text" : v.text,"value": v.value});
            wg.summaryresourcesList(val6)
            if(v.text.toLowerCase().indexOf(wg.inputsearch().toLowerCase()) > -1){
                valres6.push({"text" : v.text,"value": v.value});
            }
        }
    })
    wg.summaryresprocessesList(valres1)
    wg.summaryresdocumentsList(valres2)
    wg.summaryresassetsList(valres3)
    wg.summaryresdependenciesList(valres4)
    wg.summaryresothersList(valres5)
    wg.summaryresresourcesList(valres6)
}

// INSERT VALUE SUMMARY AND CHART //
wg.insertValueCharts =  function(payload, type, filter,  page,index){
  var newPayload = wg.parsetFilter(payload)
 
  switch(type){
    case'bar':
      switch(filter){
        case 'Service FTE':
            ajaxPost("/ociranalysis/servicefte", newPayload , function (res){
                var datas = res;
                var sortDatas = sortBarChart(datas)
                wg.charts[page][index].value = sortDatas
                wg.charts[page][index].status = true            
            });
        break;
        case 'Fte by Country':
            if ( newPayload.SupplierCountry.length == 0){
                ajaxPost("/ociranalysis/ftebycountry", newPayload , function (res){
                    var datas = res;
                    var sortDatas = sortBarChart(datas); 
                    wg.charts[page][index].value = sortDatas
                    wg.charts[page][index].status = true            
                })
            }else {
                ajaxPost("/ociranalysis/ftebycountrylegal", newPayload , function (res){
                    var datas = res;
                    var sortDatas = sortBarChart(datas);   
                    wg.charts[page][index].value = sortDatas
                    wg.charts[page][index].status = true    
                })        
            }  
        break;
        case 'level 1 by country':
            ajaxPost("/ociranalysis/levelbycountry", newPayload , function (res){
                
                var datas = []
                max = 10;
                if(res.length < 10){
                  max = res.length
                }
                for(i=0; i<max; i++){
                  datas.push({Count:res[i].Count,_id:res[i]._id})
                }
                var sortDatas = sortBarChart(datas);     
                wg.charts[page][index].value = sortDatas
                wg.charts[page][index].status = true    
            
            })
        break;
        case 'Process by GBS and Others':
          ajaxPost("/ociranalysis/processbygbs", newPayload , function (res){
              var datas = res;
              var sortDatas = sortBarChart(datas);
              wg.charts[page][index].value = sortDatas
              wg.charts[page][index].status = true
          })
        break;
        case 'Assets Utilized':
            ajaxPost("/ociranalysis/getassetsutilized", newPayload , function (res){
                var datas = res;
                var sortDatas = sortBarChart(datas);   
                wg.charts[page][index].value = sortDatas
                wg.charts[page][index].status = true    
                   
            })
        break;
        case 'Biggest':
            if(newPayload.Categoryname.length == 0){
                ajaxPost("/ociranalysis/receivercategory", newPayload , function (res){
                    var datas = res;
                    var sortDatas = sortBarChart(datas) 
                    wg.charts[page][index].value = sortDatas
                    wg.charts[page][index].status = true    
                  
                })
            }else{
                ajaxPost("/ociranalysis/receivercategoryproduct", newPayload , function (res){
                    // var datas = res;
                    // var sortDatas = sortBarChart(datas); 
                    data = []
                    max = 10;
                    if(res.length < 10){
                     max = res.length
                    }
                   
                    for(i=0; i<max; i++){
                      data.push({Count:res[i].Value,_id:res[i].Country})
                    }
                    wg.charts[page][index].value = data
                    wg.charts[page][index].status = true    
            
                });
            }
        break;
        case 'Worst 10 [% Validated]':
            var newPayload = $.extend(newPayload,{WorstType : "validated"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true 
            });
        break;
        case 'Worst 10 [% Enriched]':
              var newPayload = $.extend(newPayload,{WorstType : "enriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                    
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true 
              });
        break;
        case 'Worst 10% Validated by Business/Function':
              var newPayload = $.extend(newPayload,{WorstType : "businnessvalidated"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                
                wg.charts[pageIndex][index].value = res
                wg.charts[pageIndex][index].status = true 
              });
        break;
        case 'Worst 10% Enriched by Business/Function':
              var newPayload = $.extend(newPayload,{WorstType : "businnessenriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
               
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true   
              });
        break;
          case '% Validated all Countries': 
            var newPayload = $.extend(newPayload,{WorstType : "validated"});
            ajaxPost("/ociranalysis/percentvalidated", newPayload , function (res){
            

                wg.charts[page][index].value = res
                wg.charts[page][index].status = true 
            });
          break;
          case '% Enriched all Countries':
            var newPayload = $.extend(newPayload,{WorstType : "enriched"});
            ajaxPost("/ociranalysis/percentvalidated", newPayload , function (res){
           

                wg.charts[page][index].value = res
                wg.charts[page][index].status = true 
            });
          break;
          case 'Best 10 [% Validated]' :
              var newPayload = $.extend(newPayload,{WorstType : "reversevalidated"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                
                 wg.charts[page][index].value = res
                 wg.charts[page][index].status = true   
              });
          break;
          case 'Best 10 [% Enriched]':
              var newPayload = $.extend(newPayload,{WorstType : "reverseenriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
               
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
              });
          break;
          case 'Pending Best 10 [% Validated]':
              var newPayload = $.extend(newPayload,{WorstType : "pendingbestvalidated"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
          
                 wg.charts[page][index].value = res
                wg.charts[page][index].status = true   
              });
          break;
          case 'Pending Best 10 [% Enriched]':
              var newPayload = $.extend(newPayload,{WorstType : "pendingbestenriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
              
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
              });
          break;
          case 'Pending Worst 10 [% Validated]':
              var newPayload = $.extend(newPayload,{WorstType : "pendingworstvalidated"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                
                 wg.charts[page][index].value = res
                wg.charts[page][index].status = true   
              });
          break;
          case 'Pending Worst 10 [% Enriched]':
              var newPayload = $.extend(newPayload,{WorstType : "pendingworstenriched"});
              ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                  
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
              });
          break;
          case 'Comparison Region [% Validated Service]':
            var newPayload = $.extend(newPayload,{WorstType : "validated"});
       
            ajaxPost("/ociranalysis/comparisonregion", newPayload , function (res){
             
              wg.charts[page][index].value = res
              wg.charts[page][index].status = true
            });
          break;
          case 'Comparison Region [% Confirmed Service]':
            var newPayload = $.extend(newPayload,{WorstType : "enriched"});
           
            ajaxPost("/ociranalysis/comparisonregion", newPayload , function (res){
               
              wg.charts[page][index].value = res
              wg.charts[page][index].status = true
            });
          break;
          case 'Worst 10 by Process Owner [% Validated Service]':
            var newPayload = $.extend(newPayload,{WorstType : "worstownervalidated"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
               
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
            });
          break;
          case 'Worst 10 by Process Owner [% Confirmed Service]':
            var newPayload = $.extend(newPayload,{WorstType : "worstownerenriched"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                 
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
            });
          case 'Best 10 by Process Owner [% Validated Service]':
            var newPayload = $.extend(newPayload,{WorstType : "bestownervalidated"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
            });
          break;
          case 'Best 10 by Process Owner [% Confirmed Service]':
            var newPayload = $.extend(newPayload,{WorstType : "bestownerenriched"});
            ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
                
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
            });
          break;
          case 'Systems per business/function': //here
            var newPayload = $.extend(newPayload,{WorstType : ""});
            ajaxPost("/ociranalysis/systemsperbusiness", newPayload , function (res){
              var internal = []
              var external = []
              var underreview = []
              var total = []
            

          
              max = 10;
               if(res.internal.length < 10){
                max = res.internal.length
              }
              var tenPercent = Enumerable.From(res.internal).Max("$.Value") + ((10 * Enumerable.From(res.internal).Max("$.Value")) / 100) 
        
              for(i=0; i<max; i++){
                internal.push({Count:res.internal[i].Count,_id:res.internal[i].Country,Value:res.internal[i].Value})
                external.push({Count:res.external[i].Count,_id:res.external[i].Country,Value:res.external[i].Value})
                underreview.push({Count:res.underreview[i].Count,_id:res.underreview[i].Country,Value:res.underreview[i].Value})
                total.push(({Count:tenPercent - res.external[i].Value, _id:'', Value:res.external[i].Value}))
              }
         
            
              data = {internal:'',external:'',underreview:'',total:''};
              data.internal = internal
              data.external = external
              data.underreview = underreview
              data.total = total

              wg.charts[page][index].value = data
              wg.charts[page][index].status = true    
            });
          break;
          case 'Processes per critical service provider': //here
            var newPayload = $.extend(newPayload,{WorstType : ""});
            ajaxPost("/ociranalysis/getcriticalprovider", newPayload , function (res){
            

              data = {gbs:'',inentity:'',intra:'',other:'',total:''}
              var gbs = []
              var inentity = []
              var intra = []
              var other = []
              var total = []

              max = 10;
               if(res.intra.length < 10){
                max = res.intra.length
              }
              var tenPercent = Enumerable.From(res.intra).Max("$.Value") + ((10 * Enumerable.From(res.intra).Max("$.Value")) / 100) 

              for(i=0; i<max; i++){
                intra.push({Count:res.intra[i].Count,_id:res.intra[i].Country,Value:res.intra[i].Value})
                inentity.push({Count:res.inentity[i].Count,_id:res.inentity[i].Country,Value:res.inentity[i].Value})
                gbs.push({Count:res.gbs[i].Count,_id:res.gbs[i].Country,Value:res.gbs[i].Value})
                other.push({Count:res.other[i].Count,_id:res.other[i].Country,Value:res.other[i].Value})
                total.push(({Count:tenPercent - res.other[i].Value, _id:'', Value:res.other[i].Value}))
              }

              

              data.gbs = gbs
              data.intra = intra
              data.inentity = inentity
              data.other = other
              data.total = total
              
              wg.charts[page][index].value = data
              wg.charts[page][index].status = true    
            
              // oa.chartStackedCategory(intra,gbs,inentity,other);
            });
          break;
          case 'Critical Service Providers by FTE': //here
            var newPayload = $.extend(newPayload,{WorstType : ""});
            ajaxPost("/ociranalysis/getcriticalproviderfte", newPayload , function (res){
            

              data = {gbs:'',inentity:'',intra:'',other:'',total:''}
              var gbs = []
              var inentity = []
              var intra = []
              var other = []
              var total = []
              
              max = 10;
               if(res.intra.length < 10){
                max = res.intra.length
              }
              var tenPercent = Enumerable.From(res.intra).Max("$.Value") + ((10 * Enumerable.From(res.intra).Max("$.Value")) / 100) 

              for(i=0; i<max; i++){
                intra.push({Count:res.intra[i].Count,_id:res.intra[i].Country,Value:res.intra[i].Value})
                inentity.push({Count:res.inentity[i].Count,_id:res.inentity[i].Country,Value:res.inentity[i].Value})
                gbs.push({Count:res.gbs[i].Count,_id:res.gbs[i].Country,Value:res.gbs[i].Value})
                other.push({Count:res.other[i].Count,_id:res.other[i].Country,Value:res.other[i].Value})
                total.push(({Count:tenPercent - res.other[i].Value, _id:'', Value:res.other[i].Value}))
              }

              

              data.gbs = gbs
              data.intra = intra
              data.inentity = inentity
              data.other = other
              data.total = total
              
              wg.charts[page][index].value = data
              wg.charts[page][index].status = true  
            
            });
          break;  
          case 'Location by FTE': //here
            var newPayload = $.extend(payload,{WorstType : ""});
            ajaxPost("/ociranalysis/getlocationfte", newPayload , function (res){

              data = {gbs:'',inentity:'',intra:'',other:'',total:''}
              var gbs = []
              var inentity = []
              var intra = []
              var other = []
              var total = []
              
              max = 10;
               if(res.intra.length < 10){
                max = res.intra.length
              }
              var tenPercent = Enumerable.From(res.intra).Max("$.Value") + ((10 * Enumerable.From(res.intra).Max("$.Value")) / 100) 

              for(i=0; i<max; i++){
                intra.push({Count:res.intra[i].Count,_id:res.intra[i].Country,Value:res.intra[i].Value})
                inentity.push({Count:res.inentity[i].Count,_id:res.inentity[i].Country,Value:res.inentity[i].Value})
                gbs.push({Count:res.gbs[i].Count,_id:res.gbs[i].Country,Value:res.gbs[i].Value})
                other.push({Count:res.other[i].Count,_id:res.other[i].Country,Value:res.other[i].Value})
                total.push(({Count:tenPercent - res.other[i].Value, _id:'', Value:res.other[i].Value}))
              }

              

              data.gbs = gbs
              data.intra = intra
              data.inentity = inentity
              data.other = other
              data.total = total
              
              wg.charts[page][index].value = data
              wg.charts[page][index].status = true  
            
            });
          break;
          case 'Buildings by country':
            var newPayload = $.extend(newPayload,{WorstType : ""});
            ajaxPost("/ociranalysis/buildingbycountry", newPayload , function (res){
              data = []
              max = 10;
              if(res.length < 10){
                max = res.length
              }
                   
              for(i=0; i<max; i++){
                data.push({Count:res[i].Value,_id:res[i].Country})
              }
              wg.charts[page][index].value = data
              wg.charts[page][index].status = true    
            });
          break;    
          case 'Third party suppliers':
            var newPayload = $.extend(newPayload,{WorstType : ""});
            ajaxPost("/ociranalysis/thirdpartysuppliers", newPayload , function (res){
              data = []
              max = 10;
              if(res.length < 10){
                max = res.length
              }
                   
              for(i=0; i<max; i++){
                data.push({Count:res[i].Value,_id:res[i].Country})
              }
              wg.charts[page][index].value = data
              wg.charts[page][index].status = true    
            });
          break;
          case 'Third party suppliers by business':
              var newPayload = $.extend(newPayload,{WorstType : ""});
              ajaxPost("/ociranalysis/tpsbybusiness", newPayload , function (res){
                data = []
                max = 10;
                if(res.length < 10){
                 max = res.length
                }
                for(i=0; i<max; i++){
                  data.push({Count:res[i].Value,_id:res[i].Country})
                }  
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
              });
          break;
          case 'Third party suppliers by country':
              var newPayload = $.extend(newPayload,{WorstType : ""});
              ajaxPost("/ociranalysis/tpsbycountry", newPayload , function (res){
                data = []
                max = 10;
                if(res.length < 10){
                 max = res.length
                }
                for(i=0; i<max; i++){
                  data.push({Count:res[i].Value,_id:res[i].Country})
                }  
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
              });
          break;
          default:
             ajaxPost("/ociranalysis/cefassessmentchart", newPayload , function (res){
                var datas = res;
                var sortDatas = sortBarChart(datas);    
                wg.charts[page][index].value = sortDatas
                wg.charts[page][index].status = true    
            
          })
        }  
    break;
    case'donut': 
      switch(filter){
        case 'In-Entity vs Intra-Group':
            ajaxPost("/ociranalysis/getdonutservices", newPayload , function (res){
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
            }); 
        break;
        case 'In-Entity vs Intra-Group FTE':
            ajaxPost("/ociranalysis/getdonutservicesfte", newPayload , function (res){
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
            ;
            });
        break;
        default:
            ajaxPost("/ociranalysis/getdonutl3processes", newPayload , function (res){
                wg.charts[page][index].value = res
                wg.charts[page][index].status = true
            
            }); 
      }  
    break;
    default:
      if(filter  == 'Products'){
        ajaxPost("/ociranalysis/getproductnamecef", newPayload , function (res){
           wg.charts[page][index].value = res  
           wg.charts[page][index].status = true              
        }); 
      }else if(filter == 'countrybusinnessvalidated' || filter == 'countrybusinnessenriched'){
        newPayload.WorstType = filter
        wg.charts[page][index].value = {coloumn:'',records:''}
        ajaxPost("/ociranalysis/dgvalidatedcountryfield",newPayload , function (res){
           wg.charts[page][index].value.coloumn = res.Data.Records  
           wg.charts[page][index].status = true     
                 
        });
        ajaxPost("/ociranalysis/dgvalidatedcountry", newPayload , function (res){
         
           wg.charts[page][index].value.records = res  
           wg.charts[page][index].status = true       
                 
        });
      }else{
 
        newPayload.WorstType = filter
        
        ajaxPost("/ociranalysis/dgmappingteam", newPayload , function (res){
           wg.charts[page][index].value = res  
           wg.charts[page][index].status = true              
        }); 
      }
  }
}
wg.insertValueSummaries = function(payload, type, filter,  page, index){
  var newPayload = wg.parsetFilter(payload)
  newPayload.BoxType = filter
  ajaxPost("/widgetanalysis/getwidgetsummarybox",newPayload , function (res){
      var total = kendo.toString(res.Data, "n0"); 
      wg.summaries[page][index].value = total 
      wg.summaries[page][index].status = true 
  });
}

// PAGE CONFIG//
wg.addPage =  function(){
    return function(){
      index = parseInt(wg.totalPage()) + 1;
 

      summariesForTemplate = [];
      summaries = []
      for(i=1; i<=8; i++){
        summariesForTemplate.push({keyID:index +'-'+i, type:'',filter:''})
        summaries.push({value:''})
      }

      chartsForTemplate = []
      charts = []
      for(i=1; i<=3; i++){
        chartsForTemplate.push({keyID:index +'-'+i, type:''})
        charts.push({value:''})
      }
      wg.summaries.push(summaries) 
      wg.charts.push(charts) 

      newTemplate = ko.mapping.fromJS({page:index, filters:wg.filter,summaries:summariesForTemplate,charts:chartsForTemplate});
      wg.templateChart.push(newTemplate) 
      wg.templateChartCurrent.push(newTemplate) 
      wg.templateFilter.push(ko.mapping.fromJS(wg.filter)) 
      
      wg.callAjaxFilter(parseInt(wg.totalPage()), null)
      var pagelist = wg.activePageList();
      pagelist.push({text: index, value:index-1})
      wg.activePageList(pagelist)
      wg.pageValue(wg.totalPage())
      wg.activePage(index - 1)
      wg.totalPage(index)
    }
};
wg.movePage = function(type){
  return function(){
    page =  wg.activePage();
    if(type === 'next'){
      if((page+1) == wg.totalPage()){
        return;
      }
      page  += 1
    }else{
      if(page == 0){
        return;
      }
      page  -= 1
    }
    wg.pageValue(parseInt(page))
  }
};
wg.pageValue.subscribe(function(newValue){

    if(wg.useTemplateStatus() &&  !wg.reloadPageStatus[newValue]){
      wg.generateTemplate(parseInt(newValue))
    } 
    wg.activePage(parseInt(newValue)); 
});

wg.openPopUpChart = function(index,type){
  return function(){
    // if(type == 'bar'){
    //   typeChart = type;
    // }else{
      wg.activeIndexChart(index)
      config = ko.mapping.toJS(wg.templateChartCurrent);
      typeChart =config[wg.activePage()].charts[index].type; 
    // }
    switch(typeChart){
        case'bar':
          $("#bar-filter-modal").modal('show'); 
        break;
        case'donut':
          $("#donut-filter-modal").modal('show'); 
        break;
        default:
          $("#grid-filter-modal").modal('show'); 
    }
  }
};
wg.showPopUp =  function(id,type){
    return function(){
        if(type == "chart"){
            $('.messege-pop-up_'+id).show( "fast" );
            $('#icon-plus_'+id).removeClass( "glyphicon-plus" )
            wg.popupChartId(id)
        }else{
            wg.activeIndexSummary(id)        
            $("#summarymodal").modal('show'); 
        }
        wg.backsearch();
    }
};


wg.changeFilter =  function(e,type,pageIndex,index,filterName){ 
  config = ko.mapping.toJS(wg.templateChartCurrent)
 
  if(type === 'charts'){
    var filter = 'filter';
    config[pageIndex][type][index][filter] = e._old
    ko.mapping.fromJS(config,wg.templateChartCurrent)
    var id =  'chart-'+  config[pageIndex].charts[index].keyID;
    wg.generateChart(id, config[pageIndex].charts[index].type,pageIndex,index,true)   
  }else{
    config[pageIndex][type][filterName] = e._old
    ko.mapping.fromJS(config,wg.templateChartCurrent);
    wg.generateFilter(e._old, pageIndex, filterName);

    for(var i in config[pageIndex].charts){
        var id = 'chart-'+  config[pageIndex].charts[i].keyID;
        if(config[pageIndex].charts[i].type != ''){
            wg.generateChart(id, config[pageIndex].charts[i].type,pageIndex,i,true)   
        }
    }
    for(var i in config[pageIndex].summaries){
        var id =  config[pageIndex].summaries[i].keyID;
        if(config[pageIndex].summaries[i].type != ''){
            wg.generateSummary(config[pageIndex].summaries[i].filter,id, config[pageIndex].summaries[i].type,pageIndex,i, true)   
        }
    }
  }
};
function alignLegendLeft(id) {
    var isFound = false
    jQuery('#'+id+' g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
        if (isFound) return
        if ($(e).html() == '') isFound = true
        $(e).find('text').attr('x', 0)
    })
};
var promises = [
    $.Deferred(),
    $.Deferred()
];
wg.titleFile = '';
wg.tabFirstName = '';
wg.tabSecondName = '';

wg.tabFirst = ko.observable(true);
function exportExcelTwoTab(){
  var grid;
  if(wg.tabFirst()){
    var grid = $("#grid-chart-1").data("kendoGrid");
  }else{
    var grid = $("#grid-chart-2").data("kendoGrid");
  }
  grid.saveAsExcel();
  var payload = {
    Type : "Ociranalysis Summary Drilldown Barchart Grid"
  }
  ajaxPost("/analyticuser/downloadlog", payload, function (res){ })
    
    // var grid = $("#grid-chart-1").data("kendoGrid");
    // grid.saveAsExcel();
    // var payload = {
    //    Type : "Ociranalysis Summary Drilldown Barchart Grid"
    //  }
    //  ajaxPost("/analyticuser/downloadlog", payload, function (res){
    //  })

    // var grid = $("#grid-chart-2").data("kendoGrid");
    // grid.saveAsExcel();
    // var payload = {
    //    Type : "Ociranalysis Summary Drilldown Barchart Grid"
    //  }
    //  ajaxPost("/analyticuser/downloadlog", payload, function (res){
    //  })

}
function exportExcel2(){
  var grid;
  var grid = $("#grid-chart-detail").data("kendoGrid");
  grid.saveAsExcel();
  var payload = {
    Type : "Ociranalysis Summary Drilldown Barchart Grid"
  }
  ajaxPost("/analyticuser/downloadlog", payload, function (res){})

}
function sortBarChart (datas){
  $.each(datas,function(index,value){
      for(var i=0; i<(datas.length-1); i++){
          if(datas[i].Count < datas[i+1].Count){
              var old = datas[i+1];
              datas[i+1] = datas[i]
              datas[i] = old
          }
      }
  }) 
  return datas;
}


 

wg.statusTemplate.subscribe(function(newValue){
  listTemplate = [] 
  $.each(wg.templateList(), function(i,v){
    if(newValue == ''){
        listTemplate.push(v)
    }else{
      if(newValue == v.status){
        listTemplate.push(v)
      }
    }
  })
   
  wg.templateList2(listTemplate)

})

wg.backsearchBar = function(){
   wg.searchresultBar(false);
   wg.searchChartList();
   wg.inputsearchBar(''); 
} 
wg.titleListBar = ko.mapping.fromJS([])
wg.getListTab =  function(){
    ajaxPost("/ociranalysis/getlistbarchart",{}, function (res){
      datas = []
      dataFilter = []
      $.each(res.Data.rows, function(i,v){

        datas.push({text:v.title, value:v.url, type:v.icon})
        dataFilter.push(v.title);
      });
      ko.mapping.fromJS( res.Data.titles,wg.titleListBar)
      var titles = []
      for(i in res.Data.titles){
       var id;
        switch (res.Data.titles[i]){
          case 'Processes':
            id ='prs'
          break;
          case 'Resources':
            id ='rsc'
          break;
          case 'Assets':
            id ='ast'
          break;
          case 'CEF':
            id ='cef'
          break;
          case 'Mapping Team':
            id ='mpt'
          break;

        }
        titles.push({id:'#filterBar-'+id,name:res.Data.titles[i]})

      }
      
      $( "#filterBar-prs" ).removeClass( 'active' );
      if(titles.length > 0){
        $(titles[0].id).addClass('active')
      }
      ko.mapping.fromJS( titles, wg.titleListBar)
      wg.datafilterChartBarList(dataFilter)
      wg.filterChartBarList(datas)
      wg.searchChartList()
    });
}
wg.checksearchresultBar =  function(){
  wg.searchresultBar(true) 
  wg.searchChartList();
}
wg.searchChartList = function(){
 
    var valres1 = []
    var valres2 = []
    var valres3 = []
    var valres4 = []
    var valres5 = []
    var valres6 = []
    



    $("#inputsearchBar").kendoAutoComplete({
        dataSource: wg.datafilterChartBarList(),
        filter: "contains",
        placeholder: "Search",
        // separator: ", "
    });
    $.each(wg.filterChartBarList(), function(i, v){
 
        if (v.type == "Processes") { 
            if(v.text.toLowerCase().indexOf(wg.inputsearchBar().toLowerCase().trim()) > -1){
                valres1.push({"text" : v.text,"value": v.value});
            }
        }else if (v.type == "Resources") { 
       
            if(v.text.toLowerCase().indexOf(wg.inputsearchBar().toLowerCase().trim()) > -1){
                valres2.push({"text" : v.text,"value": v.value});
            }
        }else if (v.type == "Assets") { 
      
            if(v.text.toLowerCase().indexOf(wg.inputsearchBar().toLowerCase().trim()) > -1){
                valres3.push({"text" : v.text,"value": v.value});
            }
        }else if (v.type == "CEF") { 
   
            if(v.text.toLowerCase().indexOf(wg.inputsearchBar().toLowerCase().trim()) > -1){
                valres4.push({"text" : v.text,"value": v.value});
            }
        }else if (v.type == "Mapping Team") { 
      
            if(v.text.toLowerCase().indexOf(wg.inputsearchBar().toLowerCase().trim()) > -1){
                valres5.push({"text" : v.text,"value": v.value});
            }
        } 
    })  
    
    wg.filterChartBarProcesses(valres1)
    wg.filterChartBarResources(valres2)
    wg.filterChartBarAssets(valres3)
    wg.filterChartBarCEF(valres4)
    wg.filterChartBarMapTeam(valres5) 
}
wg.callAjaxFilter = function(index,payload){
    if(payload == null){
      payload = {
        ReceiverCountry :[],
        ReceiverLegalEntity : [],
        SupplierCountry : [],
        SupplierLegalEntity : [], 
        Categoryname : [],
        Suppliertype: '',
        Productfunction :[]
      };
    }

    wg.loading(true)
    wg.loadingFilter = {ReceiverCountry:true,ReceiverLegalEntity:true,SupplierCountry:true,SupplierLegalEntity:true,Categoryname:true,Suppliertype:true,Productfunction:true,Parentprocessname:true,GPO:true}
    wg.getReceivingCountry(index,payload);
    wg.getReceivingLegalEntity(index,payload);
    wg.getSupplyCountry(index,payload);
    wg.getSupplyLegalEntity(index,payload);
    wg.getSupplyType(index,payload);
    wg.getProduct(index,payload);
    wg.getCategoryName(index,payload); 
    wg.getRegion(index,payload); 
    wg.getFunction(index,payload);
    wg.getParentProcessName(index,payload);
    wg.getGlobalProcessOwner(index,payload);

    var checkStatusFilter  = setInterval(function(){ 
      if(!wg.loadingFilter['Region'] && !wg.loadingFilter['ReceiverCountry'] && !wg.loadingFilter['ReceiverLegalEntity'] && !wg.loadingFilter['SupplierCountry'] && !wg.loadingFilter['SupplierLegalEntity']     && !wg.loadingFilter['Categoryname'] && !wg.loadingFilter['Suppliertype']&& !wg.loadingFilter['Productfunction'] && !wg.loadingFilter['Parentprocessname']&& !wg.loadingFilter['GPO'] ){
        wg.loading(false) 
        clearInterval(checkStatusFilter)
      }
    }, 500); 
}
wg.numberFormat =  function(value){
    if (typeof value === 'string') {
        if(value.toLowerCase() === 'null' || value.toLowerCase() === 'n' || value.toLowerCase() === 'n/a' || value.toLowerCase() == ''){
            return 0;
        }
        var regex = "/[^(?:\d*\.)?\d]+/"
        return (String(value).match(/[^(?:\d*\.)?\d]+/) == null)? parseInt(value).toLocaleString():String(value); 
            // :String(value); 
    
    }else{
        var regex = "/[^(?:\d*\.)?\d]+/"
        return (String(value).match(/[^(?:\d*\.)?\d]+/) == null)? parseInt(value).toLocaleString():String(value); 
    }
}
wg.showDetailProductNameCEF = function(name, receivercountry, subgroupid, cefcritical){
  //   return function(){
        var url = "/ociranalysis/getproductnamecefdetail";
        var payload = {
            productfunction: name,
            receivercountry: receivercountry,
            subgroupid: subgroupid,
        };
        if (cefcritical == "Y"){
          cefcritical = "CEF"
        }else {
          cefcritical = "Non-CEF"
        }
        ajaxPost(url, payload, function (res){
            res.alternativeproviders = wg.numberFormat( res.alternativeproviders );
            res.customeraccounts = wg.numberFormat( res.customeraccounts );
            res.customerscounterparties = wg.numberFormat( res.customerscounterparties );
            
            res.assets = wg.numberFormat( res.assets );
            res.committedfacilities = wg.numberFormat( res.committedfacilities );
            res.liabilities = wg.numberFormat( res.liabilities );
            
            res.nonretailfunctions = wg.numberFormat( res.nonretailfunctions );
            res.notionaloutstandingbookinglocation = wg.numberFormat( res.notionaloutstandingbookinglocation );
            res.retailfunctions = wg.numberFormat( res.retailfunctions );

            res.tradevalue = wg.numberFormat( res.tradevalue );
            res.tradevolume = wg.numberFormat( res.tradevolume );

            wg.valueProductFunctionName(res) 

            $("#modalproductname").modal("show");
            if ( cefcritical == "Non-CEF"){
              $("#statusCefcritical").css("color","red")  
            }
            $("#statusCefcritical").text(cefcritical)
            $(".receivercountry").text(res.receivercountry);
            $(".receiverlegalentity").text(res.receiverlegalentity);
            $(".projectName").text(name);
        })

  //   }
}
wg.downloadbarchart = function(){
    return function(){
        var grid = $("#barchart").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
          Type : "widgetanalysis Drilldown Barchart Grid"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}
wg.productnamePopup = function(){
    var payload ={
        accessid: "ocir-analysis-product-popup"
    }
    ajaxPost("/aclsysadmin/isauthenticate",payload , function (res){
        if (res.Data == true) {
            wg.popupvalue(true);
        }else{
            wg.popupvalue(false);
        };
    })
}

wg.exportPDF = function(){
    template = JSON.stringify(ko.mapping.toJS(wg.templateChartCurrent()))
    localStorage.removeItem('type');
    localStorage.removeItem('template');
    localStorage.removeItem('valueCharts');
    localStorage.removeItem('valueSummaries');
    localStorage.removeItem('ListFilterBar'); 

    localStorage.setItem('type', 'download');
    localStorage.setItem('ListFilterBar', JSON.stringify(wg.filterChartBarList()));
    localStorage.setItem('template', template);
    localStorage.setItem('valueCharts', JSON.stringify(wg.charts));
    localStorage.setItem('valueSummaries', JSON.stringify(wg.summaries));
 
    openPopUp()

    var payload = {
      Type : "widgetanalysis PDF"
    }
    ajaxPost("/analyticuser/downloadlog", payload, function (res){
    })
}
function openPopUp(){ 
    // var wnd = 
    var childWind = window.open("/live/static/core/report-pdf/index.html");
        childWind.location.reload();
    // setTimeout(function() {
    //   wnd.close();
    // }, 5000);
    return false;
}
wg.expand = function(index){
    return function(){
        var classUp = 'glyphicon-chevron-up'
        var classDown = 'glyphicon-chevron-down'
        $("#expand-"+index).hasClass(classUp) ? $("#expand-"+index).addClass(classDown).removeClass(classUp): $("#expand-"+index).addClass(classUp).removeClass(classDown);
    }
}
wg.expandBar = function(index){
    return function(){
        var classUp = 'glyphicon-chevron-up'
        var classDown = 'glyphicon-chevron-down'
        $("#expandBar-"+index).hasClass(classUp) ? $("#expandBar-"+index).addClass(classDown).removeClass(classUp): $("#expandBar-"+index).addClass(classUp).removeClass(classDown);
 
    }
}

wg.CreateTokenInputEmail = function(){
  $("#emailTo").tokenInput([], { 
    zindex: 700,
    noResultsText: "Add New Email",
    allowFreeTagging: true,
    placeholder: 'Type Email Here',
    tokenValue: 'id',
    propertyToSearch: 'key',
    theme: "facebook",
    onAdd: function (item) {
      if (validateEmailFormat(item.key)){
        wg.emailTo.push(item);  
        $("#alertMessage1").hide();
      }else {
        $("#alertMessage1").text(item.key+" is not valid email !");
        $("#alertMessage1").show()
        this.tokenInput("remove", {id: item.key});
        setTimeout(function() {
          $("#alertMessage1").hide();
        }, 5000);
      }
    },
    onDelete: function (item) {
      wg.emailTo.remove(item);  
    }
  });

  $("#emailCc").tokenInput([], { 
    zindex: 700,
    noResultsText: "Add New Email",
    allowFreeTagging: true,
    placeholder: 'Type Email Here',
    tokenValue: 'id',
    propertyToSearch: 'key',
    theme: "facebook",
    onAdd: function (item) {
      if (validateEmailFormat(item.key)){
        wg.emailCc.push(item);  
        $("#alertMessage2").hide();
      }else {
        $("#alertMessage2").text(item.key+" is not valid email !");
        $("#alertMessage2").show()
        this.tokenInput("remove", {id: item.key});
        setTimeout(function() {
          $("#alertMessage2").hide();
        }, 5000);
      }
    },
    onDelete: function (item) {
      wg.emailCc.remove(item);  
    }
  });

}
function changeEmailTo(e){
  wg.emailValue().mailto = e.sender._values
 
}
function changeEmailCC(e){
  wg.emailValue().mailcc = e.sender._values
}
wg.sendMail =  function(){
    mailTo = [];
    mailcc = [];
    for(i in  wg.emailValue().mailto){
      for(j in wg.listEmail()){
        if(wg.emailValue().mailto[i] ==  wg.listEmail()[j].fullname){
          if( wg.listEmail()[j].status == 0){
            mailTo.push(wg.listEmail()[j].email)
          }else{
            for(x in  wg.listEmail()[j].member){
              mailTo.push(wg.listEmail()[j].member[x].email)
            }
          }
        }
      }
    }
    for(i in  wg.emailValue().mailcc){
      for(j in wg.listEmail()){
        if(wg.emailValue().mailcc[i] ==  wg.listEmail()[j].fullname){
          if( wg.listEmail()[j].status == 0){
            mailcc.push(wg.listEmail()[j].email)
          }else{
            for(x in  wg.listEmail()[j].member){
              mailcc.push(wg.listEmail()[j].member[x].email)
            }
          }
        }
      }
    } 
    template = JSON.stringify(ko.mapping.toJS(wg.templateChartCurrent()))
    localStorage.removeItem('template');
    localStorage.removeItem('valueCharts');
    localStorage.removeItem('valueSummaries');
    localStorage.removeItem('ListFilterBar'); 
    localStorage.removeItem('To');
    localStorage.removeItem('Cc'); 
    localStorage.removeItem('Subject');
    localStorage.removeItem('Body');  

    localStorage.setItem('type', 'sendMail');
    localStorage.setItem('ListFilterBar', JSON.stringify(wg.filterChartBarList()));
    localStorage.setItem('template', template);
    localStorage.setItem('valueCharts', JSON.stringify(wg.charts));
    localStorage.setItem('valueSummaries', JSON.stringify(wg.summaries));
 
    localStorage.setItem('To', mailTo.toString());
    localStorage.setItem('Cc', mailcc.toString());

    localStorage.setItem('Subject', wg.emailValue().mailsubject);
    localStorage.setItem('Body', wg.emailValue().mailmsg);
    // console.log("->",localStorage);
    // openPopUp()
    window.open("/live/static/core/report-pdf/index.html");
}
// wg.sendMail =  function(){
//     mailTo = [];
//     mailcc = [];
//     for(i in  wg.emailValue().mailto){
//       for(j in wg.listEmail()){
//         if(wg.emailValue().mailto[i] ==  wg.listEmail()[j].fullname){
//           if( wg.listEmail()[j].status == 0){
//             mailTo.push(wg.listEmail()[j].email)
//           }else{
//             for(x in  wg.listEmail()[j].member){
//               mailTo.push(wg.listEmail()[j].member[x].email)
//             }
//           }
//         }
//       }
//     }
//     for(i in  wg.emailValue().mailcc){
//       for(j in wg.listEmail()){
//         if(wg.emailValue().mailcc[i] ==  wg.listEmail()[j].fullname){
//           if( wg.listEmail()[j].status == 0){
//             mailcc.push(wg.listEmail()[j].email)
//           }else{
//             for(x in  wg.listEmail()[j].member){
//               mailcc.push(wg.listEmail()[j].member[x].email)
//             }
//           }
//         }
//       }
//     } 
 



//     kendo.drawing.drawDOM($(".content"),{
//       forcePageBreak: ".new-page",
//       paperSize: "a3",
//       landscape :true,
//       margin: {top:"1cm",left:"0cm",right:"1cm",bottom:"1cm"},
//     })
//     .then(function (group) {
//       return kendo.drawing.exportPDF(group);
//     })
//     .done(function (data) {
//       // console.log(data)
//       var payload = {
//         Subject:wg.emailValue().mailsubject,
//         Body: wg.emailValue().mailmsg,
//         To:mailTo,
//         Cc:mailcc, 
//         Menu:'dailystatus',
//         Attachment : data,
//       } 
//       $.ajax({
//           url: "/live/ociranalysis/sendemailwidget",
//           type: 'post',
//           data: JSON.stringify(payload),
//           dataType: 'json',
//           contentType: "application/json; charset=utf-8",
//           success:function(){
            
//           }
//       });
//     });
 
// }
wg.getEmail =  function(){
  ajaxPost("/widgetanalysis/getlistemail", "", function (res){
    wg.listEmail(res.Data);
    wg.listEmail().push(
                          {_id:"Global_Process_Owner",email:"Global_Process_Owner",fullname:"Global Process Owner",status:0},
                          {_id:"Pss_Head_EMail",email:"Pss_Head_EMail",fullname:"Pss Head",status:0},
                          {_id:"Master_Critical_Person_Email",email:"Master_Critical",fullname:"Master Critical",status:0},
                          {_id:"PFP_Process_Owner_Email",email:"PFP_Process_Owner_Email",fullname:"PFP Process",status:0},
                          {_id:"Team_Sme_email",email:"Team_Sme_email",fullname:"Team Sme",status:0},
                          {_id:"Pss_Manager_Name_email",email:"Pss_Manager_Name_email",fullname:"Pss Manager",status:0},
                          {_id:"Pfp_Critical_Person_Email",email:"Pfp_Critical_Person_Email",fullname:"Pfp Critical",status:0},
                          {_id:"Contract_Manager_Email ",email:"Contract_Manager_Email ",fullname:"Contract Manager",status:0},
                          {_id:"Sla_Manager_Email",email:"Sla_Manager_Email",fullname:"Sla Manager",status:0}
                        );
    wg.listEmail.valueHasMutated();
    $("#emailTo").kendoMultiSelect({
      dataTextField: "fullname",
      dataValueField: "fullname",
 
      footerTemplate: 'Total #: instance.dataSource.total() # items found',
      itemTemplate: '<span class="k-state-default header-text">#: data.fullname #<p class="footer-text">#: data.email #</p></span>',
      tagTemplate:  '<span class="selected-value"></span><span>#:data.fullname#</span>',
      change: changeEmailTo,
      dataSource: {
          data :wg.listEmail()
      },
      height: 200
    });
    $("#emailCC").kendoMultiSelect({
      dataTextField: "email",
      dataValueField: "fullname",
 
      footerTemplate: 'Total #: instance.dataSource.total() # items found',
      itemTemplate: '<span class="k-state-default header-text">#: data.fullname #<p class="footer-text">#: data.email #</p></span>',
      tagTemplate:  '<span class="selected-value"></span><span>#:data.fullname#</span>',
      change: changeEmailCC,
      dataSource: {
          data :wg.listEmail()
      },
      height: 200
    });

     
  })
}


wg.DLinputData = {template:ko.observableArray([]) ,DLName:ko.observable(''),type:ko.observable('Public'),status:ko.observable('Active'),owned:ko.observable(''),remarks:ko.observable(''),members:[]}
wg.DLmemberFilterList = [];
wg.DLinputsearch      = ko.observable('')
wg.DLtype             = ko.observableArray([{ text:"Public"},{ text:"Private"}]);
wg.DLconfDeleteMembers = ko.mapping.fromJS([])
wg.DLdataMembers      = [];
wg.DLdataMembersAll   = [];
wg.DLdataMembersSearch  = [];
wg.DLsearchStatus     = ko.observable(false)

wg.DLtemplate     = ko.observable('');
wg.DLtemplateList = ko.observableArray([])


wg.getDl =  function(){
   $("#grid-distribution-list").html('')
    $("#grid-distribution-list").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              ajaxPost('/distributionlist/getdistributionlist', {}, function(datas){
                option.success(datas);
              })
            },
            parameterMap: function(data) {
              return JSON.stringify(data);
            },
          },
          schema: {
            data: function(data) {
              if (data.Data.length == 0) {
                return [];
              } else { 
                return data.Data;
              }
            },
            total: "Data.length",
          }, 
        }, 
        columns: [
         {
            title: "No",
            template: "#= ++record #",
            width: 20,
            headerAttributes: {
             "class": "align-center header-grid"
            }, attributes: {
              "class": "align-center number"
            }
          }, 
          {
            field:"DLName",
            title:'DL Name',
            width:100, 
            headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
            {
            field:"type",
            title:'Type',
            width:30, 
            headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "align-left" 
            }
          },
          {
            field:"owned",
            title:'Owned By',
            width:75, 
             headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
          {
            field:"lastmodifiedby",
            title:'Last Modified By',
            width:100, 
             headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
          {
            field:"lastmodifiedon",
            title:'Last Modified On',
            width:100, 
            template: "#if(lastmodifiedon != ''){# #:  kendo.toString(new Date(getUTCDate(getUTCDateFull(lastmodifiedon))), 'dd/MM/yy') # #} #",
            attributes: {
              "class": "field-ellipsis align-center"
            }
          },
          {
            field:"noofmembers",
            title:'No. of Members',
            width:60,
            headerAttributes: {
                "class": "align-right"
            },
            attributes: {
                "class": "align-right"
            }
          },
          {
            field:"remarks",
            title:'Remarks',
            width:60,
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "align-left"
            }
          },
          { 
            width:25,
            // filterable: false,
            headerAttributes: {
              "class": "align-center"
            },
            attributes: {
              "class": "align-center"
            },
 
            template: "## <button  class=\"btn btn-sm pull-left btn-primary\" id=\"raady-button\"  onClick='wg.editDL(\"#:DLName #\" )'><span class=\"icon-custome glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button> ##",
          
          }
        ],
        resizable: true,
      
          sortable: true,
          scrollable:{
            virtual: true
          }, 
          pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1, 
            pageSize: 15,
          }, 
          dataBinding: function() {
            record = (this.dataSource.page() -1) * this.dataSource.pageSize();
          }
    });
}

wg.getDlName = function(){
 var payload = {
    Id : wg.template()
  }
  ajaxPost("/widgetanalysis/getdlname", payload, function (res){
    wg.emailValue().mailto = res.Data
    $("#emailCC").data("kendoMultiSelect").value([]);
    $("#emailTo").data("kendoMultiSelect").value([]);
    $("#emailTo").data("kendoMultiSelect").value(res.Data);
  })
}

wg.DLgridDetails =  function(dataSource){
  
  $("#grid-member").html('')
  $("#grid-member").kendoGrid({
        dataSource: {
          transport: {
                read:function(option){
                  option.success(dataSource); 
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
          },  
          schema: {
            data: function(data) {
              if (data.length == 0) {
                  return [];
              } else {
                  return data; 
              } 
            },
                // total: "Data.Count",
          },
        },  
        columns: [
          {
            field:"fullname",
            title:'Member Name',
            width:100, 
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"loginid",
            title:'PSID',
            width:70, 
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"email",
            title:'email',
            width:100, 
            attributes: {
              "class": "field-ellipsis"
            }
          },
      
          // {
          //   title:'',
          //   width:25,
          //   // filterable: false,
          //   headerAttributes: {
          //    "class": "align-center"
            // },
            // attributes: {
            //   "class": "align-center"
            // },
 
            // template: "## <button  class=\"btn btn-sm pull-left btn-primary\" id=\"raady-button\"  onClick='dl.edit(\"#:DLName #\" )'>Edit</button> ##",
            // template: "## <button  class=\"btn btn-sm pull-left btn-cancel \" id=\"raady-button\"  onClick='deleteRowDetails(\"#:_id #\",\"#:fullname #\",\"#:email #\" )'><span class=\"small-icon-custome glyphicon glyphicon-remove\" aria-hidden=\"true\"></button> ##",
           
          
          // }
        ],
        sortable: true,
         resizable: true,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                      display: "Showing {2} data items"
                  }
              }, 
  });
}

wg.DLsave =  function(){
  payload = {}
  var templates = []
  for(i in wg.DLinputData.template()){
    templates.push({templateName:wg.DLinputData.template()[i]})
  } 
  payload.templates = templates
  payload.DLName    = wg.DLinputData.DLName()
  payload.type      = wg.DLinputData.type()
  payload.remarks   = wg.DLinputData.remarks()
  payload.status    = wg.DLinputData.status()
  payload.members   = wg.DLdataMembers  

  ajaxPost("/distributionlist/savedistributionlist", payload, function (res){
     if(res.IsError){
        return swal("Confirmation!", res.Message, "error");
     }else{ 
        $('#grid-distribution-list').data('kendoGrid').dataSource.read({});
    
        return swal({
              title: "Confirmation!",
              text: res.Message,
              type: "success", 
            },
            function(isConfirm){
              $('#modalDL').modal('show');
              $('#addDL').modal('hide');
              
          });  
     }  
  })
}

wg.editDL =  function(dlName){
  ajaxPost("/distributionlist/getmembernameedit", {id:dlName}, function (res){
    wg.DLdataMembersAll = res.Data;
   
  })
  ajaxPost("/distributionlist/editdistributionlist",{id:dlName}, function (res){
    template = []
    for(i in res.Data.templates){
     
      template.push(res.Data.templates[i].templateName)
    }
 
    wg.DLinputData.template(template) 
    wg.DLinputData.DLName( res.Data.DLName) 
    wg.DLinputData.remarks(res.Data.remarks)  
    wg.DLinputData.type(res.Data.type)  
    wg.DLinputData.status(res.Data.status)  
    wg.DLdataMembers = res.Data.members 

    ko.mapping.fromJS(wg.DLdataMembers, wg.DLconfDeleteMembers)
    wg.DLgridDetails(wg.DLdataMembers)
    wg.inputsearch('')

  $('#modalDL').modal('hide');
    $('#addDL').modal('show');
      
    $("#grid-data-members").html('')
    
  });
}
wg.DLgetMemberList =  function(){
  memberName = [];
  for(i in dl.memberNameList ){
    memberName.push(dl.memberNameList[i].fullname)
  }
  dl.DLmemberFilterList = memberName;
}
wg.DLgetMember =  function(){
  ajaxPost("/distributionlist/getmembername", "", function (res){
      wg.DLdataMembersAll = res.Data
  })
}
wg.addDL = function(){ 
  wg.DLinputData.DLName('')
  wg.DLinputData.type('Public')
  wg.DLinputData.remarks('')
  wg.DLinputData.status('Active')   
  wg.DLdataMembers = [] 
  wg.DLgridDetails([]) 
  wg.DLinputsearch('')
  wg.DLgetMember()
  wg.DLgetOwned()
  ko.mapping.fromJS([], wg.DLconfDeleteMembers)
  $("#grid-member").html('')
  $("#grid-data-members").html('')
  
  $("#inputsearch").kendoAutoComplete({
    dataSource:   wg.DLmemberFilterList,
    filter: "contains",
    placeholder: "Search",
  });

  $('#modalDL').modal('hide');
    $('#addDL').modal('show');


}
function dlAddByemail(){
  wg.DLaddMember(wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch());
}
function emailvalidate(value){
  var email = value.toLowerCase()
  var re = /^[a-z][a-zA-Z0-9_.]*(\.[a-zA-Z][a-zA-Z0-9_.]*)?@sc\.com?$/;
  if(re.test(email))
    $("#dlAddByemail").show('fast')
  else 
    $("#dlAddByemail").hide('fast')
}
wg.DLgetOwned =  function(){
  ajaxPost("/distributionlist/getowned", "", function (res){
    wg.DLinputData.owned(res.Data[0].fullname)
  })
}
wg.DLaddMember =  function(id,fullname,email,loginid){
  wg.DLdataMembers.push({_id:id,fullname:fullname,email:email,loginid:loginid})
  for(var i in wg.DLdataMembersAll){
    if( wg.DLdataMembersAll[i]._id == id){
      wg.DLdataMembersAll.splice(i,1)
    }
  }
  for(var i in wg.DLdataMembersSearch){
    if( wg.DLdataMembersSearch[i]._id == id){
      wg.DLdataMembersSearch.splice(i,1)
    }
  }
  if(wg.DLsearchStatus()){
    wg.DLgridDataMembers(wg.DLdataMembersSearch)
  }

  ko.mapping.fromJS(wg.DLdataMembers, wg.DLconfDeleteMembers)
  wg.DLgridDetails(wg.DLdataMembers)
}
wg.DLgridDataMembers = function(dataSource){
 
  $("#grid-data-members").html('')
  $("#grid-data-members").kendoGrid({
        dataSource: {
          transport: {
                read:function(option){
                  option.success(dataSource); 
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
          },  
          schema: {
            data: function(data) {
              if (data.length == 0) {
                  return [];
              } else {
                  return data; 
              } 
            },
                // total: "Data.Count",
          },
        },  
        columns: [

          {
            title:'',
            width:17,
            headerAttributes: {
              "class": "align-center"
            },
            attributes: {
              "class": "align-center add"
            },
 
            
            template: "## <button  class=\"btn btn-sm pull-left btn-add-member   \" id=\"raady-button\"   onClick='wg.DLaddMember(\"#:_id #\",\"#:fullname #\",\"#:email #\",\"#:loginid #\")' >Add</button> ##",
           
 
          },
          {
            field:"fullname",
            title:'Member Name',
            width:100, 
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"loginid",
            title:'PSID',
            width:70, 
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"email",
            title:'Email',
            width:100, 
             headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
       
        
        ],
        resizable: true,
        sortable: true,
 
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                      display: "Showing {2} data items"
                  }
              }, 
    });
}
wg.DLsearch =  function(){
  data = []
  wg.DLinputsearch($('#searchMember').val())
  $.each(wg.DLdataMembersAll, function(i,v){
    if(v.fullname.toLowerCase().indexOf(wg.DLinputsearch().toLowerCase()) > -1){
      data.push({"_id" : v._id,"email": v.email,"fullname": v.fullname,loginid:v.loginid});
    }
  }) 
  wg.DLsearchStatus(true);
  wg.DLdataMembersSearch = data;
  wg.DLgridDataMembers(wg.DLdataMembersSearch);
}
wg.DLcancel =  function(){
   $('#addDL').modal('hide');
    $('#modalDL').modal('show');
   
}
function deleteRowDetails(id,fullname,email,loginid){
  return function(){
 
    for(i in wg.DLdataMembers){
      if(id == wg.DLdataMembers[i]._id){
        wg.DLdataMembers.splice(i,1); 
      }
    } 
    wg.DLdataMembersAll.push({"_id" :id,"email":email,"fullname": fullname,loginid:loginid});
    if(fullname.toLowerCase().indexOf(wg.DLinputsearch().toLowerCase()) > -1){
        wg.DLdataMembersSearch.push({"_id" :id,"email":email,"fullname": fullname,loginid:loginid});
    }
    if(wg.DLsearchStatus()){
      wg.DLgridDataMembers(wg.DLdataMembersSearch)
    }

    ko.mapping.fromJS(wg.DLdataMembers, wg.DLconfDeleteMembers)
    wg.DLgridDetails(wg.DLdataMembers)
  }
}
$(function(){ 
    $('#total-page').text(wg.templateChart().length)
    $('input[type=radio][name=summaryList]').change(function() {
        if($(this).val() === 'one'){
            $("#one-box").show("slow")
            $("#two-box").hide("fast")
        }else{
            $("#one-box").hide("fast")
            $("#two-box").show("slow")
        }
    });
    $('#back-button-modalDetail').click(function(){
      $('#modaldetail').modal('hide');
      $('#modaltab').modal('show');
    })
   // /; if(wg.popupChart() == true){
    $(".tableinside").mouseleave(function() {
        $('.messege-pop-up_'+wg.popupChartId()).hide( "slow" );
        $('#icon-plus_'+wg.popupChartId()).addClass( "glyphicon-plus" )
        wg.popupChartId('')
    });
    
    var defaultIndex = 0;
    var defaultpayload = {
        ReceiverCountry :[],
        ReceiverLegalEntity : [],
        SupplierCountry : [],
        SupplierLegalEntity : [], 
        Categoryname : [],
        Suppliertype: '',
        Productfunction :[],
        Parentprocessname :[],
        GPO :[]
    };
    wg.callAjaxFilter(defaultIndex, defaultpayload)  
    wg.getListTab();
    
    wg.getSummaryListBox();
    wg.getTemplate();
    wg.productnamePopup();
    wg.getEmail()
    $('#searchMember').on("keypress", function(e) {
      if(e.keyCode == 13){
        wg.DLsearch()
      }
    }); 
 
    // wg.CreateTokenInputEmail();
});
