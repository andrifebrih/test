var dailystats = {};
dailystats.tab = ko.observable("country");
dailystats.gridConfig = {
	countryValidated:
	{
		value : "country",
		flag  : "validated",
		text  : "Daily Stats Validated by Country",
		url   : "/dailystats/reportdailystatscountrysek",
		column: 
	 	[
			{
				title: "Static",
				headerAttributes: {
					class: "grid-header col-parent"
				},
				columns: [
					{
						field: "region",
						title: "Region",	
						width: 80,
						attributes: {
		                	class:"col-parent align-left titlecolor #if(data.level == 0){# bordercustom #}#",
		            	},
		          	},  
		    		{
						field: "country",
						title: "T1 Country",	
						width: 120,
						attributes: {
		                	class:"  align-left #if(data.level == 0){# bordercustom #}#"
		            	},
		          	},  
		    	]
		  	},
			{
				title: "All",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "AllColumn0",
						title: "#",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(AllColumn0,'N0')#",
						// template:function(e){
						// 	console.log(e.level)
						// 	if (e.level == 0) {
						// 		console.log($(this).parent())
						// 		$(this).addClass('bordercustom')
						// 	}else{
						// 		return kendo.toString(e.AllColumn0,'N0')
						// 	};
						// },
						attributes: {
		                	class: "align-right #if(data.level == 0){# bordercustom #}#"
		            	},
		          	},
		          	{
		              	field:  "AllColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},

						template: "#:kendo.toString(AllColumn1,'N0')#",
		              	title: "#</br>Mapped", 
		          	},
		          	{
		              	field: "AllColumn2",
		               	headerAttributes: {
		            	}, 
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.AllColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Mapped", 
		          	},    
		    	]
		  	},
		  	{
				title: "Teams",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "TeamsColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(TeamsColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
		              	field: "TeamsColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	}, 
						template: "#:kendo.toString(TeamsColumn1,'N0')#",
		              	title: "#</br>Validate",
		             	 
		          	},
		          	{
		              	field: "TeamsColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.TeamsColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Validate",
		             	 
		          	},    
		    	]
		  	},
		  	{
				title: "Systems",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "SystemsColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(SystemsColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
		            	field: "SystemsColumn1",
					    	headerAttributes: {
		            	},
						template: "#:kendo.toString(SystemsColumn1,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		              	title: "#</br>Validate",
		             	 
		          	},
		          	{
		            	field: "SystemsColumn2",
					   	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.SystemsColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Validate",
		             	 
		          	},    
		    	]
		  	},
		  	{
				title: "FMIS",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
		        },
				columns: [
		    		{
						field: "FMIColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(FMIColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
						field: "FMIColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
						template: "#:kendo.toString(FMIColumn1,'N0')#",
		              	title: "#</br>Validate",
		             	 
		          	},
		          	{
						field: "FMIColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.FMIColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Validate",
		             	
		          	},    
		    	]
		  	},
		  	{
				title: "TPS",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
		        },
				columns: [
		    		{
						field: "TPSColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(TPSColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
						field: "TPSColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
						template: "#:kendo.toString(TPSColumn1,'N0')#",
		              	title: "#</br>Validate",
		             	 
		          	},
		          	{
						field: "TPSColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.TPSColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Validate",
		             	
		          	},    
		    	]
		  	},
		]
	},
	businessvalidated:
	{
		value : "business",
		flag  : "validated",
		text  : "Daily Stats Validated by Business",
		url :"/dailystats/reportdailystatssek",	
		column :
		[
			{
				title: "Static",
				headerAttributes: {
					class: "grid-header col-parent"
				},
				columns: [
		    		{
						field: "Label",
						title: "Bussines / Function",	
						width: 200,
						attributes: {
		                	class:" #:data.classTitle# align-left #if(data.level == 0){# bordercustom #}#"
		            	},
		          	},  
		    	]
		  	},
			{
				title: "All",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "AllColumn0",
						title: "#",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(AllColumn0,'N0')#",
						attributes: {
		                	class: "align-right #if(data.level == 0){# bordercustom #}#"
		            	},
		          	},
		          	{
		              	field:  "AllColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},

						template: "#:kendo.toString(AllColumn1,'N0')#",
		              	title: "#</br>Mapped", 
		          	},
		          	{
		              	field: "AllColumn2",
		               	headerAttributes: {
		            	}, 
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.AllColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Mapped", 
		          	},    
		    	]
		  	},
		  	{
				title: "Teams",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "TeamsColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(TeamsColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
		              	field: "TeamsColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	}, 
						template: "#:kendo.toString(TeamsColumn1,'N0')#",
		              	title: "#</br>Validate",
		             	 
		          	},
		          	{
		              	field: "TeamsColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.TeamsColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Validate",
		             	 
		          	},    
		    	]
		  	},
		  	{
				title: "Systems",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "SystemsColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(SystemsColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
		            	field: "SystemsColumn1",
					    	headerAttributes: {
		            	},
						template: "#:kendo.toString(SystemsColumn1,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		              	title: "#</br>Validate",
		             	 
		          	},
		          	{
		            	field: "SystemsColumn2",
					   	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.SystemsColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Validate",
		             	 
		          	},    
		    	]
		  	},
		  	{
				title: "FMIS",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
		        },
				columns: [
		    		{
						field: "FMIColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(FMIColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
						field: "FMIColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
						template: "#:kendo.toString(FMIColumn1,'N0')#",
		              	title: "#</br>Validate",
		             	 
		          	},
		          	{
						field: "FMIColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.FMIColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Validate",
		             	
		          	},    
		    	]
		  	},
		  	{
				title: "TPS",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
		        },
				columns: [
		    		{
						field: "TPSColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(TPSColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
						field: "TPSColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
						template: "#:kendo.toString(TPSColumn1,'N0')#",
		              	title: "#</br>Validate",
		             	 
		          	},
		          	{
						field: "TPSColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.TPSColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Validate",
		             	
		          	},    
		    	]
		  	},
		]
	},
	countryConfirmed:
	{
		value : "country",
		flag  : "confirmed",
		text  : "Daily Stats Confirmed  by Country",
		url   : "/dailystats/reportdailystatscountrysek",
		column: 
	 	[
			{
				title: "Static",
				headerAttributes: {
					class: "grid-header col-parent"
				},
				columns: [
					{
						field: "region",
						title: "Region",	
						width: 80,
						attributes: {
		                	class:"col-parent align-left titlecolor #if(data.level == 0){# bordercustom #}#"
		            	},
		          	},  
		    		{
						field: "country",
						title: "T1 Country",	
						width: 120,
						attributes: {
		                	class:"  align-left #if(data.level == 0){# bordercustom #}#"
		            	},
		          	},  
		    	]
		  	},
			{
				title: "All",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "AllColumn0",
						title: "#",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(AllColumn0,'N0')#",
						attributes: {
		                	class: "align-right #if(data.level == 0){# bordercustom #}#"
		            	},
		          	},
		          	{
		              	field:  "AllColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},

						template: "#:kendo.toString(AllColumn1,'N0')#",
		              	title: "#</br>Mapped", 
		          	},
		          	{
		              	field: "AllColumn2",
		               	headerAttributes: {
		            	}, 
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.AllColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Mapped", 
		          	},    
		    	]
		  	},
		  	{
				title: "Teams",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "TeamsColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(TeamsColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
		              	field: "TeamsColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	}, 
						template: "#:kendo.toString(TeamsColumn1,'N0')#",
		              	title: "#</br>Confirmed",
		             	 
		          	},
		          	{
		              	field: "TeamsColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.TeamsColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Confirmed",
		             	 
		          	},    
		    	]
		  	},
		  	{
				title: "Systems",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "SystemsColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(SystemsColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
		            	field: "SystemsColumn1",
					    	headerAttributes: {
		            	},
						template: "#:kendo.toString(SystemsColumn1,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		              	title: "#</br>Confirmed",
		             	 
		          	},
		          	{
		            	field: "SystemsColumn2",
					   	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.SystemsColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Confirmed",
		             	 
		          	},    
		    	]
		  	},
		  	{
				title: "FMIS",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
		        },
				columns: [
		    		{
						field: "FMIColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(FMIColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
						field: "FMIColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
						template: "#:kendo.toString(FMIColumn1,'N0')#",
		              	title: "#</br>Confirmed",
		             	 
		          	},
		          	{
						field: "FMIColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.FMIColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Confirmed",
		             	
		          	},    
		    	]
		  	},
		  	{
				title: "TPS",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
		        },
				columns: [
		    		{
						field: "TPSColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(TPSColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
						field: "TPSColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
						template: "#:kendo.toString(TPSColumn1,'N0')#",
		              	title: "#</br>Confirmed",
		             	 
		          	},
		          	{
						field: "TPSColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.TPSColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Confirmed",
		             	
		          	},    
		    	]
		  	},
		]
	},
	businessConfirmed:
	{
		value : "business",
		flag  : "confirmed",
		text  : "Daily Stats Confirmed by Business",
		url :"/dailystats/reportdailystatssek",	
		column :
		[
			{
				title: "Static",
				headerAttributes: {
					class: "grid-header;"
				},
				columns: [
		    		{
						field: "Label",
						title: "Bussines / Function",	
						width: 200,
						attributes: {
		                	class:" #:data.classTitle# align-left #if(data.level == 0){# bordercustom #}#"
		            	},
		          	},  
		    	]
		  	},
			{
				title: "All",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "AllColumn0",
						title: "#",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(AllColumn0,'N0')#",
						attributes: {
		                	class: "align-right #if(data.level == 0){# bordercustom #}#"
		            	},
		          	},
		          	{
		              	field:  "AllColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},

						template: "#:kendo.toString(AllColumn1,'N0')#",
		              	title: "#</br>Mapped", 
		          	},
		          	{
		              	field: "AllColumn2",
		               	headerAttributes: {
		            	}, 
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.AllColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Mapped", 
		          	},    
		    	]
		  	},
		  	{
				title: "Teams",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "TeamsColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(TeamsColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
		              	field: "TeamsColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	}, 
						template: "#:kendo.toString(TeamsColumn1,'N0')#",
		              	title: "#</br>Confirmed",
		             	 
		          	},
		          	{
		              	field: "TeamsColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.TeamsColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Confirmed",
		             	 
		          	},    
		    	]
		  	},
		  	{
				title: "Systems",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
				},
				columns: [
		    		{
						field: "SystemsColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(SystemsColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
		            	field: "SystemsColumn1",
					    	headerAttributes: {
		            	},
						template: "#:kendo.toString(SystemsColumn1,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		              	title: "#</br>Confirmed",
		             	 
		          	},
		          	{
		            	field: "SystemsColumn2",
					   	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.SystemsColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Confirmed",
		             	 
		          	},    
		    	]
		  	},
		  	{
				title: "FMIS",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
		        },
				columns: [
		    		{
						field: "FMIColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(FMIColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
						field: "FMIColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
						template: "#:kendo.toString(FMIColumn1,'N0')#",
		              	title: "#</br>Confirmed",
		             	 
		          	},
		          	{
						field: "FMIColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.FMIColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Confirmed",
		             	
		          	},    
		    	]
		  	},
		  	{
				title: "TPS",
				headerAttributes: {
					style: "vertical-align: middle;text-align: center;font-weight:bold;"
		        },
				columns: [
		    		{
						field: "TPSColumn0",
						title: "#</br>Mapped",
						headerAttributes: {
		            	},
						template: "#:kendo.toString(TPSColumn0,'N0')#",
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
		          	},
		          	{
						field: "TPSColumn1",
		               	headerAttributes: {
		            	},
		               	attributes: {
		                    class: "align-right #if(data.level == 0){# bordercustom #}#"
		               	},
						template: "#:kendo.toString(TPSColumn1,'N0')#",
		              	title: "#</br>Confirmed",
		             	 
		          	},
		          	{
						field: "TPSColumn2",
		               	headerAttributes: {
		            	},
		            	template:function(e){
		            		if(e.level == 0){
		                		return "";
		                	}
		            		return kendo.toString(e.TPSColumn2,'N1') + "%";
		            	
		            	},
		               	attributes: {
		                    class: "align-center #if(data.level > 0){# col-percentage #}else{# bordercustom #}#"
		               	},
		              	title: "%</br>Confirmed",
		             	
		          	},    
		    	]
		  	},
		]
	}
};
dailystats.filters = {
	value:{
		template : ko.observable([]),
		region 	 : ko.observableArray([]),
		country  : ko.observableArray([]),
		legalEntity : ko.observableArray([]),
		bussines : ko.observableArray([]),
	},
	data :{
		template : ko.observableArray([]),
		region 	 : ko.observableArray([]),
		country  : ko.observableArray([]),
		legalEntity : ko.observableArray([]),
		bussines : ko.observableArray([]),
	},
	onchange:{
		template : ko.observable(true),
		region 	 : ko.observable(true),
		country  : ko.observable(true),
		legalEntity : ko.observable(true),
		bussines : ko.observable(true), 
	}
};
dailystats.getPayload = {
	filter: function(){
		with(dailystats.filters.value){
			return	{
				Region 				: region,
				ReceiverCountry 	: country,
				ReceiverLegalEntity : legalEntity,
				Categoryname 		: bussines
			}
		};
	},
	grid:function(){
		with(dailystats.filters.value){
			return	{
				Region 				: region,
				ReceiverCountry 	: country,
				ReceiverLegalEntity : legalEntity,
				Categoryname 		: bussines
			}
		};	
	} 
};
dailystats.widgetConfig = {
	type 				: ko.observable(""),
	filterValue 		: ko.observable(""),
	filterText  		: ko.observable(""),
	showWidget 			: ko.observable(false),
	showOptWidget 		: ko.observable(false),
	loading 			: ko.observable(false),
	openOptWidget 		: function(type){
	 	switch(type){
			case "grid":
				$("#grid-opt-modal").modal("show")
			break;
		}
	},
	close 				: function(){
		dailystats.widgetConfig.type("");
		dailystats.widgetConfig.filterValue("");
		dailystats.widgetConfig.filterText("");
		dailystats.widgetConfig.showWidget(false);
		dailystats.widgetConfig.showOptWidget(false);
		$("#widget1").html("");
	}
};
dailystats.masterDataGrid = {
	AllColumn0 : ko.observableArray([]),
	AllColumn1 : ko.observableArray([]),
	AllColumn2 : ko.observableArray([]),
	FMIColumn0 : ko.observableArray([]),
	FMIColumn1 : ko.observableArray([]),
	FMIColumn2 : ko.observableArray([]),
	Label : ko.observableArray([]),
	SystemsColumn0 : ko.observableArray([]),
	SystemsColumn1 : ko.observableArray([]),
	SystemsColumn2 : ko.observableArray([]),
	TPSColumn0 : ko.observableArray([]),
	TPSColumn1 : ko.observableArray([]),
	TPSColumn2 : ko.observableArray([]),
	TeamsColumn0 : ko.observableArray([]),
	TeamsColumn1 : ko.observableArray([]),
	TeamsColumn2 : ko.observableArray([]),
	country : ko.observableArray([]),
	level : ko.observableArray([]),
	parent : ko.observableArray([]),
	region : ko.observableArray([]),
}

// dailystats.gridOptions = ko.observableArray([
// 		{text:"Business", value:"Business"},
// 		{text:"Country",  value:"Country"}
// ]);
function normalizeDataGrid(ds, type){
	var dataSource = []
	var struct  = 
	{
		AllColumn0:"",AllColumn1:"",AllColumn2:"",
		FMIColumn0:"",FMIColumn1:"",FMIColumn2:"",
		SystemsColumn0:"",SystemsColumn1:"",SystemsColumn2:"",
		TPSColumn0:"",TPSColumn1:"",TPSColumn2:"",
		TeamsColumn0:"",TeamsColumn1:"",TeamsColumn2:""
	}
	// console.log("------->",type)
	switch(type){
		case "countryValidated":
		case "countryConfirmed":	
	// console.log("------->>>>>",type)

			_.each(ds, function(v){
			v.region   = v.Label;
			v.level = 0;
			v.country  =  "";
			_.extend( v,_.clone(struct));
			dataSource.push(v);
			_.each(v.detail, function(vDetails){
				vDetails.region  = "";
				vDetails.level = 1;

				vDetails.country = vDetails.Label;  
				dataSource.push(vDetails);
			})
			}); 	
		break;
		case "businessvalidated":
		case "businessConfirmed":	
			_.each(ds, function(v){
	 			v.level =1;
	 			dataSource.push(v); 
 			}); 
		break;
	}
	return dataSource; 
};


dailystats.filters.value.region.subscribe(function(newval){
	if(!dailystats.filters.onchange.region()){
		return dailystats.filters.onchange.region(true);
	}
	dailystats.GetCountry(false);
	dailystats.GetLegalEntity(false);
	dailystats.GetBussines(false);

	dailystats.refreshWidget();	
});
dailystats.filters.value.country.subscribe(function(newval){
	if(!dailystats.filters.onchange.country()){
		return dailystats.filters.onchange.country(true);
	}
	dailystats.GetRegion(false);;
	dailystats.GetLegalEntity(false);
	dailystats.GetBussines(false);

	dailystats.refreshWidget();
});
dailystats.filters.value.legalEntity.subscribe(function(newval){
	if(!dailystats.filters.onchange.legalEntity()){
		return dailystats.filters.onchange.legalEntity(true);
	}
	dailystats.GetRegion(false);
	dailystats.GetCountry(false);
	dailystats.GetBussines(false);
	
	dailystats.refreshWidget();
});
dailystats.filters.value.bussines.subscribe(function(newval){
	if(!dailystats.filters.onchange.bussines()){
		return dailystats.filters.onchange.bussines(true);
	}
	dailystats.GetRegion(false);
	dailystats.GetCountry(false);
	dailystats.GetLegalEntity(false);
	
	dailystats.refreshWidget();
});
dailystats.filters.value.template.subscribe(function(newval){
	ajaxPost("/dailystats/getdetailsdailystats", {id : newval}, function (res){
		dailystats.LoadTemplate(res);
	});
});
dailystats.widgetConfig.showWidget.subscribe(function(newval){
	if(newval)
		$(".box-grid").css({"border":"none"})
	else
		$(".box-grid").css({"border":"2px dashed #999;"})
});
 
dailystats.refreshWidget =  function(){
	switch(dailystats.widgetConfig.type()){
		case "grid":
			dailystats.GenerateGrid()
		break; 
	}
};
dailystats.GenerateGrid =  function(){
	$("#grid-opt-modal").modal("hide");

	var config = dailystats.widgetConfig; 
		config.loading(true);
		config.showWidget(true);
		config.showOptWidget(true); 
		config.type("grid"); 
	var type = config.filterValue();
 
	var properties = dailystats.gridConfig[type];
		config.filterText(properties.text);
	 
	var payload = dailystats.getPayload.grid();
		payload.Flag = properties.flag;

		if (type.indexOf('country') > -1) {
 			dailystats.createGridDailyStatusCountry(type,properties);
		}else{
 			dailystats.createGridDailyStatusBusiness(type,properties);
		};

 	ajaxPost(properties.url, payload, function(res){
		config.loading(false);
		var dataSource = normalizeDataGrid(res.Data, type);

 		$("#widget1").html("").css("width", "inherit");
 		$("#widget1").kendoGrid({
		    dataSource: {
		        data: dataSource,
		    },
		    scrollable: true,
		    sortable: true,
		    filterable: false,
		    pageable: false,
		    height:400,
		    columns:  properties.column,
		});
 	});
};

dailystats.createGridDailyStatusCountry =  function(type, payload){
 	ajaxPost("/dailystats/reportdailystatscountrysek", payload, function(res){
		$sel = $("#table1");
		$sel.addClass("fullgrid dailystatus-grid");
		$sel.html("");
		var Theader = [
 			"<thead>",
 				"<tr class='tbl-header'>",
	 				"<td colspan='2'>Static</td>",
	 				"<td colspan='3'>All</td>",
	 				"<td colspan='3'>Teams</td>",
	 				"<td colspan='3'>Systems</td>",
	 				"<td colspan='3'>FMIs</td>",
	 				"<td colspan='3'>TPS</td>",
	 				"<td colspan='2'>Total</td>",
 				"<tr>",
 				"<tr class='tbl-header'>",
	 				"<td>Region</td>",
	 				"<td>T1 Country</td>",
	 				"<td>#</td>",
	 				"<td>#<br/>Mapped</td>",
	 				"<td>%<br/>Mapped</td>",
	 				"<td>#</td>",
	 				"<td>#<br/>Mapped</td>",
	 				"<td>%<br/>Mapped</td>",
	 				"<td>#</td>",
	 				"<td>#<br/>Mapped</td>",
	 				"<td>%<br/>Mapped</td>",
	 				"<td>#</td>",
	 				"<td>#<br/>Mapped</td>",
	 				"<td>%<br/>Mapped</td>",
	 				"<td>#</td>",
	 				"<td>#<br/>Mapped</td>",
	 				"<td>%<br/>Mapped</td>",
	 				"<td>%<br/>Mapped</td>",
	 				"<td>RAG</td>",
 				"<tr>",
 			"</thead>",
 		].join(" "); 
		var Tbody = [];
		_.each(res.Data, function(o){
			
			Tbody.push("<tr class='none'><td  colspan='22'>&nbsp;</td></tr>")	 	 
			var rowspan = o.detail.length; 
			Tbody.push("<tr ><td style='border-left: 2px solid #000!important;' class='region' rowspan='"+rowspan+"'>"+o.Label+"</td>");
			_.each(o.detail, function(v,index){
 	 
				if(index > 0){
					// Tbody.push("<tr style='border-top: 1px solid #000;border-bottom: 1px solid #000;'>");
				}

				Tbody.push("<td class='main' align='left'>"+v.Label+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");
				
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");
				
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");
				
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");
		
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");
			
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
				Tbody.push("<td class='main "+v.RAG+"' style='border-right: 2px solid #000!important;'>&nbsp;</td>"); 
				Tbody.push("</tr>");
			}); 
		});

		$sel.append("<table width='100%'>"+Theader+Tbody.join(" ")+"<table>");
	});
};
dailystats.createGridDailyStatusBusiness =  function(type, payload){
	ajaxPost("/dailystats/reportdailystatssek", payload, function(res){
		$sel = $("#table1");
		$sel.addClass("fullgrid dailystatus-grid");
		$sel.html("");
		var Theader = [
 			"<thead>",
 				"<tr class='tbl-header'>",
	 				"<td>Static</td>",
					"<td colspan='3'>All</td>",
					"<td colspan='3'>Teams</td>",
					"<td colspan='3'>Systems</td>",
					"<td colspan='3'>FMIs</td>",
					"<td colspan='3'>TPS</td>",
					"<td colspan='2'>Total</td>",
 				"<tr>",
 				"<tr class='tbl-header'>",
 					"<td>Business/Function</td>",
					"<td>#</td>",
					"<td>#<br/>Mapped</td>",
					"<td>%<br/>Mapped</td>",
					"<td>#</td>",
					"<td>#<br/>Mapped</td>",
					"<td>%<br/>Mapped</td>",
					"<td>#</td>",
					"<td>#<br/>Mapped</td>",
					"<td>%<br/>Mapped</td>",
					"<td>#</td>",
					"<td>#<br/>Mapped</td>",
					"<td>%<br/>Mapped</td>",
					"<td>#</td>",
					"<td>#<br/>Mapped</td>",
					"<td>%<br/>Mapped</td>",
					"<td>%<br/>Mapped</td>",
					"<td>RAG</td>",
 				"<tr>",
 			"</thead>",
 		].join(" "); 
 		var Tbody = [];
		_.each(res.Data, function(v){
			Tbody.push("<tr>");
			Tbody.push("<td class='region' align='left'>"+v.Label+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");
			
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");
			
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");
			
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");
	
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");
		
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
			Tbody.push("<td class='main "+v.RAG+"'>&nbsp;</td>"); 
			Tbody.push("</tr>");
		});
		$sel.append("<table width='100%'>"+Theader+Tbody.join(" ")+"<table>");
	});
};

dailystats.LoadTemplate = function(res){
 	setTimeout(function(){
		with(res.Data.details){
			if(_.has(widget, "widgetType"))
		 		dailystats.widgetConfig.type(widget.widgetType);
		 	if(_.has(widget, "widgetTypeFilterValue"))
		 		dailystats.widgetConfig.filterValue(widget.widgetTypeFilterValue);
		 	if(_.has(widget, "widgetTypeFilterText"))
		 		dailystats.widgetConfig.filterText(widget.widgetTypeFilterText);
		 	if(_.has(widget, "showWidget"))
		 		dailystats.widgetConfig.showWidget(widget.showWidget); 
		
		 	if(_.has(filters, "region")){  
		 		dailystats.filters.onchange.region(false);
		 		dailystats.filters.value.region(filters.region);
		 	}
		 	if(_.has(filters, "country")){ 
		 		dailystats.filters.onchange.country(false);
		 		dailystats.filters.value.country(filters.country);
		 	}
		 	if(_.has(filters, "legalEntity")){  
		 		dailystats.filters.onchange.legalEntity(false);
		 		dailystats.filters.value.legalEntity(filters.legalEntity);
		 	}
		 	if(_.has(filters, "bussines")){ 
		 		dailystats.filters.onchange.bussines(false);
		 		dailystats.filters.value.bussines(filters.bussines);
		 	}
		};
	},100)
};
dailystats.Save = function(){
	if (dailystats.filters.value.template() == "") {
        return swal("", "Please Insert a Template Name", "warning");
    }
	var param = {
		ReportName:dailystats.filters.value.template(),
		details  : {
			filters:dailystats.filters.value,
			widget :{
				showWidget 			  : dailystats.widgetConfig.showWidget(),
				widgetType 			  : dailystats.widgetConfig.type(),
				widgetTypeFilterValue : dailystats.widgetConfig.filterValue(),
				widgetTypeFilterText  : dailystats.widgetConfig.filterText(),
			}
		}
	};
	ajaxPost("/dailystats/savedailystats", param, function(res){
		dailystats.GetTemplate();
		swal("Saved!", "", "success");
	})
};
dailystats.ExportPdf = function(){ 
 	 
 	if(dailystats.tab() == "country"){
 		$sel = $(".content-tab-country");
 		$grid = $("#gridcountry");
 	}
 	else{
 		$sel = $(".content-tab-business");
 		$grid = $("#gridbussiness");
 	}
 	
 
	var normalizeSelector =  function(){
		$grid.height("400px");
		$('.k-grid').data('kendoGrid').refresh()
		$sel.find(".section-top").text("");
		$sel.find(".section-bottom").text("");
		$sel.find(".filter").css({"padding":"0px"})
		$sel.find(".grid").css({"padding":"0px"})
	};
	$grid.height("");
	$('.k-grid').data('kendoGrid').refresh()
	$sel.find(".section-top").text("&nbsp;");
	$sel.find(".section-bottom").text("&nbsp;");
	$sel.find(".filter").css({"padding-right":"10px","padding-left":"10px"})
	$sel.find(".grid").css({"padding-right":"10px","padding-left":"10px"})
	setTimeout(function(){
		kendo.drawing.drawDOM($sel,{ 
			paperSize : "a3",
			landscape : true, 
		})
		.then(function (group) {
			return kendo.drawing.exportPDF(group);
		})
		.done(function (data) {
			kendo.saveAs({
				dataURI: data,
				fileName: "dailystatus"+dailystats.tab()+".pdf",
				callback: normalizeSelector()
			});
		});
	},100)
};
dailystats.GenerateGridTabCountry =  function(){
 	ajaxPost("/dailystats/reportdailystatscountry", {
 														Categoryname:dailystats.filters.value.bussines(),
 														ReceiverCountry:[]
 													}, function(res){
 		var dataSource = []
 		var struct  = 
 		{
 			AllColumn0:"",AllColumn1:"",AllColumn2:"",
 			FMIColumn0:"",FMIColumn1:"",FMIColumn2:"",
 			SystemsColumn0:"",SystemsColumn1:"",SystemsColumn2:"",
 			TPSColumn0:"",TPSColumn1:"",TPSColumn2:"",
 			TeamsColumn0:"",TeamsColumn1:"",TeamsColumn2:""
 		}
 		_.each(res.Data, function(v){
 			v.region   = v.Label;
 			v.level = 0;
 			v.country  =  "";
 			_.extend( v,_.clone(struct));
 			dataSource.push(v);
 			_.each(v.detail, function(vDetails){
 				vDetails.region  = "";
 				vDetails.level = 1;

 				vDetails.country = vDetails.Label;  
 				dataSource.push(vDetails);
 			})
 		});  
	 
		$("#gridcountry").html("");
		$("#gridcountry").height("400px");
		$("#gridcountry").kendoGrid({
		    dataSource: {
		        data: dataSource,
		        // pageSize: 20
		    },
		    scrollable: true,
		    sortable: true,
		    filterable: false,
		    pageable: false,
		    columns:  [
		    	{
					title: "Static",
					headerAttributes: {
						class: "grid-header;"
					},
		    		columns: [
		    			{
							field: "region",
							title: "Region",	
							width: 80,
							attributes: {
			                	class:"col-parent bordercustom align-left"
		                	},
		              	},  
		        		{
							field: "country",
							title: "T1 Country",	
							width: 120,
							attributes: {
			                	class:"  align-left"
		                	},
		              	},  
		        	]
		      	},
				{
					title: "All",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
					},
		    		columns: [
		        		{
							field: "AllColumn0",
							title: "#",
							headerAttributes: {
			            	},
							template: "#:kendo.toString(AllColumn0,'N0')#",
							attributes: {
			                	class: "align-right"
		                	},
		              	},
		              	{
		                  	field:  "AllColumn1",
		                   	headerAttributes: {
		                	},
		                   	attributes: {
			                    class: "align-right"
		                   	},

							template: "#:kendo.toString(AllColumn1,'N0')#",
		                  	title: "#</br>Mapped", 
		              	},
		              	{
		                  	field: "AllColumn2",
		                   	headerAttributes: {
		                	}, 
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.AllColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Mapped", 
		              	},    
		        	]
		      	},
		      	{
					title: "Teams",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
					},
		    		columns: [
		        		{
							field: "TeamsColumn0",
							title: "#</br>Mapped",
							headerAttributes: {
		                	},
							template: "#:kendo.toString(TeamsColumn0,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		              	},
		              	{
		                  	field: "TeamsColumn1",
		                   	headerAttributes: {
		                	},
		                   	attributes: {
			                    class: "align-right"
		                   	}, 
							template: "#:kendo.toString(TeamsColumn1,'N0')#",
		                  	title: "#</br>Validate",
		                 	 
		              	},
		              	{
		                  	field: "TeamsColumn2",
		                   	headerAttributes: {
		                	},
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.TeamsColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Validate",
		                 	 
		              	},    
		        	]
		      	},
		      	{
					title: "Systems",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
					},
		    		columns: [
		        		{
							field: "SystemsColumn0",
							title: "#</br>Mapped",
							headerAttributes: {
		                	},
							template: "#:kendo.toString(SystemsColumn0,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		              	},
		              	{
		                	field: "SystemsColumn1",
						    	headerAttributes: {
		                	},
							template: "#:kendo.toString(SystemsColumn1,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		                  	title: "#</br>Validate",
		                 	 
		              	},
		              	{
		                	field: "SystemsColumn2",
						   	headerAttributes: {
		                	},
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.SystemsColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Validate",
		                 	 
		              	},    
		        	]
		      	},
		      	{
					title: "FMIS",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
			        },
		    		columns: [
		        		{
							field: "FMIColumn0",
							title: "#</br>Mapped",
							headerAttributes: {
		                	},
							template: "#:kendo.toString(FMIColumn0,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		              	},
		              	{
							field: "FMIColumn1",
		                   	headerAttributes: {
		                	},
		                   	attributes: {
			                    class: "align-right"
		                   	},
							template: "#:kendo.toString(FMIColumn1,'N0')#",
		                  	title: "#</br>Validate",
		                 	 
		              	},
		              	{
							field: "FMIColumn2",
		                   	headerAttributes: {
		                	},
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.FMIColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Validate",
		                 	
		              	},    
		        	]
		      	},
		      	{
					title: "TPS",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
			        },
		    		columns: [
		        		{
							field: "TPSColumn0",
							title: "#</br>Mapped",
							headerAttributes: {
		                	},
							template: "#:kendo.toString(TPSColumn0,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		              	},
		              	{
							field: "TPSColumn1",
		                   	headerAttributes: {
		                	},
		                   	attributes: {
			                    class: "align-right"
		                   	},
							template: "#:kendo.toString(TPSColumn1,'N0')#",
		                  	title: "#</br>Validate",
		                 	 
		              	},
		              	{
							field: "TPSColumn2",
		                   	headerAttributes: {
		                	},
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.TPSColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Validate",
		                 	
		              	},    
		        	]
		      	},	
			],
		    dataBound: function (e) {}
		});
		setTimeout(function(){ 
			$("#gridcountry").data("kendoGrid").refresh();
		}, 100)
	});
};
dailystats.GenerateGridTabBussines =  function(){
	ajaxPost("/dailystats/reportdailystats", {
 														Categoryname:[],
 														ReceiverCountry:dailystats.filters.value.country()
 													}, function(res){
		var dataSource = []
 		 
 		_.each(res.Data, function(v){
 			 v.level =1;
 			dataSource.push(v); 
 		}); 
 
	    $("#gridbussiness").html("");
	  	$("#gridbussiness").height("400px");
	  	$("#gridbussiness").kendoGrid({
	        dataSource: {
	            data: dataSource,
	            pageSize: 20
	        },
	        scrollable: true,
	        sortable: true,
	        filterable: false,
	        pageable: false,
	        columns:  [
	        	{
					title: "Static",
					headerAttributes: {
						class: "grid-header;"
					},
	        		columns: [
		        		{
							field: "Label",
							title: "Bussines / Function",	
							width: 200,
							attributes: {
			                	class:" #:data.classTitle#   align-left"
		                	},
		              	},  
	            	]
	          	},
				{
					title: "All",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
					},
		    		columns: [
		        		{
							field: "AllColumn0",
							title: "#",
							headerAttributes: {
			            	},
							template: "#:kendo.toString(AllColumn0,'N0')#",
							attributes: {
			                	class: "align-right"
		                	},
		              	},
		              	{
		                  	field:  "AllColumn1",
		                   	headerAttributes: {
		                	},
		                   	attributes: {
			                    class: "align-right"
		                   	},

							template: "#:kendo.toString(AllColumn1,'N0')#",
		                  	title: "#</br>Mapped", 
		              	},
		              	{
		                  	field: "AllColumn2",
		                   	headerAttributes: {
		                	}, 
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.AllColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Mapped", 
		              	},    
		        	]
		      	},
		      	{
					title: "Teams",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
					},
		    		columns: [
		        		{
							field: "TeamsColumn0",
							title: "#</br>Mapped",
							headerAttributes: {
		                	},
							template: "#:kendo.toString(TeamsColumn0,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		              	},
		              	{
		                  	field: "TeamsColumn1",
		                   	headerAttributes: {
		                	},
		                   	attributes: {
			                    class: "align-right"
		                   	}, 
							template: "#:kendo.toString(TeamsColumn1,'N0')#",
		                  	title: "#</br>Validate",
		                 	 
		              	},
		              	{
		                  	field: "TeamsColumn2",
		                   	headerAttributes: {
		                	},
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.TeamsColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Validate",
		                 	 
		              	},    
		        	]
		      	},
		      	{
					title: "Systems",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
					},
		    		columns: [
		        		{
							field: "SystemsColumn0",
							title: "#</br>Mapped",
							headerAttributes: {
		                	},
							template: "#:kendo.toString(SystemsColumn0,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		              	},
		              	{
		                	field: "SystemsColumn1",
						    	headerAttributes: {
		                	},
							template: "#:kendo.toString(SystemsColumn1,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		                  	title: "#</br>Validate",
		                 	 
		              	},
		              	{
		                	field: "SystemsColumn2",
						   	headerAttributes: {
		                	},
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.SystemsColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Validate",
		                 	 
		              	},    
		        	]
		      	},
		     
		      	{
					title: "FMIS",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
			        },
		    		columns: [
		        		{
							field: "FMIColumn0",
							title: "#</br>Mapped",
							headerAttributes: {
		                	},
							template: "#:kendo.toString(FMIColumn0,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		              	},
		              	{
							field: "FMIColumn1",
		                   	headerAttributes: {
		                	},
		                   	attributes: {
			                    class: "align-right"
		                   	},
							template: "#:kendo.toString(FMIColumn1,'N0')#",
		                  	title: "#</br>Validate",
		                 	 
		              	},
		              	{
							field: "FMIColumn2",
		                   	headerAttributes: {
		                	},
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.FMIColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Validate",
		                 	
		              	},    
		        	]
		      	},
		      	{
					title: "TPS",
					headerAttributes: {
						style: "vertical-align: middle;text-align: center;"
			        },
		    		columns: [
		        		{
							field: "TPSColumn0",
							title: "#</br>Mapped",
							headerAttributes: {
		                	},
							template: "#:kendo.toString(TPSColumn0,'N0')#",
		                   	attributes: {
			                    class: "align-right"
		                   	},
		              	},
		              	{
							field: "TPSColumn1",
		                   	headerAttributes: {
		                	},
		                   	attributes: {
			                    class: "align-right"
		                   	},
							template: "#:kendo.toString(TPSColumn1,'N0')#",
		                  	title: "#</br>Validate",
		                 	 
		              	},
		              	{
							field: "TPSColumn2",
		                   	headerAttributes: {
		                	},
		                	template:function(e){
		                		if(e.level == 0){
			                		return "";
			                	}
		                		return kendo.toString(e.TPSColumn2,'N1') + "%";
		                	
		                	},
		                   	attributes: {
			                    class: "align-right  #if(data.level > 0){# col-percentage #}#"
		                   	},
		                  	title: "%</br>Validate",
		                 	
		              	},    
		        	]
		      	},
			],
	        dataBound: function (e) {}
	    });
		setTimeout(function(){ 
			$("#gridbussiness").data("kendoGrid").refresh();
		}, 100)
	});
};
dailystats.GetRegion  = function(onchangeStatus){
	onchangeStatus = onchangeStatus || true;
	dailystats.filters.onchange.region(onchangeStatus);
	var url = "/ociranalysis/getregion";
	var payload =  dailystats.getPayload.filter();
	ajaxPost(url,payload, function (res){
		var results = [];
    	_.each(res, function(v){
    		results.push(v._id);
    	});
    	dailystats.filters.data.region(results);
	})
};
dailystats.GetCountry = function(onchangeStatus){
	onchangeStatus = onchangeStatus || true;
	dailystats.filters.onchange.country(onchangeStatus);
	var url = "/ociranalysis/getreceivercountry";
   	var payload =  dailystats.getPayload.filter();
	ajaxPost(url,payload, function (res){
    	var results = [];
    	_.each(res, function(v){
    		results.push(v._id);
    	});
    	dailystats.filters.data.country(results);
    });
};
dailystats.GetLegalEntity = function(onchangeStatus){
	onchangeStatus = onchangeStatus || true;
	dailystats.filters.onchange.legalEntity(onchangeStatus);
	var url = "/ociranalysis/getlegalentityreceiver";
	var payload =  dailystats.getPayload.filter();
	ajaxPost(url,payload, function (res){
    	var results = [];
    	_.each(res, function(v){
    		results.push(v._id);
    	});
    	dailystats.filters.data.legalEntity(results);
    });    	
};
dailystats.GetBussines = function(onchangeStatus){
	onchangeStatus = onchangeStatus || true;
	dailystats.filters.onchange.bussines(onchangeStatus);
	var url = "/ociranalysis/getcategory";
    var payload =  dailystats.getPayload.filter();
	ajaxPost(url,payload, function (res){
    	var results = [];
    	_.each(res, function(v){ 
    		results.push(v._id);
    	});
    	dailystats.filters.data.bussines(results);
    });
};
dailystats.GetTemplate = function(){
	ajaxPost("/dailystats/getdailystats", {}, function (res){
 		var results = []
 		_.each(res.Data, function(v){
 			results.push({text: v._id, value: v._id })
 		});
    	dailystats.filters.data.template(results)
    })
};
$(function(){ 

	dailystats.GetRegion();
	dailystats.GetCountry();
	dailystats.GetLegalEntity();
	dailystats.GetBussines();
	dailystats.GetTemplate()
	wg.getDl();
	$('#searchMember').on("keypress", function(e) {
	 
      if(e.keyCode == 13){
        wg.DLsearch()
      }
    }); 
    $(".messege-options-widget table").mouseleave(function() {
    	dailystats.widgetConfig.showOptWidget(false);
    }); 
    wg.getEmail();
});
 