var sc = {};

// function test(id, business){
//   var self = this
//   self = {
//     Id: ko.observable(id),
//     Businessfunction: ko.observable(business),
//   }  
// return self
// }

sc.getListSettingCef = ko.observableArray([]);
sc.valueConfig = ko.observable('');
sc.getListDataSettingCEF = function(){
  ajaxPost("/saveconsider/getmastersettingcef",{}, function (res){
    // console.log(res);    
    res = res.sort(function(a, b){
    var IdA=a.Id.toLowerCase(), IdB=b.Id.toLowerCase()
    if (IdA < IdB) //sort string ascending
        return -1 
    if (IdA > IdB)
         return 1
    return 0 //default return value (no sorting)
    })


    sc.getListSettingCef(ko.mapping.fromJS(res)());

  });
}

sc.saveSetting = function(){
  var payload = {data : ko.mapping.toJS(sc.getListSettingCef())}
  var url = "/saveconsider/savemastersettingcef"
  // console.log(payload)
  ajaxPost(url,payload, function (res){
    console.log(res);
    // sc.getListSettingCef(ko.mapping.fromJS(res)());

  });

}

$(function(){
  sc.getListDataSettingCEF();
})