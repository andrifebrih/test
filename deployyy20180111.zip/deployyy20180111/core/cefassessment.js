var ca = {};

ca.receivingCountry = ko.observable('');
ca.receivingCountryList = ko.observableArray([]);

ca.receivingLegalEntityList = ko.observableArray([]);
ca.receivingLegalEntity = ko.observableArray([]);

ca.rpt2_receivingCountry = ko.observable('');
ca.rpt2_receivingCountryList = ko.observableArray([]);


ca.rpt2_receivingLegalEntity = ko.observableArray([]);
ca.rpt2_receivingLegalEntityList = ko.observableArray([]);

ca.rpt3_receivingCountry = ko.observable('');
ca.rpt3_receivingCountryList = ko.observableArray([]);


ca.rpt3_receivingLegalEntity = ko.observableArray([]);
ca.rpt3_receivingLegalEntityList = ko.observableArray([]);

ca.rpt3_receivingCountry = ko.observable('');
ca.rpt3_receivingCountryList = ko.observableArray([]);


ca.rpt3_receivingLegalEntity = ko.observableArray([]);
ca.rpt3_receivingLegalEntityList = ko.observableArray([]);


ca.rpt3_productFunctionList = ko.observableArray([]);
ca.rpt3_productFunction = ko.observableArray([]);

ca.rpt3_bussinesList = ko.observableArray([]);
ca.rpt3_bussines = ko.observableArray([]);

ca.listTab = ko.observableArray([]);

ca.numberFormat = function(value, numberFormat) {
    if (typeof value === 'string') {
        // console.log("---->",value);
        if (value.toLowerCase() === 'null' || value.toLowerCase() === 'n' || value.toLowerCase() === 'n/a' || value.toLowerCase() == '') {
            return 0;
        }
        var regex = "/[^(?:\d*\.)?\d]+/"
        return (String(value).match(/[^(?:\d*\.)?\d]+/) == null) ? kendo.toString(value, numberFormat) : String(value); //parseInt(value).toLocaleString():String(value); 
    } else {
        console.log("int------------>", value)
        return kendo.toString(value, numberFormat);
        // console.log("int ---->",value);
        // var regex = "/[^(?:\d*\.)?\d]+/"
        // return (String(value).match(/[^(?:\d*\.)?\d]+/) == null)? kendo.toString(value,"n2") : String(value) ;//parseInt(value).toLocaleString():String(value); 
    }
}

ca.getReceivingCountry = function() {
    var payload = {
        LegalEntity: ca.receivingLegalEntity()
    };

    var url = "/cefassessment/getreceivercountry";
    ajaxPost(url, payload, function(res) {
        var receivingCountries = [];
        $.each(res, function(i, v) {
            receivingCountries.push({
                text: v._id,
                value: v._id
            })
        });
        ca.receivingCountryList(receivingCountries);
    })
};

ca.getReceivingLegalEntity = function() {
    var payload = {
        ReceivingCountry: ca.receivingCountry()
    };

    var url = "/cefassessment/getlegalentity2";
    ajaxPost(url, payload, function(res) {
        var legalEntities = [];
        $.each(res, function(i, v) {
            legalEntities.push({
                text: v._id,
                value: v._id
            })
        });
        ca.receivingLegalEntityList(legalEntities);
    });
};

ca.rpt2_getReceivingCountry = function() {
    var payload = {
        LegalEntity: ca.rpt2_receivingLegalEntity()
    };

    var url = "/cefassessment/getreceivercountry";
    ajaxPost(url, payload, function(res) {
        var receivingCountries = [];
        $.each(res, function(i, v) {
            receivingCountries.push({
                text: v._id,
                value: v._id
            })
        });
        ca.rpt2_receivingCountryList(receivingCountries);
    })
};
ca.rpt2_getReceivingLegalEntity = function() {
    var payload = {
        ReceivingCountry: ca.rpt2_receivingCountry()
    };

    var url = "/cefassessment/getlegalentity2";
    ajaxPost(url, payload, function(res) {
        var legalEntities = [];
        $.each(res, function(i, v) {
            legalEntities.push({
                text: v._id,
                value: v._id
            })
        });
        ca.rpt2_receivingLegalEntityList(legalEntities);

    });
};

ca.rpt3_getReceivingCountry = function() {
    var payload = {
        ReceivingCountry: ca.rpt3_receivingCountry(),
        LegalEntity: ca.rpt3_receivingLegalEntity(),
        Business: ca.rpt3_bussines(),
        Productfunction: ca.rpt3_productFunction()
    };

    var url = "/cefassessment/getreceivercountry";
    ajaxPost(url, payload, function(res) {
        var receivingCountries = [];
        $.each(res, function(i, v) {
            receivingCountries.push({
                text: v._id,
                value: v._id
            })
        });
        ca.rpt3_receivingCountryList(receivingCountries);
    })
};
ca.rpt3_getReceivingLegalEntity = function() {
    var payload = {
        ReceivingCountry: ca.rpt3_receivingCountry(),
        LegalEntity: ca.rpt3_receivingLegalEntity(),
        Business: ca.rpt3_bussines(),
        Productfunction: ca.rpt3_productFunction()
    };

    var url = "/cefassessment/getlegalentity";
    ajaxPost(url, payload, function(res) {
        var legalEntities = [];
        $.each(res, function(i, v) {
            legalEntities.push({
                text: v._id,
                value: v._id
            })
        });
        ca.rpt3_receivingLegalEntityList(legalEntities);

    });
};

ca.rpt3_getProductFunction = function() {
    var payload = {
        ReceivingCountry: ca.rpt3_receivingCountry(),
        LegalEntity: ca.rpt3_receivingLegalEntity(),
        Business: ca.rpt3_bussines(),
        Productfunction: ca.rpt3_productFunction()
    };

    ajaxPost("/cefassessment/getproductfunction", payload, function(res) {
        var products = [];
        $.each(res, function(i, v) {
            products.push({
                text: v._id,
                value: v._id
            })
        });
        ca.rpt3_productFunctionList(products);
    });
}

ca.rpt3_getBussines = function() {
    var payload = {
        ReceivingCountry: ca.rpt3_receivingCountry(),
        LegalEntity: ca.rpt3_receivingLegalEntity(),
        Business: ca.rpt3_bussines(),
        Productfunction: ca.rpt3_productFunction()
    };

    ajaxPost("/cefassessment/getbusiness", payload, function(res) {
        var bussiness = [];
        $.each(res, function(i, v) {
            bussiness.push({
                text: v._id,
                value: v._id
            })
        });

        ca.rpt3_bussinesList(bussiness);
    })
}



ca.createGrid = function(payload) {

    var coloumns = [];

    ajaxPost("/cefassessment/getfields", payload, function(res) {
        $.each(res, function(i, v) {
            coloumns.push({
                title: v.categoryname,
                headerAttributes: {
                    "class": "header-colspan"
                },
                columns: []

            })
            $.each(v.product, function(index, value) {
                str = value.field.replace(/\s/g, '').replace('-', '').replace('(', '').replace(')', '').replace('|', '').replace('&', '');

                coloumns[i].columns.push({
                    field: str,
                    title: value.field,
                    template: "<span class=\"glyphicon #if(" + str + " == 'v'){# #: 'glyphicon-ok green-icon' # #}else if(" + str + " == '-'){# #: 'glyphicon-minus black-icon' # #}else {# #: 'glyphicon-remove red-icon' # #}# glyph-custom\"></span>",
                    headerAttributes: {
                        "class": "green-background"
                    },
                    attributes: {
                        "class": "align-center"
                    },
                    width: 100
                })
            })
        });

        var url = '/cefassessment/getdata';
        ajaxPost(url, payload, function(datas) {
            $("grid-data").html("");
            $("#grid-data").kendoGrid({
                dataSource: {
                    transport: {
                        read: function(option) {
                            _.map(datas, function(d){
                                _.sortBy( d.detailsproduct, function( item ) { return field; } )
                            })
                            console.log(datas);
                            datas.forEach(function(d) {
                                var totalCEF = 0;
                                $.each(d.details, function(i, v) {
                                    d[v.categoryname] = [];
                                    $.each(v.detailsproduct, function(index, value) {
                                        str = value.field.replace(/\s/g, '').replace('-', '').replace('(', '').replace(')', '').replace('|', '').replace('&', '');

                                        d[str] = value.status;
                                        d[v.categoryname][str] = value.status;
                                        totalCEF += (value.status == 'v') ? 1 : 0;;
                                    })
                                })
                                d.totalCEF = totalCEF;
                            })
                            console.log(datas);
                            console.log("col",coloumns);
                            
                            option.success(datas);
                        },
                        parameterMap: function(data) {
                            return JSON.stringify(data);
                        },
                    },
                    pageSize: 15,
                    serverPaging: false,
                    serverSorting: false,
                },
                resizable: true,
                scrollable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                columnMenu: false,
                columns: (function() {
                    var arr = [{
                        field: "region",
                        title: "Region",
                        headerAttributes: {
                            "class": "blue-background-left"
                        },

                        width: 150,
                    }, {
                        field: "country",
                        title: "Country",
                        headerAttributes: {
                            "class": "blue-background-left"
                        },

                        width: 150,
                    }, {
                        field: "legal",
                        title: "Legal Entity",
                        headerAttributes: {
                            "class": "blue-background-left"
                        },
                        width: 200,
                    }];
                    arr = _.union(_.union(arr, coloumns), [ //{
                        // field: "note",
                        // title: "Note Issuance",
                        // headerAttributes: {"class": "blue-background"},
                        // width: 80
                        //},
                        {
                            field: "totalCEF",
                            title: "Total No of CEFs",
                            headerAttributes: {
                                "class": "blue-background-right"
                            },
                            attributes: {
                                "class": "align-right"
                            },
                            width: 80
                        }
                    ]);
                    console.log(arr);
                    return arr;

                })(),
            });
            setTimeout(function() {
                $("#grid-data .k-grid-content").height(382);
            }, 300);
        });
    });
}
ca.createGrid1 = function() {
    var payload = {
        ReceivingCountry: ca.receivingCountry(),
        LegalEntity: ca.receivingLegalEntity()
    }

    var url = "/cefassessment/getdata"
    ajaxPost("/cefassessment/getfields", payload, function(fields) {


        ajaxPost(url, payload, function(res) {
            ca.createGridReport1(res, fields)
        })
    });
}
ca.receivingCountry.subscribe(function(newValue) {
    if (newValue.length === 0) {
        ca.getReceivingCountry();
    }
    ca.getReceivingLegalEntity()
    ca.createGrid1()
});
ca.receivingLegalEntity.subscribe(function(newValue) {
    if (newValue.length === 0) {
        ca.getReceivingLegalEntity()
    }
    ca.getReceivingCountry();
    ca.createGrid1()
});
ca.loadFirstDataGrid = function() {
    var payload = {
        ReceivingCountry: "",
        LegalEntity: []
    };
    ajaxPost("/cefassessment/getfields", payload, function(fields) {
        ajaxPost("/cefassessment/getdata", payload, function(res) {
            ca.createGridReport1(res, fields);
        })
    });
}

ca.createGridReport1 = function(data, fields) {
    console.log(fields)
    $("#grid-report1").html("");
    $("#grid-report1").kendoGrid({
        dataSource: {
            data: data,
            pageSize: 20,
            sort: [{
                field: "country",
                dir: "asc"
            }, {
                field: "legal",
                dir: "asc"
            }]
        },

        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: (function() {
            var dynamicColumn = _.map(fields, function(o, i) {
                return {
                    title: o.categoryname,
                    headerAttributes: {
                        "class": "header-colspan"
                    },
                    columns: [{
                        field: 'details[' + i + '].cef',
                        title: "CEF",
                        attributes: {
                            "class": "align-right"
                        },
                        headerAttributes: {
                            "class": "green-background align-right"
                        }
                    }, {
                        field: 'details[' + i + '].noncef',
                        title: "Non-CEF",
                        attributes: {
                            "class": "align-right"
                        },
                        headerAttributes: {
                            "class": "green-background align-right"
                        }
                    }]
                }
            });

            return _.union([{
                    field: "region",
                    title: "Region",
                    // template: "Client to provide data",
                    headerAttributes: {
                        "class": "blue-background-left field-ellipsis"
                    },
                    attributes: {
                        "class": "align-left field-ellipsis"
                    },
                    width: 150
                }, {
                    field: "country",
                    title: "Country",
                    headerAttributes: {
                        "class": "blue-background-left"
                    },
                    attributes: {
                        "class": "align-left field-ellipsis"
                    },
                    width: 150
                }, {
                    field: "legal",
                    title: "Legal Entity",
                    headerAttributes: {
                        "class": "blue-background-left"
                    },
                    attributes: {
                        "class": "align-left field-ellipsis"
                    },
                    width: 150
                }], dynamicColumn)
                //   {
                //     title: "Transaction Banking",
                //     headerAttributes: {
                //       "class": "header-colspan"
                //     },
                //     columns: [{
                //       field: 'details[0].cef',
                //       title: "CEF",
                //       attributes:{
                //         "class": "align-right"
                //       },
                //       headerAttributes: {
                //         "class": "green-background align-right"
                //       }
                //     },{
                //       field: 'details[0].noncef',
                //       title: "Non-CEF",
                //       attributes:{
                //         "class": "align-right"
                //       },
                //       headerAttributes: {
                //         "class": "green-background align-right"
                //       }
                //     },
                //     ]
                //   },
                //   {
                //     title: "Retail Products",
                //     headerAttributes: {
                //       "class": "header-colspan"
                //     },
                //     columns: [{
                //       field: 'details[1].cef',
                //       title: "CEF",
                //       attributes:{
                //         "class": "align-right"
                //       },
                //       headerAttributes: {
                //         "class": "green-background align-right"
                //       }
                //     },{
                //       field: 'details[1].noncef',
                //       title: "Non-CEF",
                //       attributes:{
                //         "class": "align-right"
                //       },
                //       headerAttributes: {
                //         "class": "green-background align-right",
                //       }
                //     },
                //     ]
                //   }
                // ];
        })(),
        // height: 450
    });
    setTimeout(function() {
        $("#grid-report1 .k-grid-content").height(416);
    }, 300);
}
ca.createGrid3 = function() {
    var payload = {
        Country: ca.rpt3_receivingCountry(),
        LegalEntity: ca.rpt3_receivingLegalEntity(),
        Business: ca.rpt3_bussines(),
        Productfunction: ca.rpt3_productFunction()
    }

    var url = "/cefassessment/getdetailsreport"

    ajaxPost(url, payload, function(res) {
        ca.createGridReport3(res)
    })
}

ca.rpt3_receivingCountry.subscribe(function(newValue) {
    if (newValue.length === 0) {
        ca.rpt3_getReceivingCountry()
    }
    ca.rpt3_getReceivingLegalEntity()
    ca.rpt3_getProductFunction()
    ca.rpt3_getBussines()
    ca.createGrid3()
})
ca.rpt3_receivingLegalEntity.subscribe(function(newValue) {
    if (newValue.length === 0) {
        ca.rpt3_getReceivingLegalEntity()
    }
    ca.rpt3_getReceivingCountry()
    ca.rpt3_getProductFunction()
    ca.rpt3_getBussines()
    ca.createGrid3()
})
ca.rpt3_bussines.subscribe(function(newValue) {
    if (newValue.length === 0) {
        ca.rpt3_getBussines()
    }
    ca.rpt3_getReceivingCountry()
    ca.rpt3_getReceivingLegalEntity()
    ca.rpt3_getProductFunction()
    ca.createGrid3()
})
ca.rpt3_productFunction.subscribe(function(newValue) {
    if (newValue.length === 0) {
        ca.rpt3_getProductFunction()
    }
    ca.rpt3_getReceivingCountry()
    ca.rpt3_getReceivingLegalEntity()
    ca.rpt3_getBussines()
    ca.createGrid3()
})

ca.firstLoadReport3 = function() {
    var payload = {
        Country: "",
        LegalEntity: [],
        Business: [],
        Productfunction: []
    };
    ajaxPost("/cefassessment/getdetailsreport", payload, function(res) {
        // console.log(res);
        ca.createGridReport3(res);
    })
}

ca.createGridReport3 = function(data) {
    // console.log("ww", data)
    $("#grid-report3").html("");
    $("#grid-report3").kendoGrid({
        dataSource: {
            data: data,
            pageSize: 20,
            // sort:[{field: "country", dir: "asc"}, {field: "legal", dir: "asc"}]  
        },
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5,
        },
        scrollable: true,
        columns: [{
            field: "_id.countryname",
            title: "Country",
            attributes: {
                "class": "align-left field-ellipsis"
            },
            headerAttributes: {
                "class": "blue-background-left"
            },
            width: 150
        }, {
            field: "_id.receiverlegalentity",
            title: "Legal Entity",
            attributes: {
                "class": "align-left field-ellipsis"
            },
            headerAttributes: {
                "class": "blue-background-left"
            },
            width: 150
        }, {
            field: "_id.categoryname",
            title: "Business/Function Group",
            attributes: {
                "class": "align-left field-ellipsis"
            },
            headerAttributes: {
                "class": "blue-background-left"
            },
            width: 150
        }, {
            field: "_id.subgroupname",
            title: "Business/Function Sub-Group",
            attributes: {
                "class": "align-left field-ellipsis"
            },
            headerAttributes: {
                "class": "blue-background-left"
            },
            width: 150
        }, {
            title: "Firm Specific",
            headerAttributes: {
                "class": "header-colspan"
            },
            columns: [{
                field: "_id.firmspecificestimatedmarketforretailfunctions",
                title: "Estimated Market for Retail Functions",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                //format:"{0:P2}",
                width: 150,
                template: "#= kendo.toString(_id.firmspecificestimatedmarketforretailfunctions, 'N2') #%"
                    //template:"#if(_id.firmspecificestimatedmarketfornonretailfunctions == 'NULL' || _id.firmspecificestimatedmarketfornonretailfunctions == 'N' ){ ##: 0  ##}  else { ##: _id.firmspecificestimatedmarketfornonretailfunctions ## }#" 
            }, {
                field: "_id.firmspecificestimatedmarketfornonretailfunctions",
                title: "Estimated Market for Non-Retail Functions",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                //format:"{0:P2}",  
                width: 150,
                template: "#= kendo.toString(_id.firmspecificestimatedmarketfornonretailfunctions, 'N2') #%"
                    //template:"#if(_id.firmspecificestimatedmarketfornonretailfunctions == 'NULL' || _id.firmspecificestimatedmarketfornonretailfunctions == 'N' ){ ##: 0  ##}  else { ##: _id.firmspecificestimatedmarketfornonretailfunctions ## }#" 

            }, {
                field: "SpecificAssets",
                title: "Assets ($mn)",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                format: "{0:N2}",
                width: 150,
                //template:"#if(SpecificAssets == 'NULL' || SpecificAssets == 'N' ){ ##: 0  ##}  else { ##: SpecificAssets ## }#" 

            }, {
                field: "_id.firmspecificliabilities",
                title: "Liabilities ($mn)",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                format: "{0:N2}",
                width: 150,
                //template:"#if(_id.firmspecificliabilities == 'NULL' || _id.firmspecificliabilities == 'N' ){ ##: 0  ##}  else { ##: _id.firmspecificliabilities ## }#" 
            }, {
                field: "CommittedFacilitiesValue",
                title: "Committed Facilities Value ($mn)",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                format: "{0:N2}",
                width: 150,
                //template:"#if(CommittedFacilitiesValue == 'NULL' || CommittedFacilitiesValue == 'N' ){ ##: 0  ##}  else { ##: CommittedFacilitiesValue ## }#" 

            }, {
                field: "TradeVolume",
                title: "Trade Volume",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                format: "{0:N2}",
                width: 150,
                //template:"#if(TradeVolume == 'NULL' || TradeVolume == 'N' ){ ##: 0  ##}  else { ##: TradeVolume ## }#" 

            }, {
                field: "TradeValue",
                title: "Trade Value ($mn)",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                format: "{0:N2}",
                width: 150,
                //template:"#if(TradeValue == 'NULL' || TradeValue == 'N' ){ ##: 0  ##}  else { ##: TradeValue ## }#" 
            }, {
                field: "NotionalOutstandingBooking",
                title: "Notional Outstanding in Booking Location",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                format: "{0:N2}",
                width: 150,
                //template:"#if(NotionalOutstandingBooking == 'NULL' || NotionalOutstandingBooking == 'N' ){ ##: 0  ##}  else { ##: NotionalOutstandingBooking ## }#" 
            }],
        }, {
            title: "Nature of Function",
            headerAttributes: {
                "class": "header-colspan"
            },
            columns: [{
                field: "_id.natureoffunctionimpactofcustomeraccounts",
                title: "# of Customer Accounts",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                format: "{0:N0}",
                width: 150,
                //template:"#if(_id.natureoffunctionimpactofcustomeraccounts == 'NULL' || _id.natureoffunctionimpactofcustomeraccounts == 'N' ){ ##: 0  ##}  else { ##: _id.natureoffunctionimpactofcustomeraccounts ## }#" 
            }, {
                field: "_id.natureoffunctionimpactofcustomerscounterparties",
                title: "# of Customers / Counterparties",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                format: "{0:N0}",
                width: 150,
                //template:"#if(_id.natureoffunctionimpactofcustomerscounterparties == 'NULL' || _id.natureoffunctionimpactofcustomerscounterparties == 'N' ){ ##: 0  ##}  else { ##: _id.natureoffunctionimpactofcustomerscounterparties ## }#" 

            }, {
                field: "_id.natureoffunctionsupplysidealternativeproviders",
                title: "# of Alternative Providers",
                attributes: {
                    "class": "align-right"
                },
                headerAttributes: {
                    "class": "green-background align-right"
                },
                format: "{0:N0}",
                width: 150,
                //template:"#if(_id.natureoffunctionsupplysidealternativeproviders == 'NULL' || _id.natureoffunctionsupplysidealternativeproviders == 'N' ){ ##: 0  ##}  else { ##: _id.natureoffunctionsupplysidealternativeproviders ## }#" 


            }],
        }],
        // height : 500,
    });

    setTimeout(function() {
        // $("#grid-report3").data("kendoGrid").resize();
        $("#grid-report3 .k-grid-content").height(400);
    }, 300);

}

ca.getData = function() {
    var payload = {
        ReceivingCountry: ca.rpt2_receivingCountry(),
        LegalEntity: ca.rpt2_receivingLegalEntity()
    };
    console.log(payload)
    ca.createGrid(payload);
}

ca.rpt2_receivingCountry.subscribe(function(newValue) {
    ca.rpt2_getReceivingLegalEntity();
    if (ca.rpt2_receivingCountry() == '') {
        ca.rpt2_getReceivingCountry();
    }
    ca.getData();
});
ca.rpt2_receivingLegalEntity.subscribe(function(newValue) {
    ca.rpt2_getReceivingCountry();
    if (ca.rpt2_receivingLegalEntity().length == 0) {
        ca.rpt2_getReceivingLegalEntity();
    }
    ca.getData();

});
ca.getListTab = function() {
    ajaxPost("/cefassessment/getlisttab", {}, function(res) {
        ca.listTab(res.Data)
    })
}
$(function() {

    ca.getListTab();
    ca.getReceivingCountry();
    ca.getReceivingLegalEntity();
    ca.loadFirstDataGrid();
    ca.rpt2_getReceivingCountry();
    ca.rpt2_getReceivingLegalEntity();

    ca.rpt3_getReceivingCountry();
    ca.rpt3_getReceivingLegalEntity();
    ca.rpt3_getProductFunction();
    ca.rpt3_getBussines();

    ca.firstLoadReport3();
    ca.getData();
})