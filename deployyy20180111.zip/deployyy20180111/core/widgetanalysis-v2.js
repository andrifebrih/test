var widget = {};

widget.page ={
	active : ko.observable(0),
	total  : ko.observable(0),
	data   : ko.observableArray([])
};
widget.active = {
	page : ko.observable(0),
	index: ko.observable(0)
};
widget.loading = {
	popUpbarModal: ko.observable(false)
}
var time 	= 	[ 
					{text:"01:00",value:"0100"},
					{text:"02:00",value:"0200"},
					{text:"03:00",value:"0300"},
					{text:"04:00",value:"0400"},
					{text:"05:00",value:"0500"},
					{text:"06:00",value:"0600"},
					{text:"07:00",value:"0700"},
					{text:"08:00",value:"0800"},
					{text:"09:00",value:"0900"},
					{text:"10:00",value:"1000"},
					{text:"11:00",value:"1100"},
					{text:"12:00",value:"1200"},
					{text:"13:00",value:"1300"},
					{text:"14:00",value:"1400"},
					{text:"15:00",value:"1500"},
					{text:"16:00",value:"1600"},
					{text:"17:00",value:"1700"},
					{text:"18:00",value:"1800"},
					{text:"19:00",value:"1900"},
					{text:"20:00",value:"2000"},
					{text:"21:00",value:"2100"},
					{text:"22:00",value:"2200"},
					{text:"23:00",value:"2300"}, 
					{text:"24:00",value:"2400"},
				]
widget.loadingPage = ko.observable(false);
var days 	= [
				{text:"Monday",value:"Monday"},
				{text:"Tuesday",value:"Tuesday"},
				{text:"Wednesday",value:"Wednesday"},
				{text:"Thursday",value:"Thursday"},
				{text:"Friday",value:"Friday"},
				{text:"Saturday",value:"Saturday"},
				{text:"Sunday",value:"Sunday"},
			  ];
var months 	= [
				{text:"January",value:"January"},
				{text:"February",value:"February"},
				{text:"March",value:"March"},
				{text:"April",value:"April"},
				{text:"May",value:"May"},
				{text:"JUne",value:"JUne"},
				{text:"JUly",value:"JUly"},

				{text:"August",value:"August"},
				{text:"September",value:"September"},
				{text:"October",value:"October"},
				{text:"November",value:"November"},
				{text:"December",value:"December"},
			  ];
var ordinal = [
				{text:"First",value:1},
				{text:"Second",value:2},
				{text:"Third",value:3},
				{text:"Fourth",value:4},
				{text:"Last",value:5}
			  ];
widget.emailList 	= ko.observableArray([]); 
widget.template   	= ko.observableArray([]);
widget.mode 		= ko.observable("preview");
widget.inputTemplate = ko.observable("");



widget.modalGridProduct = ko.observable();
widget.popUpOptionsSummary = {
	inputsearch  : ko.observable(""),
	category : ko.observableArray([]),
	data 	 : ko.observableArray([]),
	dataSearch 	 : ko.observableArray([]), 
	searchStatus : ko.observable(false),
	loading 	 : ko.observable(false),
	search 	 : function(){ 
		with(this){
			var input = inputsearch().toLowerCase().trim();
			if(input != ""){
				searchStatus(true);
			}else{
				searchStatus(false); 
			} 
			var results = [];
			_.each(data(), function(v){
 				if(v.text.toLowerCase().indexOf(input) > -1)
					results.push({text:v.text, value:v.value, type:v.type});
			}); 
			dataSearch(results)
			category(_.countBy(results, 'type'));
		} 
	}
}; 
widget.popUpOptionsBar = {
	inputsearch  : ko.observable(""),
	category : ko.observableArray([]),
	data 	 : ko.observableArray([]),
	dataSearch 	 : ko.observableArray([]),
	searchStatus : ko.observable(false),
	loading 	 : ko.observable(false),
	search 	 : function(){
		with(this){	
			var input = inputsearch().toLowerCase().trim();
			if(input != ""){
				searchStatus(true);
			}else{
				searchStatus(false); 
			} 
			var results = [];
			_.each(data(), function(v){
 				if(v.text.toLowerCase().indexOf(input) > -1)
					results.push({text:v.text, value:v.value, type:v.type});
			}); 
			dataSearch(results)
			category(_.countBy(results, 'type'));
		} 
	}
};
widget.popUpOptionsDonut = {
	data 	 : ko.observableArray([]),
	loading  : ko.observable(false),
};
widget.popUpOptionsGrid = {
	data 	 : ko.observableArray([]),
	loading  : ko.observable(false),
};
widget.popUpSendEmail = {
	value:{
		emailTO : ko.observableArray([]),
		emailCC : ko.observableArray([]),
		subject : ko.observable(""),
		messege : ko.observable("")
	},
	list:{
		email : ko.observableArray([])
	},
	rendered : function(){
		with(widget.popUpSendEmail){
			$modal = $("#send-email-modal");
			list.email(_.clone(widget.emailList()));
			list.email().push(
				{_id:"Global_Process_Owner",email:"Global_Process_Owner",fullname:"Global Process Owner",status:0},
				{_id:"Pss_Head_EMail",email:"Pss_Head_EMail",fullname:"Pss Head",status:0},
				{_id:"Master_Critical_Person_Email",email:"Master_Critical",fullname:"Master Critical",status:0},
				{_id:"PFP_Process_Owner_Email",email:"PFP_Process_Owner_Email",fullname:"PFP Process",status:0},
				{_id:"Team_Sme_email",email:"Team_Sme_email",fullname:"Team Sme",status:0},
				{_id:"Pss_Manager_Name_email",email:"Pss_Manager_Name_email",fullname:"Pss Manager",status:0},
				{_id:"Pfp_Critical_Person_Email",email:"Pfp_Critical_Person_Email",fullname:"Pfp Critical",status:0},
				{_id:"Contract_Manager_Email ",email:"Contract_Manager_Email ",fullname:"Contract Manager",status:0},
				{_id:"Sla_Manager_Email",email:"Sla_Manager_Email",fullname:"Sla Manager",status:0}
			);
			list.email.valueHasMutated(); 
			
			$modal.find("#emailTO").kendoMultiSelect({
				dataTextField: "fullname",
				dataValueField: "fullname",

				footerTemplate: 'Total #: instance.dataSource.total() # items found',
				itemTemplate: '<span class="k-state-default header-text">#: data.fullname #<p class="footer-text">#: data.email #</p></span>',
				tagTemplate:  '<span class="selected-value"></span><span>#:data.fullname#</span>',
				change: function(e){ 
					value.emailTO(e.sender._old)
				},
				dataSource: {
					data :list.email()
				},
				height: 200
			});		
			
			$modal.find("#emailCC").kendoMultiSelect({
				dataTextField: "email",
				dataValueField: "fullname",

				footerTemplate: 'Total #: instance.dataSource.total() # items found',
				itemTemplate: '<span class="k-state-default header-text">#: data.fullname #<p class="footer-text">#: data.email #</p></span>',
				tagTemplate:  '<span class="selected-value"></span><span>#:data.fullname#</span>',
				change: function(e){
					value.emailCC(e.sender._old)
				},
				dataSource: {
					data :list.email()
				},
				height: 200
			});
		}
	},
	SendEmail :function(){
		with(widget.popUpSendEmail){
			$("#send-email-modal").modal("hide");
			var emailTO = [];
			var emailCC = [];
			_.each(value.emailTO(), function(o){
				emailTO.push(_.find(list.email(), function(list){ return list.fullname == o}).email);
			}); 
			_.each(value.emailCC(), function(o){ 
				emailCC.push(_.find(list.email(), function(list){ return list.fullname == o}).email);
			});
	 

			widget.mode("export");
			$(".grid-preview").css({"display":"none"});
			$(".grid-pdf").css({"display":"block"});

		 
			ajaxPost("/widgetanalysis/getdategenerate", {}, function(res){ 
	  			$('.date-generate').html(""); 
	  			$('.date-generate').html(formatDateGeneate(res.Data));
				// setTimeout(function(){ 
				kendo.drawing.drawDOM($(".app-content"),{
					forcePageBreak	: ".page-break",
					paperSize 	: "a3",
					landscape 	: true,
					margin 		: {top:"5mm",left:"-2cm",right:"-2cm",bottom:"0cm"},
				})
			    .then(function (group) {
					return kendo.drawing.exportPDF(group);
			    })
				.done(function (data) { 
					var payload = {
						Subject:value.subject,
			            Body:value.messege,
			            To:emailTO,
			            Cc:emailCC, 
			            Menu:'widget',
			            Attachment : data,
					}
					widget.mode("preview");
					$(".grid-preview").css({"display":""});
					$(".grid-pdf").css({"display":"none"});
					widget.mode("preview");
					ajaxPost("/ociranalysis/sendemailwidget",payload, function(res){
					}); 
				});
				// },500);
			});
		}
	}
};
widget.popUpEmailSettings = {   
	form 				:{
		subject :ko.observable(""),
		body 	:ko.observable(""),
		remarks :ko.observable(""),
	},
	sendto : ko.observableArray(),
	search 				: ko.observable(""),
	dataMemberList 		: ko.observableArray([]),
	dataMemberSelected 	: ko.observableArray([]),
	rendered          	: function(){
		widget.popUpEmailSettings.gridMemberList();
		widget.popUpEmailSettings.gridMemberSelected();
		widget.popUpEmailSettings.search.subscribe(function(newValue){
			console.log(newValue);
		})
	},
	gridMemberList 		: function(){
		var $modal 	= $("#email-settings-modal");
		var $grid 	= $modal.find("#grid-email-list");
			$grid.html("");
			$grid.kendoGrid({
				dataSource: {
		          	transport: {
						read:function(option){
							option.success(widget.popUpEmailSettings.dataMemberList()); 
							setTimeout(function() {
								$grid.find(".k-grid-content").height(250);
							}, 300);
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					},  
		          	schema: {
		            	data: function(data) {
		             		if (data.length == 0) {
		                 		return [];
		             		}else{ 
		                 		return data; 
		             		} 
		            	}, 
		          	},
	        	},  
	        	columns: [
					{
						title:'',
						width:30,
						headerAttributes: {
							"class": "align-center"
						},
						attributes: {
							"class": "align-center button-grid"
						},
						 template: "## <button  class=\"btn btn-sm pull-left btn-add-member add-member   \" id=\"raady-button\"   onClick='widget.popUpEmailSettings.selectMember(\"#:_id #\")' >Add</button> ##",
           
					},
					{
						field:"fullname",
						title:'Member Name',
						width:100, 
						headerAttributes: {
							"class": "align-left"
						},
						attributes: {
							"class": "field-ellipsis"
						}
					},
					{
						field:"loginid",
						title:'PSID',
						width:70, 
						headerAttributes: {
							"class": "align-left"
						},
						attributes: {
							"class": "field-ellipsis"
						}
					},
					{
						field:"email",
						title:'Email',
						width:100, 
						headerAttributes: {
							"class": "align-left"
						},
						attributes: {
							"class": "field-ellipsis"
						}
					}
	        	],
		       	sortable: true,
				filterable: {
				    extra:false, 
				    operators: {
				        string: {
				            contains: "Contains",
				            startswith: "Starts with",
				            eq: "Is equal to",
				            neq: "Is not equal to",
				            doesnotcontain: "Does not contain",
				            endswith: "Ends with"
				        },
				    }
				},
				// height: 400, 
			});
	},
	gridMemberSelected 	: function(){
		var $modal 	= $("#email-settings-modal");
		var $grid 	= $modal.find("#grid-email-selected");
			$grid.html("")
			$grid.kendoGrid({
				dataSource: {
		          	transport: {
						read:function(option){
							option.success(widget.popUpEmailSettings.dataMemberSelected()); 
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					},  
		          	schema: {
		            	data: function(data) {
		             		if (data.length == 0) {
		                 		return [];
		             		}else{ 
		                 		return data; 
		             		} 
		            	}, 
		          	},
	        	},  
	        	columns: [
					
					{
						field:"fullname",
						title:'Member Name',
						width:100, 
						headerAttributes: {
							"class": "align-left"
						},
						attributes: {
							"class": "field-ellipsis"
						}
					},
					{
						field:"loginid",
						title:'PSID',
						width:70, 
						headerAttributes: {
							"class": "align-left"
						},
						attributes: {
							"class": "field-ellipsis"
						}
					},
					{
						field:"email",
						title:'Email',
						width:100, 
						headerAttributes: {
							"class": "align-left"
						},
						attributes: {
							"class": "field-ellipsis"
						}
					},
					{
						title:'',
						width:30,
						headerAttributes: {
							"class": "align-center"
						},
						attributes: {
							"class": "align-center button-grid"
						},
						template: "## <button  class=\"btn btn-sm pull-left btn-add-member remove-member  \" id=\"raady-button\"   onClick='widget.popUpEmailSettings.removeSelectedMember(\"#: _id #\")' >Remove</button> ##",
					}
	        	],
				sortable: true,
				filterable: {
				    extra:false, 
				    operators: {
				        string: {
				            contains: "Contains",
				            startswith: "Starts with",
				            eq: "Is equal to",
				            neq: "Is not equal to",
				            doesnotcontain: "Does not contain",
				            endswith: "Ends with"
				        },
				    }
				},
				// height: 400,
			});
	},
	selectMember 		: function(id){
		var dataMemberList  	= [];
		var dataMemberSelected 	= widget.popUpEmailSettings.dataMemberSelected();
		_.each(widget.popUpEmailSettings.dataMemberList(), function(key,num){
			if(key._id == id){
				dataMemberSelected.push(key);
				widget.popUpEmailSettings.sendto.push({
															name:key.fullname,
															psid:key.loginid,
															email:key.email,
														})
			}else{
				dataMemberList.push(key);	
			}
		}); 
		widget.popUpEmailSettings.dataMemberList(dataMemberList);
		widget.popUpEmailSettings.dataMemberSelected(dataMemberSelected);
		widget.popUpEmailSettings.refreshAllGrid();
	},
	refreshAllGrid 		 : function(){
		var $modal 			= $("#email-settings-modal");
		var $gridList 		= $modal.find("#grid-email-list");
		var $gridSelected 	= $modal.find("#grid-email-selected");
		$gridList.data('kendoGrid').dataSource.read();
		$gridSelected.data('kendoGrid').dataSource.read();
		kendo.resize($gridList);
		kendo.resize($gridSelected);
	},
	removeSelectedMember : function(id){
		var dataMemberList  	= widget.popUpEmailSettings.dataMemberList();
		var dataMemberSelected 	= [];
		_.each(widget.popUpEmailSettings.dataMemberSelected(), function(key,num){
			if(key._id == id)
				dataMemberList.push(key);
			else
				dataMemberSelected.push(key);	
		}); 
		widget.popUpEmailSettings.dataMemberList(dataMemberList);
		widget.popUpEmailSettings.dataMemberSelected(dataMemberSelected);
		widget.popUpEmailSettings.refreshAllGrid();
	},
	openModalEmailSettings : function(){

		$("#email-settings-modal").modal('hide');
		$("#email-scheduller-modal").modal('show');
	},
	save : function(){
		$("#email-settings-modal").modal("hide");
		if(widget.configTemplateFilter.value.template() ==  ""){
			return;
		}
		var payload = {
				startdate 	: widget.popUpSchedullerEmail.filter.value.startDate(),
			    endemail 	: widget.popUpSchedullerEmail.filter.value.endType(),
			    endvalue 	: widget.popUpSchedullerEmail.filter.value.endValue(),
			    strstarttime : widget.popUpSchedullerEmail.filter.value.TimeStart(),
			    strendtime   : widget.popUpSchedullerEmail.filter.value.TimeEnd(),
			    duration  	 : widget.popUpSchedullerEmail.filter.value.TimeDuration(),
			    patern    	 : widget.popUpSchedullerEmail.filter.value.pattern(),
			    patternValue :  widget.popUpSchedullerEmail.filter.value.patternChilds(),
			    idtemplate  : widget.configTemplateFilter.value.template(),
			    subject 	: widget.popUpEmailSettings.form.subject(),
			    body 		: widget.popUpEmailSettings.form.body(),
			    ramarks 	: widget.popUpEmailSettings.form.remarks(),
			    sendto  	: widget.popUpEmailSettings.dataMemberSelected()
		}
		var url = "/emailscheduller/saveemailsetting";   
  		ajaxPost(url, payload, function (datas){
  			
  			 swal("Saved!", "", "success");
  		});
	}
};
widget.popUpSchedullerEmail = {
	filter:{
		data:{
			TimeEnd 	: ko.observableArray(time),
			
			time 	: ko.observableArray(time),
			ordinal : ko.observableArray(ordinal),
			day 	: ko.observableArray(days),
			month  	: ko.observableArray(months),
			duration:ko.observableArray([
											{text:"1 Hours",value:1},
											{text:"2 Hours",value:2},
											{text:"3 Hours",value:3},
											{text:"1 Day",value:24}
										]),
		},
		value:{ 
			TimeStart:ko.observable("0100"),
			TimeEnd:ko.observable("0200"),
			TimeDuration:ko.observable(1),
			
			EndTime	 : ko.observable(""),
			startDate : ko.observable(), 

			pattern: ko.observable("Daily"),
			patternType:ko.observable("Everyday"),
			patternValue:ko.observable(""),
			
			ordinal:ko.observable(1),
			day  :ko.observable("Monday"),
			month:ko.observable("January"),
			days : ko.observableArray([]),
			startValue : ko.observable(""),
			endType   : ko.observable("No End Date"),
			endValue : ko.observable(""),
			patternChilds : ko.observableArray([])
		}
	}, 
	checkedDay : function(val){
		with(widget.popUpSchedullerEmail){
			var a = filter.value.days;
	 
			if(a().indexOf(val) > -1)
				 a().push(val)
			else
				 a().slice(0, a().indexOf(val));
			a.valueHasMutated();
		}
	},
	checkPattern : function(val){
		with(widget.popUpSchedullerEmail.filter.value){ 
			patternType("");
			switch(val){
				case"Daily":
					patternType("Everyday");
				break;
				case"Monthly":
					patternType("Day");
				break;
					case"Yaerly":
					patternType("Month");
				break;
			}
			pattern(val);
			ordinal(1);
			day("Monday");
			month("January");
			patternValue("");
		}
	},
	renderNewListEndTime : function(duration, startTime){ 
		if(duration ==  24){ 
			widget.popUpSchedullerEmail.filter.data.TimeEnd(time);
			widget.popUpSchedullerEmail.filter.value.TimeEnd(startTime);
			widget.popUpSchedullerEmail.filter.value.EndTime("2400"); 
			return;
		}
		if(parseInt(widget.popUpSchedullerEmail.filter.value.TimeStart()) +  parseInt(widget.popUpSchedullerEmail.filter.value.TimeDuration() * 100) >= 2400){
			widget.popUpSchedullerEmail.filter.data.TimeEnd(time);
			widget.popUpSchedullerEmail.filter.value.TimeEnd(startTime);
			widget.popUpSchedullerEmail.filter.value.EndTime("2400"); 
			return;
		}
		var duration   = parseInt(duration) * 100; 
		var minEndTime = parseInt(startTime) + duration;
		var newListTime = [];
		_.each(time, function(val, key){
		 	var valueTime = parseInt(val.value) 
			if( valueTime > parseInt(startTime) ){ 
				if( valueTime > minEndTime )
					 newListTime.push(val);
			}
		}); 
		var end = (String(minEndTime).length < 4)? '0' + String(parseInt(minEndTime + 100)) : String(parseInt(minEndTime + 100))
		widget.popUpSchedullerEmail.filter.data.TimeEnd(newListTime);   
		widget.popUpSchedullerEmail.filter.value.TimeEnd(end);	 
	}, 
	save : function(){
		with(widget.popUpSchedullerEmail.filter.value){
			startDate(fomatkendoDatePickerToString($("#start-date").data("kendoDatePicker")._oldText));
	  		if(endType() == "End By"){ 
				endValue(fomatkendoDatePickerToString($("#end-date").data("kendoDatePicker")._oldText));  
			}else if(endType() == "No End Date"){ 
				endValue("Yes");
			}	
		  
			var template = {}; 
			switch(pattern()){
				case "Daily":
					template.paternvalue = patternType();
				break;
				case "Weekly":
					template.paternvalue = days();
				break;
				case "Monthly":
					template.paternvalue = {
						"type" : patternType(),
					}
					if(patternType() == "Day")
						template.paternvalue.value = patternValue();
					else
						template.paternvalue.value = [
							{
								week: ordinal(),
								day : day()
							}
						];
				break;
				default:
					template.paternvalue = {
						type : patternType(),
					}
					if(patternType() == "Month")
						template.paternvalue.value =  [
							{
								month:month(),
								value:patternValue(),
							}
						];
					else
						template.paternvalue.value = [
							{
								week: ordinal(),
								day : day(),
								month : month()
							}
						];
			}
			patternChilds(template.paternvalue)
		}
		$("#email-scheduller-modal").modal("hide");
		$("#email-settings-modal").modal("show");
	}
};
widget.popUpSchedullerEmail.filter.value.TimeStart.subscribe(function(newValue){ 
	widget.popUpSchedullerEmail.renderNewListEndTime(widget.popUpSchedullerEmail.filter.value.TimeDuration(), widget.popUpSchedullerEmail.filter.value.TimeStart());
});
widget.popUpSchedullerEmail.filter.value.TimeEnd.subscribe(function(newValue){ 
	widget.popUpSchedullerEmail.renderNewListEndTime(widget.popUpSchedullerEmail.filter.value.TimeDuration(), widget.popUpSchedullerEmail.filter.value.TimeStart());
});
widget.popUpSchedullerEmail.filter.value.TimeDuration.subscribe(function(newValue){	 
	widget.popUpSchedullerEmail.renderNewListEndTime(widget.popUpSchedullerEmail.filter.value.TimeDuration(), widget.popUpSchedullerEmail.filter.value.TimeStart());
});


// widget.emailSettingtemplate = {
// 	startdate 	: widget.popUpSchedullerEmail.filter.value.startDate(),
//     endemail 	: widget.popUpSchedullerEmail.filter.value.endType(),
//     endvalue 	: widget.popUpSchedullerEmail.filter.value.endValue(),
//     strstarttime : widget.popUpSchedullerEmail.filter.value.TimeStart(),
//     strendtime   : widget.popUpSchedullerEmail.filter.value.TimeEnd(),
//     duration  	 : widget.popUpSchedullerEmail.filter.value.TimeDuration(),
//     patern    	 : widget.popUpSchedullerEmail.filter.value.pattern(),
//     patternValue : "",
//     idtemplate  : ko.observable(""),
//     subject 	: widget.popUpEmailSettings.form.subject(),
//     body 		: widget.popUpEmailSettings.form.body(),
//     ramarks 	: widget.popUpEmailSettings.form.remarks(),
   
//     sendto  	: widget.popUpEmailSettings.dataMemberSelected()
// };
 


widget.DonutseriesColors = ["#00506D","#0077A3","#50D0FF","#8ADFFF","#E6E7E8", "#BCBEC0"]; 
widget.configTemplateFilter = {
	value:{
		template:ko.observable(""),
		type :ko.observable(""),
	},
	data:{
		template:ko.observableArray([])
	},
	onchange:{
		template:ko.observable(true)
	}

};
// widget.filterProp = {
// 	"default":
widget.filterDefault 		= [
							  		{id:'Region', title:"Region"},
							  		{id:'Cefcritical', title:"Cefcritical"},
							  		{id:'Pfpcritical', title:"Pfpcritical"},
							  		{id:'ReceiverCountry', title:"Receiver Country"},
							  		{id:'ReceiverLegalEntity', title:"Receiver Legal Entities"},
							  		{id:'SupplierCountry', title:"Supplier Country"},
							  		{id:'SupplierLegalEntity', title:"Supplier Legal Entities"},
							  		{id:'Categoryname', title:"Business/Function Group"},
							  		{id:'Suppliertype', title:"Service Type"},
							  		{id:'Productfunction', title:"Business/Function Sub-Group"},
							  		{id:'Functiontype', title:"Business/Function Type"},
							  		{id:'Parentprocessname', title:"Parent Process Name"},
							  		{id:'GPO', title:"Global Process Owner"}, 
							  		{id:'dailystatus', title:"dailystatus"},
							  		{id:'cpoReport', title:"cpoReport"},
							  ]
widget.filterDailyStatus 	= [
									{id:'Region', title:"Region"},
									{id:'ReceiverCountry', title:"Receiver country"},
									{id:'ReceiverLegalEntity', title:"Receiver Legal Entity"},
									{id:'Categoryname', title:"Bussiness/Function"}
							  ];
widget.filterCpoReport 	    = [
									{id:'Region', title:"Region"},
									{id:'ReceiverCountry', title:"Receiver country"},
									{id:'ReceiverLegalEntity', title:"Receiver Legal Entity"},
									{id:'GPO', title:"CPO"},
									{id:'Pfpprocessowner',title:'Mapper'},
									{id:'Categoryname', title:"Business/Function"},
									{id:'Productfunction', title:"Product"},
									{id:'Parentprocessname', title:"Level 1 Process"},
							   ];

widget.processLoadTemplate 	= ko.observable(false);

widget.nobox = ko.observable(false);
function fomatkendoDatePickerToString(date){
	var	ymd = (date.split("/"));
	return ymd[0]+ymd[1]+ymd[2];
};
function getTemplateActive(page){
	return widget.template()[page];
};
function getDataViZActive(page, index){
	return widget.template()[page].mainpage.dataViz[index]
};
function getSummaryActive(page, index){ 
	return widget.template()[page].mainpage.summary[index]
}; 
function getFilterActive(page){
	return widget.template()[page].filter;
};
function capitalize(string){
	return string.replace(/\b\w/g, function(l){ return l.toUpperCase() })
};
function limitResultBar(dataSource,limit){
	limit -= 1;
	if(dataSource.length < limit)
		return dataSource;
	var results = []
	for(i=0; i<=limit; i++){
		results.push(dataSource[i])
	}
	return results;
};
function limitResultGrid(dataSource,limit){
	limit -= 1;
	if(dataSource.length < limit)
		return dataSource;
	var results = []
	for(i=0; i<=limit; i++){
		results.push(dataSource[i])
	}
	return results;
};
function getDate(){
	var d = new Date();
	var Months 		= ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	var Days 		= ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	
	var year	 	= d.getFullYear();
	var month 		= Months[parseInt(d.getMonth())];
	var date 		= d.getDate();
	var formatDate 	= date +" "+month+" "+ year + " " +d.getHours() + ":" + ((d.getMinutes() < 10)? "0"+ d.getMinutes() : d.getMinutes() + ":" + d.getSeconds())
    return formatDate;
};
function formatDateGeneate(date){
	return 'Report generated on: ' + getDate() +"</br>"+date[0]+"</br>"+date[1];
};
function openModalEmailSettings(){
	$("#email-settings-modal").modal("show");
};
widget.configTemplateFilter.value.template.subscribe(function(newValue){
	if(!widget.configTemplateFilter.onchange.template()){
		return widget.configTemplateFilter.onchange.template(true);
	}
	if(newValue == "") 
		widget.formatTemplate();
	else{
		widget.GetEmailScheduller(newValue);
		widget.loadTemplate(newValue);
	}
});
widget.formatTemplate = function(){ 
	widget.page.active(0);
	widget.page.total(0);
	widget.page.data([]);  
	widget.active.page(0);
	widget.active.index(0);
	widget.template([]);
	widget.CreatePage();
};
 
widget.getFilterTemplate = function(){
	return {
		Region : {
			id 	 :"Region",
			data :ko.observableArray([{text:"Region",value:"Region"}]), 
			value:ko.observableArray([]), 
			title: "Region",
			url  :"/ociranalysis/getregion",
			loading : false,
			visible : true
		},
		Cefcritical : {
			id 	 :"Cefcritical",
			data:ko.observableArray([{text:"Yes",value:"Yes"},{text:"No",value:"NO"}]),
			value:ko.observableArray([]), 
			title:"Cefcritical",
			url  :"/ociranalysis/getcef",
			loading : false, 
			visible : true
		},
		Pfpcritical : {
			id 	 :"Pfpcritical",
			data:ko.observableArray([{text:"Yes",value:"Yes"},{text:"No",value:"NO"}]),
			value:ko.observableArray([]), 
			title:"Pfpcritical",
			url  :"/ociranalysis/getnecessary",
			loading : false,
			visible : true
		},
		ReceiverCountry : {
			id 	 :"ReceiverCountry",
			data:ko.observableArray([{text:"ReceiverCountry",value:"Pfpcritical"}]), 
			value:ko.observableArray([]), 
			title:"Receiver Country",
			url  :"/ociranalysis/getreceivercountry",
			loading : false,
			visible : true
		},
		ReceiverLegalEntity : {
			id 	 :"ReceiverLegalEntity",
			data:ko.observableArray([{text:"ReceiverLegalEntity",value:"Pfpcritical"}]), 
			value:ko.observableArray([]), 
			title:"Receiver Legal Entities",
			url  :"/ociranalysis/getlegalentityreceiver",
			loading : false,
			visible : true
		},
		SupplierCountry : {
			id 	 :"SupplierCountry",
			data:ko.observableArray([{text:"SupplierCountry", value:"SupplierCountry"}]), 
			value:ko.observableArray([]), 
			title:"Supplier Country",
			url  :"/ociranalysis/getsuppliercountry",
			loading : false,
			visible : true
		},
		SupplierLegalEntity : {
			id 	 :"SupplierLegalEntity",
			data:ko.observableArray([{text:"SupplierLegalEntity", value:"SupplierLegalEntity"}]), 
			value:ko.observableArray([]), 
			title:"Supplier Legal Entities",
			url  :"/ociranalysis/getlegalentitysupplier",
			loading : false,
			visible : true
		},
		Categoryname : {
			id 	 :"Categoryname",
			data:ko.observableArray([{text:"Categoryname", value:"Categoryname"}]), 
			value:ko.observableArray([]), 
			title:"Business/Function Group",
			url  :"/ociranalysis/getcategory",
			loading : false,
			visible : true
		},
		Suppliertype : {
			id 	 :"Suppliertype",
			data:ko.observableArray([{text:"Suppliertype", value:"Suppliertype"}]), 
			value:ko.observableArray([]), 
			title:"Service Type",
			url  :"/ociranalysis/getsuppliertype",
			loading : false,
			visible : true
		},
		Productfunction : {
			id 	 :"Productfunction",
			data:ko.observableArray([{text:"Productfunction", value:"Productfunction"}]), 
			value:ko.observableArray([]), 
			title:"Business/Function Sub-Group",
			url  :"/ociranalysis/getproductfunction",
			loading : false,
			visible : true
		},
		Functiontype : {
			id 	 :"Functiontype",
			data:ko.observableArray([{text:"Functiontype", value:"Functiontype"}]),
			value:ko.observableArray([]), 
			title:"Business/Function Type",
			url  :"/ociranalysis/getfunctiontype",
			loading : false,
			visible : true
		},
		Parentprocessname : {
			id 	 :"Parentprocessname",
			data:ko.observableArray([{text:"Parentprocessname", value:"Parentprocessname"}]), 
			value:ko.observableArray([]), 
			title:"Parent Process Name",
			url  :"/ociranalysis/getparentprocessname",
			loading : false,
			visible : true
		},
		GPO : {
			id 	 :"GPO",
			data :ko.observableArray([{text:"GPO", value:"GPO"}]), 
			value:ko.observableArray([]), 
			title:"Global Process Owner",
			url  :"/ociranalysis/getgpo",
			loading : false,
			visible : true
		},
		Pfpprocessowner : {
			id 	 :"Pfpprocessowner",
			data :ko.observableArray([{text:"mapper", value:"mapper"}]), 
			value:ko.observableArray([]), 
			title:"Mapper",
			url  :"/widgetanalysis/getmapper",
			loading : false,
			visible : true
		},
		dailystatus:{
			id 	  	: "dailystatus",
			data  	: ko.observableArray([{text:"true", value:"true"},{text:"false", value:"false"}]), 
			value 	: ko.observable(false), 
			title 	: "dailystatus",
			loading : false,
			visible : false
		},
		cpoReport:{
			id 	  	: "cpoReport",
			data  	: ko.observableArray([{text:"true", value:"true"},{text:"false", value:"false"}]), 
			value 	: ko.observable(false), 
			title 	: "dailystatus",
			loading : false,
			visible : false
		}
	};
};
widget.createFilter =  function(){	
	return widget.getFilterTemplate();
};
widget.createDataviz  =  function(page, totalWidget){
	var results = [];
	for(var i = 1; i<=totalWidget; i++){
		results.push({
			id  : "widget"+page+i,
			active : ko.observable(false),
			type: ko.observable(""),
			filter :{
				value : ko.observable(""),
				text  : ko.observable(""),
			},
			data:[],
			showFilter : ko.observable(false),
			loading    : ko.observable(false)
		})
	}
	return results;
};
widget.createSummary =  function(page, totalSummary){
	var results = [] 
	for(var i = 1; i<=totalSummary; i++){
		results.push({
			id  : "summary"+page+i,
			active  : ko.observable(false),
			value  	: ko.observable(0),
			filter 	:{
				value : ko.observable(""),
				text  : ko.observable(""),
			},
			data:[],
			showFilter : ko.observable(false),
			loading    : ko.observable(false)
		})
	}
	return results;
};
widget.CreatePage = function(){
  
	var page 	= widget.page.total() + 1;
	var filter 	= widget.createFilter();
	
	var totalSummary = 8;
	var totalDataviz = 3;

	var summary 	= widget.createSummary(page, totalSummary);
	var dataViz 	= widget.createDataviz(page, totalDataviz);

	widget.GetDataFilter(filter);
	 
	widget.template().push({
		filter: filter,
		mainpage:{
			summary 	: summary,
			fulDataViz 	: ko.observable(false),
			fulDataVizIndex   : ko.observable(""),
			fulDataVizLoading : ko.observable(false),
			dataViz  	: dataViz
		}
	}); 

	 

	widget.template.valueHasMutated();
	 

	widget.page.data().push(page)
	widget.page.data.valueHasMutated();
	widget.page.active(page);
	widget.page.total(page);
};

widget.checkFullDataViz  = function(page){
	if (getTemplateActive(page).mainpage.fulDataViz()){
		getTemplateActive(page).mainpage.fulDataViz(false);
		getTemplateActive(page).mainpage.fulDataVizIndex("");
	}
};

widget.generateDataviz      =  function(type, page, index){
 	widget.checkFullDataViz(page)
	switch(type.toLowerCase()){
		case"bar":
			widget.generateDatavizBar(page, index);
		break;
		case"donut":
			widget.generateDatavizDonut(page, index);
		break;
		case"grid":
			widget.generateDatavizGrid(page, index);
		break;
	};
};
widget.clearDataviz =  function(page, ExceptIndex){ 
	var template = getTemplateActive(page); 
	_.each(template.mainpage.dataViz, function(o,i){
	 
		if(i == ExceptIndex)
			return
		else
			widget.CloseDataViZActive(page,i)
	});
};

widget.generateDatavizBar   =  function(page, index){
	$("#opt-bar-modal").modal('hide'); 
 
	var config = getDataViZActive(page, index);
		config.active(true);
		config.type("bar");
		config.loading(true);

	var payload = widget.GeneratePayload(getTemplateActive(page).filter);
	var filter  = config.filter.value();  

	switch(filter){
		// normal Bar
		case "Biggest":
			if(payload.Categoryname.length == 0){
				ajaxPost("/ociranalysis/receivercategory", payload, function(res){
					config.loading(false);
					widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
				});
			}else{
				ajaxPost("/ociranalysis/receivercategoryproduct", newPayload , function (res){
                    config.loading(false);
					_.each(res, function(o){
						o._id = o.Country;
					});
					widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
                });
			}
		break;
		case "Service FTE":
			ajaxPost("/ociranalysis/servicefte", payload, function(res){
				config.loading(false);
				widget.creataNormalBar(config.id, page, filter,_.sortBy(res, "Count").reverse());
			});
		break;
		case "Fte by Country":
			if(payload.SupplierCountry.length == 0){
				ajaxPost("/ociranalysis/ftebycountry", payload , function (res){
                    config.loading(false);
					widget.creataNormalBar(config.id, page, filter,_.sortBy(res, "Count"));           
                });
			}else{
				ajaxPost("/ociranalysis/ftebycountrylegal", payload , function (res){
                    config.loading(false);
					widget.creataNormalBar(config.id, page, filter,_.sortBy(res, "Count"));   
                }); 
			}
		break;
		case 'level 1 by country':
			ajaxPost("/ociranalysis/levelbycountry", payload, function(res){
				config.loading(false);
				widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
			});
		break;
		case "Process by GBS and Others":
			ajaxPost("/ociranalysis/processbygbs", payload , function (res){
				config.loading(false);
				widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break; 
		case "Assets Utilized":
			ajaxPost("/ociranalysis/getassetsutilized", payload , function (res){
				config.loading(false);
				widget.creataNormalBar(config.id, page, filter,_.sortBy(res, "Count").reverse());
            });
		break;
		case 'Third party suppliers':
            payload.WorstType = "";
			ajaxPost("/ociranalysis/thirdpartysuppliers", payload , function (res){
				config.loading(false);
				_.each(res, function(o){
					o._id = o.Country;
				});
				widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break;
		case 'Third party suppliers by business':
            payload.WorstType = "";
			ajaxPost("/ociranalysis/tpsbybusiness", payload , function (res){
				config.loading(false);
				_.each(res, function(o){
					o._id = o.Country;
				});
				widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break;
		case 'Third party suppliers by country':
            payload.WorstType = "";
			ajaxPost("/ociranalysis/tpsbycountry", payload , function (res){
				config.loading(false);
				_.each(res, function(o){
					o._id = o.Country;
				});
				widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break;
		case "Barriers to Resolution by Region":
			payload.Flag = "region";
			ajaxPost("/ociranalysis/barriersbar", payload , function (res){
				config.loading(false); 
				widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res.Data, "Count").reverse(),10));
            });
		break;
		case "Different Types  of Barriers":
			payload.Flag = "barriertype";
			ajaxPost("/ociranalysis/barriersbar", payload , function (res){
				config.loading(false); 
				widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res.Data, "Count").reverse(),10));
            });
		break;

		// Bar with label
		case "Worst 10 [% Validated]":
			payload.WorstType = "validated";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case "Worst 10 [% Enriched]":
			payload.WorstType = "enriched";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case "Worst 10% Validated by Business/Function":
			payload.WorstType = "businnessvalidated";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case "Worst 10% Enriched by Business/Function":
			payload.WorstType = "businnessenriched";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
		case 'Best 10 [% Validated]' :
            payload.WorstType = "reversevalidated";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
		case 'Best 10 [% Enriched]' :
            payload.WorstType = "reverseenriched";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Pending Best 10 [% Validated]':
            payload.WorstType = "pendingbestvalidated";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
		case 'Pending Best 10 [% Enriched]':
            payload.WorstType = "pendingbestenriched";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
	    case 'Pending Worst 10 [% Validated]':
            payload.WorstType = "pendingworstvalidated";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
		case 'Pending Worst 10 [% Enriched]':
            payload.WorstType = "pendingworstenriched";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Worst 10 by Process Owner [% Validated Service]':
            payload.WorstType = "worstownervalidated";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Worst 10 by Process Owner [% Confirmed Service]':
            payload.WorstType = "worstownerenriched";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Best 10 by Process Owner [% Validated Service]':
            payload.WorstType = "bestownervalidated";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Best 10 by Process Owner [% Confirmed Service]':
            payload.WorstType = "bestownerenriched";
			ajaxPost("/ociranalysis/worstvalidated", payload , function (res){
				config.loading(false);
				widget.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Buildings by country':
            payload.WorstType = "";
			ajaxPost("/ociranalysis/buildingbycountry", payload , function (res){
				config.loading(false);
				_.each(res, function(o){
					o._id = o.Country;
				});
				widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break; 
		
		//barfull
		case 'Barriers to Resolution by Business': 
			config.loading(false);
            widget.clearDataviz(page, index);

            var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);     
            	template.mainpage.fulDataVizLoading(true);     
            payload.Flag = "categoryname_";
            ajaxPost("/ociranalysis/barriersbar", payload , function (res){

            	template.mainpage.fulDataVizLoading(false); 
            	var id = "fullDataViz"+page;
				widget.createFullBar(id, filter, res.Data);
            });
        break; 
        case 'Barriers to Resolution by Country': 
			config.loading(false);
            widget.clearDataviz(page, index);

            var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);     
            	template.mainpage.fulDataVizLoading(true);     
            payload.Flag = "receivercountry";
            ajaxPost("/ociranalysis/barriersbar", payload , function (res){
            	
            	template.mainpage.fulDataVizLoading(false); 
            	var id = "fullDataViz"+page;
				widget.createFullBar(id, filter, res.Data);
            });
        break; 
    	case '% Validated all Countries': 
			config.loading(false);
            widget.clearDataviz(page, index);

            var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);     
            	template.mainpage.fulDataVizLoading(true);     
            payload.WorstType = "validated";
            ajaxPost("/ociranalysis/percentvalidated", payload , function (res){
            	 
            	template.mainpage.fulDataVizLoading(false); 
            	var id = "fullDataViz"+page;
				widget.createFullBar(id, filter, res);
            });
        break; 
        case '% Enriched all Countries':
        	config.loading(false);
            widget.clearDataviz(page, index);

            var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);     
            	template.mainpage.fulDataVizLoading(true);     
            payload.WorstType = "enriched";
            ajaxPost("/ociranalysis/percentvalidated", payload , function (res){
            	 
            	template.mainpage.fulDataVizLoading(false); 
            	var id = "fullDataViz"+page;
				widget.createFullBar(id, filter, res);
            });
        break;
       
        //barfull with condition
        case 'Comparison Region [% Validated Service]':     
		    payload.WorstType = "validated";
        	ajaxPost("/ociranalysis/comparisonregion", payload , function (res){
            	if(res.length >= 19){
            		config.loading(false);
           		 	widget.clearDataviz(page, index);
            		var template = getTemplateActive(page);
		            	template.mainpage.fulDataVizIndex(index);
		            	template.mainpage.fulDataViz(true);      	
	            	var id = "fullDataViz"+page;
					widget.createFullBar(id, filter, res);
            	}else{
            		config.loading(false);
					widget.createBarWithLabel(config.id, page, filter, res);
            	}
            });
        break;
		case 'Comparison Region [% Confirmed Service]':     
		    payload.WorstType = "enriched";
        	ajaxPost("/ociranalysis/comparisonregion", payload , function (res){
            	if(res.length >= 19){
            		config.loading(false);
           		 	widget.clearDataviz(page, index);
            		var template = getTemplateActive(page);
		            	template.mainpage.fulDataVizIndex(index);
		            	template.mainpage.fulDataViz(true);      	
	            	var id = "fullDataViz"+page;
					widget.createFullBar(id, filter, res);
            	}else{
            		config.loading(false);
					widget.createBarWithLabel(config.id, page, filter, res);
            	}
            });
        break;

        // stacked bar
        case "Systems per business/function":
        	payload.Flag = filter;
            ajaxPost("/ociranalysis/systemsperbusiness", payload , function (res){
            	config.loading(false); 
            	widget.createStackedBar(config.id, filter, widget.mappingDataStackedBar(res));
            });
        break;
        case "Processes per critical service provider":
        	payload.Flag = filter;
            ajaxPost("/ociranalysis/getcriticalprovider", payload , function (res){
            	config.loading(false); 
            	widget.createStackedBar(config.id, filter, widget.mappingDataStackedBar(res));
            });
        break;
        case "Critical Service Providers by FTE":
        	payload.Flag = filter;
            ajaxPost("/ociranalysis/getcriticalproviderfte", payload , function (res){
            	config.loading(false); 
            	widget.createStackedBar(config.id, filter, widget.mappingDataStackedBar(res));
            });
        break;
        case "Location by FTE":
        	payload.Flag = filter;
            ajaxPost("/ociranalysis/getlocationfte", payload , function (res){
            	config.loading(false); 
            	widget.createStackedBar(config.id, filter, widget.mappingDataStackedBar(res));
            });
        break;
        // cefassessmentchart
        default:
			payload.Flag = filter;
			ajaxPost("/ociranalysis/cefassessmentchart", payload , function (res){
				config.loading(false);
				widget.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
			})
	}
};
widget.creataNormalBar 		= function(id, page, type,dataSource){ 
	var $id = $("#"+id).find(".content");
	
	var max = (dataSource.length == 0) ? 0 : _.max(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var min = (dataSource.length == 0) ? 0 : _.min(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	if(max == 0 && min == 0)
		dataSource  = [];
 	
 	if(dataSource.length == 1){ 
		$id.css('height', (dataSource.length * 60) + 'px');
    }else if (dataSource.length <= 7){ 
		$id.css('height', (dataSource.length * 52) + 'px'); 
    }else{
		$id.css('height','370px');  
    }
	
	var eventClick  = seriesClick; 
	var filter 		= getFilterActive(widget.page.active()-1);
	switch(type){
		case"Buildings by country":
		case"Third party suppliers":
		case"Third party suppliers by business":
		case"Third party suppliers by country": 
		// case"Barriers to Resolution by Region":
		// case"Different Types  of Barriers": 
			eventClick = undefined;
			hoverType  = 0; 
	 	break;
	}


	$id.html('');
    $id.kendoChart({
        dataSource: {
            data:dataSource,
            dataType: "json"
        },
        legend :{
            position :"top",
            margin:{
                visible:true,
                top:40
            },
            font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
        },
        chartArea: { 
        	width:331,
        },
        transitions: false,
        seriesDefaults: {
            type: "bar",
            overlay: {
            	gradient: "none"
            },
            tooltip: {
            	visible: false,
            	template: "#:kendo.toString(value,'N0')#"
            },
            labels: {
				font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
				color: "#0075B2",
				visible: true, 
				position:"outsideEnd",
				background: "transparent",
				template : function(e){ 
					return parseInt(e.value.toFixed(0)).toLocaleString()
              	},
            }, 
            gap: 0.3, 
        },
        series: [{
            field: "Count",
            border: {
                width: 1,
                color: "transparent"
            },
			color: function(e){
				if(type == 'Process by GBS and Others'){
					if(e.dataItem.Color == 'gbs'){
						return "#2F7528"
					}else{
						return "#005C84"
					}
				}else{
					return "#005C84"
				} 
			} 
        }],
        categoryAxis :{
            field : "_id",
            labels: {
                template: labelTemplate,
                font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            majorGridLines: {
				visible: false
            },
            line:{
                visible:false
            }
        },
        valueAxis:{
            min:0,
            max: max * 1.2,

            majorGridLines: {
              visible: false,
            },
        
            line: {
              visible: false
            },
           
            labels:{
              visible:false,
            },
        },
        tooltip: {
            visible: true,
            format: "n0",
        }, 
        seriesClick: eventClick,
        seriesHover: function(e) { 
        	if(eventClick)
        		$id.css("cursor","pointer");
        	else
        		$id.css("cursor","default");

        	setTimeout(function(){
        		$id.find("g path").each(function (idx){
        			var op = $(this).attr('stroke-opacity');
        			if (op == 0.2){
                		if(filter.ReceiverCountry == e.category){
							$(this)
							.attr('fill','#50D0FF')
							.attr('fill-opacity', 1)
						}else if(type == 'Process by GBS and Others'){
							if(e.dataItem.Color == 'gbs'){
								$(this)
								.attr('fill','#1f4f1a')
								.attr('fill-opacity', 1)
							}else{
								$(this)
								.attr('fill','#002951')
								.attr('fill-opacity', 1)
							}
						}else{
							$(this)
							.attr('fill','#002951')
							.attr('fill-opacity', 1)
						}

					}	
        		});
        	},100);
        },
        seriesColors: ["#66DBFF"],
    });
    var isFound = false
    jQuery('#'+id+' .content g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
        if (isFound) return
        if ($(e).html() == '') isFound = true
        $(e).find('text').attr('x', 0)
	});
    function labelTemplate(e) { 
		var finalStm = "";
		var maxlen = 14;
		var Spl = e.value.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
		    lenStm = lenStm + o.length + 1;
		    var tb = "";
		    if (lenStm <= maxlen) {
		        tb = " ";
		    } else {
		        lenStm = o.length;
		        tb = "\n";
		    }
		    if (i == 0) {
		        tb = "";
		    }
		    finalStm = finalStm + tb + o;
		}); 
		return finalStm
    };
    function seriesClick(e){
    	$modal = $("#bar-normal-modal");
    	var url 	= "";
    	var payload = widget.GeneratePayload(getFilterActive(page));
    	var column = []; 
    	switch(type){
    		case "Different Types  of Barriers":
    			payload.Barriertype =  e.category;
    			url = "/ociranalysis/popupbarrier";
    			column = [
					{
					    field:"receivercountry",
					    title:'Receiver Country',
					    /*filterable: false,*/
					    width:180,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    },
					    template: "#= receivercountry + ' - ' + receiverlegalentity #",
					},
					{
					    field:"suppliercountry",
					    title:'Supplier Country',
					    /*filterable: false,*/
					    width:180,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    },
					    template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
					},
					{
					    field:"categoryname_",
					    title:'Business',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"productfunction",
					    title:'Product',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"parentprocessname",
					    title:'Level 1 Process',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"processname",
					    title:'Level 2 Process',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"servicedescription",
					    title:'Service Description',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"barriertype",
					    title:'Barrier Type',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					}
				]
    		break;
    		case "Barriers to Resolution by Region":
    			payload.Region = [e.category];
    			url = "/ociranalysis/popupbarrier";
    			column = [
					{
					    field:"receivercountry",
					    title:'Receiver Country',
					    /*filterable: false,*/
					    width:180,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    },
					    template: "#= receivercountry + ' - ' + receiverlegalentity #",
					},
					{
					    field:"suppliercountry",
					    title:'Supplier Country',
					    /*filterable: false,*/
					    width:180,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    },
					    template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
					},
					{
					    field:"categoryname_",
					    title:'Business',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"productfunction",
					    title:'Product',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"parentprocessname",
					    title:'Level 1 Process',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"processname",
					    title:'Level 2 Process',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"servicedescription",
					    title:'Service Description',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"barriertype",
					    title:'Barrier Type',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					}
				]
    		break;
    		case"Service FTE":
    			payload.Categoryname =  [e.category];
    			url = "/ociranalysis/modalforfte";
    			column = [
    				{
						field:"_id",
						title:'Function Name',
						width:200, 
						attributes: {
							"class": "field-ellipsis"
						}
					},
					{
						field:"Count",
						title:'FTE',
						width:100, 
						attributes: {
							"class": "field-ellipsis align-right"
						},
						template: "#:kendo.toString(Count,'N2')#",
						headerAttributes: {
							"class": "align-right"
						},
					}
				];
    		break;
    		case"Fte by Country":
    			url = "/ociranalysis/modalforfte";
    			if ( payload.SupplierCountry.length === 0 )
					payload.SupplierCountry = [e.category]; 
	            else 
					payload.SupplierLegalEntity =  [e.category]  
	              
				column = [
					{
						field:"_id",
						title:'Function Name',
						width:200,
						attributes: {
							"class": "field-ellipsis"
						}
					},
					{
						field:"Count",
						title:'FTE',
						width:100,
						attributes: {
							"class": "field-ellipsis align-right"
						},
						headerAttributes: {
							"class": "align-right"
						},
						template: "#:kendo.toString(Count,'N2')#"
					}
				];
    		break;
    		case"level 1 by country":
    			url = "/ociranalysis/getdetailchart";
    			if(payload.SupplierCountry.length == 0)
    				payload.SupplierCountry = [e.category];
    			else
    				payload.SupplierLegalEntity = [e.category];

    			column = [
	    			{
						field:"_id.Parentprocessname",
						title:'Level 1 Process',
						width:200, 
						attributes: {
						"class": "field-ellipsis"
						}
					}
				];
    		break;
    		case"Assets Utilized":
  				url = "/ociranalysis/getdetailassetutilized";
  				payload.Categoryname =  [e.category];
  				payload.Typebar = "";
				switch(e.category){
					case 'Buildings':
						payload.Typebar = "BLD";
						column = [
							{
								field:"_id.buildingid",
								title:'Building ID',
								width: 50,
								attributes: {
									"class": "field-ellipsis"
								},
								headerAttributes: {
									"class": "align-left"
								}
							},
							{
								field:"_id.buildingname",
								title:'Building Name',
								width: 150,
								attributes: {
									"class": "field-ellipsis"
								}
							}
						]
					break;
					case 'External Systems':
						payload.Typebar  = "ES";
						column = [
							{
								field:"_id.supplierid",
								title:'Supplier ID',
								width: 50,
								attributes: {
									"class": "field-ellipsis"
								},
								headerAttributes: {
									"class": "align-left"
								}
							},
							{
								field:"_id.suppliername",
								title:'Name',
								width: 150,
								attributes: {
									"class": "field-ellipsis"
								}
							}
						]
					break;
					case 'Internal Systems':
						payload.Typebar = "IS";
						column = [
							{
								field:"_id.supplierid",
								title:'Supplier ID',
								width: 50,
								attributes: {
									"class": "field-ellipsis"
								},
								headerAttributes: {
									"class": "align-left"
								}
							},
							{
								field:"_id.suppliername",
								title:'Name',
								width: 150,
								attributes: {
									"class": "field-ellipsis"
								}
							}
						]
					break;
					case 'Data Centers':
						payload.Typebar = "DC";
						column = [
							{
								field:"_id.hublocationcountry",
								title:'Hub Location',
								width: 50,
								attributes: {
									"class": "field-ellipsis"
								},
								headerAttributes: {
									"class": "align-left"
								}
							},{
								field:"_id.systemshublocation",
								title:'Hub Location Country',
								width: 150,
								attributes: {
									"class": "field-ellipsis"
								}
							}
						]
					break;
				}  
  	 		break;
    		case"Biggest":
    			if(payload.Categoryname.length == 0)
    				payload.Categoryname =  [e.category]; 

    			url 	= "/ociranalysis/getdetailchart";
    			column = [
		    		{
		    			attributes:{
		    				class: "field-ellipsis"
		    			},
		    			field : "_id.Parentprocessname",
		    			title : "Level 1 Process",
		    			width : 200 
		    		}, 
		    	];
    		break;
    		case"Process by GBS and Others":
    			if(payload.SupplierCountry.length == 0)
    				payload.SupplierCountry = [e.category];
    			else
    				payload.SupplierLegalEntity = [e.category];
    			url 	= "/ociranalysis/getdetailchart";
    			column = [
		    		{
		    			attributes:{
		    				class: "field-ellipsis"
		    			},
		    			field : "_id.Parentprocessname",
		    			title : "Level 1 Process",
		    			width : 200 
		    		}, 
		    	];
    		break;
    		default:
    			payload.Productfunction = [e.category];
    			url 	= "/ociranalysis/getdetailchart";
    			column = [
		    		{
		    			attributes:{
		    				class: "field-ellipsis"
		    			},
		    			field : "_id.Parentprocessname",
		    			title : "Level 1 Process",
		    			width : 200 
		    		}, 
		    	];
    	}
    	widget.loading.popUpbarModal(true);
    	$modal.modal("show");
    	$grid = $modal.find("#grid");
    	$grid.html('')
    	if(type ==  "Different Types  of Barriers" || type ==  "Barriers to Resolution by Region"  ){
			$grid.kendoGrid({
					dataSource: {
						transport: {
							read:function(option){
								payload.filter 	 = option.data.filter
			                    payload.page 	 = option.data.page
			                    payload.pageSize = option.data.pageSize
			                    payload.skip = option.data.skip
			                    payload.sort = option.data.sort
			                    payload.take = option.data.take
								ajaxPost(url, payload, function(datas){
									option.success(datas);
									widget.loading.popUpbarModal(false);
									setTimeout(function() {
										$grid.find(".k-grid-content").height(250);
									}, 300);
								});
							},
							parameterMap: function(data) {
								return JSON.stringify(data);
							},
						},
						schema: {
			                data: function(data) {      
			                    if (data.Count == 0) {
			                        return [];
			                    } else {
			                        return data.Records;
			                    }   
			                },
			                total: "Count",
			            },
				        pageSize: 10,
			            serverPaging: true,
			            serverSorting: true,
			            serverFiltering: true,
						 
					},
					excel: {
						// fileName: type,
						allPages: true
					},
					columns: column,
					sortable: true,
					// filterable: {
					// 	extra:false, 
					// 	operators: {
					// 		string: {
					// 			contains: "Contains",
					// 			startswith: "Starts with",
					// 			eq: "Is equal to",
					// 			neq: "Is not equal to",
					// 			doesnotcontain: "Does not contain",
					// 			endswith: "Ends with"
					// 		},
					// 	}
					// },
					 pageable: {
			            refresh: true,
			            pageSizes: true,
			            buttonCount: 1,
			            pageSize: 20,
			            pageSizes: [5, 10, 20],
			        },
					height: 250,
	        });	
		}else{
	        $grid.kendoGrid({
				dataSource: {
					transport: {
						read:function(option){

							ajaxPost(url, payload, function(datas){
								widget.loading.popUpbarModal(false);
								option.success(datas);
								setTimeout(function() {
									$grid.find(".k-grid-content").height(250);
								}, 300);
							});
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					} 
				},
				excel: {
					fileName: type,
					allPages: true
				},
				columns: column,
				sortable: true,
				filterable: {
					extra:false, 
					operators: {
						string: {
							contains: "Contains",
							startswith: "Starts with",
							eq: "Is equal to",
							neq: "Is not equal to",
							doesnotcontain: "Does not contain",
							endswith: "Ends with"
						},
					}
				},
				pageable: {
					numeric: false,
					previousNext: false,
					messages: {
						display: "Showing {2} data items"
					}
				},
				height: 250,
	        });
		}
    };  
};
widget.createBarWithLabel =  function(id, page, type, dataSource){
	$id = $("#"+id).find(".content"); 
	console.log(dataSource);
	var max = (dataSource.length == 0) ? 0 : _.max(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var min = (dataSource.length == 0) ? 0 : _.min(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var dataSourceAdditional = [];
		
	if(max == 0 && min == 0)
		dataSource  = [];
 	else
 		_.each(dataSource, function(v){
			var twentyPercent =  (max == 0) ? 0 : max / ( 100/20 );
			dataSourceAdditional.push({_id:null,val:(max + twentyPercent) - v.Count, label:v.Count,label2:v.Value});
		});
 	
 	if(dataSource.length == 1){ 
		$id.css('height', (dataSource.length * 60) + 'px');
    }else if (dataSource.length <= 7){ 
		$id.css('height', (dataSource.length * 52) + 'px'); 
    }else{
		$id.css('height','370px');  
    } 
    console.log($id, type);
    $id.html('');
   	$id.kendoChart({ 
	    legend :{
			position :"top",
			margin:{
				visible:true,
				top:40
			},
			font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif"
	    },
	    transitions: false,
	    seriesDefaults: {
	    	type: "bar",
			stack: {
				type: "100%"
			},
			overlay: {
				gradient: "none"
			},
			gap: 0.5,
			color: "#36BC9B",
		},
	    series: [
		    {
				data:dataSource,
				categoryField: "_id",
	      		field: "Count", 
	      		border: {
	        		width: 1.7,
	        		color: "transparent"
	      		},
		    	color: function(e){
					return "#005C84"
	      		},
	      		labels: {
					font: "8px Helvetica Neue, Helvetica, Arial, sans-serif",
					color: "#fff", 
					visible: function(e){
						switch(type){ 
							case"Comparison Region [% Validated Service]":
							case"Comparison Region [% Confirmed Service]":
								return false;
							break;
							default:
								return true;
						}
					},
					position:"InsideEnd",
					template: function(e){ 
						return "Rank " + e.dataItem.Rank;
						 
					},
					background: "transparent"
				},
			}, 
			{ 
				data: dataSourceAdditional,
				field: "val", 
				color: "#FFFFFF",
		        border: {
		            width: 1.7,
		            color: "transparent"
		        },
				labels: {
					font: "bold 8px Helvetica Neue, Helvetica, Arial, sans-serif",
					color: "#005C84", 
					visible: true,
					position:"InsideEnd",
					template: function(e){
					 
						return e.dataItem.label.toFixed(1) + "%\n"+ e.dataItem.label2.toFixed(1) + "%";
						 
					},//   
					background: "transparent"
				},
			}
		],
	    categoryAxis :{ 
			labels: {
				template: labelTemplate,
				font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
				color: "#000",
				visible: true, 
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
	    valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
	    },  
	    seriesClick: seriesClick,    
	    seriesColors: ["#66DBFF"],
	    render: function(){
			setTimeout(function(){
		        kendo.resize($id);
			},400);
	    }
	}); 
	var isFound = false
    jQuery('#'+id+' .content g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
        if (isFound) return
        if ($(e).html() == '') isFound = true
        $(e).find('text').attr('x', 0)
	});
    function labelTemplate(e) { 
		var finalStm = "";
		var maxlen = 14;
		var Spl = e.value.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
		    lenStm = lenStm + o.length + 1;
		    var tb = "";
		    if (lenStm <= maxlen) {
		        tb = " ";
		    } else {
		        lenStm = o.length;
		        tb = "\n";
		    }
		    if (i == 0) {
		        tb = "";
		    }
		    finalStm = finalStm + tb + o;
		}); 
		return finalStm
    };
    function seriesClick(e){
    	var payload 		= widget.GeneratePayload(getFilterActive(page));
    	var region  		= payload.Region; 
    	var receiverCountry = payload.ReceiverCountry;
    	var categoryName  	= payload.Categoryname;
    	var Productfunction = payload.Productfunction;
    	var Pfpprocessowner	= payload.Pfpprocessowner;
    
    	var Global 			= "";
    	var worstType  		= "";    	
    	var dataItemFlag 	= "";
    	var flagFirst 		= "";    	
    	var flagSecond 		= "";
     	var tabFirstName 	= "";    	
    	var tabSecondName 	= "";
     	console.log(type);
     	switch(type){
    		case"Worst 10 [% Validated]":
				receiverCountry       = [e.category];

				worstType     	= 'validated'
				tabFirstName  	= 'Validated';
				tabSecondName 	= 'Pending Item';
				flagfirst  		= 'validated';
				flagSecond 		= 'pendingvalid';
    		break;
    		case"Worst 10 [% Enriched]":
				receiverCountry       = [e.category];

				worstType 		= 'validated'
				tabFirstName 	= 'Validated';
				tabSecondName 	= 'Pending Item';
				flagfirst 		= 'validated';
				flagSecond 		= 'pendingvalid';  
    		break;
    		case"Worst 10% Validated by Business/Function":
				if (payload.Categoryname.length === 0){
					categoryname = [e.category];
				}else{
					product = [e.category];
				}

				worstType    	= 'businnessvalidated'
				tabFirstName 	= 'Validated';
				tabSecondName 	= 'Pending Item';
				flagfirst 		= 'validated';
				flagSecond 		= 'pendingvalid';
    		break;
    		case"Worst 10% Enriched by Business/Function":
    			if (payload.Categoryname.length === 0){
					categoryname = [e.category];
				}else{
					product = [e.category];
				}

				worstType 		= 'businnessenriched'
				tabFirstName 	= 'Enriched';
				tabSecondName 	= 'Pending Item';
				flagfirst 		= 'Enriched';
				flagSecond 		= 'pendingvalid';
    		break;
    		case"Best 10 [% Validated]":
    			receiverCountry = [e.category];
				
				worstType 		= 'reversevalidated'
				tabFirstName 	= 'Validated';
				tabSecondName 	= 'Pending Item';
				flagfirst  		= 'Validated';
				flagSecond  	= 'pendingvalid';
    		break;
    		case"Best 10 [% Enriched]":
    			receiverCountry = [e.category];
				
				worstType 		= 'reverseenriched'
				tabFirstName 	= 'Enriched';
				tabSecondName 	= 'Pending Item';
				flagfirst     	= 'enriched';
				flagSecond    	= 'pendingenriched';
    		break;
    		
    		case"Pending Best 10 [% Validated]":
    			receiverCountry = [e.category];
				
				worstType 		= 'pendingbestvalidated';
				tabFirstName 	= 'Validated';
				tabSecondName 	= 'Pending Item'; 
				flagfirst 		= 'validated';
				flagSecond 		= 'pendingvalid';
    		break;
    		case"Pending Best 10 [% Enriched]":
    			receiverCountry = [e.category];
				
				worstType 		= 'pendingbestenriched';
				tabFirstName 	= 'Enriched';
				tabSecondName 	= 'Pending Item';	
				flagfirst 		= 'enriched';
				flagSecond 		= 'pendingenriched';
    		break;
    		case"Pending Worst 10 [% Validated]":
    			receiverCountry = [e.category];
				
				worstType 		= 'pendingworstvalidated';
				tabFirstName 	= 'Validated';
				tabSecondName 	= 'Pending Item';
				flagfirst 		= 'validated';
				flagSecond 		= 'pendingvalid';
    		break;
    		case"Pending Worst 10 [% Enriched]":
    			receiverCountry = [e.category];
				
				worstType     	= 'pendingworstenriched'
				tabFirstName 	= 'Enriched';
				tabSecondName 	= 'Pending Item';
				flagfirst 		= 'enriched';
				flagSecond 		= 'pendingenriched';
    		break;

    		case"Worst 10 by Process Owner [% Validated Service]":
				Pfpprocessowner = [e.category];
				worstType 		= 'worstownervalidated'
				tabFirstName 	= 'Validated';
				tabSecondName 	= 'Pending Item';
				flagfirst 		= 'validated';
				flagSecond 		= 'pendingvalid';
    		break;
    		case"Worst 10 by Process Owner [% Confirmed Service]":
				Pfpprocessowner = [e.category];
				worstType 		= 'worstownerenriched';
				tabFirstName 	= 'Enriched';
				tabSecondName 	= 'Pending Item';
				flagfirst 		= 'enriched';
				flagSecond 		= 'pendingenriched';
    		break;
    		case"Best 10 by Process Owner [% Validated Service]":
				Pfpprocessowner = [e.category];
				worstType 		= 'bestownervalidated';
				tabFirstName 	= 'Validated';
				tabSecondName 	= 'Pending Item'; 
				flagfirst 		= 'validated';
				flagSecond 		= 'pendingvalid';
    		break;
    		case"Best 10 by Process Owner [% Confirmed Service]":
				Pfpprocessowner = [e.category];
				worstType 		= 'bestownerenriched';
				tabFirstName 	= 'Enriched';
				tabSecondName 	= 'Pending Item'; 
				flagfirst 		= 'enriched';
				flagSecond 		= 'pendingenriched'; 
    		break;

    		case"Comparison Region [% Validated Service]": 
				if (payload.Region === 0) {
					region = [e.category]
				}else{
					if(e.dataItem.Flag == 'Region'){
						region =  [e.category] 
					}else{ 
						receiverCountry = [e.category]
					}
				}
				if([e.dataItem.Flag] == 'Global'){
					Global = 'Y'; 
				}else{
					Global = 'N'; 
				}


				dataItemFlag 	= e.dataItem.Flag;
				worstType 		= 'comparisonvalidated';
				tabFirstName 	= 'Validated';
				tabSecondName 	= 'Pending Item';
				flagfirst 		= 'validated';
				flagSecond 		= 'pendingvalid';
    		break;
    		case"Comparison Region [% Confirmed Service]":
				if (payload.Region === 0) {
					region = [e.category]
				}else{
					if(e.dataItem.Flag == 'Region'){
						region =  [e.category]
					}else{
						receiverCountry = [e.category]
					}
				}
				
				if([e.dataItem.Flag] == 'Global'){
					Global = 'Y'; 
				}else{
					Global = 'N'; 
				}

				dataItemFlag 	= e.dataItem.Flag;
				worstType 		= 'comparisonenriched' 
				tabFirstName 	= 'Enriched';
				tabSecondName 	= 'Pending Item'; 
				flagfirst 		= 'enriched';
				flagSecond 		= 'pendingenriched';
    		break;	
    	};

		payload.Region          = region;
		payload.ReceiverCountry = receiverCountry;
		payload.Categoryname    = categoryName; 
		payload.Productfunction = Productfunction;
		payload.worstType       = worstType;
		payload.Pfpprocessowner = Pfpprocessowner;
		payload.Global          = Global;
 		
 		ajaxPost("/ociranalysis/popupnewbar",payload , function (res){
 			var dataSource_grid1 = res.tab1; 
 			var dataSource_grid2 = res.pending;
 			
 			$modal = $('#bar-with-label-modal');

 			$modal.find(".nav-pills a").removeData("cache.tabs");
          	$modal.modal('show');
          	$modal.find("#tab-first-name").text(tabFirstName);
          	$modal.find("#tab-second-name").text(tabSecondName);
          	
          	setTimeout(function() {
            	$modal.find(".k-grid-content").height(250);
          	},280);
          	
          	if (tabFirstName == 'Pending Item') {
				$modal.find("#container-tab ul").find('li').removeClass('active')
				$modal.find("#container-tab ul li:eq(0)").addClass('active')
				$modal.find("#container-tab").tabs({active:0});
			}else{
				$modal.find("#container-tab ul").find('li').removeClass('active')
				$modal.find("#container-tab ul li:eq(1)").addClass('active')
				$modal.find("#container-tab").tabs({active:1});
			}

			$grid1 = $modal.find("#grid1");
			$grid2 = $modal.find("#grid2");
			$grid1.css("width", "inherit");
			$grid2.css("width", "inherit");
			
			$grid1.kendoGrid({
				dataSource: {
					transport: {
						read:function(option){ 
							dataSource_grid1.forEach(function (d) {
								d.type 			= type;
								d.Global    	= payload.Global; 
								d.worstType 	= worstType;
								d.receiverCountry = e.category;
							 	d.page 			= page;
								d.flag 			= flagfirst;
								d.flagRegion 	= dataItemFlag;
							});
							option.success(dataSource_grid1); 
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					},
				}, 
				columns: [
					{
						field:"Country",
						title:'PFP Process Name',
						width:100, 
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						},
					},
					{
						field:"Count",
						title:'Total',
						width:50,
						attributes: {
							"class": "field-ellipsis align-right"
						},
						template: "#if(Count !== 0){# <a href=\"\\#\" onclick='widget.popUpDetailbarWithlabel(\"#:page#\", \"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\", \"#:worstType#\",\"#:receiverCountry#\",\"#:flag#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
						headerAttributes: {
							"class": "align-right"
						},
					}
				],
				sortable: true,
				// filterable: {
				// 	extra:false, 
				// 	operators: {
				// 		string: {
				// 			contains: "Contains",
				// 			startswith: "Starts with",
				// 			eq: "Is equal to",
				// 			neq: "Is not equal to",
				// 			doesnotcontain: "Does not contain",
				// 			endswith: "Ends with"
				// 		},
				// 	}
				// },
				pageable: {
					numeric: false,
					previousNext: false,
					messages: {
						display: "Showing {2} data items"
					}
				}, 
				height: 250,
				// resizable:true
			});
			$grid2.kendoGrid({
				dataSource: {
					transport: {
						read:function(option){
							dataSource_grid2.forEach(function (d) {
							d.type 					= type
							d.worstType 		= worstType
							d.receiverCountry 	= e.category 
							d.flag 				= flagSecond
							d.page 				= page;
							d.Global    		= payload.Global
							d.flagRegion 		= dataItemFlag 
							})
							option.success(dataSource_grid2); 
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					},
				}, 
				columns: [
					{
						field:"Country",
						title:'PFP Process Name',
						width:100,
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						},
					},
					{
						field:"Count",
						title:'Total',
						width:50, 
						attributes: {
							"class": "field-ellipsis align-right"
						},
						template: "#if(Count !== 0){# <a href=\"\\#\" onclick='widget.popUpDetailbarWithlabel(\"#:page#\",\"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\", \"#:worstType#\",\"#:receiverCountry#\",\"#:flag#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
						headerAttributes: {
							"class": "align-right"
						},
					}
				],
				sortable: true,
				// filterable: {
				// 	extra:false, 
				// 	operators: {
				// 		string: {
				// 			contains: "Contains",
				// 			startswith: "Starts with",
				// 			eq: "Is equal to",
				// 			neq: "Is not equal to",
				// 			doesnotcontain: "Does not contain",
				// 			endswith: "Ends with"
				// 		},
				// 	}
				// },
				pageable: {
					numeric: false,
					previousNext: false,
					messages: {
						display: "Showing {2} data items"
					}
				}, 
				height: 250,
				// resizable:true
			});
 		});
    };
};
widget.popUpDetailbarWithlabel =  function(page,flagRegion, type, Global, Country, worstType, receivercountry , flagTab){
	$('#bar-with-label-modal').modal('hide');	
	var payload =  widget.GeneratePayload(getFilterActive(page));
		payload.WorstType 	= worstType
		payload.Owner 		= Country
		payload.FlagTab 	= flagTab
		payload.Global 		= '';

	switch(type){
		case"Comparison Region [% Validated Service]":
		case"Comparison Region [% Confirmed Service]":
			payload.Global      = Global 
			
			if(flagRegion == 'Region')
				payload.Region =  [receivercountry];
			else(flagRegion != 'Global')
				payload.ReceiverCountry =  [receivercountry]; 
		break;

		case"Worst 10% Validated by Business/Function":
		case"Worst 10% Enriched by Business/Function":
			payload.Categoryname  = [receivercountry]
		break;

		case"% Validated all Countries":
		case"% Enriched all Countries":
			payload.ReceiverCountry = [receivercountry]
    		payload.FlagTab = flagTab
		break;

		// default:
		// 	payload.ReceiverCountry = [receivercountry]
	}
	$modal = $('#bar-with-label-detail-modal');
  
    $modal.modal('show');

	ajaxPost("/ociranalysis/popupnewbar2",payload , function (res){
    
    	
		console.log(res);
		
		$grid = $modal.find("#grid");
		$grid.html("");
		$grid.kendoGrid({
			dataSource: {
				transport: {
					read:function(option){
						option.success(res);
						// setTimeout(function() {
				  //     		$modal.find(".k-grid-content").height(250);
					 //    },300);
					},
					parameterMap: function(data) {
						return JSON.stringify(data);
					},
				},
			},
			columns: [
				{
					field:"phpowner",
					title:'PFP Owner',
					width:100,
					// filterable: false,
					attributes: {
						"class": "field-ellipsis"
					},
					headerAttributes: {
						"class": "align-left"
					},
				},
				{
					field:"processname",
					title:'Process Name',
					width:100,
					attributes: {
						"class": "field-ellipsis"
					},
					headerAttributes: {
						"class": "align-left"
					},
				},
				{
					field:"status",
					title:'Status',
					width:50,
					attributes: {
						"class": "align-center"
					},
					headerAttributes: {
						"class": "align-center"
					},
				}
			],
			sortable: true,
			filterable: {
				extra:false,
				operators: {
					string: {
						contains: "Contains",
						startswith: "Starts with",
						eq: "Is equal to",
						neq: "Is not equal to",
						doesnotcontain: "Does not contain",
						endswith: "Ends with"
					},
				}
			},
			pageable: {
				numeric: false,
				previousNext: false,
				messages: {
					display: "Showing {2} data items"
				}
			},
			height: 250,
			resizable:true
		});
  })
};
widget.backPopUpBarwithLabelMain  = function(){
	$modal = $('#bar-with-label-modal');
	$modaldetail = $('#bar-with-label-detail-modal');
	
	$modaldetail.modal('hide');
	$modal.modal('show');
};

widget.createFullBar =  function(id, type, dataSource){
	var max = (dataSource.length == 0) ? 0 : _.max(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var min = (dataSource.length == 0) ? 0 : _.min(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var dataSourceAdditional = [];
	
	if(max == 0 && min == 0)
		dataSource = [];
	else{
		_.each(dataSource, function(v){
			var ninePercent =  (max == 0) ? 0 : max / ( 100/9 );
			dataSourceAdditional.push({_id:null,Count:(max + ninePercent) - v.Count, label:v.Count});
		});
	}
	var evantClick = "";
	switch(type){ 
		case "Barriers to Resolution by Business":
		case "Barriers to Resolution by Country": 
			eventClick = seriesClick;
		break;
    }
	$id = $("#"+id).find(".content");
	$id.html('');
  	$id.kendoChart({ 
	    legend :{
			position :"top",
			margin:{
				visible:true,
				top:40
			},
			font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif"
	    },
	    transitions: false,
	    seriesDefaults: {
			stack: {
				type: "100%"
			},
			overlay: {
				gradient: "none"
			},
			gap: 0.5,
			color: "#36BC9B",
		},
	    series: [
		    {
				data:dataSource,
				categoryField: "_id",
	      		field: "Count", 
	      		border: {
	        		width: 1.7,
	        		color: "transparent"
	      		},
		    	color: function(e){
					return "#36BC9B"
	      		},
	      		labels: {
					font: "8px Helvetica Neue, Helvetica, Arial, sans-serif",
					color: "#fff",
					rotation: -90,
					visible: false,
					position:"insideEnd",
					template: function(e){
						
						if(type == "Barriers to Resolution by Business" || type  == "Barriers to Resolution by Country"){
							return e.value.toFixed(0);
						}
						if(e.value === 0){
							return 0;
						}else{
							return e.value.toFixed(1) + "%";
						}
					},
					background: "transparent"
				},
			}, 
			{ 
				data: dataSourceAdditional,
				field: "Count", 
				color: "#F2F2F2",
		        border: {
		            width: 1.7,
		            color: "transparent"
		        },
				labels: {
					font: "bold 8px Helvetica Neue, Helvetica, Arial, sans-serif",
					color: "#00506D",
					rotation: -90,
					visible: true,
					position:"insideEnd",
					template: function(e){
						if(type == "Barriers to Resolution by Business" || type  == "Barriers to Resolution by Country"){
							return e.dataItem.label.toFixed(0);
						}
						if(e.dataItem.label === 0){
							return 0;
						}else{
							return e.dataItem.label.toFixed(1) + "%";
						}
					},//   
					background: "transparent"
				},
			}
		],
	    categoryAxis :{

			labels: {
				font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
				color: "#00506D",
				visible: true,
				mirror: true,
				rotation: -90,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
	    valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
	    },      
	    seriesColors: ["#66DBFF"],
	    seriesClick: seriesClick,
	    render: function(){
			setTimeout(function(){
		        kendo.resize($id);
			},400);
	    }
	});

	function seriesClick(e){
    	$modal = $("#bar-normal-modal");
    	var url 	= "";
    	var payload = widget.GeneratePayload(getFilterActive(widget.page.active() - 1));
    	var column = []; 



    	switch(type){ 
    		case "Barriers to Resolution by Business":
    			url = "/ociranalysis/popupbarrier";
    			column = [
					{
					    field:"receivercountry",
					    title:'Receiver Country',
					    /*filterable: false,*/
					    width:180,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    },
					    template: "#= receivercountry + ' - ' + receiverlegalentity #",
					},
					{
					    field:"suppliercountry",
					    title:'Supplier Country',
					    /*filterable: false,*/
					    width:180,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    },
					    template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
					},
					{
					    field:"categoryname_",
					    title:'Business',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"productfunction",
					    title:'Product',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"parentprocessname",
					    title:'Level 1 Process',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"processname",
					    title:'Level 2 Process',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"servicedescription",
					    title:'Service Description',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"barriertype",
					    title:'Barrier Type',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					}
				]
				payload.Categoryname = [e.category];
    		break;
    		case "Barriers to Resolution by Country": 
    			url = "/ociranalysis/popupbarrier";
    			column = [
					{
					    field:"receivercountry",
					    title:'Receiver Country',
					    /*filterable: false,*/
					    width:180,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    },
					    template: "#= receivercountry + ' - ' + receiverlegalentity #",
					},
					{
					    field:"suppliercountry",
					    title:'Supplier Country',
					    /*filterable: false,*/
					    width:180,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    },
					    template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
					},
					{
					    field:"categoryname_",
					    title:'Business',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"productfunction",
					    title:'Product',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"parentprocessname",
					    title:'Level 1 Process',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"processname",
					    title:'Level 2 Process',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"servicedescription",
					    title:'Service Description',
					    /*filterable: false,*/
					    width:250,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					},
					{
					    field:"barriertype",
					    title:'Barrier Type',
					    /*filterable: false,*/
					    width:130,
					    attributes: {
					        "class": "field-ellipsis"
					    },
					    headerAttributes: {
					        "class": "align-left"
					    }
					}
				]
				
				payload.ReceiverCountry = [e.category];
    		break; 
    	}

		widget.loading.popUpbarModal(true);
    	$modal.modal("show");
    	$grid = $modal.find("#grid");
    	$grid.html('')
        $grid.kendoGrid({
				dataSource: {
					transport: {
						read:function(option){
							payload.filter 	 = option.data.filter
		                    payload.page 	 = option.data.page
		                    payload.pageSize = option.data.pageSize
		                    payload.skip = option.data.skip
		                    payload.sort = option.data.sort
		                    payload.take = option.data.take
							ajaxPost(url, payload, function(datas){
								option.success(datas);
								widget.loading.popUpbarModal(false);
								setTimeout(function() {
									$grid.find(".k-grid-content").height(250);
								}, 300);
							});
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					},
					schema: {
		                data: function(data) {      
		                    if (data.Count == 0) {
		                        return [];
		                    } else {
		                        return data.Records;
		                    }   
		                },
		                total: "Count",
		            },
			        pageSize: 10,
		            serverPaging: true,
		            serverSorting: true,
		            serverFiltering: true,
					 
				},
				excel: {
					// fileName: type,
					allPages: true
				},
				columns: column,
				sortable: true,
				// filterable: {
				// 	extra:false, 
				// 	operators: {
				// 		string: {
				// 			contains: "Contains",
				// 			startswith: "Starts with",
				// 			eq: "Is equal to",
				// 			neq: "Is not equal to",
				// 			doesnotcontain: "Does not contain",
				// 			endswith: "Ends with"
				// 		},
				// 	}
				// },
				 pageable: {
		            refresh: true,
		            pageSizes: true,
		            buttonCount: 1,
		            pageSize: 20,
		            pageSizes: [5, 10, 20],
		        },
				height: 250,
        });	
    };  
};

widget.createStackedBar = function(id, type, series){
    var $id = $("#"+id).find(".content");
    var ds =  series[0].data;
    if(ds == undefined){
    	$id.css('height','370px');  
    }else{
		if(ds.length == 1){ 
			$id.css('height', (ds.length * 60) + 'px');
	    }else if (ds.length <= 7){ 
			$id.css('height', (ds.length * 52) + 'px'); 
	    }else{
			$id.css('height','370px');  
	    }
	}
   

	$id.html('');
    $id.kendoChart({
		legend :{
			position :"bottom",
			font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
		},
		chartArea: { 
			width:331,
		},
		transitions: false,
		seriesDefaults: {
			type: "bar",
			stack:true,
				overlay: {
					gradient: "none"
			},
			gap: 0.5,
			color: "transparent",
		},
		series: series,
		categoryAxis :{ 
			labels: {
				font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
				template: labelTemplate,
				visible: true,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
		valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
		}, 
		seriesColors: ["#66DBFF"],
	});
	function labelTemplate(e) {
		var finalStm = "";
		var maxlen = 14;
		var Spl = e.value.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
			lenStm = lenStm + o.length + 1;
			var tb = "";
			if (lenStm <= maxlen) {
				tb = " ";
			} else {
				lenStm = o.length;
				tb = "\n";
			}
			if (i == 0) {
				tb = "";
			}
			finalStm = finalStm + tb + o;
		});  
		return finalStm  
	}
};
widget.mappingDataStackedBar = function(dataSource){
	console.log(dataSource)
	var results = [];
	var config = {
		internal:
		{ 
			name :"Internal",
			color : "#00506D"
		},
		external:
		{ 
			name :"External",
			color : "#2F7528"
		},
		underreview:
		{ 
			name :"Under Review",
			color : "#939598"
		},
		additional:
		{ 
			name:"Additional",
			color : "#fff"
		},
		hub:
		{ 
			name:"HUB",
			color : "#0075B0"
		},
		inentity:
		{ 
			name:"In-Entity",
			color : "#009FDA"
		},
		gbs:
		{ 
			name:"GBS",
			color : "#3F9C35"
		},
		other:
		{ 
			name:"Other",
			color : "#A6A6A6"
		},
		intra:{
			name :"HUb",
			color : "#0075B0"
		}
	};
	var series = {
		categoryField: "Country",
		field: "Count",
		border: {
			width: 0,
		},  
		tooltip: {
			visible: true,
			template: "#= kendo.toString(value,'N0') #"
		},
	};
	additionalSeries = [];
	var idx = 0;
	var o = _.sortBy(o, "Count").reverse()
	_.each(dataSource, function(o, i){
		if(o.length == 0)
			return;
		if(idx == 0){
			var max =(o.length == 0) ? 0 : _.max(o, function(o){ return o.Value; }).Value;
			var tenPercent =  max + ((10 * max) / 100);
			var ds = [];
			for(var j=0; j<10; j++){
				ds.push({Count:tenPercent - o[j].Value, Country:o[j].Country, Value:o[j].Value})
			}

			additionalSeries = {
				categoryField: "Country",
				field: "Count",
				border: {
					width: 0,
				},
				data 	:ds,
				color 	:"#FFF",
				labels 	:{ 
			        position:"insideEnd ",
	                template: "#= kendo.toString(dataItem.Value,'N0') #",
	                visible: true
				}
			};
		}	 
		var s = _.clone(series);
			s.data = limitResultBar(o,10);
			s.name = config[i].name;
			s.color = config[i].color; 
		results.push(s);
		idx++;
	}); 
	results.push(additionalSeries);
	return results;
};


widget.generateDatavizDonut =  function(page, index){
	$("#opt-donut-modal").modal('hide'); 

	var config = getDataViZActive(page, index);
		config.active(true);
		config.type("donut");
		config.loading(true);

	var payload = widget.GeneratePayload(getTemplateActive(page).filter);
	var filter  = config.filter.value();
	switch(filter){
		case"In-Entity vs Intra-Group":
			ajaxPost("/ociranalysis/getdonutservices", payload , function (res){
				config.loading(false);
				widget.createDonut(config.id,filter, res);
			});
		break;
		case"In-Entity vs Intra-Group FTE":
			ajaxPost("/ociranalysis/getdonutservicesfte", payload , function (res){
				config.loading(false);
				widget.createDonut(config.id, filter, res);
			});
		break;
		case"% of Services by Service Type":
			ajaxPost("/ociranalysis/getdonutl3processes", payload , function (res){
				config.loading(false);
				widget.createDonut(config.id, filter, res);
			});
		break;
	};
};
widget.clickdonutlegendCustom =  function(id, index, color){
	$id = $("#"+id).find(".content").find("#çhart");
	var $chart = $id.getKendoChart();
	 	$chart.options.series[0].data[index].visible = !$chart.options.series[0].data[index].visible;
	 	$chart.redraw();
	var dataTotal = 0
 	_.each($chart.options.series[0].data, function(key, num){ 
 		if(!key.visible)
			return;
		dataTotal += key.value;
 	}); 

	var $legend = $("#"+id).find(".content").find(".donut_legend_custom");
	var colorLegends = $chart.options.series[0].data[index].visible? color :"#9b9898" ;
 	$legend.find(".legend-donut-"+index+"").find(".title").css({"color":colorLegends});
 	$legend.find(".legend-donut-"+index+"").find(".percentage").css({"color":colorLegends}); 
	
	_.each($chart.options.series[0].data, function(key, num){
		if(!key.visible)
			return $(".legend-donut-"+num+"").find(".percentage").text("");
		var percentage = (Math.abs(key.value) == 0) ? 0 : 100 / (dataTotal / key.value); 
		$legend.find(".legend-donut-"+num+"").find(".percentage").text(percentage.toFixed(0)+"%");
		
	})
};
widget.createDonut =  function(id, Type, dataSource){
 	$id = $("#"+id).find(".content");
 	$id.append("<div id='çhart'></div>"); 
 	 
 	 
	var legend = "<table class='donut_legend_custom' width='100%'>"; 
   	_.each(dataSource.Donut, function(o, i){
   		var title = o.category;
   		switch(o.category){
	        case'FMI':
				title = 'FMI'
	        break;
	        case'FMI_System':
				title = 'FMI Systems'
	        break;
	        case'FMI_TPS':
				title = 'FMI External'
	        break;
	        case'Systems':
				title = 'Systems'
	        break;
	        case'IGS':
				title = 'Intra-Group'
	        break;
	        default:
				title = 'In-Entity'
        } 
   		o.color = widget.DonutseriesColors[i];
   		o.visible = true;
   		if(i == 0 || (i % 2) == 0)
   			legend += "</tr><tr>";
   		var percentage = (Math.abs(o.value) == 0) ? 0 : 100 / (dataSource.Total / o.value); 
   		legend +=   "<td width='50%'>"+
   						"<a class='legend-donut-"+i+"' onclick='widget.clickdonutlegendCustom(\""+id+"\",\""+i+"\",\""+o.color+"\")'>"+
							"<span class='pull-left title' style='color:"+o.color+"'><i class='fa fa-square' aria-hidden='true'></i>" +title+ "</span>"+
	   						"<span class='pull-right percentage' style='color:"+o.color+"'>"+percentage.toFixed(0)+"%</span>"+
   						"</a>"
   					"</td>";
   	});

 	legend += "<table>";
 	
 	$id.append(legend); 
 	
 	$chart = $id.find("#çhart");
 	$chart.html('')
    $chart.kendoChart({
        legend: {
            visible:false,
            labels: {
                font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
                template: "#if(dataItem.category==='FMI_Systems'){# #: 'FMI Systems' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'Intra-Group' # #}else if(dataItem.category=='FMI_TPS'){# #: 'FMI External' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='FMI'){# #: 'FMI' # #}else{# #: 'In-Entity' #&nbsp;# # #}# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; #= removeSpace(kendo.toString(percentage,'P0'))# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                color: "#0075B2"
            },
            margin:{
                visible:true,
                left:100,
                top:-30
            },
            position: "bottom",
        },
        seriesDefaults: {
            holeSize: 60,
            labels: {
                visible: false,
                template: "#= removeSpace(kendo.toString(percentage,'P0'))#", 
                background: "transparent"
            }
        }, 
        series: [{
            type: "donut",
            data: dataSource.Donut ,
            overlay:{gradient:"none"},
        }],
        valueAxis:{
            visible:false,
            labels: {
                font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                visible: false,
                format:"{0:P0}",
            },
            majorGridLines: {
                visible: false
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#=kendo.toString(value,'N0')#"
        }
    });
};

widget.generateDatavizGrid  =  function(page, index){
	$("#opt-grid-modal").modal('hide'); 

	var config = getDataViZActive(page, index);
		config.active(true);
		config.type("grid");
		config.loading(true);

	var payload = widget.GeneratePayload(getTemplateActive(page).filter);
	var filter  = config.filter.value();
 	 
	switch(filter){
		case"Products":
			var url = "/ociranalysis/getproductnamecef";
			widget.createGridProduct(config.id, url, payload, config.loading);	
		break;
		case"countrybusinnessvalidated":
		case"countrybusinnessenriched":
			config.loading(false);
   		 	widget.clearDataviz(page, index);
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);      	
			payload.WorstType = filter;
        	var id = "fullDataViz"+page
			widget.createGridFull(id, payload, template.mainpage.fulDataViz);
		break;

		case"countryValidated":
			config.loading(false);
   		 	widget.clearDataviz(page, index);
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);    
        	var id = "fullDataViz"+page;

			payload.Flag = "validated";
			getTemplateActive(page).filter.dailystatus.value(true);
			widget.createGridDailyStatusByCuntry(page, id, payload, config.loading);
		break;
		case"businessvalidated":
			config.loading(false);
   		 	widget.clearDataviz(page, index);
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);  
        	var id = "fullDataViz"+page;

			payload.Flag = "validated";
			getTemplateActive(page).filter.dailystatus.value(true);
			widget.createGridDailyStatusByBusiness(page, id, payload, config.loading);
		break;
		case"countryConfirmed":
			config.loading(false);
   		 	widget.clearDataviz(page, index);
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);  
        	var id = "fullDataViz"+page;

			payload.Flag = "confirmed";
			getTemplateActive(page).filter.dailystatus.value(true);
			widget.createGridDailyStatusByCuntry(page, id, payload, config.loading);
		break;
		case"businessConfirmed":
			config.loading(false);
   		 	widget.clearDataviz(page, index);
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);  
        	var id = "fullDataViz"+page;

			payload.Flag = "confirmed";
			getTemplateActive(page).filter.dailystatus.value(true);
			widget.createGridDailyStatusByBusiness(page, id, payload, config.loading);
		break;
		case"cpoReport":
			config.loading(false);
   		 	widget.clearDataviz(page, index);
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);  
        	var id = "fullDataViz"+page;

			payload.Flag = "confirmed";
			console.log(payload);
			getTemplateActive(page).filter.cpoReport.value(true);
			var newPayload ={
				Region         		:payload.Region,
				ReceiverCountry    	:payload.ReceiverCountry,
	 			ReceiverLegalEntity :payload.ReceiverLegalEntity,
				Categoryname    	:payload.Categoryname,
				GPO             	:payload.GPO,
				Mapping         	:payload.pfpprocessowner,
				L1process 	     	:payload.Parentprocessname,
				Productfunction 	:payload.Productfunction
			};
			widget.createGridCpoReport(page, id, newPayload, config.loading);
		break;
		default:
			payload.WorstType = filter;
			var url = "/ociranalysis/dgmappingteam"; 
			widget.createGridNormal(config.id, url, payload, config.loading);	
	};
};

widget.createGridProduct =  function(id, url, payload, loading){
	var $id = $("#"+id).find(".content"); 
		$id.html('');;
		$id.append("<div class='grid-preview product-grid'></div>");
	payload.Flag = "widget";
	$grid = $id.find(".grid-preview");
	$grid.html('');
	$grid.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					ajaxPost(url, payload, function(datas){
						loading(false);
						option.success(datas);
						widget.createGridNormal_Pdf(id, limitResultGrid(datas,10)); 
						
					});
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data; 
                    } 
                },
			}
		},
		columns:[ 
            {
                field:"_id.productfunction",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"Product Name",
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                template: "<a href=\"\\#\" onclick='widget.popUpGridproduct(\"#:_id.productfunction#\",\"#:_id.receivercountry#\",\"#:_id.subgroupid#\",\"#:_id.cefcritical#\")'>#:_id.categoryname_# - #:_id.productfunction#</a>"
                	
            },
            {
                field:"_id.receivercountry",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"Country",
                width:100,
                attributes: {
                    "class": "field-ellipsis"
                },
            },
            {
                field:"_id.cefcritical",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"CEF?",
                width:70,
                attributes: {
                    "class": "field-ellipsis"
                },
                template: "#if(_id.cefcritical=='Y'){# #: 'Yes' # #}else{# #: 'No' # #}#",
            },
        ],
		sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        columnMenu: true,
        height: 400,
	});
};
widget.createGridProduct_Pdf = function(id, dataSource){
	var $id = $("#"+id).find(".content");  
	$id.append("<div class='grid-pdf product-grid'></div>");
	$grid = $id.find(".grid-pdf");
	$grid.html('');
	$grid.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){ 
					option.success(dataSource); 
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data; 
                    } 
                },
			}
		},
		columns:[ 
            {
                field:"_id.productfunction",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"Product Name",
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                template: "#:_id.productfunction#"
                	
            },
            {
                field:"_id.receivercountry",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"Country",
                width:100,
                attributes: {
                    "class": "field-ellipsis"
                },
            },
            {
                field:"_id.cefcritical",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"CEF?",
                width:70,
                attributes: {
                    "class": "field-ellipsis"
                },
                template: "#if(_id.cefcritical=='Y'){# #: 'Yes' # #}else{# #: 'No' # #}#",
            },
        ],
		sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        height: 400,
	});
};
widget.popUpGridproduct =  function(name, receivercountry, subgroupid, cefcritical){
	widget.modalGridProduct()
	var $modal = $("#grid-product-modal");
	$modal.modal("show");
	var url = "/ociranalysis/getproductnamecefdetail";
	var payload = {
        productfunction: name,
        receivercountry: receivercountry,
        subgroupid: subgroupid,
    };
    if (cefcritical == "Y")
		cefcritical = "CEF";
    else 
		cefcritical = "Non-CEF";

	ajaxPost(url, payload, function (res){
	
		if (res.assets == undefined) {
			swal("", "Data CEF Not Found", "error")
		}else{
			res.alternativeproviders = kendo.toString(res.alternativeproviders,'n0');
			res.customeraccounts = kendo.toString( res.customeraccounts, 'n0');
			res.customerscounterparties = kendo.toString( res.customerscounterparties, 'n0');
			
			res.assets = kendo.toString( res.assets, 'n0');
			res.committedfacilities = kendo.toString( res.committedfacilities, 'n0');
			res.liabilities = kendo.toString( res.liabilities, 'n0');
			
			res.nonretailfunctions = kendo.toString( res.nonretailfunctions, 'n0');
			res.notionaloutstandingbookinglocation = kendo.toString( res.notionaloutstandingbookinglocation, 'n0');
			res.retailfunctions = kendo.toString( res.retailfunctions, 'n0');

			res.tradevalue = kendo.toString( res.tradevalue, 'n0');
			res.tradevolume = kendo.toString( res.tradevolume, 'n0');

			widget.modalGridProduct(res) 

			$modal.find("#productNameModal").modal("show");
			if ( cefcritical == "Non-CEF"){
				$modal.find("#statusCefcritical").css("color","red")
			}
			$modal.find("#statusCefcritical").text(cefcritical)
			$modal.find(".receivercountry").text(res.receivercountry);
			$modal.find(".receiverlegalentity").text(res.receiverlegalentity);
			$modal.find(".projectName").text(res.categoryname + " - " + name);
		};
	});        
};

widget.createGridNormal = function(id, url, payload, loading){
	var $id = $("#"+id).find(".content"); 
		$id.html('');
	$id.append("<div class='grid-preview normal-grid'></div>");
	$grid = $id.find(".grid-preview");
	$grid.html('');
	$grid.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					ajaxPost(url, payload, function(datas){
						loading(false); 
						widget.createGridNormal_Pdf(id, limitResultGrid(datas,10)); 
						option.success(datas);
					});
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data; 
                    } 
                },
			}
		},
		columns:[ 
			{
				field:"Rank",
				headerAttributes: {
					"class": "align-left"
				},
				title:"Rank",
				width:75,
				attributes: {
					"class": "field-ellipsis rank"
				},
			},
			{
				field:"Country",
				headerAttributes: {
					"class": "align-left"
				},
				title:"Country",
				width:130,
				attributes: {
					"class": "field-ellipsis"
				},
			// template: "#if(oa.popupvalue()==true){# <a href=\"\\#\" onclick='oa.showDetailProductNameCEF(\"#:_id.productfunction#\",\"#:_id.receivercountry#\",\"#:_id.subgroupid#\",\"#:_id.cefcritical#\")'>#:_id.productfunction#</a> #}else{# #: _id.productfunction # #}#"
			},
			{
				field:"Count",
				headerAttributes: {
					"class": "align-left"
				},
				title:"% Validated",
				width:105,
				attributes: {
					"class": "field-ellipsis"
				},
			}, 			
		],
		sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        height: 400,
	});
};
widget.createGridNormal_Pdf = function(id, dataSource){
	var $id = $("#"+id).find(".content");  
	$id.append("<div class='grid-pdf product-grid'></div>");
	$grid = $id.find(".grid-pdf");
	$grid.html('');
	$grid.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){ 
					option.success(dataSource); 
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data; 
                    } 
                },
			}
		},
		columns:[ 
			{
				field:"Rank",
				headerAttributes: {
					"class": "align-left"
				},
				title:"Rank",
				width:75,
				attributes: {
					"class": "field-ellipsis rank"
				},
			},
			{
				field:"Country",
				headerAttributes: {
					"class": "align-left"
				},
				title:"Country",
				width:130,
				attributes: {
					"class": "field-ellipsis"
				},
			// template: "#if(oa.popupvalue()==true){# <a href=\"\\#\" onclick='oa.showDetailProductNameCEF(\"#:_id.productfunction#\",\"#:_id.receivercountry#\",\"#:_id.subgroupid#\",\"#:_id.cefcritical#\")'>#:_id.productfunction#</a> #}else{# #: _id.productfunction # #}#"
			},
			{
				field:"Count",
				headerAttributes: {
					"class": "align-left"
				},
				title:"% Validated",
				width:105,
				attributes: {
					"class": "field-ellipsis"
				},
			}, 			
		],
		sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        height: 400,
	});
};

widget.createGridFull =  function(id, payload, loading){
	ajaxPost("/ociranalysis/dgvalidatedcountryfield", payload, function(res){
		var columns = res.Data.Records;
		console.log(columns);
		var $id = $("#"+id).find(".content");
			$id.html('');
			$id.append("<div class='grid-preview full-grid'></div>");
		var $grid = $id.find(".grid-preview");
		$grid.html(""); 
		$grid.kendoGrid({
			dataSource: {
				transport: {
					read:function(option){ 
						ajaxPost("/ociranalysis/dgvalidatedcountry", payload, function(datas){ 
							widget.createGridFull_pdf(id, limitResultGrid(datas.Data.Records,10), columns); 
							option.success(datas.Data.Records);
						}); 
					},
					parameterMap: function(data) {
						return JSON.stringify(data);
					},
				},
				schema: {
					data: function(data) {
						console.log(data);
	                    if (data.length == 0) {
	                        return [];
	                    } else {
	                        return data; 
	                    } 
	                },
				}
			},
			columns:columns,
			sortable: true,
	        // filterable: {
	        //     extra:false, 
	        //     operators: {
	        //         string: {
	        //             contains: "Contains",
	        //             startswith: "Starts with",
	        //             eq: "Is equal to",
	        //             neq: "Is not equal to",
	        //             doesnotcontain: "Does not contain",
	        //             endswith: "Ends with"
	        //         },
	        //     }
	        // },
	        height: 400,
		});
	});
};
widget.createGridFull_pdf = function(id, dataSource, columns){
	var $id = $("#"+id).find(".content"); 
		$id.append("<div class='grid-pdf full-grid'></div>");
	var $grid = $id.find(".grid-pdf");
	$grid.html(""); 
	$grid.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){ 
					option.success(dataSource); 
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data; 
                    } 
                },
			}
		},
		columns:columns,
		sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        height: 400,
	});
}
widget.creatGridDailyStatus =  function(id, url, payload, loading){
};

widget.createGridDailyStatusByCuntry =  function(page, id, payload, loading){
	ajaxPost("/dailystats/reportdailystatscountrysek", payload, function(res){
 		loading(false);
		
		var $id = $("#"+id).find(".content");
			$id.html("");
			$id.append("<div class='grid-preview dailystatus-view dailystatus-grid' ></div>");
		var $sel = $id.find(".grid-preview");  
		if (payload.Flag == 'validated') {
			var Theader = [
	 			"<thead>",
	 				"<tr class='tbl-header'>",
		 				"<td colspan='2'>Static</td>",
		 				"<td colspan='3'>All</td>",
		 				"<td colspan='3'>Teams</td>",
		 				"<td colspan='3'>Systems</td>",
		 				"<td colspan='3'>Vendors</td>",
		 				"<td colspan='3'>FMIs</td>",
		 				"<td colspan='2'>Total</td>",
	 				"<tr>",
	 				"<tr class='tbl-header'>",
	 					//Static
		 				"<td>Region</td>",
		 				"<td>T1 Country</td>",
		 				//ALL
		 				"<td>#</td>",
		 				"<td>#<br/>Mapped</td>",
		 				"<td>%<br/>Mapped</td>",
	 					//Teams
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
	 					//Systems
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
	 					//Vendor
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
	 					//FMIs
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
		 				 //total
		 				"<td>%<br/>Validated</td>",
		 				"<td>RAG</td>",
	 				"<tr>",
	 			"</thead>",
	 		].join(" "); 
		}else{
			var Theader = [
	 			"<thead>",
	 				"<tr class='tbl-header'>",
		 				"<td colspan='2'>Static</td>",
		 				"<td colspan='3'>All</td>",
		 				"<td colspan='3'>Teams</td>",
		 				"<td colspan='3'>Systems</td>",
		 				"<td colspan='3'>Vendors</td>",
		 				"<td colspan='3'>FMIs</td>",
		 				"<td colspan='2'>Total</td>",
	 				"<tr>",
	 				"<tr class='tbl-header'>",
	 					//Static
		 				"<td>Region</td>",
		 				"<td>T1 Country</td>",
		 				//ALL
		 				"<td>#</td>",
		 				"<td>#<br/>Mapped</td>",
		 				"<td>%<br/>Mapped</td>",
	 					//Teams
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Confirmed</td>",
		 				"<td>%<br/>Confirmed</td>",
	 					//Systems
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Confirmed</td>",
		 				"<td>%<br/>Confirmed</td>",
	 					//Vendor
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Confirmed</td>",
		 				"<td>%<br/>Confirmed</td>",
	 					//FMIs
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Confirmed</td>",
		 				"<td>%<br/>Confirmed</td>",
		 				 //total
		 				"<td>%<br/>Confirmed</td>",
		 				"<td>RAG</td>",
	 				"<tr>",
	 			"</thead>",
	 		].join(" "); 
		}
		var Tbody = [];
		_.each(res.Data, function(o){
			
			Tbody.push("<tr class='none'><td  colspan='22'>&nbsp;</td></tr>")
			var rowspan = o.detail.length;
			Tbody.push("<tr ><td style='border-left: 1px solid #000!important;' class='region' rowspan='"+rowspan+"'>"+o.Label+"</td>");
			_.each(o.detail, function(v,index){
		 
				if(index > 0){
					// Tbody.push("<tr style='border-top: 2px solid #000;border-bottom: 2px solid #000;'>");
				}

				Tbody.push("<td class='main' align='left'>"+v.Label+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");
				
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");
				
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");
				
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");
		
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");
			
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
				Tbody.push("<td class='main "+v.RAG+"' style='border-right: 1px solid #000!important;'>&nbsp;</td>"); 
				Tbody.push("</tr>");
			}); 
		}); 
		$sel.append("<table width='100%'>"+Theader+Tbody.join(" ")+"<table>");
		widget.createGridDailyStatusByCuntry_pdf(id,res.Data ,payload.Flag);
	});
};
function mappingData(dataSource){
	console.log(dataSource);
	var results = [];
	var counter = 0;
	var newDs = [];
	var ds    = {label:"",detail:[]};
	var counter = 0;
	var page = 15
	for(var i in dataSource){
		var o = dataSource[i];
		for(var n in o.detail){
			counter+=1;
			var v = o.detail[n]
			ds.detail.push(v)
			if(n == (o.detail.length-1)){
				ds.Label = o.Label;
				newDs.push(ds); 
				ds = {label:"",detail:[]};
			}
			if(counter == page){
				ds.Label = o.Label;
				newDs.push(ds); 
				counter=0;
				ds = {label:"",detail:[]};
			}
		}
	}
	console.log(newDs);
	return newDs;
};
widget.createGridDailyStatusByCuntry_pdf =  function(id, dataSource,Flag){
	var newDs = mappingData(dataSource);
	var $id = $("#"+id).find(".content");
   		$id.append("<div class='grid-pdf'></div>");
    $sel = $id.find(".grid-pdf")
    var Theader = [
      "<thead>",
        "<tr class='tbl-header'>",
          "<td colspan='2'>Static</td>",
          "<td colspan='3'>All</td>",
          "<td colspan='3'>Teams</td>",
          "<td colspan='3'>Systems</td>",
          "<td colspan='3'>FMIs</td>",
          "<td colspan='3'>TPS</td>",
          "<td colspan='2'>Total</td>",
        "<tr>",
        "<tr class='tbl-header'>",
          //Static
          "<td>Region</td>",
          "<td>T1 Country</td>",
          //ALL
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          
          //Teams
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          
          //Systems
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          
          //FMIs
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          
          //TPS
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
           
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          "<td>RAG</td>",
        "<tr>",
      "</thead>",
    ].join(" "); 
    var Tbody = [];
    var columnAtas = 0
    var counter = 0;
    var pageTbl = 0;
    $.each(newDs, function(i,o){
   
		Tbody.push([]);
		Tbody[pageTbl].push("<tr class='none'><td  colspan='22'>&nbsp;</td></tr>")    
		var rowspan = o.detail.length; 
		Tbody[pageTbl].push("<tr ><td style='border-left: 1px solid #000!important;' class='region' rowspan='"+rowspan+"'>"+o.Label+"</td>");
		 
		$.each(o.detail, function(index,v){
			counter +=1;

			if(index > 0){
				Tbody[pageTbl].push("<tr style='border-top: 1px solid #000;border-bottom: 1px solid #000;'>");
			}
			Tbody[pageTbl].push("<td class='main' align='left'>"+v.Label+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
			Tbody[pageTbl].push("<td class='main "+v.RAG+"' style='border-right: 1px solid #000!important;'>&nbsp;</td>"); 
			Tbody[pageTbl].push("</tr>");

		}); 
		if(counter == 15 || i == (newDs.length - 1)){
			if(counter > 0){
				$sel.append("<div class='dailystatus-grid'><table  class='dailystatus-grid'id='table-dailystatus"+pageTbl+"' style='margin-top:40px;' width='100%'>"+Theader+Tbody[pageTbl].join(" ")+"<table></div>");
			} else{
			  $sel.append("<div class='dailystatus-grid'><table  class='dailystatus-grid' id='table-dailystatus"+pageTbl+"' width='100%'>" + Theader + Tbody[pageTbl].join(" ") + "<table></div>");
			} 

			if(i != newDs.length - 1){
			    $sel.append("<div class='page-break'></div>")
			}else{
			    var marginTop = 670 - $('#table-dailystatus'+pageTbl).height();  
			    // $(".date-pdf").css({"margin-top":marginTop});
			}
			counter = 0;
			pageTbl +=1;
		}  
    });
};
widget.createGridDailyStatusByBusiness =  function(page, id, payload, loading){
	ajaxPost("/dailystats/reportdailystatssek", payload, function(res){ 
		loading(false);
		var $id = $("#"+id).find(".content");
			$id.html("");
			$id.append("<div class='grid-preview dailystatus-view dailystatus-grid' ></div>");
		var $sel = $id.find(".grid-preview"); 
		if (payload.Flag  == 'validated') {
			var Theader = [
	 			"<thead>",
	 				"<tr class='tbl-header'>",
		 				"<td>Static</td>",
						"<td colspan='3'>All</td>",
						"<td colspan='3'>Teams</td>",
						"<td colspan='3'>Systems</td>",
						"<td colspan='3'>Vendors</td>",
			 			"<td colspan='3'>FMIs</td>",
						"<td colspan='2'>Total</td>",
	 				"<tr>",
	 				"<tr class='tbl-header'>",
	 					"<td>Business/Function</td>",
						"<td>#</td>",
		 				"<td>#<br/>Mapped</td>",
		 				"<td>%<br/>Mapped</td>",
						"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
						"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
						"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
						"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
						"<td>%<br/>Validated</td>",
						"<td>RAG</td>",
	 				"<tr>",
	 			"</thead>",
	 		].join(" ");
	 	}else{
	 		var Theader = [
	 			"<thead>",
	 				"<tr class='tbl-header'>",
		 				"<td>Static</td>",
						"<td colspan='3'>All</td>",
						"<td colspan='3'>Teams</td>",
						"<td colspan='3'>Systems</td>",
						"<td colspan='3'>Vendors</td>",
			 			"<td colspan='3'>FMIs</td>",
						"<td colspan='2'>Total</td>",
	 				"<tr>",
	 				"<tr class='tbl-header'>",
	 					"<td>Business/Function</td>",
						"<td>#</td>",
		 				"<td>#<br/>Mapped</td>",
		 				"<td>%<br/>Mapped</td>",
						"<td>#<br/>Mapped</td>",
						"<td>#<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>#<br/>Mapped</td>",
						"<td>#<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>#<br/>Mapped</td>",
						"<td>#<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>#<br/>Mapped</td>",
						"<td>#<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>RAG</td>",
	 				"<tr>",
	 			"</thead>",
	 		].join(" ");
	 	};
 		var Tbody = [];
		_.each(res.Data, function(v){
			var lastdata = res.Data.length - 1; 
			if (v.Label.indexOf("Total") > -1) {
				Tbody.push("<tr class=''><td  colspan='22'>&nbsp;</td></tr>")
			};
			Tbody.push("<tr>");
			Tbody.push("<td class='region' align='left'>"+v.Label+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");
			
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");
			
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");
			
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");
	
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");
		
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
			Tbody.push("<td class='main "+v.RAG+"' style='border-right: 1px solid #000!important;'>&nbsp;</td>"); 
			Tbody.push("</tr>");
		});
		$sel.append("<div class='grid-preview dailystatus-grid dailystatus-view'><table width='100%'>"+Theader+Tbody.join(" ")+"<table></div>");
		widget.createGridDailyStatusByBusiness_pdf(id, res.Data, payload.Flag);
	
	});
};
widget.createGridDailyStatusByBusiness_pdf =  function(id, dataSource,Flag){ 
	 
	var $id = $("#"+id).find(".content");
   		$id.append("<div class='grid-pdf'></div>");
    $sel = $id.find(".grid-pdf")
	var Theader = [
		"<thead>",
		"<tr class='tbl-header'>",
		"<td>Static</td>",
		"<td colspan='3'>All</td>",
		"<td colspan='3'>Teams</td>",
		"<td colspan='3'>Systems</td>",
		"<td colspan='3'>FMIs</td>",
		"<td colspan='3'>TPS</td>",
		"<td colspan='2'>Total</td>",
		"<tr>",
		"<tr class='tbl-header'>",
		"<td>Business/Function</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>RAG</td>",
		"<tr>",
		"</thead>",
	].join(" "); 
	var Tbody = []; 


	var tblIndex = 0;
	var counter = 0
	for(var i in dataSource){ 
		var v  = dataSource[i];

		Tbody.push("<tr>");
		Tbody.push("<td class='region' align='left'>"+v.Label+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");

		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");

		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");

		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");

		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");

		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
		Tbody.push("<td class='main "+v.RAG+"' style='border-right: 1px solid #000!important;'>&nbsp;</td>"); 

		Tbody.push("</tr>");

		counter += 1;
		if(counter == 15 || i == (dataSource.length - 1)){
			tblIndex += 1;
			counter = 0;

			if(tblIndex > 1){
				$sel.append("<div class='dailystatus-grid'><table    id='table-dailystatus"+tblIndex+"' style='margin-top:40px;' width='100%'>"+Theader+Tbody.join(" ")+"<table></div>");
			}else{
				$sel.append("<div class='dailystatus-grid'><table    id='table-dailystatus"+tblIndex+"' width='100%'>"+Theader+Tbody.join(" ")+"<table></div>");  
			}
			if(i != (dataSource.length - 1)){
				$sel.append("<div class='page-break'></div>"); 
			}
			Tbody = [];
		}
	}
};
widget.createGridCpoReport = function(page, id, payload, loading){
 
		var $id = $("#"+id).find(".content"); 
	 
		$id.append("<div class='cpoReport-grid'></div>");
		$grid = $id.find('.cpoReport-grid'); 
		$grid.kendoGrid({
		        dataSource: {
		            transport: {
		               read:function(options){
		                    payload.Skip = options.data.skip
		                    payload.Take = options.data.take
		                    ajaxPost("/cpo/statusdefault", payload, function(datas){
		         
		                        options.success(datas); 
							 
		                    })
		                }, 
		            },
		            schema: {
		                data: function(data) {      
		                    if (data.Data.length == 0) {
		                        return dataSource;
		                    } else {
		                        return data.Data;
		                    }   
		                },
		                total: "Total",
		            },
		            pageSize: 10,
		            serverPaging: true,
		            serverSorting: true,
		            serverFiltering: true, 
		            
		        },
		        columns: [
			        {
						field:"country",
						title:'Country',
						width:200,
						attributes: {
							"class": "field-ellipsis blue-background"
						},
						headerAttributes: {
							"class": "align-left cpoReport-header-left"
						},
					},{
						field:"gpo",
						title:'CPO',
						width:200,
						attributes: {
							"class": "field-ellipsis align-left blue-background"
						},
						headerAttributes: {
							"class": "align-left cpoReport-header-left"
						},
					},{
						field:"mapping",
						title:'Mapper',
						width:200,
						attributes: {
							"class": "field-ellipsis align-left blue-background"
						},
						headerAttributes: {
							"class": "align-left cpoReport-header-left"
						},
					},{
						field:"l1_process",
						title:'L1 Process',
						width:200,
						attributes: {
							"class": "field-ellipsis align-left blue-background"
						},
						headerAttributes: {
							"class": "align-left cpoReport-header-left"
						},
					},{
						field:"business_function",
						title:'Business Function',
						width:200,
						attributes: {
							"class": "field-ellipsis align-left blue-background"
						},
						headerAttributes: {
							"class": "align-left cpoReport-header-left"
						},
					},
			 
			  		{
						title: "Mapped",
						headerAttributes: {
							class: "grid-header col-parent"
						},
						columns: [
							{
								field: "mapped.teams",
								title: "Teams",	
								width: 80,
								attributes: {
				                	class:"col-parent align-right",
				            	},
				          	},  
				    		{
								field: "mapped.system",
								title: "Systems",	
								width: 120,
								attributes: {
				                	class:"col-parent align-right",
				            	},   
				          	},
				          	{
								field: "mapped.vendor",
								title: "Vendor",	
								width: 120,
								attributes: {
				                	class:"col-parent align-right",
				            	}, 
				          	},
				          	{
								field: "mapped.fmi",
								title: "FMI",	
								width: 120,
								attributes: {
				                	class:"col-parent align-right",
				            	},
				          	},  
			    		]
			  		},
			  		{
						title: "Validated",
						headerAttributes: {
							class: "grid-header col-parent"
						},
						columns: [
							{
								field: "validated.teams",
								title: "Teams",	
								width: 80,
								attributes: {
				                	class:"col-parent align-right",
				            	},
				          	},  
				    		{
								field: "validated.system",
								title: "Systems",	
								width: 120,
								attributes: {
				                	class:"col-parent align-right",
				            	},   
				          	},
				          	{
								field: "validated.vendor",
								title: "Vendor",	
								width: 120,
								attributes: {
				                	class:"col-parent align-right",
				            	}, 
				          	},
				          	{
								field: "validated.fmi",
								title: "FMI",	
								width: 120,
								attributes: {
				                	class:"col-parent align-right",
				            	},
				          	},  
			    		]
			  		},
			  		{
						title: "Confirmed",
						headerAttributes: {
							class: "grid-header col-parent"
						},
						columns: [
							{
								field: "confirmed.teams",
								title: "Teams",	
								width: 80,
								attributes: {
				                	class:"col-parent align-right",
				            	},
				          	},  
				    		{
								field: "confirmed.system",
								title: "Systems",	
								width: 120,
								attributes: {
				                	class:"col-parent align-right",
				            	},   
				          	},
				          	{
								field: "confirmed.vendor",
								title: "Vendor",	
								width: 120,
								attributes: {
				                	class:"col-parent align-right",
				            	}, 
				          	},
				          	{
								field: "confirmed.fmi",
								title: "FMI",	
								width: 120,
								attributes: {
				                	class:"col-parent align-right",
				            	},
				          	},  
			    		]
			  		}
		  		],
 
		        excel: { 
		            allPages: true
		        },
		        sortable: true,
		        pageable: {
		            refresh: true,
		            pageSizes: true,
		            buttonCount: 1,
		            pageSize: 20,
		            pageSizes: [5, 10, 20],
		        }, 
		        height: 500,
		});
};
// widget.createGridCpoReport_pdf =  function(id, dataSource){
// 	console.log(dataSource);
// 	var $id = $("#"+id).find(".content"); 
// 		$id.append("<div class='grid-pdf cpoReport-grid'></div>");
// 		$grid = $id.find('.grid-pdf'); 
// 		$grid.kendoGrid({
// 		        dataSource: {
// 		            transport: {
// 		               read:function(options){
// 		                   options.success(dataSource); 
// 		                }, 
// 		            },
// 		            schema: {
// 		                data: function(data) {      
// 		                    if (data.length == 0) {
// 		                        return dataSource;
// 		                    } else {
// 		                        return data;
// 		                    }   
// 		                },
// 		                total: 10,
// 		            },
// 		            pageSize: 10, 
// 		            serverSorting: true,
// 		            serverFiltering: true, 
		            
// 		        },
// 		        columns: [
// 			        {
// 						field:"country",
// 						title:'Country',
// 						width:200,
// 						attributes: {
// 							"class": "field-ellipsis blue-background"
// 						},
// 						headerAttributes: {
// 							"class": "align-left cpoReport-header-left"
// 						},
// 					},{
// 						field:"gpo",
// 						title:'GPO',
// 						width:200,
// 						attributes: {
// 							"class": "field-ellipsis align-left blue-background"
// 						},
// 						headerAttributes: {
// 							"class": "align-left cpoReport-header-left"
// 						},
// 					},{
// 						field:"mapping",
// 						title:'Mapping',
// 						width:200,
// 						attributes: {
// 							"class": "field-ellipsis align-left blue-background"
// 						},
// 						headerAttributes: {
// 							"class": "align-left cpoReport-header-left"
// 						},
// 					},{
// 						field:"l1_process",
// 						title:'L1 Process',
// 						width:200,
// 						attributes: {
// 							"class": "field-ellipsis align-left blue-background"
// 						},
// 						headerAttributes: {
// 							"class": "align-left cpoReport-header-left"
// 						},
// 					},{
// 						field:"business_function",
// 						title:'Business Function',
// 						width:200,
// 						attributes: {
// 							"class": "field-ellipsis align-left blue-background"
// 						},
// 						headerAttributes: {
// 							"class": "align-left cpoReport-header-left"
// 						},
// 					},
			 
// 			  		{
// 						title: "Mapped",
// 						headerAttributes: {
// 							class: "grid-header col-parent"
// 						},
// 						columns: [
// 							{
// 								field: "mapped.teams",
// 								title: "Teams",	
// 								width: 80,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	},
// 				          	},  
// 				    		{
// 								field: "mapped.system",
// 								title: "System",	
// 								width: 120,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	},   
// 				          	},
// 				          	{
// 								field: "mapped.vendor",
// 								title: "Vendor",	
// 								width: 120,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	}, 
// 				          	},
// 				          	{
// 								field: "mapped.fmi",
// 								title: "FMI",	
// 								width: 120,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	},
// 				          	},  
// 			    		]
// 			  		},
// 			  		{
// 						title: "Validated",
// 						headerAttributes: {
// 							class: "grid-header col-parent"
// 						},
// 						columns: [
// 							{
// 								field: "validated.teams",
// 								title: "Teams",	
// 								width: 80,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	},
// 				          	},  
// 				    		{
// 								field: "validated.system",
// 								title: "System",	
// 								width: 120,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	},   
// 				          	},
// 				          	{
// 								field: "validated.vendor",
// 								title: "Vendor",	
// 								width: 120,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	}, 
// 				          	},
// 				          	{
// 								field: "validated.fmi",
// 								title: "FMI",	
// 								width: 120,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	},
// 				          	},  
// 			    		]
// 			  		},
// 			  		{
// 						title: "Confirmed",
// 						headerAttributes: {
// 							class: "grid-header col-parent"
// 						},
// 						columns: [
// 							{
// 								field: "confirmed.teams",
// 								title: "Teams",	
// 								width: 80,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	},
// 				          	},  
// 				    		{
// 								field: "confirmed.system",
// 								title: "System",	
// 								width: 120,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	},   
// 				          	},
// 				          	{
// 								field: "confirmed.vendor",
// 								title: "Vendor",	
// 								width: 120,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	}, 
// 				          	},
// 				          	{
// 								field: "confirmed.fmi",
// 								title: "FMI",	
// 								width: 120,
// 								attributes: {
// 				                	class:"col-parent align-right",
// 				            	},
// 				          	},  
// 			    		]
// 			  		}
// 		  		],
 
// 		        excel: { 
// 		            allPages: true
// 		        },
// 		        sortable: true,
// 		        pageable: {
// 		            refresh: true,
// 		            pageSizes: true,
// 		            buttonCount: 1,
// 		            pageSize: 20,
// 		        }, 
// 		        height: 350,
// 		});
// };


widget.OpenPopUpOptionsDataViz 	= function(type, page,index){
 	widget.active.page(page)
	widget.active.index(index)
	switch(type.toLowerCase()){
		case"bar":
			$("#inputsearchBar").kendoAutoComplete({ 
				dataSource 	: _.pluck(widget.popUpOptionsBar.data(), 'text'),
		        filter 		: "contains",
		        placeholder : "Search",
		    }); 
			$("#opt-bar-modal").modal('show'); 
		break;
		case"donut":
			 $("#opt-donut-modal").modal('show'); 
		break;
		case"grid":
			 $("#opt-grid-modal").modal('show'); 
		break;
	}
};
widget.OpenPopUpOptionsSummary  = function(page, index){
	widget.active.page(page);
	widget.active.index(index);
	$("#inputsearchSummary").kendoAutoComplete({
        dataSource 	: _.pluck(widget.popUpOptionsSummary.data(), 'text'),
        filter 		: "contains",
        placeholder : "Search",
    });
	$("#opt-summary-modal").modal('show'); 
};
widget.checkFilterDailyStatus = function(page, index){
	if(getFilterActive(page).dailystatus.value())
		return getFilterActive(page).dailystatus.value(false);
	else 
		return;
};
widget.checkFilterCpoReport = function(page, index){
	if(getFilterActive(page).cpoReport.value())
		return getFilterActive(page).cpoReport.value(false);
	else 
		return;
};


widget.createGridDailyStatusCuntry =  function(type, payload, page, index, onchangStatus){
 	ajaxPost("/dailystats/reportdailystatscountrysek", payload, function(res){
 		wg.charts[page][index].value = res.Data; 
        wg.charts[page][index].status = true;
 
		$sel = $("#full-chart-" + page);
		$sel.addClass("fullgrid dailystatus-grid");
		$sel.html("");
		if (payload.Flag == 'validated') {
			var Theader = [
	 			"<thead>",
	 				"<tr class='tbl-header'>",
		 				"<td colspan='2'>Static</td>",
		 				"<td colspan='3'>All</td>",
		 				"<td colspan='3'>Teams</td>",
		 				"<td colspan='3'>Systems</td>",
		 				"<td colspan='3'>Vendors</td>",
		 				"<td colspan='3'>FMIs</td>",
		 				"<td colspan='2'>Total</td>",
	 				"<tr>",
	 				"<tr class='tbl-header'>",
	 					//Static
		 				"<td>Region</td>",
		 				"<td>T1 Country</td>",
		 				//ALL
		 				"<td>#</td>",
		 				"<td>#<br/>Mapped</td>",
		 				"<td>%<br/>Mapped</td>",
	 					//Teams
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
	 					//Systems
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
	 					//Vendor
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
	 					//FMIs
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
		 				 //total
		 				"<td>%<br/>Validated</td>",
		 				"<td>RAG</td>",
	 				"<tr>",
	 			"</thead>",
	 		].join(" "); 
		}else{
			var Theader = [
	 			"<thead>",
	 				"<tr class='tbl-header'>",
		 				"<td colspan='2'>Static</td>",
		 				"<td colspan='3'>All</td>",
		 				"<td colspan='3'>Teams</td>",
		 				"<td colspan='3'>Systems</td>",
		 				"<td colspan='3'>Vendors</td>",
		 				"<td colspan='3'>FMIs</td>",
		 				"<td colspan='2'>Total</td>",
	 				"<tr>",
	 				"<tr class='tbl-header'>",
	 					//Static
		 				"<td>Region</td>",
		 				"<td>T1 Country</td>",
		 				//ALL
		 				"<td>#</td>",
		 				"<td>#<br/>Mapped</td>",
		 				"<td>%<br/>Mapped</td>",
	 					//Teams
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Confirmed</td>",
		 				"<td>%<br/>Confirmed</td>",
	 					//Systems
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Confirmed</td>",
		 				"<td>%<br/>Confirmed</td>",
	 					//Vendor
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Confirmed</td>",
		 				"<td>%<br/>Confirmed</td>",
	 					//FMIs
		 				"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Confirmed</td>",
		 				"<td>%<br/>Confirmed</td>",
		 				 //total
		 				"<td>%<br/>Confirmed</td>",
		 				"<td>RAG</td>",
	 				"<tr>",
	 			"</thead>",
	 		].join(" "); 
		};
		var Tbody = [];
		_.each(res.Data, function(o){
			
			Tbody.push("<tr class='none'><td  colspan='22'>&nbsp;</td></tr>")
			var rowspan = o.detail.length;
			Tbody.push("<tr ><td style='border-left: 1px solid #000!important;' class='region' rowspan='"+rowspan+"'>"+o.Label+"</td>");
			_.each(o.detail, function(v,index){
 	 
				if(index > 0){
					// Tbody.push("<tr style='border-top: 2px solid #000;border-bottom: 2px solid #000;'>");
				}

				Tbody.push("<td class='main' align='left'>"+v.Label+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");
				
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");
				
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");
				
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");
		
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
				Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");
			
				Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
				Tbody.push("<td class='main "+v.RAG+"' style='border-right: 1px solid #000!important;'>&nbsp;</td>"); 
				Tbody.push("</tr>");
			}); 
		});

		$sel.append("<table width='100%'>"+Theader+Tbody.join(" ")+"<table>");
	});
};
widget.createGridDailyStatusBusiness =  function(type, payload, page, index, onchangStatus){
	ajaxPost("/dailystats/reportdailystatssek", payload, function(res){
	 	wg.charts[page][index].value  = res.Data; 
        wg.charts[page][index].status = true;
       
		$sel = $("#full-chart-" + page);
		$sel.addClass("fullgrid dailystatus-grid");
		$sel.html("");
		if (payload.Flag == 'validated') {
			var Theader = [
	 			"<thead>",
	 				"<tr class='tbl-header'>",
		 				"<td>Static</td>",
						"<td colspan='3'>All</td>",
						"<td colspan='3'>Teams</td>",
						"<td colspan='3'>Systems</td>",
						"<td colspan='3'>Vendors</td>",
			 			"<td colspan='3'>FMIs</td>",
						"<td colspan='2'>Total</td>",
	 				"<tr>",
	 				"<tr class='tbl-header'>",
	 					"<td>Business/Function</td>",
						"<td>#</td>",
		 				"<td>#<br/>Mapped</td>",
		 				"<td>%<br/>Mapped</td>",
						"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
						"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
						"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
						"<td>#<br/>Mapped</td>",
		 				"<td>#<br/>Validated</td>",
		 				"<td>%<br/>Validated</td>",
						"<td>%<br/>Validated</td>",
						"<td>RAG</td>",
	 				"<tr>",
	 			"</thead>",
	 		].join(" ");
	 	}else{
	 		var Theader = [
	 			"<thead>",
	 				"<tr class='tbl-header'>",
		 				"<td>Static</td>",
						"<td colspan='3'>All</td>",
						"<td colspan='3'>Teams</td>",
						"<td colspan='3'>Systems</td>",
						"<td colspan='3'>Vendors</td>",
			 			"<td colspan='3'>FMIs</td>",
						"<td colspan='2'>Total</td>",
	 				"<tr>",
	 				"<tr class='tbl-header'>",
	 					"<td>Business/Function</td>",
						"<td>#</td>",
		 				"<td>#<br/>Mapped</td>",
		 				"<td>%<br/>Mapped</td>",
						"<td>#<br/>Mapped</td>",
						"<td>#<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>#<br/>Mapped</td>",
						"<td>#<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>#<br/>Mapped</td>",
						"<td>#<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>#<br/>Mapped</td>",
						"<td>#<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>%<br/>Confirmed</td>",
						"<td>RAG</td>",
	 				"<tr>",
	 			"</thead>",
	 		].join(" ");
	 	};
 		var Tbody = [];
		_.each(res.Data, function(v){
			var lastdata = res.Data.length - 1;
				console.log(v.Label)
			if (v.Label.indexOf("Total") > -1) {
				Tbody.push("<tr class=''><td  colspan='22'>&nbsp;</td></tr>")
			};
			Tbody.push("<tr>");
			Tbody.push("<td class='region' align='left'>"+v.Label+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");
			
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");
			
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");
			
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");
	
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
			Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");
		
			Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
			Tbody.push("<td class='main "+v.RAG+"' style='border-right: 1px solid #000!important;'>&nbsp;</td>"); 
			Tbody.push("</tr>");
		});
		$sel.append("<table width='100%'>"+Theader+Tbody.join(" ")+"<table>");
	});
};

widget.GenerateSummry =  function(page, index){
	$("#opt-summary-modal").modal('hide'); 
	var config = getSummaryActive(page, index); 
		config.loading(true);
	var payload = widget.GeneratePayload(getTemplateActive(page).filter);
		payload.BoxType = config.filter.value(); 

	ajaxPost("/widgetanalysis/getwidgetsummarybox",payload, function(res){
		config.loading(false);
		config.active(true); 
		config.value( (res.Data == null)? 0 : res.Data );
	});
};

widget.CloseDataViZActive = function(page,index){
	var config = getDataViZActive(page, index);
		config.type("");
		config.active(false);
		config.filter.value("");
		config.filter.text("");
	$("#"+config.id).find(".content").html("");
};
widget.CloseFullDataViZActive = function(page, fulldataVizIndex){ 
	widget.checkFilterDailyStatus(page);
	widget.checkFilterCpoReport(page);
	var config = getDataViZActive(page, fulldataVizIndex); 
		config.type("");
		config.active(false);
		config.filter.value("");
		config.filter.text("");

	$("#fullDataViz"+fulldataVizIndex).find(".content").html(""); 
	var template = getTemplateActive(page);
		template.mainpage.fulDataViz(false);     
		template.mainpage.fulDataVizIndex("");   
};
widget.CloseSummaryActive =  function(page, index){
	var config = getSummaryActive(page, index);
		config.active(false);
		config.value(0); 
		config.filter.value("");
		config.filter.text("");
};

widget.movePage =  function(move){
	if(move == "prev")
		return widget.page.active(widget.page.active() - 1);
	if(move == "next")
		return widget.page.active(widget.page.active() + 1); 		
}; 

widget.GetSummaryOptions =  function(){
	ajaxPost("/widgetanalysis/getlistsummarybox",{}, function(res){
		var results = [];
		_.each(res.Data, function(v){
			results.push({text:v.desc, value:v.id, type:v.type});
		}); 
		widget.popUpOptionsSummary.data(results);
		widget.popUpOptionsSummary.category(_.countBy(results, 'type'));
	});
};
widget.GetBarOptions =  function(){
	ajaxPost("/ociranalysis/getlistbarchart",{}, function (res){
		var results = [];
		_.each(res.Data.rows, function(v){
        	results.push({text:v.title, value:v.url, type:v.icon});
      	}); 
      	widget.popUpOptionsBar.data(results);
		widget.popUpOptionsBar.category(_.countBy(results, 'type'));
      	
	});
};
widget.GetDonutOptions =  function(){
	var donutOptions = [
	    {value:"% of Services by Service Type",text:"% of Services by Service Type"},
	    {value:"In-Entity vs Intra-Group",text:"% Services Performed In-Entity Vs Intra-Group"},
	    {value:"In-Entity vs Intra-Group FTE",text:"FTE Utilized by In-Entity Vs Intra-Group"}
    ]; 
    widget.popUpOptionsDonut.data(donutOptions); 
}; 
widget.GetGridOptions =  function(){
	var gridOptions = [
	 	{value:"Products",text:"Products"},
        {value:"validated",text:"For Validated Service by Country"},
        {value:"enriched",text:"For Confirmed Service by Country"},
        {value:"businnessvalidated",text:"For Validated Service by Business"},
        {value:"businnessenriched",text:"For Confirmed Service by Business"},
        {value:"countrybusinnessvalidated",text:"% Validated Service by Country and Business"},
        {value:"countrybusinnessenriched",text:"% Confirmed Service by Country and Business"},

		{value:"countryValidated",text:"Daily Stats Validated by Country"},
        {value:"businessvalidated",text:"Daily Stats Validated by Business"},
        {value:"countryConfirmed",text:"Daily Stats Confirmed  by Country"},
        {value:"businessConfirmed",text:"Daily Stats Confirmed by Business"},
        {value:"cpoReport",text:"CPO Report"}
	];
	widget.popUpOptionsGrid.data(gridOptions);
	// widget.widgetOptions.grid(gridOptions);
};
widget.GetTemplate =  function(){
	ajaxPost("/widgetanalysis/gettemplatename",{}, function (res){
	    var datas = []
	    _.each(res.Data, function(v){ 
			datas.push({text:v._id,value:v._id, status:v.status}) 
	    })
		widget.configTemplateFilter.data.template(datas);
		widget.configTemplateFilter.value.template(widget.inputTemplate());
	});
};
widget.GetEmail = function(){
	ajaxPost("/widgetanalysis/getlistemail", "", function (res){
		widget.emailList(res.Data);

		widget.popUpSendEmail.rendered();
	});		
};
widget.GetMembers =  function(){
	ajaxPost("/distributionlist/getmembername", {}, function(res){
		widget.popUpEmailSettings.dataMemberList(res.Data);
		widget.popUpEmailSettings.rendered();
	});
};

widget.SaveTemplate =  function(){
	if (widget.inputTemplate() == "") 
		return swal("", "Please Insert a Template Name", "warning");
     
	var newTemplate  = [];
	var template = widget.template();

 
	_.each(template, function(v,i){  
		newTemplate.push({
			filter   	: {},
			mainpage 	:{
				summary 			: [],
				fulDataViz 			: v.mainpage.fulDataViz(),
				fulDataVizIndex 	: v.mainpage.fulDataVizIndex(),
				dataViz  			: [],
				fulDataVizLoading 	: v.mainpage.fulDataVizLoading()
			}
		});
		_.each(v.mainpage.dataViz, function(dataViz){
			newTemplate[i].mainpage.dataViz.push({
				id 			: dataViz.id,
				filter 		: {
					value 	: dataViz.filter.value(),
					text 	: dataViz.filter.text()
				},
				active 		: dataViz.active(),
				loading 	: dataViz.loading(),
				showFilter 	: dataViz.showFilter(),
				type 		: dataViz.type(),
			});
		});
		_.each(v.mainpage.summary, function(summary){
			newTemplate[i].mainpage.summary.push({
				id 			: summary.id,
				filter 		: {
					value 	: summary.filter.value(),
					text 	: summary.filter.text()
				},
				active 		: summary.active(),
				loading 	: summary.loading(),
				showFilter 	: summary.showFilter(),
				value 		: summary.value(),
			});
		}); 
		_.each(v.filter, function(filter,idx){ 
			newTemplate[i].filter[idx] = {
				// id 		: filter.id,
				// loading : filter.loading,
				// title   : filter.title, 
				value   : filter.value(),
				// data 	: [],
				// visible : filter.visible,
			};
			// if(!_.has(filter.url, "url"))
			// 	newTemplate[i].filter[idx].url = filter.url;
		});

	});
	var payload = {TemplateName:widget.inputTemplate(), status:"Public",details:newTemplate}
	
	ajaxPost("/widgetanalysis/savewidgettemplate",payload , function (res){
        widget.configTemplateFilter.onchange.template(false); 
        widget.GetTemplate()
        swal("Saved!", "", "success");
    })
};

widget.loadPage = function(noPage, payload){
	var page = getTemplateActive(noPage);
	var summary = page.mainpage.summary; 
	var dataViz = page.mainpage.dataViz; 
	for(var i in summary){ 
		if(summary[i].active())
			widget.GenerateSummry(noPage, parseInt(i));
	}
	for(var i in dataViz){
		if(dataViz[i].active())
			widget.generateDataviz(dataViz[i].type(),noPage, i);
	}
};
widget.loadTemplate =  function(id){ 
	widget.inputTemplate(id);
	ajaxPost("/widgetanalysis/getdetailstemplatename",{id:id}, function (res){
		var template =  res.Data.details;
		var newTemplate = [];
		_.each(template, function(v){
			var newFilter =  widget.getFilterTemplate() 
			_.each(v.filter, function(obj, key){
				if(_.has(newFilter, key)){ 
					if(obj.value.length > 0){
						ds = []
						_.each(obj.value,function(o){
							ds.push({text:o,value:o})
						})
						newFilter[key].value = ko.observableArray(obj.value);
						newFilter[key].data = ko.observableArray(ds);
					}
				}
			});

			v.mainpage.fulDataViz 		= ko.observable(v.mainpage.fulDataViz);
			v.mainpage.fulDataVizIndex 	= ko.observable(v.mainpage.fulDataVizIndex);
			v.mainpage.fulDataVizLoading 	= ko.observable(v.mainpage.fulDataVizLoading);
			_.each(v.mainpage.dataViz, function(dataviz){
				dataviz.active 		=  ko.observable(dataviz.active);
				dataviz.type 		=  ko.observable(dataviz.type); 
				dataviz.showFilter  =  ko.observable(dataviz.showFilter);
				dataviz.loading 	=  ko.observable(dataviz.loading); 
				dataviz.filter 		=  {
					value: ko.observable(dataviz.filter.value),
					text: ko.observable(dataviz.filter.text),
				};
			}); 
			_.each(v.mainpage.summary, function(summary){
				summary.active 		=  ko.observable(summary.active);
				summary.value 		=  ko.observable(summary.value); 
				summary.showFilter  =  ko.observable(summary.showFilter);
				summary.loading 	=  ko.observable(summary.loading); 
				summary.filter 		=  {
					value: ko.observable(summary.filter.value),
					text: ko.observable(summary.filter.text),
				};
			});
			newTemplate.push({
								filter  : newFilter, 
								mainpage: v.mainpage
							});
		}); 

		widget.template(newTemplate);
		widget.page.total(newTemplate.length);
		_.each(widget.template(), function(o,i){
			widget.GetDataFilter(o.filter)
			widget.loadTemplateSummary(i, o.mainpage.summary);
			widget.loadTemplateDataviz(i, o.mainpage.dataViz);
		});
	});
};
widget.loadTemplateSummary =  function(page, summary){
	_.each(summary, function(o,i){
		if(o.active())
			widget.GenerateSummry(page, i);
	});
};
widget.loadTemplateDataviz =  function(page, dataviz){
	_.each(dataviz, function(o,i){ 
		if(o.active())
			widget.generateDataviz(o.type(), page, i);
	});
};


widget.exportPdf =  function(){
	widget.mode("export"); 
	$(".grid-preview").css({"display":"none"});
	$(".grid-pdf").css({"display":"block"});

	var backtopreview = function(){ 
		$(".grid-preview").css({"display":""});
		$(".grid-pdf").css({"display":"none"});
		widget.mode("preview");
	}
	ajaxPost("/widgetanalysis/getdategenerate", {}, function(res){ 
  		$('.date-generate').html(""); 
  		$('.date-generate').html(formatDateGeneate(res.Data));
		kendo.drawing.drawDOM($(".app-content"),{
			forcePageBreak	: ".page-break",
			paperSize 	: "a3",
			landscape 	: true,
			margin 		: {top:"5mm",left:"-2cm",right:"-2cm",bottom:"0cm"},
		})
	    .then(function (group) {
			return kendo.drawing.exportPDF(group);
	    })
		.done(function (data) { 
			 
			kendo.saveAs({
				dataURI 	: data,
				fileName 	: "OCIR_Focus_Report.pdf",
				callback 	: backtopreview()
			});
		});
	}); 
};
widget.exportExcel = function(page){
	var payload = widget.GeneratePayload(getFilterActive(page)); 
	var newPayload ={
				 ReceiverCountry : payload.ReceiverCountry,
				 ReceiverLegalEntity : payload.ReceiverLegalEntity,
				 Region 			 : payload.Region,
				 productfunction 	 : payload.Productfunction,
				 Categoryname    : payload.Categoryname,
				 GPO             : payload.GPO,
				 Mapping         : [],
				 L1process 	     : payload.Parentprocessname,
			};
	widget.loadingPage(true);
	ajaxPost("/cpo/getexcelfilter", payload, function (res){
 		widget.loadingPage(false);
 		redirectUrl("/static/temp/CPOReport/"+res.msg);
    })
} 

widget.GeneratePayload = function(filter){
	var payload = {};
	_.each(filter, function(v){
		payload[v.id] = v.value();
	})
	return payload;
};
var callAjaxFilter = function(url, payload, data){
		// data([]);
	ajaxPost(url, payload, function(res){ 
		var results = [] 
		_.each(res, function(v){ 
			if(url == "/ociranalysis/getcef" || url == "/ociranalysis/getnecessary"){
				results.push(v); 
			}else{
				results.push({text:v._id, value:v._id});
			}
		});
		data(results);
	});
};

widget.ChangeFilter  = function(e, id, page){
	var filter 	= getFilterActive(page); 
		filter[id].value(e._old);

	if(!_.has(filter[id], "url"))
		return;

	var payload = widget.GeneratePayload(filter);  

	widget.loadPage(page, payload);
	if(filter.cpoReport.value()){
		widget.filterCpoReport.forEach(function(v){
			o = filter[v.id];
			if(o.id == id)
				return;
			if(!_.has(o, "url"))
				return;
			callAjaxFilter(o.url, payload, o.data);
		});
	}else if(filter.dailystatus.value()){
		widget.filterDailyStatus.forEach(function(v){
			o = filter[v.id];
			if(o.id == id)
				return;
			if(!_.has(o, "url"))
				return;
			callAjaxFilter(o.url, payload, o.data);
		});
	}else{
		console.log(filter)
		_.each(filter, function(o){

			if(o.id == id)
				return;
			if(!_.has(o, "url"))
				return;
			// console.log("------>>>>",o);
			callAjaxFilter(o.url, payload, o.data);


			// ajaxPost(o.url, payload, function(res){ 
				
			// 	var results = []
			// 	_.each(res, function(v){
			// 		results.push({text:v._id, value:v._id});
			// 	});
			// 	o.data(results);
			// });
		});
	}
};
widget.GetDataFilter = function(filter){
	var payload 	= widget.GeneratePayload(filter); 
	if(filter.cpoReport.value() == true){
		widget.filterCpoReport.forEach(function(v){
			o = filter[v.id]; 
			if(!_.has(o, "url"))
				return;
			callAjaxFilter(o.url, payload, o.data);
		});
	}else if(filter.dailystatus.value() == true){
		widget.filterDailyStatus.forEach(function(v){
			o = filter[v.id]; 
			if(!_.has(o, "url"))
				return;
			callAjaxFilter(o.url, payload, o.data);
		});
	}else{
		_.each(filter, function(o){ 
			if(!_.has(o, "url"))
				return;
			callAjaxFilter(o.url, payload, o.data); 
		});
	}
};
widget.GetEmailScheduller = function(id){
	ajaxPost("/emailscheduller/getemailscheduller",{Id : id} , function (res){
       	console.log(res)
    })	
};
$(function(){
	// widget.popUpSendEmail.rendered();
	widget.CreatePage();
	
	widget.GetTemplate();
	widget.GetBarOptions();
	widget.GetDonutOptions();
	widget.GetGridOptions();
	widget.GetSummaryOptions(); 
	widget.GetTemplate();
	widget.GetEmail();
	widget.GetMembers();

	$("#email-scheduller-modal #start-date").kendoDatePicker({
    	format: "yyyy/MM/dd",
    	 value: new Date(),
	});

	$("#email-scheduller-modal #end-date").kendoDatePicker({
    	format: "yyyy/MM/dd",
    	 value: new Date(),
	});

})