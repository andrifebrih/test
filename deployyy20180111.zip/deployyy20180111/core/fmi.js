var fmi = {};

// fmi.filters = {
// 	OriginatingBusiness: {
// 		active: ko.observable(false),
// 		subtitle: ko.observable('No Filter Selected'),
// 		components: {
// 			Cmgcountries1:{
// 				id: "Cmgcountries1",
// 				data: [{ text: "All", value: "all" }, { text: "Yes", value: "yes" }, { text: "No", value: "no" }],
// 				value: ko.observable("all")
// 			},
// 			Receivercountry: {
// 				id: "Receivercountry",
// 				url: "/fmi/filterreceivercountry",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([]),
// 			},
// 			Receiverlegalenitity: {
// 				id: "Receiverlegalenitity",
// 				url: "/fmi/filterreceiverlegal",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([]),
// 			},
// 			Business: {
// 				id: "Business",
// 				url: "/fmi/filterbusiness",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([]),
// 			},
// 			Productfunction: {
// 				id: "Productfunction",
// 				url: "/fmi/filterproductfunction",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([]),
// 			},
// 			Cef: {
// 				id: "Cef",
// 				data: [{ value: "", text: "All" }, { value: "Y", text: "Yes" }, { value: "N", text: "No" }],
// 				value: ko.observableArray([]),
// 			}
// 		}
// 	},
// 	InternalAccessPoint: {
// 		active: ko.observable(false),
// 		subtitle: ko.observable('No Filter Selected'),
// 		enabled: ko.observable(true),
// 		components: {
// 			Cmgcountries2: {
// 				id: "Cmgcountries2",
// 				data: [{ text: "All", value: "all" }, { text: "Yes", value: "yes" }, { text: "No", value: "no" }],
// 				value: ko.observable("all"),
// 			},
// 			Suppliercountry: {
// 				id: "Suppliercountry",
// 				url: "/fmi/filtersuppliercountry",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([]),
// 			},
// 			Supplierlegalentity: {
// 				id: "Supplierlegalentity",
// 				url: "/fmi/filtersupplierlegal",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([]),
// 			}
// 		}
// 	},
// 	ExternalAccesPoint: {
// 		active: ko.observable(false),
// 		subtitle: ko.observable('No Filter Selected'),
// 		enabled: ko.observable(true),
// 		components: {
// 			Vendorname: {
// 				id: "Vendorname",
// 				url: "/fmi/filtervendorname",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([])
// 			}
// 		}
// 	},
// 	FMI: {
// 		active: ko.observable(false),
// 		subtitle: ko.observable("No Filter Selected"),
// 		components: {
// 			Cmgcountries3: {
// 				id: "Cmgcountries3",
// 				data: [{ text: "All", value: "all" }, { text: "Yes", value: "yes" }, { text: "No", value: "no" }],
// 				value: ko.observable("all"),
// 			},
// 			Fmicountryname: {
// 				id: "Fmicountryname",
// 				url: "/fmi/filterfmicountryname",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([]),
// 			},
// 			Fmicategory: {
// 				id: "Fmicategory",
// 				url: "/fmi/filterfmicategory",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([]),
// 			},
// 			Suppliername: {
// 				id: "Suppliername",
// 				url: "/fmi/filtersuppliername",
// 				data: ko.observableArray([]),
// 				value: ko.observableArray([]),
// 			}
// 		}
// 	}
// }

fmi.filter1active = ko.observable(false)
fmi.filter2active = ko.observable(false)
fmi.filter3active = ko.observable(false)
fmi.filter4active = ko.observable(false)
fmi.activeFilter = ko.observable("");
fmi.activePage = ko.observable("Chart");
fmi.iapEnable = ko.observable(true)
fmi.eapEnable = ko.observable(true)
fmi.filter1subtitle = ko.observable('No Filter Selected')
fmi.filter2subtitle = ko.observable('No Filter Selected')
fmi.filter3subtitle = ko.observable('No Filter Selected')
fmi.filter4subtitle = ko.observable('No Filter Selected')
fmi.isObCountryDD = ko.observable(false);
fmi.isIapCountryDD = ko.observable(false);
fmi.isFmiCountryDD = ko.observable(false);
fmi.isMapModeFC = ko.observable(false);
fmi.mapCenter = "";
fmi.mapBranch = "";
fmi.mapBoxUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoiYW5kcmlmOTUiLCJhIjoiY2l6ZGsyYm9yMjR1NjJxcDk4OXl2OWF1eCJ9.mIOW47-NbEinOt2RdL9yJQ';
fmi.mapBoxAttr = 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
                 '<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
                 'Imagery © <a href="http://mapbox.com">Mapbox</a>';
fmi.mapExportUrl = "";
fmi.mapDetailField = "";
fmi.mapDetailCountry = "";
fmi.mapLoader = ko.observable(true);
fmi.mapExportLoader = ko.observable(false);
fmi.mapSummaryLoader = ko.observable(false);
fmi.mapPrimarySummary = ko.observableArray([]);
fmi.mapSecondarySummary = ko.observableArray([]);
fmi.mapSwapFilter = false;


fmi.templateConfigDonut = {
    legend: {
        visible:false,
        labels: {
            font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            template:'',
            color: "#e8e8ea"
        },
        margin:{
            visible:true,
            left:-10
        },
    },
    chartArea: {
        height : 100,
        background: "transparent",
        width : 120,
    },
    seriesDefaults: {
        labels: {
            visible: false,
            template: "#= removeSpace(kendo.toString(percentage,'P0'))#",
            font: "9px Helvetica Neue, Arial, sans-serif",
            background: "transparent"
        }
    },
   // / seriesColors: ["#00506D","#0077A3","#0075B2"],
    series: [{
        type: "donut",
        data: '',
        overlay:{gradient:"none"},
    }],
    valueAxis:{
        visible:false,
        labels: {
            font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            visible: false,
            format:"{0:P0}",
        },
        majorGridLines: {
            visible: false
        },
    },
    tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#=kendo.toString(value,'N0')#"
    },
};
fmi.configDonut = ko.mapping.fromJS(fmi.templateConfigDonut);

fmi.filter = {
	receivercountryDD: ko.observable(''),
	suppliercountryDD: ko.observable(''),
	fmicountrynameDD: ko.observable(''),
	diValue : ko.observable('all'),
	diValueList : ko.observableArray([]),
	eiValue : ko.observable('all'),
	eiValueList : ko.observableArray([]),
	obCmgCountry : ko.observable('all'),
	obCmgCountryList : ko.observableArray([]),
	obCountry : ko.observableArray([]),
	obCountryList : ko.observableArray([]),
	obLegalEntity : ko.observableArray([]),
	obLegalEntityList : ko.observableArray([]),
	obBusiness : ko.observableArray([]),
	obBusinessList : ko.observableArray([]),
	obProduct : ko.observableArray([]),
	obProductList : ko.observableArray([]),
	obCef : ko.observableArray([]),
	obCefList : ko.observableArray([]),
	iapCmgCountry : ko.observable('all'),
	iapCmgCountryList : ko.observableArray([]),
	iapCountry : ko.observableArray([]),
	iapCountryList : ko.observableArray([]),
	iapLegalEntity : ko.observableArray([]),
	iapLegalEntityList : ko.observableArray([]),
	vendorName : ko.observableArray([]),
	vendorNameList : ko.observableArray([]),
	fmiCmgCountry : ko.observable('all'),
	fmiCmgCountryList : ko.observableArray([]),
	fmiCountry : ko.observableArray([]),
	fmiCountryList : ko.observableArray([]),
	fmiCategory : ko.observableArray([]),
	fmiCategoryList : ko.observableArray([]),
	fmiName : ko.observableArray([]),
	fmiNameList : ko.observableArray([]),
}

fmi.summary = [
		{
			id: "sum-fmiList",
			label: "# of Total FMIs",
			value: ko.observable(0),
		},
		{
			id: "sum-cefSupported",
			label: "# of CEFs Supported",
			url: "/fmi/getcefsupproted",
			value: ko.observable(0),
		},
		{
			id: "sum-fmiCountries",
			label: "# of FMI Countries",
			value: ko.observable(0),
		},
		{
			id: "sum-accessCountry",
			label: "# of Access Countries",
			value: ko.observable(0),
		},
		{
			id: "sum-originatingCountry",
			label: "# of Originating Countries",
			url: "/fmi/getnumberoforiginatingcountry",
			value: ko.observable(0),
		},
		{
			id: "sum-totalValue",
			label: "Total Amount ($B)",
			url: "/fmi/getsumfmiammount",
			value: ko.observable(0),
      template : function(v) {
        return Number(v).toLocaleString();
      }
		},
		{
			id: "sum-volume",
			label: "Total Volume",
			url: "/fmi/getsumfmivolume",
			value: ko.observable(0),
      template : function(v) {
        return Number(v).toLocaleString();
      }
		}
];

fmi.content = {
	gridFMI: {
		loading: ko.observable(true),
		data: ko.observableArray([]),
		selector: "#gridFMI",
		url: "/fmi/getfmilist"
	},
	chartOriginating: {
		loading: ko.observable(true),
		data: {
      "TransactionBanking": ko.observable(0),
      "FinancialMarkets": ko.observable(0),
      "RetailProducts": ko.observable(0),
      "HeadOfficeCreditReportingPolicy": ko.observable(0),
    },
		selector: "#chartOriginating .chart",
		url: "/fmi/getfmiperoriginatingbusiness"
	},
	chartCountry: {
		loading: ko.observable(true),
		data: ko.observableArray([]),
		selector: "#chartCountry .chart",
		url: "/fmi/getfmiperfmicountry",
	},
	chartAccess: {
		loading: ko.observable(true),
		data: ko.observableArray([]),
		selector: "#chartAccess .chart",
		url: "/fmi/getfmiperaccesscountry",
	},
	receiverCountry: {
		loading: ko.observable(true),
		data: ko.observableArray([]),
		selector: "#chartCountryList .chart",
		url: "/fmi/getfmiperreceivercountry",
	}
}

fmi.loaderExport = ko.observable(false);
fmi.grid = {
	Filter: {
		Filters: [],
		Logic: ""
	},
	SortType: null,
	SortField: null,
};
fmi.lenAvailableDataContent = ko.computed(function(){
	var len = 0;
	if(fmi.content.chartOriginating.data['TransactionBanking']() > 0)
		len += 1;
	if(fmi.content.chartOriginating.data['FinancialMarkets']() > 0)
		len += 1;
	if(fmi.content.chartOriginating.data['RetailProducts']() > 0)
		len += 1;
	if(fmi.content.chartOriginating.data['HeadOfficeCreditReportingPolicy']()  > 0)
		len += 1;
	return len;
})
 
fmi.getOBcmgCountry = function() {
	var countries = [
	{value:"all", text:"All"},
	{value:"yes", text:"Yes"},
	{value:"no", text:"No"},
	]
	fmi.filter.obCmgCountryList(countries);
}
fmi.getOBcountry = function() {
	var payload = fmi.getPayload();
	payload.Receivercountry = [];
	ajaxPost("/fmi/filterreceivercountry", payload, function (res){
		var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        fmi.filter.obCountryList(receivingCountries);
	})
}
fmi.getOBlegalentity = function() {
	var payload = fmi.getPayload();
	payload.Receiverlegalenitity = [];
	ajaxPost("/fmi/filterreceiverlegal", payload, function (res){
		var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        fmi.filter.obLegalEntityList(legalEntities);
	})
}
fmi.getOBbusiness = function() {
	var payload = fmi.getPayload();
	payload.Business = [];
	ajaxPost("/fmi/filterbusiness", payload, function (res){
		var business = [];
        $.each(res, function(i,v){
            business.push({text:v._id, value:v._id})
        });
        fmi.filter.obBusinessList(business);
	})
}
fmi.getOBproduct = function() {
	var payload = fmi.getPayload();
	payload.Productfunction = [];
	ajaxPost("/fmi/filterproductfunction", payload, function (res){
		var products = [];
        $.each(res, function(i,v){
            products.push({text:v._id, value:v._id})
        });
        fmi.filter.obProductList(products);
	})
}
fmi.getOBcef = function() {
	var cef = [
	{value:"", text:"All"},
	{value:"Y", text:"Yes"},
	{value:"N", text:"No"},
	]
	fmi.filter.obCefList(cef);
}
fmi.getIAPcmgCountry = function() {
	var countries = [
		{value:"all", text:"All"},
		{value:"yes", text:"Yes"},
		{value:"no", text:"No"},
	]
	fmi.filter.iapCmgCountryList(countries);
}
fmi.getIAPcountry = function() {
	var payload = fmi.getPayload();
	payload.Suppliercountry = [];
	ajaxPost("/fmi/filtersuppliercountry", payload, function (res){
		var supplyCountries = [];
        $.each(res, function(i,v){
            supplyCountries.push({text:v._id, value:v._id})
        });
        fmi.filter.iapCountryList(supplyCountries);
	})
}
fmi.getIAPlegalentity = function() {
	var payload = fmi.getPayload();
	payload.Supplierlegalentity = [];
	ajaxPost("/fmi/filtersupplierlegal", payload, function (res){
		var supplyEntities = [];
        $.each(res, function(i,v){
            supplyEntities.push({text:v._id, value:v._id})
        });
        fmi.filter.iapLegalEntityList(supplyEntities);
	})
}
fmi.getVendorname = function() {
	var payload = fmi.getPayload();
	payload.Vendorname = [];
	ajaxPost("/fmi/filtervendorname", payload, function (res){
		var vendorNames = [];
        $.each(res, function(i,v){
            vendorNames.push({text:v._id, value:v._id})
        });
        fmi.filter.vendorNameList(vendorNames);
	})
}
fmi.getFMIcmgCountry = function() {
	var countries = [
		{value:"all", text:"All"},
		{value:"yes", text:"Yes"},
		{value:"no", text:"No"},
	]
	fmi.filter.fmiCmgCountryList(countries);
}
fmi.getFMIcountry = function() {
	var payload = fmi.getPayload();
	payload.Fmicountryname = [];
	ajaxPost("/fmi/filterfmicountryname", payload, function (res){
		var fmiCountries = [];
        $.each(res, function(i,v){
            fmiCountries.push({text:v._id, value:v._id})
        });
        fmi.filter.fmiCountryList(fmiCountries);
	})
}
fmi.getFMIcategory = function() {
	var payload = fmi.getPayload();
	payload.Fmicategory = [];
	ajaxPost("/fmi/filterfmicategory", payload, function (res){
		var fmiCategories = [];
        $.each(res, function(i,v){
            fmiCategories.push({text:v._id, value:v._id})
        });
        fmi.filter.fmiCategoryList(fmiCategories);
	})
}
fmi.getFMIname = function() {
	var payload = fmi.getPayload();
	payload.Suppliername = [];
	ajaxPost("/fmi/filtersuppliername", payload, function (res){
		var fmiNames = [];
        $.each(res, function(i,v){
            fmiNames.push({text:v._id, value:v._id})
        });
        fmi.filter.fmiNameList(fmiNames);
	})
}

fmi.filter.diValue.subscribe(function(newValue) {
	if(fmi.filter.eiValue() == "internal" && newValue == "direct") {
		fmi.iapEnable(false);
		fmi.eapEnable(false);
		fmi.resetFilter("iap");
		fmi.resetFilter("eap");
	}else if(fmi.filter.eiValue() == "external" && newValue == "direct"){
		fmi.iapEnable(false);
		fmi.resetFilter("iap");
		fmi.eapEnable(true);
	} else {
		fmi.iapEnable(true);
		fmi.eapEnable(true);
	}

	if (fmi.filter1active() == true) {
		fmi.getOBcmgCountry()
		fmi.getOBcountry()
		fmi.getOBlegalentity()
		fmi.getOBbusiness()
		fmi.getOBproduct()
		fmi.getOBcef()
	}
	if (fmi.filter2active() == true) {
		fmi.getIAPcmgCountry()
		fmi.getIAPcountry()
		fmi.getIAPlegalentity()
	}
	if (fmi.filter3active() == true) {
		fmi.getVendorname()
	}
	if (fmi.filter4active() == true) {
		fmi.getFMIcmgCountry()
		fmi.getFMIcountry()
		fmi.getFMIcategory()
		fmi.getFMIname()
	}
	fmi.init()
})
fmi.filter.eiValue.subscribe(function(newValue) {
	if(fmi.filter.diValue() == "direct" && newValue == "internal") {
		fmi.iapEnable(false);
		fmi.eapEnable(false);
		fmi.resetFilter('iap');
		fmi.resetFilter('eap');
		fmi.filter2active(false);
		fmi.filter3active(false);
	}else if(fmi.filter.diValue() == "direct" && newValue == "external"){
		fmi.iapEnable(false);
		fmi.resetFilter("iap");
		fmi.filter2active(false);
		fmi.eapEnable(true);
	} else {
		fmi.iapEnable(true);
		fmi.eapEnable(true);
	}

	if (fmi.filter1active() == true) {
		fmi.getOBcmgCountry()
		fmi.getOBcountry()
		fmi.getOBlegalentity()
		fmi.getOBbusiness()
		fmi.getOBproduct()
		fmi.getOBcef()
	}
	if (fmi.filter2active() == true) {
		fmi.getIAPcmgCountry()
		fmi.getIAPcountry()
		fmi.getIAPlegalentity()
	}
	if (fmi.filter3active() == true) {
		fmi.getVendorname()
	}
	if (fmi.filter4active() == true) {
		fmi.getFMIcmgCountry()
		fmi.getFMIcountry()
		fmi.getFMIcategory()
		fmi.getFMIname()
	}

	fmi.init()
})
fmi.activeFilter.subscribe(function() {
	fmi.updateOpenedFilter();
})
fmi.activePage.subscribe(function(val) {
	if(val == 'Map') {
    fmi.initMapFilter();
    fmi.initMapMode(fmi.isMapModeFC());
  } else {
  	fmi["init"+val]();
  }
});
fmi.activePage.subscribe(function(oldVal){
	if(oldVal == 'Map') fmi.initMapFilter();
}, null, 'beforeChange');
fmi.isMapModeFC.subscribe(function(newValue) {
  console.log(newValue);

  var payload = fmi.generateMapPayload();

  payload.Branch = (fmi.isMapModeFC())?"fmicountryname":"suppliercountry";
  fmi.generateMapSummary(payload)
  if(newValue == true) {
    if(fmi.mapCenter != "") {
      fmi.isIapCountryDD(false);
      if(fmi.mapCenter == "suppliercountry"){
        var curVal = fmi.filter.suppliercountryDD();
        fmi.mapSwapFilter = true;
        fmi.isObCountryDD(false);
        fmi.isFmiCountryDD(true);
        fmi.suppliercountryDDUpdate("", false);
        fmi.fmicountrynameDDUpdate(curVal);
      }
      else{
        fmi.mapBranch = "fmicountryname"
        fmi.isFmiCountryDD(false);
        fmi.isObCountryDD(true);
        fmi.init();
 
      }

      if(fmi.filter[fmi.mapCenter+"DD"]() == ""){

        fmi.isObCountryDD(true);
        fmi.isFmiCountryDD(true);
      	

      }
    } else {
      fmi.initMapMode(newValue);
    }
  } else {
    if(fmi.mapCenter != "") {
      fmi.isFmiCountryDD(false);
      if(fmi.mapCenter == "fmicountryname"){
        var curVal = fmi.filter.fmicountrynameDD()
        fmi.mapSwapFilter = true;
        fmi.isIapCountryDD(true);
        fmi.isObCountryDD(false);
        fmi.fmicountrynameDDUpdate("", false);
        fmi.suppliercountryDDUpdate(curVal);
      }
      else{
        fmi.mapBranch = "suppliercountry"
        fmi.isIapCountryDD(false);
        fmi.isObCountryDD(true);
        fmi.init();

      }
      if(fmi.filter[fmi.mapCenter+"DD"]() == ""){
        fmi.isObCountryDD(true);
        fmi.isIapCountryDD(true);
      }
    } else {
      fmi.initMapMode(newValue);
    }
  } 
});

fmi.resetFilter = function(type) {
	switch (type) {
		case "ob":
			fmi.filter.obCmgCountry("");
			fmi.filter.obCountry([]);
			fmi.filter.obLegalEntity([]);
			fmi.filter.obBusiness([]);
			fmi.filter.obProduct([]);
			fmi.filter.obCef([]);
      if(fmi.activePage() == "Map" && fmi.mapCenter == 'receivercountry') {
        fmi.filter.receivercountryDD("");
        fmi.mapCenter = "";
        fmi.mapBranch = "";
        if(fmi.isMapModeFC()) {
          fmi.isObCountryDD(true);
          fmi.isFmiCountryDD(true);
        } else {
          fmi.isObCountryDD(true);
          fmi.isIapCountryDD(true);
        }
      }
			fmi.updateFilter1();
			break;
		case "iap":
			fmi.filter.iapCmgCountry("");
			fmi.filter.iapCountry([]);
			fmi.filter.iapLegalEntity([]);
      if(fmi.activePage() == "Map" && fmi.mapCenter == "suppliercountry") {
        fmi.filter.suppliercountryDD("");
        fmi.mapCenter = "";
        fmi.mapBranch = "";
        fmi.isObCountryDD(true);
        fmi.isIapCountryDD(true);
      }
			fmi.updateFilter2();
			break;
		case "eap":
			fmi.filter.vendorName([]);
			fmi.updateFilter3();
			break;
		case "fmi":
			fmi.filter.fmiCmgCountry("");
			fmi.filter.fmiCountry([]);
			fmi.filter.fmiCategory([]);
			fmi.filter.fmiName([]);
      if(fmi.activePage() == "Map" && fmi.mapCenter == "fmicountryname") {
        fmi.filter.fmicountrynameDD("");
        fmi.mapCenter = "";
        fmi.mapBranch = "";
        fmi.isObCountryDD(true);
        fmi.isFmiCountryDD(true);
      }
			fmi.updateFilter4();
			break;
		default:
			fmi.filter.obCmgCountry("");
			fmi.filter.obCountry([]);
			fmi.filter.obLegalEntity([]);
			fmi.filter.obBusiness([]);
			fmi.filter.obProduct([]);
			fmi.filter.obCef([]);
			fmi.filter.iapCmgCountry("");
			fmi.filter.iapCountry([]);
			fmi.filter.iapLegalEntity([]);
			fmi.filter.vendorName([]);
			fmi.filter.fmiCmgCountry("");
			fmi.filter.fmiCountry([]);
			fmi.filter.fmiCategory([]);
			fmi.filter.fmiName([]);
      fmi.updateFilter1();
      fmi.updateFilter2();
      fmi.updateFilter3();
      fmi.updateFilter4();
			break;
	}
	fmi.init();
}
fmi.updateOpenedFilter = function() {
	var filters = fmi.activeFilter();
	if(filters == "filter1active") fmi.updateObFilter();
	if(filters == "filter2active") fmi.updateIapFilter();
	if(filters == "filter3active") fmi.updateEapFilter();
	if(filters == "filter4active") fmi.updateFmiFilter();
}
fmi.closeOtherFilter = function(filter) {
	var activeFilter = fmi.activeFilter();
	fmi.activeFilter(filter);
	if(activeFilter == "")
		return;
	fmi[activeFilter](false);
	if (activeFilter == filter)
		fmi.activeFilter("");
}
fmi.closeActiveFilter = function() {
  if(fmi.activeFilter() != "") fmi[fmi.activeFilter()](false);
}
fmi.updateObFilter = function() {
		fmi.getOBcmgCountry()
		fmi.getOBcountry()
		fmi.getOBlegalentity()
		fmi.getOBbusiness()
		fmi.getOBproduct()
		fmi.getOBcef()
}
fmi.updateIapFilter = function() {
		fmi.getIAPcmgCountry()
		fmi.getIAPcountry()
		fmi.getIAPlegalentity()
}
fmi.updateEapFilter = function() {
		fmi.getVendorname()
}
fmi.updateFmiFilter = function() {
		fmi.getFMIcmgCountry()
		fmi.getFMIcountry()
		fmi.getFMIcategory()
		fmi.getFMIname()
}
fmi.callFilter= function(val) {
	// return function(){
	if (val == 'ob') {
		fmi.filter1active(!fmi.filter1active())
		fmi.closeOtherFilter('filter1active');
	}else if (val == 'iap') {
		fmi.filter2active(!fmi.filter2active())
		fmi.closeOtherFilter('filter2active');
	}else if (val == 'eap') {
		fmi.filter3active(!fmi.filter3active())
		fmi.closeOtherFilter('filter3active');
	}else if (val == 'fmi') {
		fmi.filter4active(!fmi.filter4active())
		fmi.closeOtherFilter('filter4active');
	}else{
		fmi.filter1active(false)
		fmi.filter2active(false)
		fmi.filter3active(false)
		fmi.filter4active(false)
	}
	// }
}
fmi.initFilter = function() {
	fmi.getFMIcmgCountry()
	fmi.getFMIcountry()
	fmi.getFMIcategory()
	fmi.getFMIname()
	fmi.getVendorname()
	fmi.getIAPcmgCountry()
	fmi.getIAPcountry()
	fmi.getIAPlegalentity()
	fmi.getOBcmgCountry()
	fmi.getOBcountry()
	fmi.getOBlegalentity()
	fmi.getOBbusiness()
	fmi.getOBproduct()
	fmi.getOBcef()
}

fmi.updateFilter1 = function() {
	var total = 0
	var max = 5
	var title = ""
	if (fmi.filter.obCountry().length > 0){
		total = total + 1
	}
	if (fmi.filter.obLegalEntity().length > 0){
		total = total + 1
	}
	if (fmi.filter.obBusiness().length > 0){
		total = total + 1
	}
	if (fmi.filter.obProduct().length > 0){
		total = total + 1
	}
	if (fmi.filter.obCef().length > 0){
		total = total + 1
	}
	if (total == max) {
		title = 'All'
	} else if( total == 0) {
		title = "No Filter Selected";
	}else{
		title = total + ' Filter(s) Selected'
	}
	fmi.filter1subtitle(title)
}
fmi.updateFilter2 = function() {
	var total = 0
	var max = 2
	var title = ""
	if (fmi.filter.iapCountry().length > 0){
		total = total + 1
	}
	if (fmi.filter.iapLegalEntity().length > 0){
		total = total + 1
	}
	if (total == max) {
		title = 'All'
	} else if( total == 0) {
		title = "No Filter Selected";
	}else{
		title = total + ' Filter(s) Selected'
	}
	fmi.filter2subtitle(title)
}
fmi.updateFilter3 = function() {
	var total = 0;
	var title = "";
	if (fmi.filter.vendorName().length > 0){
		fmi.filter3subtitle('All')
	} else{
		fmi.filter3subtitle('No Filter Selected')
	}
}
fmi.updateFilter4 = function() {
	var total = 0
	var max = 3
	var title = ""

	if (fmi.filter.fmiCountry().length > 0){
		total = total + 1
	}
	if (fmi.filter.fmiCategory().length > 0){
		total = total + 1
	}
	if (fmi.filter.fmiName().length > 0){
		total = total + 1
	}
	if (total == max) {
		title = 'All'
	} else if( total == 0) {
		title = "No Filter Selected";
	}else{
		title = total + ' Filter(s) Selected'
	}
	fmi.filter4subtitle(title)
}

fmi.changeFilter1 = function(value, reinit = true){
		if (value ==  "obCountry") {
			fmi.getOBlegalentity()
			fmi.getOBbusiness()
			fmi.getOBproduct()
			if(reinit) fmi.init("receiverCountry")
			if(fmi.activePage() == "Chart") fmi.reloadChart(fmi.content.receiverCountry, fmi.filter.obCountry)
		}else if (value ==  "obLegalEntity") {
			fmi.getOBcountry()
			fmi.getOBbusiness()
			fmi.getOBproduct()
			fmi.init()
		}else if (value ==  "obBusiness") {
			fmi.getOBcountry()
			fmi.getOBlegalentity()
			fmi.getOBproduct()
			fmi.init("chartOriginating")
			if(fmi.activePage() == "Chart") fmi.reloadChart(fmi.content.chartOriginating, fmi.filter.obBusiness())
		}else if (value ==  "obProduct") {
			fmi.getOBcountry()
			fmi.getOBlegalentity()
			fmi.getOBbusiness()
			fmi.init()
		}else{
			fmi.getOBcountry()
			fmi.getOBlegalentity()
			fmi.getOBbusiness()
			fmi.getOBproduct()
			fmi.init()
		}
		fmi.updateFilter1();
}
fmi.changeFilter2 = function(value, reinit = true){
		if (value ==  "iapCountry") {
			fmi.getIAPlegalentity()
			if(reinit) fmi.init("chartAccess")
			if(fmi.activePage() == "Chart") fmi.reloadChart(fmi.content.chartAccess, fmi.filter.iapCountry())
		}else if(value == 'legalEntities') {
			fmi.getIAPcountry()
			fmi.init()
		} else{
			fmi.getIAPcountry()
			fmi.getIAPlegalentity()
			fmi.init()
		}
		fmi.updateFilter2();
}
fmi.changeFilter3 = function(value){
	fmi.updateFilter3();
	fmi.init()
}
fmi.changeFilter4 = function(value, reinit = true){
		if (value ==  "fmiCountry") {
			fmi.getFMIcategory()
			fmi.getFMIname()
			if(reinit) fmi.init("chartCountry")
			if(fmi.activePage() == "Chart") fmi.reloadChart(fmi.content.chartCountry, fmi.filter.fmiCountry())
		}else if (value ==  "fmiCategory") {
			fmi.getFMIcountry()
			fmi.getFMIname()
			fmi.init()
		}else if (value == "fmiName") {
			fmi.reloadFmiSummary(fmi.filter.fmiName(), fmi.content.gridFMI.data());
			fmi.getFMIcountry();
			fmi.getFMIcategory();
			fmi.init("gridFMI")
			fmi.reloadTable(fmi.filter.fmiName());
		}else{
			fmi.getFMIcountry()
			fmi.getFMIcategory()
			fmi.getFMIname()
			fmi.init()
		}
		fmi.updateFilter4();
}

function labelTemplate(e) {
	var finalLabel = "";
	var maxLen = 14;
	var words = e.value.split(" ");
	var len = 0;
	for(i = 0; i < words.length; i++) {
		var word = words[i].toLowerCase();
		word = word[0].toUpperCase() + word.slice(1);
		len = len+word.length;
		var br = "";
		if(len <= maxLen) {
			br = " ";
		} else {
			br = "\n";
		}

		if(i == 0) {
			br = "";
		}
		finalLabel = finalLabel + br + word;
		if(len >= 16 & i != words.length - 1){
			finalLabel = finalLabel + " ...";
			break;
		}
	}
	return finalLabel;
}
function generateChart($selector, dataSource, onclick) {
	if(dataSource.length < 10) {
		$selector.parent().css("overflow-y", "hidden");
	}else{
		$selector.parent().css("overflow-y", "auto");
		
	}
	// 
	$selector.kendoChart({
		dataSource: {
			data: dataSource
		},
		seriesDefaults: {
			type: "bar",
			overlay: {
				gradient: "none"
			},
			gap: 0.5,
		},
		transitions: false,
		seriesColors: ["#e8e8ea"],
		series: [{
			field: "value",
			colorField: "customColor",
			labels: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
		}],
		chartArea: {
      width: $(".fmi-panel").width() - 20,
			height: (25 * dataSource.length) + 60,
			margin: 20
		},
		categoryAxis: {
			labels: {
				template: labelTemplate,
				background: "transparent",
				visible: true,
			},
			line: {
				visible: false
			},
			majorGridLines: {
				visible: false
			},
			field: "category"
		},
		valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
		},
		seriesClick: function(e) {
			onclick(e);
		}
	})
}

fmi.reloadChart = function(content, filter) {
	var chart = $(content.selector).data("kendoChart");
	var newDataSource = _.map(content.data(), function(d) {
		if(filter.indexOf(d.category) !== -1) {
			d.customColor = "#0075B2"
		} else {
			d.customColor = "#e8e8ea"
		}
		return d
	});
	chart.dataSource.read({data : newDataSource});
	chart.refresh();
}
fmi.reloadTable = function(filter) {
	var data = fmi.content.gridFMI.data();
	_.map(data, function(d) {
		if(filter.indexOf(d.value) !== -1) {
			d.active(true);
		} else {
			d.active(false);
		}
		return d;
	})
}

fmi.reloadFmiSummary = function(val, data) {
	if(val.length > 0) {
		if(val.length > data.length) {
			fmi.summary[0].value(data.length);
		}else {
			fmi.summary[0].value(val.length);
		}
	} else {
		fmi.summary[0].value(data.length);
	}
}
fmi.reloadSummary = function() {
	_.each(fmi.summary, function(s) {
		if(s.url) {
			var payload = fmi.getPayload();
			ajaxPost(s.url, payload, function(res) {
				if(res.Data[0]) {
					var result = typeof s.template == 'function' ? s.template(Math.round(res.Data[0].Sum)) : Math.round(res.Data[0].Sum);
					s.value(result);
				} else {
					s.value(0);
				}
			})
		}
	})
}

fmi.getPayload = function() {
	return {
		Class1				 : fmi.filter.diValue(),
		Class2				 : fmi.filter.eiValue(),
		Cmgcountries1		 : fmi.filter.obCmgCountry(),
		Cmgcountries2		 : fmi.filter.iapCmgCountry(),
		Cmgcountries3        : fmi.filter.fmiCmgCountry(),
		Receivercountry      : fmi.filter.obCountry(),
		Receiverlegalenitity : fmi.filter.obLegalEntity(),
		Business             : fmi.filter.obBusiness(),
		Productfunction      : fmi.filter.obProduct(),
		Cef                  : fmi.filter.obCef(),
		Suppliercountry      : fmi.filter.iapCountry(),
		Supplierlegalentity  : fmi.filter.iapLegalEntity(),
		Suppliername		 : fmi.filter.fmiName(),
		Vendorname           : fmi.filter.vendorName(),
		Fmicountryname       : fmi.filter.fmiCountry(),
		Fmicategory          : fmi.filter.fmiCategory(),
	}
}
fmi.generateFMIList = function(uncheck) {
	var payload = fmi.getPayload();
	if(uncheck == "gridFMI")
		payload.Suppliername = [];
	var $selector = $(fmi.content.gridFMI.selector);
	fmi.content.gridFMI.loading(true);
	ajaxPost(fmi.content.gridFMI.url, payload, function(res) {
		var fmis = fmi.filter.fmiName();
		var data = _.map(res.Data, function(d) {
			if(fmis.indexOf(d) != -1) {
				return {
					active: ko.observable(true),
					value: d
				}
			}
			return {
				active: ko.observable(false),
				value: d
			}
		})
		fmi.content.gridFMI.data(data);
		fmi.content.gridFMI.loading(false);
		fmi.reloadFmiSummary(fmis, data);
	})
}
fmi.toggleFMIItem = function(data) {
	data.active(!data.active());
	var currVal = fmi.filter.fmiName();
	var newVal = [];
	if(currVal.indexOf(data.value) !== -1) {
		newVal = _.without(currVal, data.value);
		fmi.filter.fmiName(newVal);
		fmi.init(null, "gridFMI");
		fmi.updateFilter4();
	} else {
		currVal.push(data.value);
		newVal = currVal;
		fmi.filter.fmiName(newVal);
		fmi.init("gridFMI");
	}
	fmi.reloadFmiSummary(currVal, fmi.content.gridFMI.data());
	fmi.updateOpenedFilter();
  fmi.closeActiveFilter();
}
fmi.toggleOriginating = function(val, el) {
  var currVal = fmi.filter.obBusiness();
  if(currVal.indexOf(val) == -1) {
    currVal.push(val);
    fmi.filter.obBusiness(currVal);
    fmi.init("chartOriginating");
  } else {
    fmi.filter.obBusiness(_.without(currVal, val));
    fmi.init(null, "chartOriginating");
    fmi.updateFilter1();
  }
  fmi.updateOpenedFilter();
  fmi.closeActiveFilter();
}
fmi.generateOriginating = function(uncheck) {
	var payload = fmi.getPayload();
	if(uncheck == "chartOriginating")
		payload.Business = [];
	var $selector = $(fmi.content.chartOriginating.selector);
	fmi.content.chartOriginating.loading(true);

	ajaxPost(fmi.content.chartOriginating.url, payload, function(res) {
    var data = {};
    _.each(res.Data, function(o) {
      data[o.Categoryname_.replace(/[[\s||']||&]/g, '')] = o.Count;
    })
    _.each(fmi.content.chartOriginating.data, function(d, i) {
      if(typeof data[i] != 'undefined') {
        d(data[i]);
      } else {
        d(0);
      }
    })
		// var data = res.Data;
		// var dataSource = [];
		// var orVal = fmi.filter.obBusiness();
		// dataSource = _.map(data, function(o) {
		// 	if(orVal.indexOf(o.Categoryname_) != -1) {
		// 		return {
		// 			customColor : "#0075B2",
		// 			category: o.Categoryname_,
		// 			value: o.Count
		// 		}
		// 	}
		// 	return {
		// 		customColor : "#e8e8ea",
		// 		category: o.Categoryname_,
		// 		value: o.Count
		// 	}
		// })
		// fmi.content.chartOriginating.data(dataSource);
    //
		// generateChart($selector, dataSource, function(e) {
		// 	var chart = $selector.data("kendoChart");
		// 	var currVal = fmi.filter.obBusiness();
		// 	var newVal = [];
		// 	if(currVal.indexOf(e.category) !== -1) {
		// 		newVal = _.without(currVal, e.category);
		// 		e.dataItem.customColor = "#e8e8ea";
		// 		fmi.filter.obBusiness(newVal);
		// 		fmi.init(null, "chartOriginating");
		// 		fmi.updateFilter1();
		// 	} else {
		// 		currVal.push(e.category);
		// 		newVal = currVal;
		// 		e.dataItem.customColor = "#0075B2";
		// 		fmi.filter.obBusiness(newVal);
		// 		fmi.init("chartOriginating");
		// 	}
		// 	fmi.updateOpenedFilter();
		// 	chart.refresh();
		// });
    //
		// fmi.content.chartOriginating.loading(false);
	})
}
fmi.generateAccessCountry = function(uncheck) {
	var payload = fmi.getPayload();
	if(uncheck == "chartAccess")
		payload.Suppliercountry = [];
	var $selector = $(fmi.content.chartAccess.selector);
	fmi.content.chartAccess.loading(true);
	ajaxPost(fmi.content.chartAccess.url, payload, function(res) {
		fmi.summary[3].value(res.Data.length);
		var data = res.Data;
		var dataSource = [];
		var acVal = fmi.filter.iapCountry();
		dataSource = _.map(data, function(o) {
			if(acVal.indexOf(o.FMI_Country_name) != -1) {
				return {
					customColor : "#0075B2",
					category: o.FMI_Country_name,
					value: o.Count
				}
			}
			return {
				customColor : "#e8e8ea",
				category: o.FMI_Country_name,
				value: o.Count
			}
		})
		fmi.content.chartAccess.data(dataSource);
		generateChart($selector, dataSource, function(e) {
			var chart = $selector.data("kendoChart");
			var currVal = fmi.filter.iapCountry();
			var newVal = [];
			if(currVal.indexOf(e.category) !== -1) {
				newVal = _.without(currVal, e.category);
				e.dataItem.customColor = "#e8e8ea";
				fmi.filter.iapCountry(newVal);
				fmi.init(null, "chartAccess");
				fmi.updateFilter2();
			} else {
				currVal.push(e.category);
				newVal = currVal;
				e.dataItem.customColor = "#0075B2";
				fmi.filter.iapCountry(newVal);
				fmi.init("chartAccess");
			}
			fmi.updateOpenedFilter();
      fmi.closeActiveFilter();
			chart.refresh();
		});

		fmi.content.chartAccess.loading(false);
	})
}
fmi.generateFMICountry = function(uncheck) {
	var payload = fmi.getPayload();
	if(uncheck == "chartCountry")
		payload.Fmicountryname = [];
	var $selector = $(fmi.content.chartCountry.selector);
	fmi.content.chartCountry.loading(true);
	ajaxPost(fmi.content.chartCountry.url, payload, function(res) {
		fmi.summary[2].value(res.Data.length);
		var data = res.Data;
		var fmiCountry = fmi.filter.fmiCountry();
		var dataSource = [];
		dataSource = _.map(data, function(o) {
			if(fmiCountry.indexOf(o.FMI_Country_name) != -1) {
				return {
					customColor : "#0075B2",
					category: o.FMI_Country_name,
					value: o.Count
				}
			}
			return {
				customColor : "#e8e8ea",
				category: o.FMI_Country_name,
				value: o.Count
			}
		})
		fmi.content.chartCountry.data(dataSource);
		generateChart($selector, dataSource, function(e) {
			var chart = $selector.data("kendoChart");
			var currVal = fmi.filter.fmiCountry();
			var newVal = [];
			if(currVal.indexOf(e.category) !== -1) {
				newVal = _.without(currVal, e.category);
				e.dataItem.customColor = "#e8e8ea";
				fmi.filter.fmiCountry(newVal);
				fmi.init(null, "chartCountry");
				fmi.updateFilter4();
			} else {
				currVal.push(e.category);
				newVal = currVal;
				e.dataItem.customColor = "#0075B2";
				fmi.filter.fmiCountry(newVal);
				fmi.init("chartCountry");
			}
			fmi.updateOpenedFilter();
      fmi.closeActiveFilter();
			chart.refresh();
		});

		fmi.content.chartCountry.loading(false);
	})
}
fmi.generateCountry = function(uncheck) {
	var $selector = $(fmi.content.receiverCountry.selector);
	var payload = fmi.getPayload();
	if(uncheck == "receiverCountry"){
		payload.Receivercountry = [];
	}
	fmi.content.receiverCountry.loading(true);

	ajaxPost(fmi.content.receiverCountry.url, payload, function(res) {
		var dataSource = [];
		var country = fmi.filter.obCountry();
		dataSource = _.map(res.Data, function(o) {
			if(country.indexOf(o.FMI_Country_name) != -1) {
				return {
					customColor : "#0075B2",
					category: o.FMI_Country_name,
					value: o.Count
				}
			}
			return {
				customColor : "#e8e8ea",
				category: o.FMI_Country_name,
				value: o.Count
			}
		})
		fmi.content.receiverCountry.data(dataSource);
    	generateChart($selector, dataSource, function(e) {
			var chart = $selector.data("kendoChart");
			var currVal = fmi.filter.obCountry();
			var newVal = [];
			if(currVal.indexOf(e.category) !== -1) {
				fmi.filter.obCountry(_.without(currVal, e.category));
				e.dataItem.customColor = "#e8e8ea";
				fmi.init(null, "receiverCountry");
				fmi.updateFilter1();
			} else {
				currVal.push(e.category);
				fmi.filter.obCountry(_.clone(currVal));
				e.dataItem.customColor = "#0075B2";
				fmi.init("receiverCountry");
			}
			fmi.updateOpenedFilter();
			fmi.closeActiveFilter();
			chart.refresh();
		});
		fmi.content.receiverCountry.loading(false);
	})
}

fmi.initChart = function(source, uncheck) {
	if(source) {
		switch (source) {
			case "chartOriginating":
				fmi.generateFMIList();
				fmi.generateFMICountry();
				fmi.generateAccessCountry();
				fmi.generateCountry();
				fmi.reloadSummary();
				fmi.updateFilter1();
				break;
			case "gridFMI":
				fmi.generateOriginating();
				fmi.generateFMICountry();
				fmi.generateAccessCountry();
				fmi.generateCountry();
				fmi.reloadSummary();
				fmi.updateFilter4();
				break;
			case "chartCountry":
				fmi.generateFMIList();
				fmi.generateOriginating();
				fmi.generateAccessCountry();
				fmi.generateCountry();
				fmi.reloadSummary();
				fmi.updateFilter4();
				break;
			case "chartAccess":
				fmi.generateFMIList();
				fmi.generateOriginating();
				fmi.generateFMICountry();
				fmi.generateCountry();
				fmi.reloadSummary();
				fmi.updateFilter2();
				break;
			case "receiverCountry":
				fmi.generateFMIList();
				fmi.generateOriginating();
				fmi.generateFMICountry();
				fmi.generateAccessCountry();
				fmi.reloadSummary();
				fmi.updateFilter1();
				break;
		}
	} else {
		fmi.generateFMIList(uncheck);
		fmi.generateOriginating(uncheck);
		fmi.generateFMICountry(uncheck);
		fmi.generateAccessCountry(uncheck);
		fmi.generateCountry(uncheck);
		fmi.reloadSummary();
	}
}
fmi.initGrid = function() {
	var payload = fmi.getPayload();
	$(".dataGrid").kendoGrid({
		dataSource: {
			transport: {
				read: function(option) {
					var param = {
						Filters: [],
						Logic: ""
					}
					if(typeof option.data.filter != "undefined") {
						var param = {
							Filters: option.data.filter ? option.data.filter.filters : "",
							Logic: "AND"
						}
					}
					payload.Filter = param;
					fmi.grid.Filter = param;
					if(typeof option.data.sort != "undefined") {
						payload.SortField = option.data.sort[0].field;
						payload.SortType = option.data.sort[0].dir == "asc" ? -1 : 1;
						fmi.grid.SortType = option.data.sort[0].dir == "asc" ? -1 : 1;
						fmi.grid.SortField = option.data.sort[0].field;
					} else {
						payload.SortField = "";
						payload.SortType = "";
						fmi.grid.SortType = "";
						fmi.grid.SortField = "";
					}
					payload.ItemPerPage = option.data.take;
					payload.StartPage = option.data.page;
					ajaxPost("/fmi/gettabularview", payload, function(res) {
						option.success({data: res.Data, count: res.Total});
					})
				}
			},
			schema: {
				data: 'data',
				total: 'count'
			},
			serverPaging: true,
			serverSorting: true,
			serverFiltering: true,
			pageSize: 10,
		},
		sortable: true,
		filterable: {
			extra: false,
			operators: {
				string: {
					contains: "Contains",
					startswith: "Starts With",
					eq: "Is Equal to",
					neq: "Is Not Equal to",
					doesnotcontain: "Does Not Contain",
					endswith: "Ends With",
				}
			}
		},
		pageable: {
			numeric: true,
			previousNext: true,
			messages: {
				display: "Showing {2} data items"
			}
		},
		columns: [
			{
				title: "Originating Country",
				field: "receivercountry",
			},
			{
				title: "Originating LE",
				field: "receiverlegalentity",
			},
			{
				title: "Originating Business",
				field: "categoryname_",
			},
			{
				title: "Product",
				field: "productfunction"
			},
			{
				title: "CEF",
				field: "cefcritical",
			},
			{
				title: "Access Country",
				field: "suppliercountry"
			},
			{
				title: "Access LE",
				field: "supplierlegalentity",
			},
			{
				title: "Access Type",
				field: "class2",
			},
			{
				title: "Vendor Name",
				field: "vendorname"
			},
			{
				title: "FMI Country",
				field: "FMi_Country_name",
			},
			{
				title: "FMI Category",
				field: "FMI_CATEGORY_NAME",
			},
			{
				title: "FMI Name",
				field: "suppliername"
			}
		]
	})
}
fmi.initMap = function() {
	if(fmi.mapCenter == ""){
    fmi.initDefaultMap();
  } else{
    if(fmi.filter[fmi.mapCenter+"DD"]() != "") fmi.initDetailMap();
    else fmi.initDefaultMap();
  }
}
fmi.init = function(source, uncheck) {
	console.log("init" + fmi.activePage(), source, uncheck);
	fmi["init"+fmi.activePage()](source, uncheck);
}

fmi.initMapMode = function(mode) {

	if(mode == false) {
		fmi.isObCountryDD(true);
		fmi.isIapCountryDD(true);
		fmi.isFmiCountryDD(false);
	} else {
		fmi.isObCountryDD(true);
		fmi.isFmiCountryDD(true);
		fmi.isIapCountryDD(false);
	}
}
fmi.initMapFilter = function() {
  fmi.resetFilter();
	fmi.isObCountryDD(false);
	fmi.isIapCountryDD(false);
	fmi.isFmiCountryDD(false);
  fmi.isMapModeFC(false);
	fmi.mapCenter = "";
	fmi.mapBranch = "";
}


fmi.initDefaultMap = function() {
  fmi.mapLoader(true);
  var payload = fmi.generateMapPayload();
  ajaxPost("/fmi/getdefaultfmisummarymap", payload, function(res) {
    fmi.generateMap(res);
    fmi.mapLoader(false);
  });
  fmi.generateMapSummary(payload);
}
fmi.initDetailMap = function() {
  fmi.mapLoader(true);
  var payload = fmi.generateMapPayload();
  ajaxPost("/fmi/getfmisummarymap", payload, function(res) {
    fmi.generateDetailMap(res);
    fmi.mapLoader(false);
  });
  fmi.generateMapSummary(payload);
}
fmi.generateMapPayload = function() {
	var payload = fmi.getPayload();
	payload.Center = fmi.mapCenter;
	payload.Branch = fmi.mapBranch;
	if(fmi.mapCenter !== "" && fmi.filter[fmi.mapCenter+"DD"]() !== "")
    payload[fmi.mapCenter.charAt(0).toUpperCase()+fmi.mapCenter.slice(1)] = new Array(fmi.filter[fmi.mapCenter+"DD"]());
	return payload;
}
fmi.resetMapContainer = function() {
  $("#fmiMap").remove();
	$(".map-container").append("<div id='fmiMap'></div>");
}
fmi.generateMap = function(source) {
	fmi.resetMapContainer();
	var greenIcon = L.icon({
		iconUrl: '/live/static/img/marker-green.png',
		iconSize: [20,45]
	})
	var blueIcon = L.icon({
			iconUrl: '/live/static/img/marker-blue.png',
			iconSize:     [20, 45], // size of the icon
	});
	var greyIcon = L.icon({
			iconUrl: '/live/static/img/marker-grey.png',
			iconSize:     [20, 45], // size of the icon
	});

	var grayscale = L.tileLayer(fmi.mapBoxUrl, {
		id: 'mapbox.light',
		attribution: fmi.mapBoxAttr,
		minZoom: 2
	})

	var map = L.map('fmiMap', {
		center: [1,38],
		zoom: 2,
		layers: grayscale,
		zoomControl: false,
	})

	L.control.zoom({
		position: 'topright'
	}).addTo(map);

	var geo = source.features;
	_.each(geo, function(v, i) {
		var icon;
    if(v.properties.count <= 5)
      icon = greyIcon;
    else if(v.properties.count <= 20)
      icon = greenIcon;
    else
      icon = blueIcon;
		var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}).addTo(map);
		marker.Country = v.properties.SecondaryID;
		marker.on('click', function(e) {
			console.log(e);
		})
	})
}
fmi.generateDetailMap = function(source) {
	source = source.Data;
	fmi.resetMapContainer();
	var greenIcon = L.icon({
		iconUrl: '/live/static/img/marker-green.png',
		iconSize: [20,45]
	})
	var blueIcon = L.icon({
			iconUrl: '/live/static/img/marker-blue.png',
			iconSize:     [20, 45], // size of the icon
	});
	var greyIcon = L.icon({
			iconUrl: '/live/static/img/marker-grey.png',
			iconSize:     [20, 45], // size of the icon
	});
	var receiverIcon = L.icon({
		iconUrl: '/live/static/img/receiver-marker2.png',
		iconSize: [20, 30],
	});
  var supplierIcon = L.icon({
		iconUrl: '/live/static/img/supplier-marker2.png',
		iconSize: [20, 30],
	});
  var fmiIcon = L.icon({
		iconUrl: '/live/static/img/fmicountry-icon.png',
		iconSize: [20, 30],
	});

	var grayscale = L.tileLayer(fmi.mapBoxUrl, {
		id: 'mapbox.light',
		attribution: fmi.mapBoxAttr,
		minZoom: 2
	})

	var map = L.map('fmiMap', {
		center: [1,38],
		zoom: 2,
		layers: grayscale,
		zoomControl: false,
	})

	L.control.zoom({
		position: 'topright'
	}).addTo(map);

	var dataInfo = source.BoxInfo[0];
	var path = [];
	var allSupplier = {"SupplierName": 0,"FunctionName":0,"LevelOne":0, "count":0, "FMI":0};
	var geo = source.BubbleSupplier.features;
	_.each(geo, function(v, i) {
		if(dataInfo.Latitude == v.geometry.coordinates[1] && dataInfo.Longitude == v.geometry.coordinates[0]){
			allSupplier = _.extend({}, v.properties);
		} else {
			var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: greyIcon}).addTo(map);
      var titleTemplate = "";
      switch (fmi.mapBranch) {
        case "receivercountry":
          titleTemplate = "Receiver Country";
          break;
        case "suppliercountry":
          titleTemplate = "Supplier Country";
          break;
        case "fmicountryname":
          titleTemplate = "FMI Country";
          break;
      }
			var templatePopUp = ["<span style='color:#0644a0'>"+ titleTemplate +" Data</span>",
													"<a href='#"+(titleTemplate == "Receiver" ? "primary" : "secondary")+"_"+v.properties.SecondaryID.replace(/[\s||']/g, '')+"'><b>"+ v.properties.SecondaryID + "</b></a>",
													"# of Suppliers : <a onclick='fmi.mapDetailPopup(\""+v.properties.SecondaryID+"\", \"suppliername\", "+v.properties.SupplierName+")' href='#'>"+v.properties.SupplierName+" </a>",
													"# of Functions : <a onclick='fmi.mapDetailPopup(\""+v.properties.SecondaryID+"\", \"functionname\", "+v.properties.FunctionName+")' href='#'>"+v.properties.FunctionName+"  </a>",
													"# of Level 1 Processes : <a onclick='fmi.mapDetailPopup(\""+v.properties.SecondaryID+"\", \"parentprocessname\", "+v.properties.LevelOne+")' href='#'> "+v.properties.LevelOne+"  </a>",
													"# of FMI  : <a onclick='fmi.mapDetailFMIModal(\""+v.properties.SecondaryID+"\", "+v.properties.FMI+")' href='#'> "+v.properties.FMI+"  </a>",
													"# of Vendors :  <a onclick='fmi.mapDetailPopup(\""+v.properties.SecondaryID+"\", \"vendorname\", "+v.properties.Vendor+")' href='#'> "+v.properties.Vendor+" </a>",
													"<a href='#' onclick='fmi.mapMoreDetailModal(\""+v.properties.SecondaryID+"\", "+v.properties.FMI+")'>Details</a>"].join("<br>");
			marker.bindPopup(templatePopUp);
			marker.on('mouseover', function(e) {
				this.openPopup();
			});
			latSelisih = Math.abs( Math.abs(dataInfo.Latitude) -  Math.abs(v.geometry.coordinates[1]))
			lngSelisih = Math.abs( Math.abs(dataInfo.Longitude) -  Math.abs(v.geometry.coordinates[0]))
			var x = 0;
			if(latSelisih >= 1 && latSelisih <= 5){
				if (lngSelisih >= 1 && lngSelisih <= 5 ){
						x = 1
				}else if (lngSelisih > 5 && lngSelisih <= 16 ){
						x = 4
				}else{
						x = 9
				}
			}else if(latSelisih > 5 && latSelisih <= 10 ){
				if (lngSelisih >= 1 && lngSelisih <= 5 ){
						x = 1
				}else if (lngSelisih > 5 && lngSelisih <= 10 ){
						x = 4
				}else{
						x = 9
				}
			}else if ((latSelisih > 10 && latSelisih <= 15 ) && (lngSelisih > 10 && lngSelisih <= 15 ) ){
				x = 10
			}else{
				if (lngSelisih >= 1 && lngSelisih <= 5 ){
						x = 1
				}else if (lngSelisih > 5 && lngSelisih <= 10 ){
						x = 4
				}else{
						x = 9
				}
			}

			latCenter = ((dataInfo.Latitude + v.geometry.coordinates[1]) / 2) + x

			if(Math.abs(lngSelisih <= 15)){
					lngCenter = ((dataInfo.Longitude + v.geometry.coordinates[0]) / 2 ) + x

			}else{
					lngCenter = ((dataInfo.Longitude + v.geometry.coordinates[0]) / 2 )
			}

			path.push(L.curve(['M',[dataInfo.Latitude,dataInfo.Longitude ],
													'Q',[latCenter,lngCenter],
															[v.geometry.coordinates[1],v.geometry.coordinates[0]]],{color:v.properties.Color}).addTo(map));
		}
	})
  var centerTitle = fmi.mapCenter.substr(0, fmi.mapCenter.indexOf("country"));
  centerTitle = centerTitle.charAt(0).toUpperCase() + centerTitle.slice(1);
  var branchTitle = fmi.mapBranch.substr(0, fmi.mapBranch.indexOf("country"));
  branchTitle = branchTitle.charAt(0).toUpperCase() + branchTitle.slice(1);

	var templatePopUpReceivingCountry =
											[
										 "<a href='#"+(centerTitle == "Receiver" ? "primary" : "secondary")+"_"+fmi.filter[fmi.mapCenter+"DD"]().replace(/[\s||']/g, '')+"'><b>"+ fmi.filter[fmi.mapCenter+"DD"]()+ "</b></a><span style='color:#0644a0'> as "+ (centerTitle == "Fmi" ? centerTitle.toUpperCase() : centerTitle) +"</span>",
											"# of Suppliers : <a onclick='fmi.mapDetailPopup(\"\", \"suppliername\", "+dataInfo.SupplierName+")' href='#'>"+dataInfo.SupplierName+"</a>",
											"# of Functions : <a onclick='fmi.mapDetailPopup(\"\", \"functionname\", "+dataInfo.FunctionName+")' href='#'>"+dataInfo.FunctionName+"</a>",
											"# of Level 1 Processes : <a onclick='fmi.mapDetailPopup(\"\", \"parentprocessname\", "+dataInfo.LevelOne+")' href='#'>"+dataInfo.LevelOne+" </a>",
											"# of FMI : <a onclick='fmi.mapDetailFMIModal(\"\", "+dataInfo.FMI+")' href='#'> "+dataInfo.FMI+"  </a>",
											 "# of Vendors : <a onclick='fmi.mapDetailPopup(\"\", \"vendorname\", "+dataInfo.Vendor+")' href='#'>"+dataInfo.Vendor+"  </a>",
											"<a href='#' onclick='fmi.mapMoreDetailModal(\"\", "+dataInfo.FMI+")'>Details</a></br>",

											"<a href='#"+(branchTitle == "Receiver" ? "primary" : "secondary")+"_"+fmi.filter[fmi.mapCenter+"DD"]().replace(/[\s||']/g, '')+"'><b>"+ fmi.filter[fmi.mapCenter+"DD"]() + "</b></a><span style='color:#0644a0'> as  "+ (branchTitle == "Fmi" ? branchTitle.toUpperCase() : branchTitle) +"</span>",
											"# of Suppliers : <a onclick='fmi.mapDetailPopup(\""+fmi.filter[fmi.mapCenter+"DD"]()+"\", \"suppliername\", "+allSupplier.SupplierName+")' href='#'>"+ allSupplier.SupplierName+"</a>",
											"# of Functions : <a onclick='fmi.mapDetailPopup(\""+fmi.filter[fmi.mapCenter+"DD"]()+"\", \"functionname\", "+allSupplier.FunctionName+")' href='#'>"+ allSupplier.FunctionName+"</a>",
											"# of Level 1 Processes : <a onclick='fmi.mapDetailPopup(\""+fmi.filter[fmi.mapCenter+"DD"]()+"\", \"parentprocessname\", "+allSupplier.LevelOne+")' href='#'>"+allSupplier.LevelOne+"</a>",
											"# of FMI : <a onclick='fmi.mapDetailFMIModal(\""+fmi.filter[fmi.mapCenter+"DD"]()+"\", "+allSupplier.FMI+")' href='#'> "+allSupplier.FMI+"  </a>",
											"# of Vendors : <a onclick='fmi.mapDetailPopup(\""+fmi.filter[fmi.mapCenter+"DD"]()+"\", \"vendorname\", "+allSupplier.Vendor+")' href='#'> "+(allSupplier.Vendor ? allSupplier.Vendor : 0)+"  </a>",
											"<a onclick='fmi.mapMoreDetailModal(\""+fmi.filter[fmi.mapCenter+"DD"]()+"\", "+allSupplier.FMI+")' href='#'>Details</a>"
											]
											.join("<br>");
  var icon;
  if(fmi.mapCenter == "suppliercountry") icon = supplierIcon;
  else if(fmi.mapCenter == "receivercountry") icon = receiverIcon;
  else if(fmi.mapCenter == "fmicountryname") icon = fmiIcon;
	var mainMarker = L.marker([dataInfo.Latitude, dataInfo.Longitude], {icon: icon})
										.addTo(map)
										.bindPopup(templatePopUpReceivingCountry)
										.openPopup();
	mainMarker.on('mouseover', function(e) {
		this.openPopup();
	});
}

fmi.expandSummary = function(type,index){
    return function(){
      var classUp = 'glyphicon-chevron-up'
      var classDown = 'glyphicon-chevron-down'
       $("#"+type+"-legal_"+index).slideToggle( "slow", function() {
            $("#"+type+"-expand-"+index).hasClass(classDown) ? $("#"+type+"-expand-"+index).addClass(classUp).removeClass(classDown): $("#"+type+"-expand-"+index).addClass(classDown).removeClass(classUp);
       });
    }
};
fmi.generateMapSummary = function(payload) {
  fmi.mapSummaryLoader(true);
  ajaxPost("/fmi/getsummaryfmi", payload, function(res) {
    fmi.mapPrimarySummary(res.Primary);
    fmi.mapSecondarySummary(res.Secondary);
    fmi.generateDonutSummary();
  })
}
fmi.generateDonutSummary = function() {
  var primary = fmi.mapPrimarySummary();
  var secondary = fmi.mapSecondarySummary();
  var color=["#00506D","#0077A3","#0075B2"];
  var donutCategory = {
    "OCIRCompliant": "OCIR Compliant",
    "NoSLA" : "No SLA",
    "NonCompliantSLA": "Non-Compliant SLA",
  };
  _.each(primary, function(o, i) {
    var data = [];
    _.each(o.DetailsDonut, function(d, idx) {
      data.push({
        category: d.category,
        value: d.value,
        color: color[idx],
        visible: true
      })
      var dataItem = donutCategory[d.category];
      var percentage = (Math.abs(d.value) != 0) ? 100 / (o.TotalDonut / d.value) : 0;
      $("#legend-donut_primary_"+i+" ul").append("<li><a onClick='fmi.configSeries("+i+","+idx+",\"fmi_receiver\")'><div class='square' style='background:"+color[idx]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-primary-precentage_"+ i +"_"+idx+"'></span></a></li>");
      $("#legend-donut-primary-precentage_"+ i +"_"+idx).text(percentage.toFixed(0)+"%")
    })

    var clickHandler = function(e) {
      var payload = fmi.generateMapPayload();
      payload.Typedonut = donutCategory[e.category];
      payload.Receivercountry = [o.Country];

      fmi.mapDetailDonutPopup(payload);
    }

    var config = ko.mapping.toJS(fmi.configDonut);
    config.series[0].data = data;
    config.seriesClick = clickHandler;
    config.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",

    $("#donut_primary_"+i).kendoChart(config);

    _.each(o.DetailsLegal, function(l, idxL) {
      var legalData = [];
      _.each(l.DetailsDonut, function(d, idx) {
        legalData.push({
          category: d.category,
          value: d.value,
          color: color[idx],
          visible: true
        })
        var dataItem = donutCategory[d.category];
        var percentage = (Math.abs(d.value) != 0) ? 100 / (o.TotalDonut / d.value) : 0;
        $("#legend-donut_primary-entity_"+(i+"-"+idxL)+" ul").append("<li><a onClick='fmi.configSeries("+idxL+","+idx+",\"fmi_receiver\")'><div class='square' style='background:"+color[idx]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-primary-entity-precentage_"+ idxL +"_"+idx+"'></span></a></li>");
        $("#legend-donut-primary-entity-precentage_"+ idxL +"_"+idx).text(percentage.toFixed(0)+"%")
      })

      var legalClickHandler = function(e) {
        var payload = fmi.generateMapPayload();
        payload.Typedonut = donutCategory[e.category];
        payload.Receivercountry = [o.Country];
        payload.Supplierlegalentity = [l.CountryLegal.split(" ~ ")[0]];

        fmi.mapDetailDonutPopup(payload);
      }

      var configLegalDonut = ko.mapping.toJS(fmi.configDonut);
      configLegalDonut.series[0].data = legalData;
      configLegalDonut.seriesClick = legalClickHandler;
      configLegalDonut.legend.labels.template ="#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
      $("#donut_primary-entity_"+(i+"-"+idxL)).kendoChart(configLegalDonut);
    })
  })




  _.each(secondary, function(o, i) {
    var data = [];
    _.each(o.DetailsDonut, function(d, idx) {
      data.push({
        category: d.category,
        value: d.value,
        color: color[idx],
        visible: true
      })
      var dataItem = donutCategory[d.category];
      var percentage = (Math.abs(d.value) != 0) ? 100 / (o.TotalDonut / d.value) : 0;
      $("#legend-donut_secondary_"+i+" ul").append("<li><a onClick='fmi.configSeries("+i+","+idx+",\"fmi_receiver\")'><div class='square' style='background:"+color[idx]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-secondary-precentage_"+ i +"_"+idx+"'></span></a></li>");
      $("#legend-donut-secondary-precentage_"+ i +"_"+idx).text(percentage.toFixed(0)+"%")
    })
    var clickHandler = function(e) {
      var payload = fmi.generateMapPayload();
      payload.Typedonut = donutCategory[e.category];
      if(fmi.isMapModeFC()) payload.Fmicountryname = [o.Country];
      else payload.Suppliercountry = [o.Country];
      fmi.mapDetailDonutPopup(payload);
    }

    var config = ko.mapping.toJS(fmi.configDonut);
    config.series[0].data = data;
    config.seriesClick = clickHandler;
    config.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",

    $("#donut_secondary_"+i).kendoChart(config);

    _.each(o.DetailsLegal, function(l, idxL) {
      var legalData = [];
      _.each(l.DetailsDonut, function(d, idx) {
        legalData.push({
          category: d.category,
          value: d.value,
          color: color[idx],
          visible: true
        })
        var dataItem = donutCategory[d.category];
        var percentage = (Math.abs(d.value) != 0) ? 100 / (o.TotalDonut / d.value) : 0;
        $("#legend-donut_secondary-entity_"+(i+"-"+idxL)+" ul").append("<li><a onClick='fmi.configSeries("+idxL+","+idx+",\"fmi_receiver\")'><div class='square' style='background:"+color[idx]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-secondary-entity-precentage_"+ idxL +"_"+idx+"'></span></a></li>");
        $("#legend-donut-secondary-entity-precentage_"+ idxL +"_"+idx).text(percentage.toFixed(0)+"%")
      })

      var legalClickHandler = function(e) {
        var payload = fmi.generateMapPayload();
        payload.Typedonut = donutCategory[e.category];
        if(fmi.isMapModeFC()) payload.Fmicountryname = [o.Country];
        else payload.Suppliercountry = [o.Country];
        payload.Supplierlegalentity = [l.CountryLegal.split(" ~ ")[0]]

        fmi.mapDetailDonutPopup(payload);
      }

      var configLegalDonut = ko.mapping.toJS(fmi.configDonut);
      configLegalDonut.series[0].data = legalData;
      configLegalDonut.seriesClick = legalClickHandler;
      configLegalDonut.legend.labels.template ="#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
      $("#donut_secondary-entity_"+(i+"-"+idxL)).kendoChart(configLegalDonut);
    })
  })

  fmi.mapSummaryLoader(false);
}
fmi.mapDetailDonutPopup = function(payload) {
  var url = "/fmi/getgriddonutfmi";
  var $modal = $("#summaryMapDetail");
  $modal.find("#contentSummaryMap").html("");
  $modal.find("#contentSummaryMap").kendoGrid({
    dataSource: {
      transport: {
        read: function(opt) {
          ajaxPost(url, payload, function(res) {
            opt.success(res);
            $modal.modal('show');
          })
        },
      },
      sort: [
          {field:"receivercountry",dir:"asc"},
          {field:"suppliercountry",dir:"asc"},
          {field:"categoryname_",dir:"asc"},
          {field:"productfunction",dir:"asc"},
          {field:"parentprocessname",dir:"asc"},
          {field:"processname",dir:"asc"},
          {field:"servicedescription",dir:"asc"},
          {field:"barriertype",dir:"asc"},
      ],
    },
    columns: [
      {
           field:"receivercountry",
           title:'Receiver Country',
           width:180,
           headerAttributes: {
               "class": "text-left"
           },
           template: "#= receivercountry + ' - ' + receiverlegalentity #",
       },
       {
           field:"suppliercountry",
           title:'Supplier Country',
           width:180,
           headerAttributes: {
               "class": "text-left"
           },
           template: "#= suppliercountry + ' - ' + supplierlegalentity #",
       },
       {
           field:"categoryname_",
           title:'Business',
           width:130,
           headerAttributes: {
               "class": "text-left"
           }
       },
       {
           field:"productfunction",
           title:'Product',
           width:130,
           headerAttributes: {
               "class": "text-left"
           }
       },
       {
           field:"parentprocessname",
           title:'Level 1 Process',
           width:250,
           headerAttributes: {
               "class": "text-left"
           }
       },
       {
           field:"processname",
           title:'Level 2 Process',
           width:250,
           attributes: {
               "class": "field-ellipsis"
           },
           headerAttributes: {
               "class": "text-left"
           }
       },
       {
           field:"servicedescription",
           title:'Service Description',
           width:250,
           headerAttributes: {
               "class": "align-left"
           }
       },
       {
           field:"barriertype",
           title:'Barrier Type',
           width:130,
           headerAttributes: {
               "class": "align-left"
           }
       }
    ],
    excel: {
        fileName: "PopUpFMIGroupDonut.xlsx",
        allPages: true
    },
    sortable: true,
    pageable: {
        numeric: false,
        previousNext: false,
        messages: {
            display: "Showing {2} data items"
        }
    },
    filterable: {
        extra:false,
        operators: {
            string: {
                contains: "Contains",
                startswith: "Starts with",
                eq: "Is equal to",
                neq: "Is not equal to",
                doesnotcontain: "Does not contain",
                endswith: "Ends with"
            },
        }
    },
  });
}
fmi.summaryMapExport = function() {
  var grid = $("#contentSummaryMap").data("kendoGrid");
  grid.saveAsExcel();

}

fmi.mapDetailPopup = function(country, field, val){
  if(typeof val == 'undefined' || val == 0)
    return false
  var payload = fmi.generateMapPayload();
  payload.DetailField = field;
  payload[fmi.mapBranch.charAt(0).toUpperCase()+fmi.mapBranch.slice(1)] = country == "" ? payload[fmi.mapBranch.charAt(0).toUpperCase()+fmi.mapBranch.slice(1)] : [country];
  fmi.mapDetailField = field;
  fmi.mapDetailCountry = country == "" ? [] : [country];
  fmi.mapExportUrl = "/fmi/getdetailtooltipexcel";
  var colName = "";
  switch (field) {
    case "functionname":
      colName = "Function Name";
      break;
    case "receiverlegalentity":
      colName = "Receiver Legal Entity"
      break;
    case "supplierlegalentity":
      colName = "Supplier Legal Entity"
      break;
    case "parentprocessname":
      colName = "Level 1 Process"
      break;
    case "suppliername":
      colName = "Supplier Name"
      break;
    case "receivername":
      colName = "Receiver Name"
      break;
    case "receivercountry":
      colName = "Receiver Country"
      break;
    case "suppliercountry":
      colName = "Supplier Country"
      break;
    case "vendorname":
      colName = "Vendor Name"
      break;
  }
  fmi.mapLoader(true);
  var url = "/fmi/getdetailtooltip";
  var $modal = $("#mapDetailModal");
  $modal.find("#contentDetailMap").html("");
  $modal.find("#contentDetailMap").kendoGrid({
    dataSource: {
      transport: {
        read: function(opt) {
          ajaxPost(url, payload, function(res) {
            opt.success(_.map(res.Data, function(o) {return {_id: o}}));
            $modal.modal('show');
            fmi.mapLoader(false);
          })
        },
      }
    },
    columns: [{
      title: colName,
      field: '_id'
    }],
    excel: {
        fileName: colName + " FMI Receiver.xlsx",
        allPages: true
    },
    pageable: {
        numeric: false,
        previousNext: false,
        messages: {
            display: "Showing {2} data items"
        }
    },
    filterable: {
      extra: false,
      operators: {
        string: {
          contains: "Contains",
          startswith: "Starts With",
          eq: "Is equal to",
          neq: "Is not equal to",
          doesnotcontain: "Does not contain",
          endswith: "Ends with"
        }
      }
    }
  });
}
fmi.mapDetailFMIModal = function(country, val) {
  if(typeof val == 'undefined' || val == 0)
    return false
  var payload = fmi.generateMapPayload();
  payload.DetailField = "FMI";
  fmi.mapDetailField = "FMI";
  payload[fmi.mapBranch.charAt(0).toUpperCase()+fmi.mapBranch.slice(1)] = country == "" ? payload[fmi.mapBranch.charAt(0).toUpperCase()+fmi.mapBranch.slice(1)] : [country];
  fmi.mapDetailCountry = country == "" ? [] : [country];
  fmi.mapExportUrl = "/fmi/getfmidetailtooltipexcel";
  var url = "/fmi/getfmitooltip";
  var $modal = $("#fmiDetailModal");
  $modal.find("#contentFMIDetailMap").html("");
  fmi.mapLoader(true);
  $modal.find("#contentFMIDetailMap").kendoGrid({
    dataSource: {
      transport: {
        read: function(opt) {
          ajaxPost(url, payload, function(res) {
            opt.success(res.Data);
            $modal.modal('show');
            fmi.mapLoader(false);
          })
        }
      }
    },
    columns: [
      {
        title: "FMI Name",
        field: "_id.suppliername"
      },
      {
        title: "FMI Type",
        field: "_id.FMI_CATEGORY_NAME"
      },
      {
        title: "FMI Transaction Amount",
        field: "FMI_Transaction_Amount",
        format:"{0:N0}",
        attributes: {
          class: "text-right",
        },
      },
      {
        title: "FMI Transaction Volume",
        field: "FMI_Transaction_Volume",
        format:"{0:N0}",
        attributes: {
          class: "text-right",
        },
      }
    ],
    sortable: true,
    excel: {
        fileName: "FMI Receiver.xlsx",
        allPages: true
    },
    pageable: {
        numeric: false,
        previousNext: false,
        messages: {
            display: "Showing {2} data items"
        }
    },
    filterable: {
      extra: false,
      operators: {
        string: {
          contains: "Contains",
          startswith: "Starts With",
          eq: "Is equal to",
          neq: "Is not equal to",
          doesnotcontain: "Does not contain",
          endswith: "Ends with"
        }
      }
    }
  })
}
fmi.mapMoreDetailModal = function(country, val) {
  if(typeof val == 'undefined' || val == 0)
    return false
  var payload = fmi.generateMapPayload();
  payload[fmi.mapBranch.charAt(0).toUpperCase()+fmi.mapBranch.slice(1)] = country == "" ? payload[fmi.mapBranch.charAt(0).toUpperCase()+fmi.mapBranch.slice(1)] : [country];
  fmi.mapDetailField = "";
  fmi.mapDetailCountry = country == "" ? [] : [country];
  fmi.mapExportUrl = "/fmi/getmoredetailtooltipexcel";
  var url = "/fmi/getmoredetailtooltip";
  var $modal = $("#mapDetailModal");
  $modal.find("#contentDetailMap").html("");
  fmi.mapLoader(true);
  $modal.find("#contentDetailMap").kendoGrid({
    dataSource: {
      transport: {
        read: function(opt) {
          ajaxPost(url, payload, function(res) {
            opt.success(res.Data);
            $modal.modal('show');
            fmi.mapLoader(false);
          })
        },
      },
      sort: [
          {field:"_id.suppliername",dir:"asc"},
          {field:"_id.suppliercountry",dir:"asc"},
          {field:"_id.supplierlegalentity",dir:"asc"},
          {field:"_id.FMI_CATEGORY_NAME",dir:"asc"},
          {field:"_id.FMI_Access_Type",dir:"asc"}
      ],
    },
    columns: [
      {
        title: "FMI Name",
        width: 170,
        field: "_id.suppliername"
      },
      {
        title: "Receiver Country",
        width: 170,
        field: "_id.receivercountry"
      },
      {
        title: "Receiver Legal Entity",
        width: 170,
        field: "_id.receiverlegalentity"
      },
      {
        title: "FMI Country Name",
        width: 170,
        field: "_id.FMi_Country_name"
      },
      {
        title: "Supplier Country",
        width: 170,
        field: "_id.suppliercountry"
      },
      {
        title: "Supplier Legal Entity",
        width: 170,
        field: "_id.supplierlegalentity"
      },
      {
        title: "FMI Type",
        width: 170,
        field: "_id.FMI_CATEGORY_NAME"
      },
      {
        title: "Access Type",
        width: 170,
        field: "_id.FMI_Access_Type"
      },
      {
        title: "Vendor",
        width: 170,
        field: "_id.vendorname",
        template: function(e){
            if(e._id.vendorname == "")
                return "Not Available";
            return e._id.vendorname;
        },
      },
      {
        title: "FMI Transaction Amount",
        field: "FMI_Transaction_Volume",
        width: 170,
        format:"{0:N0}",
        attributes: {
          class: "text-right",
        },
      },
      {
        title: "FMI Transaction Volume",
        field: "FMI_Transaction_Volume",
        width: 170,
        format:"{0:N0}",
        attributes: {
          class: "text-right",
        },
      }
    ],
    sortable: true,
    excel: {
        fileName: "Detail FMI.xlsx",
        allPages: true
    },
    pageable: {
        numeric: false,
        previousNext: false,
        messages: {
            display: "Showing {2} data items"
        }
    },
    filterable: {
      extra: false,
      operators: {
        string: {
          contains: "Contains",
          startswith: "Starts With",
          eq: "Is equal to",
          neq: "Is not equal to",
          doesnotcontain: "Does not contain",
          endswith: "Ends with"
        }
      }
    }
  });
}
fmi.exportDetail = function(e) {
  var payload = fmi.generateMapPayload();
  payload.Suppliercountry = fmi.mapDetailCountry;
  payload.DetailField = fmi.mapDetailField;
  fmi.mapExportLoader(true);
	ajaxPost(fmi.mapExportUrl, payload, function(res) {
		var interval = setInterval(function() {
			ajaxPost("/ocirtranchev2/getjobstatus", {Jobid: res.msg}, function(r) {
				if(r.status == "Done") {
					clearInterval(interval);
					fmi.mapExportLoader(false);
					redirectUrl("/static/temp/databrowser/"+res.msg)
				}
			})
		}, 2000)
		interval;
	})
}

fmi.receivercountryDDUpdate = function(val) {
  fmi.filter.receivercountryDD(val);
  fmi.mapCenter = 'receivercountry';
	if(fmi.isMapModeFC() == false) {
		fmi.isIapCountryDD(false);
		fmi.mapBranch = "suppliercountry";
	} else {
		fmi.isFmiCountryDD(false);
		fmi.mapBranch = "fmicountryname";
	}
  if(val == "") {
    fmi.initMapMode(fmi.isMapModeFC());
    fmi.filter.obCountry([]);
  } else {
    fmi.filter.obCountry([val]);
  }
  fmi.changeFilter1('obCountry');
}
fmi.fmicountrynameDDUpdate = function(val, reinit = true) {
  fmi.filter.fmicountrynameDD(val);
  fmi.mapCenter = "fmicountryname";
	fmi.mapBranch = "receivercountry";
	fmi.isObCountryDD(false);
  if(val == "") {
    fmi.initMapMode(fmi.isMapModeFC());
    fmi.filter.fmiCountry([]);
  } else {
    fmi.filter.fmiCountry([val]);
  }
  fmi.changeFilter4('fmiCountry', reinit);
}
fmi.suppliercountryDDUpdate = function(val, reinit = true) {
  fmi.filter.suppliercountryDD(val);
  fmi.isObCountryDD(false);
	fmi.mapCenter = "suppliercountry";
	fmi.mapBranch = "receivercountry";
  if(val == "") {
    fmi.initMapMode(fmi.isMapModeFC());
    fmi.filter.iapCountry([]);
  } else {
    fmi.filter.iapCountry([val]);
  }
  fmi.changeFilter2('iapCountry', reinit);
}


fmi.export = function() {
	var payload = fmi.getPayload();
	payload = _.extend(payload, fmi.grid);
	fmi.loaderExport(true);
	ajaxPost("/fmi/getexceldefault", payload, function(res) {
		var interval = setInterval(function() {
			ajaxPost("/ocirtranchev2/getjobstatus", {Jobid: res.msg}, function(r) {
				if(r.status == "Done") {
					clearInterval(interval);
					fmi.loaderExport(false);
					redirectUrl("/static/temp/databrowser/"+res.msg)
				}
			})
		}, 2000)
		interval;
	})
}

$(function() {
	fmi.initFilter();
	fmi.init();
	$(document).click(function(e) {
	  if(!$(e.target).closest('.arrow').length && !$(e.target).closest('.k-list-container').length) {
	    fmi.closeActiveFilter();
	  }
	});
})
