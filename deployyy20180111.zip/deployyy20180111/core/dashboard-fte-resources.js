var dfr = {}

dfr.receivingCountry     = ko.observable("");
dfr.receivingCountryList = ko.observableArray([]);

dfr.receivingLegalEntity     = ko.observableArray([]);
dfr.receivingLegalEntityList = ko.observableArray([]);

dfr.receivingBusiness     = ko.observable([]);
dfr.receivingBusinessList = ko.observableArray([]);

dfr.onchangeReceivingLegalEntity = ko.observable(true);
dfr.onchangeReceivingBusiness = ko.observable(true);

dfr.labelReceivingCountry =  ko.observable('GLobal');
dfr.showAnalyze = ko.observable(false)
dfr.summaryCountryDetails  = ko.mapping.fromJS([]);
dfr.summaryEntitiesDetails = ko.mapping.fromJS([]);

dfr.receiverviewValue = ko.observable('');
dfr.chekboxCountry = ko.observable();
dfr.chekboxLegal = ko.observable();
dfr.clickSupplierIndex = 0;
dfr.slideMax    = ko.observable('');
dfr.slideValue  = ko.observable('');
dfr.loadingMap  = ko.observable(false);
dfr.indexingAjax = {
    receiverSummary: ko.observable(0)
}

dfr.receivingPrepareMap = function(){
    $('#map-receiving').remove();
    $(".panelMap").append("<div id='map-receiving' class='map'> </div>");    
}

dfr.receivingMapDetails = function(dataSource){
    dfr.receivingPrepareMap();
    setTimeout(function(){
        var geoJson = dataSource.BubbleSupplier.features; 
        var zoom = 10;
      
        
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});


        var zoom = 10;
        var marker = [];
        $.each(geoJson, function(i,v){
            if(v.properties['FTE'] <= 50){
                var icon = dashboard.mapGreyIcon;
            }else if(v.properties['FTE']  <= 500){
                var icon = dashboard.mapGreenIcon;
            }  else {
                var icon = dashboard.mapBlueIcon; 
            }

            marker.push(L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}));
            if(v.geometry.coordinates[0] === 0 && v.geometry.coordinates[1] === 0){
               v.geometry.coordinates[1] = dataSource.BoxInfo.Latitude;
               v.geometry.coordinates[0] = dataSource.BoxInfo.Longitude;
               zoom = 7;
            }

            var FTE = kendo.toString(v.properties['FTE'],"n2")
            var templatePopUp = [
                "<b>Building Name : </b>" +  v.properties['SecondaryID'],
                "<b>FTE : </b>" + FTE].join("<br>")  ; 
            marker[i].bindPopup(templatePopUp);
            marker[i].on('mouseover', function (e) {
                this.openPopup();
            });
          
        }) 

        zoom +=   dataSource.BoxInfo.Zoom  

        var map = L.map('map-receiving', {
            center: [dataSource.BoxInfo.Latitude,dataSource.BoxInfo.Longitude],
            zoom: zoom,
            layers: grayscale,
            zoomControl: false,
        })
        L.control.zoom({
             position:'topright'
        }).addTo(map);
        for(var i in marker){
            marker[i].addTo(map)
        }
    }, 100);
};

dfr.receivingMap = function(dataSource){
    dfr.receivingPrepareMap()
    setTimeout(function(){
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});
        var map = L.map('map-receiving', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
            zoomControl: false,
        })
        L.control.zoom({
             position:'topright'
        }).addTo(map);
        map.options.minZoom = 2;


        var geoJson = dataSource.features;
        $.each(geoJson, function(i,v){
            if(v.properties.count <= 5){
                var icon = dashboard.mapGreenIcon;
            }else if(v.properties.count <= 20){
                var icon = dashboard.mapGreenIcon;
            }  else {
                var icon = dashboard.mapBlueIcon ; 
            }
         
            var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}).addTo(map);
            marker.Country = v.properties.SecondaryID
            // marker.bindPopup(templatePopUp);
            marker.on('mouseover', function (e) {
                this.openPopup();
            });
            marker.on('click', function(e){ 
                dfr.receivingCountry(e.target.Country);
                dfr.receivingGetData();
            });
        }) 
    }, 100);   
};

 

dfr.createEntitiesSummary = function(dataSource){
    ko.mapping.fromJS(dataSource,dfr.summaryEntitiesDetails) 
};
 
dfr.receivingGetData = function(){
  var payload;
	if(dfr.receivingCountry() == ''){
    var payload={
      Business :  dfr.receivingBusiness(),
      LegalEntity : dfr.receivingLegalEntity()
    }
		   
    
    var url = "/receiverview/getdefaultreceivernew";
    dfr.loadingMap(true);
    ajaxPost(url, payload, function (res){
          
        dfr.loadingMap(false);
        dfr.receivingMap(res);
        // setTimeout(function(){

        // },100)
   	});

    dfr.labelReceivingCountry('Global')
    dfr.showAnalyze (false)
    var url = "/receiverview/summaryfteresourcedefault";
    var payloadSummary = _.clone(payload);
    increaseIndexingAjx(dfr.indexingAjax.receiverSummary);
    payloadSummary.Index = dfr.indexingAjax.receiverSummary();  
    
    ajaxPost(url, payloadSummary , function (res){
      if(res.Index != dfr.indexingAjax.receiverSummary())
            return;  
      ko.mapping.fromJS(res.Country,dfr.summaryCountryDetails)  
      dfr.createDonut(res.Country)
    });
	}else{
		payload = {
      Business :  dfr.receivingBusiness(),
      ReceivingCountry :  dfr.receivingCountry(),
      LegalEntity : dfr.receivingLegalEntity()
    }  
       var url = "/receiverview/getdetailsreceivernew";
    ajaxPost(url, payload, function (res){
     
      dfr.receivingMapDetails(res)
    });
    
    dfr.labelReceivingCountry(dfr.receivingCountry()) 
    dfr.showAnalyze (true)
    ajaxPost("/receiverview/summaryfteresource",payload , function (res){
        ko.mapping.fromJS(res.Country,dfr.summaryCountryDetails)   
        ko.mapping.fromJS(res.CountryLegal,dfr.summaryEntitiesDetails)  
        dfr.createDonut(res.Country)
        dfr.createEntitiesDonut(res.CountryLegal)
    });
	}
  localStorage.setItem('filter', JSON.stringify(payload));
};
dfr.getReceivingCountry = function(){
    var payload = {
        Business :  dfr.receivingBusiness(),
        LegalEntity : dfr.receivingLegalEntity()
    
    };
    var url = "/receiverview/getreceiverfte";
    ajaxPost(url,payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        dfr.receivingCountryList(receivingCountries);
    });
};

dfr.getReceivingLegalEntity = function(){
    var payload = {
        ReceivingCountry : dfr.receivingCountry(), 
        Business :  dfr.receivingBusiness()
    
    };
    var url = "/receiverview/getlegalentityfte";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        
        dfr.receivingLegalEntityList(legalEntities) 
    });
};

dfr.getReceivingBusiness = function(){
    var payload = {
        ReceivingCountry : dfr.receivingCountry(),
        LegalEntity : dfr.receivingLegalEntity()
    };
    ajaxPost("/receiverview/getteamfunctionname",payload, function (res){
        var bussiness = [];
        $.each(res, function(i,v){
            bussiness.push({text:v._id, value:v._id})
        });
        dfr.receivingBusinessList(bussiness) 
    });  
};

dfr.receivingCountry.subscribe(function(newValue){
    dfr.onchangeReceivingLegalEntity(false);
    dfr.onchangeReceivingBusiness(false);
    
    if (dfr.receivingCountry() == '') {
        dfr.receivingLegalEntity([]);
        dfr.receivingBusiness([]);        
    };
  
    dfr.getReceivingLegalEntity();
    dfr.getReceivingBusiness();
    dfr.receivingGetData();

    dashboard.createNewCookie({receiverCountry:dfr.receivingCountry()}); 
    CNUtimeout = setTimeout(function(){
        dfr.onchangeReceivingLegalEntity(true)
        dfr.onchangeReceivingBusiness(true) 
    },1000);
});
dfr.receivingLegalEntity.subscribe(function(newValue){
    if(dfr.onchangeReceivingLegalEntity() === true){    
        dashboard.createNewCookie({receiverCountry:dfr.receivingCountry(),receiverLegalEntity:newValue.toString()}); 
        dfr.receivingGetData();
    }
    dfr.getReceivingCountry();
    dfr.getReceivingBusiness();
});
dfr.receivingBusiness.subscribe(function(newValue){
    if(dfr.onchangeReceivingBusiness() === true){
        dfr.receivingGetData();
    }
    dfr.getReceivingCountry();
    dfr.getReceivingLegalEntity();
});

dfr.parseLegalEntity = function(value){
    // var obj = value.hasOwnProperty('receiverLegalEntity') ? value.receiverLegalEntity : value.supplierLegalentity;
    arr = value.split("~");
    var result = [];
        result['country'] = arr[arr.length - 1];
        result['legalEntity'] = arr[arr.length - 2];
    if(arr.length > 1){
        legalEntity = '';
        for(i=0; i<arr.length-1; i++){
            legalEntity += arr[i]; 
        }
    }
    return result;
}
dfr.setCookie = function(type,category,value){
    var cookies;
    if(type === "country"){
        if(category === "receiver"){ 
            cookies = {receiverCountry:value};
            if(value == "UNITED ARAB EMIRATES"){
                value = "DUBAI INT FIN CENTRE (DIFC)";
            }else if(value == "UNITED STATES"){
                value = "NEW YORK"
            }
            var legalEntity = {receiverLegalEntity:dfr.receivingLegalEntity()}
        }else{
            key = 'supplierCountry';
            if(value == "UNITED STATES"){
                value = "UNITED STATES OF AMERICA";
            }
            cookies = {supplierCountry:value};
            var legalEntity = {supplierLegalentity:dfr.receivingLegalEntity()}
        }
        if(dfr.receivingLegalEntity().length > 0){
            $.extend(true,cookies,legalEntity );
        }
    }else{
        var data = dfr.parseLegalEntity(value)
        var country = data['country'].trim();
        var legal = data['legalEntity'].trim();
        if(category === "receiver"){
            if(country == "UNITED ARAB EMIRATES"){
                country = "DUBAI INT FIN CENTRE (DIFC)";
            }else if(country == "UNITED STATES"){
                country = "NEW YORK"
            }
            
            cookies = {receiverCountry:country,receiverLegalEntity:legal};
        }else{
            
            if(country == "UNITED STATES"){
                country = "UNITED STATES OF AMERICA";
            }
            cookies = {supplierCountry:country,supplierLegalentity:legal};
        }
    }
    if(dfr.receivingBusiness().length > 0){
        $.extend(true,cookies,{bussiness:dfr.receivingBusiness()} );
    }
    dashboard.createNewCookie(cookies);
    redirectUrl("/ociranalysis/default")
}

dfr.receiverViewProcess = function(){
    var category = $("input[name='receiver']:checked").val();
    
    dfr.setCookie('country',category,dfr.receiverviewValue());
}

dfr.suppliererViewProcess = function(){
    var category = $("input[name='supplier']:checked").val();
    dfr.setCookie('legal',category,dfr.receiverviewValue());
}

dfr.receiverClick = function(a){
    return function(){
        dfr.receiverviewValue(a);
    }
}

dfr.createDonut = function(dataSource){
    
    var data = []
    var color = ["#00506D","#0077A3","#50D0FF"]
    var newData = []
    
    $.each(dataSource, function(i, val){            
       
        var data2 = []  
        $.each(val.DetailsDonut, function(index, value){ 
            data2.push({"category" : value.Type,"value": value.Count, "color" : color[index], visible:true});
            switch(value.Type){
                case'inentity':
                    var dataItem = 'Supporting In-Entity'
                break;
                case'intragroup':
                    var dataItem = 'Intra-Group'
                break;
                default:
                    var dataItem = 'Not Mapped'
            }

            var percentage = (Math.abs(value.Count) != 0) ? 100 / (dataSource[0].TotalDonut / value.Count) : 0; 
        
            $("#legend_donut_fte-country_"+i+" ul").append("<li>"+
                                                      "<a onClick='dashboard.configDonutSeries(\"fte-country\","+i+","+index+")'>"+
                                                      "<div class='square' style='background:"+color[index]+"'></div>"+ 
                                                         dataItem+
                                                      "<span style='float:right' id='legend_donut_fte-country_precentage_"+ i +"_"+index+"'>"+
                                                         percentage.toFixed(0)+"<b>%</b>"+
                                                      "</span>"+
                                                      "</a>"+
                                                      "</li>") 
            
        }); 
        data.push(data2) 



        $("#donut_fte-country_"+i).kendoChart({
            legend: {
                visible:false,
                margin:{visible:true,left:-10},
                labels: {
                    font: "9px Helvetica Neue, Arial, sans-serif",
                    template: "#if(dataItem.category=='inentity'){# #: 'Supporting In-Entity' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; #  # #}else if(dataItem.category==='intragroup'){# #: 'Supporting Intra-Group' # &nbsp;&nbsp;&nbsp;# # #}else{# #: 'Not Mapped' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#  # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#  ",
                    color: "#0075B2"
                },
            },
            chartArea: { 
               height:100,
               width:150,
                background: "transparent",
      
            },
            seriesDefaults: {
                labels: {
                    visible: false,
                    template: "#= removeSpace(kendo.toString(percentage,'P0'))#",
                    font: "9px Helvetica Neue, Arial, sans-serif",
                    background: "transparent",
                }
            },
            series: [{
                type: "donut",
                data: data[i],
                overlay:{gradient:"none"},
            }],
            valueAxis:{
                visible:false,
                labels: {
                  font: "8px Open Sans, Helvetica, Arial, sans-serif",
                  visible: false,
                  format:"{0:P0}",
                },
                majorGridLines: {
                    visible: false
                },
            },
            tooltip: {
                visible: true,
                font: "11px Open Sans, Helvetica, Arial, sans-serif",
                template: "#=kendo.toString(value,'N0')#"
            },
            seriesClick: klickDonnutGlobal,            
        });
        function klickDonnutGlobal(){
          dfr.onFTEClick('')
        }
        $(window).on("resize", function() {
            kendo.resize($(".container-donut"));
        });
    });

};

dfr.onFTEClick = function(legal) {
  if (legal === ''){
      var payload = {
           ReceivingCountry : dfr.receivingCountry(),
           LegalEntity : dfr.receivingLegalEntity(),
           Business : dfr.receivingBusiness()                   
      };
      var url = "/receiverview/getpupupftedonut";
  }else {
      var payload = {
           ReceivingCountry : dfr.receivingCountry(),
           LegalEntity : legal,
           Business : dfr.receivingBusiness()                   
      };
      var url = "/receiverview/getpupupftedonutlegal";
  }

    $("#grid-popup-fte").html("");
    $("#grid-popup-fte").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#modalFTE').modal('show');
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
       
            sort: [{field:'teamfunctionname',dir:"asc"}]
        },
        dataBound: function(){
            $('#grid-popup-fte .k-grid-content').height(315);
        },
        columns: [{
              field:"_id.teamfunctionname",
              title:'Team Function Name ',
              headerAttributes: {
                    "class": "align-left"
                },
            },
            {
              field:"fte",
              title:'Total',
              format:"{0:N2}",
              attributes: {"class": "align-right"},
              headerAttributes: {
                    "class": "align-right"
                },
            },
            {
              field:"fteigs",
              title:'Intra-Group',
              format:"{0:N2}",
              attributes: {"class": "align-right"},
              headerAttributes: {
                    "class": "align-right"
                },
            },
            {
              field:"fteteams",
              title:'In-Entity',
              format:"{0:N2}",
              attributes: {"class": "align-right"},
              headerAttributes: {
                    "class": "align-right"
                },
            },
            {
              field:"notmapped",
              title:'Not Mapped',
              format:"{0:N2}",
              attributes: {"class": "align-right"},
              headerAttributes: {
                    "class": "align-right"
                },
            },
            {
              field:"notmappedprecentage",
              title:'% Not Mapped',
              template: '#=kendo.format("{0:p0}", notmappedprecentage / 100)#',
              attributes: {"class": "align-right"},
              headerAttributes: {
                    "class": "align-right"
                },
            },
        ],
        excel: {
            fileName: "PopUpFTEDonut.xlsx",
            allPages: true
        },
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });
}

dfr.createEntitiesDonut = function(dataSource){
    var data = [] 
    var color = ["#00506D","#0077A3","#50D0FF"]
    var newData = []
    
    $.each(dataSource, function(i, val){
        var data2 = []
        $.each(val.DetailsDonut, function(index, value){ 
            data2.push({"category" : value.Type,"value": value.Count, "color" : color[index], visible:true});
            switch(value.Type){
                case'inentity':
                    var dataItem = 'Supporting In-Entity'
                break;
                case'intragroup':
                    var dataItem = 'Intra-Group'
                break;
                default:
                    var dataItem = 'Not Mapped'
            }
            var percentage = (Math.abs(value.Count) != 0) ? 100 / (dataSource[i].TotalDonut / value.Count) : 0; 
            
            $("#legend_donut_fte-entities_"+i+" ul").append("<li>"+
                                                      "<a onClick='dashboard.configDonutSeries(\"fte-entities\","+i+","+index+")'>"+
                                                      "<div class='square' style='background:"+color[index]+"'></div>"+ 
                                                         dataItem+
                                                      "<span style='float:right' id='legend_donut_fte-entities_precentage_"+ i +"_"+index+"'>"+
                                                         percentage.toFixed(0)+"<b>%</b>"+
                                                      "</span>"+
                                                      "</a>"+
                                                      "</li>")       
         });

        data.push(data2)
        $("#donut_fte-entities_"+i).kendoChart({
            legend: {
                visible:false,
                margin:{visible:true,left:-10},
                labels: {
                    font: "10px Helvetica Neue, Arial, sans-serif",
                    template: "#if(dataItem.category=='inentity'){# #: 'Supporting In-Entity'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; #  # #}else if(dataItem.category==='intragroup'){# #: 'Supporting Intra-Group' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else{# #: 'Not Mapped' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}# #= removeSpace(kendo.toString(percentage,'P0'))#  ",
                    color: "#0075B2"
                },
            },
            chartArea: {
                height : 100,
                background: "transparent",
                width : 150,
            },
            seriesDefaults: {
                labels: {
                    visible: false,
                    template: "#= removeSpace(kendo.toString(percentage,'P0'))#",
                    font: "10px Helvetica Neue, Arial, sans-serif",
                    background: "transparent"
                }
            },
            series: [{
                type: "donut",
                data: data[i],
                overlay:{gradient:"none"},
                // CountryLegal : 
            }],
            valueAxis:{
                visible:false,
                labels: {
                    font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                    visible: false,
                    format:"{0:P0}",
                },
                majorGridLines: {
                    visible: false
                },
            },
            tooltip: {
                visible: true,
                font: "11px  , Helvetica, Arial, sans-serif",
                 template: "#=kendo.toString(value,'N0')#"
                // template: "#if(dataItem.category=='inentity'){# #: 'In-Entity' # #}else if(dataItem.category==='intragroup'){# #: 'Intra-Group' # #}else{# #: 'Not Mapped' # #} # - #= kendo.format('{0:P}', percentage) #"
                // template: "#= category # - #= kendo.format('{0:P}', percentage) #"
            },
            seriesClick: onEntitiesFTEClick,
        });

        function onEntitiesFTEClick() {
          // console.log(val.CountryLegal)        
            var legalEntity  = val.CountryLegal.split("~")[0];
            legalEntity = legalEntity.trim()
            dfr.onFTEClick([legalEntity]);
            // console.log([legalEntity]);
        }
    });
};

dfr.downloadDonutFte = function(){
    return function(){
        var grid = $("#grid-popup-fte").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard FTE Drilldown Donut"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}

dfr.init = function(){
   localStorage.setItem('tab', 'fte-resources');
	 dfr.getReceivingCountry();
   dfr.getReceivingLegalEntity();
   dfr.getReceivingBusiness();
	 dfr.receivingGetData(); 
}
$(function(){
    $('button[data-dismiss="modal"]').click(function(){
      $('.modal-backdrop').remove();
    });

})