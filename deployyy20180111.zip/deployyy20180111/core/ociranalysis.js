 var oa = {};

oa.region     = ko.observable([]);
oa.regionList = ko.observableArray([]);

oa.receivingCountry     = ko.observable([]);
oa.receivingCountryList = ko.observableArray([]);

oa.receivingLegalEntityList  = ko.observableArray([]);
oa.receivingLegalEntity      = ko.observableArray([]);

oa.supplycountryList    = ko.observableArray([]);
oa.supplycountry        = ko.observableArray([]);

oa.supplylegalentityList   = ko.observableArray([]);
oa.supplylegalentity       = ko.observableArray([]);

oa.LegalSignatoryList = ko.observableArray([]);
oa.LegalSignatory = ko.observableArray([]);

oa.categorynameList = ko.observableArray([]);
oa.categoryname     = ko.observableArray([]);

oa.supplytypeList  = ko.observableArray([]);
oa.supplytype      = ko.observableArray([]);

oa.productList =  ko.observableArray([]);
oa.product = ko.observableArray([]);

oa.parentprocessnameList =  ko.observableArray([]);
oa.parentprocessname = ko.observableArray([]);

oa.globalprocessownerList =  ko.observableArray([]);
oa.globalprocessowner = ko.observableArray([]);

oa.valueProductFunctionName = ko.observable();
oa.listFieldDetailAnalysis = ko.observableArray([]);
oa.listColumnFieldDetailAnalysis = ko.observableArray([]);
oa.listColumnIsendEs = ko.observableArray([]);

oa.listDataPopUp = ko.observableArray([]);

oa.loading = ko.observable(false);
oa.checkPopUp = ko.observable(false);
oa.viewfullchart = ko.observable(false);
oa.viewfullgrid = ko.observable(false);
oa.viewnonproductgridchart = ko.observable(false);

oa.gridListColumn = ko.observableArray([]);

oa.filterChartBarList = ko.observableArray([])

oa.filterChartBar = ko.observable('Biggest');

oa.filterDonutBarList = ko.observableArray([
											{value:"",text:"% of Services by Service Type"},
											{value:"In-Entity vs Intra-Group",text:"% Services Performed In-Entity Vs Intra-Group"},
											{value:"In-Entity vs Intra-Group FTE",text:"FTE Utilized by In-Entity Vs Intra-Group"}
										])
oa.filterDonutBar = ko.observable('');

oa.filterProductNameList = ko.observableArray([
												{value:"Products",text:"Products"},
												{value:"validated",text:"For Validated Service by Country"},
												{value:"enriched",text:"For Confirmed Service by Country"},
												{value:"businnessvalidated",text:"For Validated Service by Business"},
												{value:"businnessenriched",text:"For Confirmed Service by Business"},
												{value:"countrybusinnessvalidated",text:"% Validated Service by Country and Business"},
												{value:"countrybusinnessenriched",text:"% Confirmed Service by Country and Business"},
											])
oa.filterProductName = ko.observable('');

oa.levelProcess = ko.observable('');

oa.cefList = ko.observableArray([{value:"Y",text:"Yes"},{value:"N",text:"No"}]);
oa.cef = ko.observableArray([]);

oa.necessaryList = ko.observableArray([{value:"Y",text:"Yes"},{value:"N",text:"No"}]);
oa.necessary = ko.observableArray([]);

oa.showGridOcir = ko.observable(false);
oa.showFilterDetail = ko.observable(true);
oa.lookingRealeted = ko.observable(false);
oa.selectedRadio = ko.observable('');

oa.gridReceiver = ko.observable(true);
oa.gridSupplier = ko.observable(true);
oa.gridServiceType = ko.observable(true);

oa.popupvalue = ko.observable(true);

oa.dataProductName = ko.observableArray([]);

oa.gridlvl1 = ko.observableArray([]);
oa.functionType = ko.observableArray([]);
oa.functionTypeList = ko.observableArray([]);

oa.onchange = {
	receivingCountry:true,
	receivingLegalEntity:true,
	supplyCountry:true,
	Supplylegalentity:true,
	LegalSignatory:true,
	Category:true,
	supplyType:true,
}

oa.loadingSecondButton = ko.observable(false);
oa.showFirstFilter = ko.observable(true);
oa.showSecondFilter = ko.observable(false);
oa.afterSecondFilter = ko.observable(false);
oa.showGridDetail = ko.observable(false)
oa.firstFilter = ko.observable('');
oa.secondFilter = ko.observableArray([]);
oa.disableSecondFilterList = ko.observableArray([]);
oa.defaultFilter = ko.observableArray(['Receiver','Supplier','Business','Product']);
oa.default_listColoumn_detailAnalysis = ko.observableArray([]);
oa.loadingGridDetail = ko.observable(false);

oa.flag = ko.observable();
oa.countparent = ko.observable();
oa.gridprocess = ko.observable(false);
oa.chooseTab = ko.observable('summary');

oa.showSummary = ko.observable(false)
var CNUtimeout = setTimeout(function(){
	},1000);

oa.getregion = function(){
	var payload = {
		Functiontype 		: oa.functionType(),	
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
	};
	var url = "/ociranalysis/getregion";
	ajaxPost(url,payload, function (res){
		var regions = [];
		$.each(res, function(i,v){
			regions.push({text:v._id, value:v._id})
		});
		oa.regionList(regions);
	})
};
oa.getReceivingCountry = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
	};
	var url = "/ociranalysis/getreceivercountry";
	ajaxPost(url,payload, function (res){
		var receivingCountries = [];
		$.each(res, function(i,v){
			receivingCountries.push({text:v._id, value:v._id})
		});
		oa.receivingCountryList(receivingCountries);
	})
};
oa.getPfp = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	};
	var url = "/ociranalysis/getnecessary";
	ajaxPost(url,payload, function (res){
		oa.necessaryList(res);
	})
};
oa.getCef = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	};
	var url = "/ociranalysis/getcef";
	ajaxPost(url,payload, function (res){ 
		oa.cefList(res);
	})
};

oa.getReceivingLegalEntity = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : [],
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	};
	var url = "/ociranalysis/getlegalentityreceiver";
	ajaxPost(url,payload, function (res){
		var legalEntities = [];
		$.each(res, function(i,v){
			legalEntities.push({text:v._id, value:v._id})
		});
		oa.receivingLegalEntityList(legalEntities);
		if(legalEntities.length == 1){
			oa.onchange["receivingLegalEntity"] = false
			oa.receivingLegalEntity([res[0]._id]);
			oa.gridReceiver(false);
		}else{
			oa.gridReceiver(true);
			if(oa.gridprocess()){
				oa.gridProcessName();
			}
		}
	});
};
oa.getSupplyCountry = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(), 
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	};
	var url = "/ociranalysis/getsuppliercountry";
	ajaxPost(url,payload, function (res){
		var country = []
		$.each(res, function(index, result){
			country.push({text:result._id, value:result._id});
		});
		oa.supplycountryList(country);
	});
};
oa.getSupplyLegalEntity = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : [], 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: [],
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	}
	if(oa.supplytype() === 'TPS'){
		oa.onchange.Supplylegalentity = false
		oa.supplylegalentity([])
		oa.onchange.Supplylegalentity = true
		var url = "/ociranalysis/getlegalsignatory";
		ajaxPost(url,payload, function (res){
			var signatory = []
			$.each(res, function(index, result){
				signatory.push({text:result._id, value:result._id});
			});
			oa.LegalSignatoryList(signatory);
		});
	}else{
		oa.onchange.LegalSignatory = false
		oa.LegalSignatory([])
		oa.onchange.LegalSignatory = true
		var url = "/ociranalysis/getlegalentitysupplier";
		ajaxPost(url,payload, function (res){
			var entity = []
			$.each(res, function(index, result){
				entity.push({text:result._id, value:result._id});
			});
			oa.supplylegalentityList(entity);
			if(entity.length  == 1){
				oa.onchange["Supplylegalentity"] = false
				oa.supplylegalentity([res[0]._id])
				oa.gridSupplier(false)
			}else{
				oa.gridSupplier(true)
				if(oa.gridprocess()){
					oa.gridProcessName();
				}
			}
		});
	}
};
oa.getCategoryName = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	};
	var url = "/ociranalysis/getcategory";
	ajaxPost(url,payload, function (res){
		var category = []
		$.each(res, function(index, result){
			category.push({"name" : result._id,"text": result._id});
		});
		oa.categorynameList(category);
	});
};
oa.getSupplyType = function(){
	var payload = {
		ReceivingCountry 	: oa.receivingCountry(),
		Filtertype 			: ''
	};
	var url = "/ociranalysis/getsuppliertype";
	ajaxPost(url,payload, function (res){
		var supplier = []
		$.each(res, function(index, result){
			var results;
			if(result._id == 'IGS'){
				results = "Intra-Group"
			} else if(result._id == 'FMI'){
				results = "FMI"
			} else if(result._id == 'FMI_System'){
				results = "FMI Systems"
			} else if(result._id == 'FMI_TPS'){
				results = "FMI External"
			} else if(result._id == 'TPS'){
				results = "External"
			} else if(result._id == 'Teams'){
				results = "In-Entity"
			} else {
				results = "Systems"
			}
			supplier.push({text:results, value:result._id});
		});
		oa.supplytypeList([])
		if ( oa.selectedRadio() == "TEAM"){
			$.each(supplier, function(i , v){
				if ( v.value == 'IGS' || v.value == 'Teams'){
				 oa.supplytypeList().push(v) 
				}
			})
		}else if (oa.selectedRadio() == "TPV"){
			$.each(supplier, function(i , v){
				if ( v.value == 'TPS'){
				 oa.supplytypeList().push(v) 
				}
		 	})
		}else if (oa.selectedRadio() == "IS"){
			$.each(supplier, function(i , v){
				if ( v.value == 'Systems' || v.value == 'FMI_TPS'){
				 oa.supplytypeList().push(v) 
				}
			})
		}else if (oa.selectedRadio() == "ES"){
			$.each(supplier, function(i , v){
				if ( v.value == 'Systems' || v.value == 'FMI_TPS'){
				 oa.supplytypeList().push(v) 
				}
			})
		}else if (oa.selectedRadio() == "CTR"){
			$.each(supplier, function(i , v){
				if ( v.value == 'Systems' || v.value == 'FMI_TPS'){
				 oa.supplytypeList().push(v) 
				}
			})
		}else {
			oa.supplytypeList(supplier)
		}
	});
};
oa.GetProduct = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	};
	var url = "/ociranalysis/getproductfunction";
	ajaxPost(url,payload, function (res){
		var product = []
		$.each(res, function(index, result){
			product.push({"name" : result._id,"text": result._id});
		});
		oa.productList(product);
	});
};
oa.getParentProcessName = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	};
	var url = "/ociranalysis/getparentprocessname";
	ajaxPost(url,payload, function (res){
		var parentprocessname = []
		$.each(res, function(index, result){
			parentprocessname.push({"name" : result._id,"text": result._id});
		});
		oa.parentprocessnameList(parentprocessname);
	});
};
oa.getGlobalProcessOwner = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	};
	var url = "/ociranalysis/getgpo";
	ajaxPost(url,payload, function (res){
		var globalprocessowner = []
		$.each(res, function(index, result){
			globalprocessowner.push({"name" : result._id,"text": result._id});
		});
		oa.globalprocessownerList(globalprocessowner);
	});
};
oa.getFunction = function(){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(), 
		Categoryname 		: oa.categoryname(),
		Suppliertype 		: oa.supplytype(),
		Productfunction 	: oa.product(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef()
	};
	var url = "/ociranalysis/getfunctiontype";
	ajaxPost(url,payload, function (res){
		var functiontypes = []
		$.each(res, function(index, result){
			functiontypes.push({"name" : result._id,"text": result._id});
		});
		oa.functionTypeList(functiontypes);
	});
};
oa.configOnchange = function(value,status){
	data = []
	for(x in oa.onchange){
		if(x != value){
			oa.onchange[x] = status
		}
		data.push({x: oa.onchange[x]})
	}
};
oa.cef.subscribe(function(newValue){
	oa.asd = true;
	if(oa.cef().length == 0){
		oa.getCef(); 
	} 
  	oa.getregion(); 
	oa.getReceivingCountry(); 
	oa.getReceivingLegalEntity();
	oa.getSupplyCountry();
	oa.getSupplyLegalEntity();
	oa.getCategoryName(); 
	oa.GetProduct();
	oa.getParentProcessName();
	oa.getGlobalProcessOwner();
	oa.getFunction(); 
	oa.getPfp(); 
	oa.getData();
});
oa.necessary.subscribe(function(newValue){
	oa.asd = true;
	if(oa.necessary().length == 0){
		oa.getPfp(); 
	} 
  	oa.getregion(); 
	oa.getReceivingCountry(); 
	oa.getReceivingLegalEntity();
	oa.getSupplyCountry();
	oa.getSupplyLegalEntity();
	oa.getCategoryName(); 
	oa.GetProduct();
	oa.getParentProcessName();
	oa.getGlobalProcessOwner();
	oa.getFunction(); 
	oa.getCef(); 
	oa.getData();
});
oa.region.subscribe(function(newValue){
	oa.asd = true;
	if(oa.receivingCountry().length == 0){
		oa.getregion(); 
	} 
	if(oa.onchange["region"]){
		oa.configOnchange("region",false);
		oa.getReceivingCountry(); 
		oa.getReceivingLegalEntity();
		oa.getSupplyCountry();
		oa.getSupplyLegalEntity();
		oa.getCategoryName(); 
		oa.GetProduct();
		oa.getParentProcessName();
		oa.getGlobalProcessOwner();
		oa.getFunction();  
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("region",true);
		},2000);
	}
});
oa.receivingCountry.subscribe(function(newValue){
	oa.asd = true;
	if(oa.receivingCountry().length == 0){
		oa.gridReceiver(true);
		oa.getReceivingCountry(); 
	} 
	if(oa.onchange["receivingCountry"]){
		oa.configOnchange("receivingCountry",false);
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getSupplyCountry();
		oa.getSupplyLegalEntity();
		oa.getCategoryName(); 
		oa.GetProduct();
		oa.getParentProcessName();
		oa.getGlobalProcessOwner();
			oa.getFunction();  
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("receivingCountry",true);
		},2000);
	}
});
oa.receivingLegalEntity.subscribe(function(newValue){
	oa.asd = true;
	if(oa.receivingLegalEntity().length == 0){
		oa.getReceivingLegalEntity();
	}
	if(oa.onchange["receivingLegalEntity"]){
		oa.configOnchange("receivingLegalEntity",false);
		oa.getregion(); 
		oa.getReceivingCountry(); 
		oa.getSupplyCountry();
		oa.getSupplyLegalEntity();
		oa.getCategoryName(); 
		oa.GetProduct();
		oa.getFunction();
		oa.getParentProcessName();
		oa.getGlobalProcessOwner();
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("receivingLegalEntity",true);
		},2000);
	}
});
oa.supplycountry.subscribe(function(newValue){
	oa.asd = true;
	if(oa.supplycountry().length == 0){
		oa.gridSupplier(true) 
		oa.getSupplyCountry();
	}
	if(oa.onchange["supplyCountry"]){
		oa.configOnchange("supplyCountry",false);
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getReceivingCountry(); 
		oa.getSupplyLegalEntity();
		oa.getCategoryName(); 
		oa.GetProduct();
		oa.getFunction(); 
		oa.getParentProcessName();
		oa.getGlobalProcessOwner(); 
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("supplyCountry",true);
		},2000);
	}
});
oa.LegalSignatory.subscribe(function(newValue){
	oa.asd =  true;
	if(oa.onchange["LegalSignatory"]){ 
		if(oa.LegalSignatory().length == 0){ 
			oa.getSupplyLegalEntity();
		}
		oa.onchange.LegalSignatory = false;
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getReceivingCountry(); 
		oa.getSupplyCountry();
		oa.getCategoryName(); 
		oa.GetProduct();
		oa.getFunction();
		oa.getParentProcessName();
		oa.getGlobalProcessOwner();
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.onchange.LegalSignatory = true;
		},2000);
	}
});
oa.supplylegalentity.subscribe(function(newValue){
	oa.asd = true;
	if(oa.onchange["Supplylegalentity"]){ 
		if(oa.supplylegalentity().length == 0){ 
			oa.getSupplyLegalEntity();
		}
		oa.configOnchange("Supplylegalentity",false);
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getReceivingCountry(); 
		oa.getSupplyCountry();
		oa.getCategoryName(); 
		oa.GetProduct();
		oa.getFunction();
		oa.getParentProcessName();
		oa.getGlobalProcessOwner();
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("Supplylegalentity",true);
		},2000);
	}
});
oa.categoryname.subscribe(function(newValue){
	oa.asd =  true;
	if(oa.categoryname().length == 0){ 
		oa.getCategoryName();
	}
	if(oa.onchange["Category"]){
		oa.configOnchange("Category",false)
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getReceivingCountry(); 
		oa.getSupplyCountry();
		oa.getSupplyLegalEntity(); 
		oa.GetProduct();
		oa.getFunction();
		oa.getParentProcessName();
		oa.getGlobalProcessOwner();
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("Category",true);
		},2000);
	}
});
oa.supplytype.subscribe(function(newValue){
	oa.asd =  true;
	if(oa.supplytype() == ''){
		oa.gridServiceType(true)
		oa.getSupplyType();
		oa.onchange.LegalSignatory = false
		oa.LegalSignatory([])
		oa.onchange.LegalSignatory = true
	}else{
		oa.gridServiceType(false)
		if(oa.supplytype() === 'TPS'){
			oa.onchange.Supplylegalentity = false
			oa.supplylegalentity([])
			oa.onchange.Supplylegalentity = true
		}else{
			oa.onchange.LegalSignatory = false
			oa.LegalSignatory([])
			oa.onchange.LegalSignatory = true
		}
	}
	if(oa.onchange["supplyType"]){
		oa.configOnchange("supplyType",false)
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getReceivingCountry(); 
		oa.getSupplyCountry();
		oa.getSupplyLegalEntity();
		oa.getCategoryName(); 
		oa.GetProduct();
		oa.getFunction();
		oa.getParentProcessName();
		oa.getGlobalProcessOwner();
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("supplyType",true);
		},2000);
	}
	oa.cekfirstFilter();
});
oa.product.subscribe(function(newValue){
	oa.asd =  true;
	if(oa.product().length == 0){ 
			oa.GetProduct();  
		}
	if(oa.onchange["Category"]){
		oa.configOnchange("Category",false);
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getReceivingCountry(); 
		oa.getSupplyCountry();
		oa.getSupplyLegalEntity();
		oa.getCategoryName();
		oa.getFunction();
		oa.getParentProcessName();
		oa.getGlobalProcessOwner();
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("Category",true);
		},2000);
	}
});
oa.parentprocessname.subscribe(function(newValue){
	oa.asd =  true;
	if(oa.product().length == 0){ 
			oa.GetProduct();  
		}
	if(oa.onchange["Category"]){
		oa.configOnchange("Category",false);
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getReceivingCountry(); 
		oa.getSupplyCountry();
		oa.getSupplyLegalEntity();
		oa.getCategoryName();
		oa.GetProduct();
		oa.getFunction();
		oa.getGlobalProcessOwner();
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("Category",true);
		},2000);
	}
});
oa.globalprocessowner.subscribe(function(newValue){
	oa.asd =  true;
	if(oa.product().length == 0){ 
			oa.GetProduct();  
		}
	if(oa.onchange["Category"]){
		oa.configOnchange("Category",false);
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getReceivingCountry(); 
		oa.getSupplyCountry();
		oa.getSupplyLegalEntity();
		oa.getCategoryName();
		oa.GetProduct();
		oa.getFunction();
		oa.getParentProcessName();
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("Category",true);
		},2000);
	}
});
oa.functionType.subscribe(function(newValue){
	if(oa.functionType().length == 0){ 
		oa.getFunction();  
	}
	if(oa.onchange["functionType"]){
		oa.configOnchange("functionType",false);
		oa.getregion(); 
		oa.getReceivingLegalEntity();
		oa.getReceivingCountry(); 
		oa.getSupplyCountry();
		oa.getSupplyLegalEntity();
		oa.getCategoryName();
		oa.getParentProcessName();
		oa.getGlobalProcessOwner();
		oa.getPfp();
		oa.getCef();
		CNUtimeout = setTimeout(function(){
			oa.getData();
			oa.configOnchange("functionType",true);
		},2000);
	}
});
oa.filterChartBar.subscribe(function(newValue){
	var payload = {
		Functiontype : oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(),
		Suppliertype 		: oa.supplytype(),
		Categoryname 		: oa.categoryname(),
		Productfunction 	: oa.product(),
		Pfpcritical			: oa.necessary(),
		Cefcritical 		: oa.cef(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
	}
	if(
		newValue !== '% Validated all Countries' || 
		newValue !== '% Enriched all Countries' ||
		newValue !== 'Barriers to Resolution by Business' || 
		newValue !== 'Barriers to Resolution by Country'
	  ){
		// oa.checkFullChart();
		oa.filterChartBar(newValue)
		$("#receivercategorychart").show('fast');
		$("#chart-donutL3Processes").show('fast');
		$("#legend-chart-donutL3Processes").show('fast');
		$("#productgrid").show('fast');
	} 
	oa.getSummaryBarChart(payload,newValue);
});
oa.filterDonutBar.subscribe(function(newValue){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(),
		Suppliertype 		: oa.supplytype(),
		Categoryname 		: oa.categoryname(),
		Productfunction 	: oa.product(),
		Pfpcritical			: oa.necessary(),
		Cefcritical 		: oa.cef(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
	}
	if(oa.filterChartBar() == '% Validated all Countries' || oa.filterChartBar() == '% Enriched all Countries'){
		oa.filterChartBar('Biggest')
	}
	oa.getSummaryBarDonut(payload,newValue);
});
oa.filterProductName.subscribe(function(newValue){
	var payload = {
		Functiontype : oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(),
		Suppliertype 		: oa.supplytype(),
		Categoryname 		: oa.categoryname(),
		Productfunction 	: oa.product(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef(),
		LegalSignatory 		: oa.LegalSignatory(),
		WorstType 			: oa.filterProductName(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
	}
	if(oa.filterProductName() == 'Products'){
		oa.getDataProduct(payload,newValue);
		$("#receivercategorychart").show('fast');
		$("#chart-donutL3Processes").show('fast');
		$("#legend-chart-donutL3Processes").show('fast');
	}else if (oa.filterProductName() == 'validated' || oa.filterProductName() == 'enriched' || oa.filterProductName() == 'businnessvalidated' || oa.filterProductName() == 'businnessenriched'){
		oa.getDataNonProduct(payload,newValue);
		$("#receivercategorychart").show('fast');
		$("#chart-donutL3Processes").show('fast');
		$("#legend-chart-donutL3Processes").show('fast');
	}else{
		oa.fullgrid(payload);
	}
});
oa.cef.subscribe(function(newValue){
	oa.getData();
});
oa.necessary.subscribe(function(newValue){
	oa.getData();
});

oa.changCEF = function(val){
	($(val).is(':checked'))?oa.cef('Y'):oa.cef('N');
	oa.getData();
}
oa.changNecessary = function(val){
	($(val).is(':checked'))?oa.necessary('Y'):oa.necessary('N');
	oa.getData();
}
function alignLegendLeft() {
	var isFound = false
	jQuery('#receivercategorychart g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
		if (isFound) return
		if ($(e).html() == '') isFound = true
		$(e).find('text').attr('x', 0)
	})
}
oa.chartStackedTwoCategory = function(internal, external, underreview, total){
	oa.viewfullgrid(false);
	oa.viewfullchart(false);
	if ( internal.length == 1){
     	$("#receivercategorychart").replaceWith('<div id="receivercategorychart"></div>')
    	$("#receivercategorychart").css('height', (internal.length * 87) + 'px') 
    }else if (internal.length <= 7){
		$("#receivercategorychart").replaceWith('<div id="receivercategorychart"></div>')
		$("#receivercategorychart").css('height', (internal.length * 64) + 'px') 
  	}else {
    	// $("#receivercategorychart").css('height','370px')  
    }
	$("#receivercategorychart").kendoChart({
		legend :{
			position :"bottom",
			font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
		},
		seriesDefaults: {
			type: "bar",
			stack:true,
			overlay: {
				gradient: "none"
			},
			gap: 0.5,
			color: "transparent",
		},
		series: [{
			name: "Internal",
			data: internal,
			categoryField: "_id",
			field: "Count",
			color: "#005C84",
			border: {
				width: 0,
			},
			tooltip: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
		},{
			name: "External",
            data: external,
         	field: "Count", 
            color: "#2F7528",
            border: {
                width: 0,
            },
            tooltip: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
        },{
			name: "Under Review",
            data: underreview,
         	field: "Count", 
            color: "#939598",
            border: {
                width: 0,
            },
            tooltip: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
        },{
            data: total,
         	field: "Count", 
            color: "#fff",
            border: {
                width: 0,
            },
			labels: {	
				position:"insideEnd ",
                template: "#= kendo.toString(dataItem.Value,'N0') #",
                visible: true
            },
        }],
		categoryAxis :{ 
			labels: {
				font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
				template: labelTemplate,
				visible: true,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
		valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
		},
		seriesColors: ["#66DBFF"],
	});
	function labelTemplate(e) {
		var finalStm = "";
		var maxlen = 14;
		var Spl = e.value.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
			lenStm = lenStm + o.length + 1;
			var tb = "";
			if (lenStm <= maxlen) {
				tb = " ";
			} else {
				lenStm = o.length;
				tb = "\n";
			}
			if (i == 0) {
				tb = "";
			}
			finalStm = finalStm + tb + o;
		});  
		return finalStm	 
	}
	alignLegendLeft ();
}
oa.chartStackedFourCategory = function(intra, inentity, gbs, other, total){
	oa.viewfullgrid(false);
	oa.viewfullchart(false);
	if ( intra.length == 1){
    	$("#receivercategorychart").replaceWith('<div id="receivercategorychart"></div>')
    	$("#receivercategorychart").css('height', (intra.length * 87) + 'px') 
    }else if (intra.length <= 7){
    	$("#receivercategorychart").replaceWith('<div id="receivercategorychart"></div>')
    	$("#receivercategorychart").css('height', (intra.length * 64) + 'px') 
  	}else {
    	// $("#receivercategorychart").css('height','370px')  
    } 
	$("#receivercategorychart").kendoChart({
		legend :{
			position :"bottom",
			font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
		},
		seriesDefaults: {
			type: "bar",
			stack:true,
			overlay: {
				gradient: "none"
			},
			gap: 0.5,
			color: "transparent",
		},
		series: [{
			name: "Hub",
			data:intra,
			categoryField: "_id",
			field: "Count",
			border: {
				width: 0,
			},
			color: "#005C84",
			labels: {
				font: "9px Helvetica Neue, Helvetica, Arial, sans-serif",
				color: "#fff",
				visible: false,
				background: "transparent"
			},
			tooltip: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
		},{
			name: "In-Entity",
            data: inentity,
         	field: "Count", 
            color: "#50D0FF",
            border: {
                width: 0,
            }, 
			tooltip: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
        },{
			name: "GBS",
            data: gbs,
         	field: "Count", 
            color: "#2F7528",
            border: {
                width: 0,
            },
            tooltip: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
        },{
			name: "Other",
            data: other,
         	field: "Count", 
            color: "#939598",
            border: {
                width: 0,
            },
            tooltip: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
        },{
            data: total,
         	field: "Count", 
            color: "#fff",
            border: {
                width: 0,
            },
			labels: {	
			  position:"insideEnd ",
                template: "#= kendo.toString(dataItem.Value,'N0') #",
                visible: true
            },
        }],
		categoryAxis :{ 
			labels: {
				font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
				template: labelTemplate,
				visible: true,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
		valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
		},
		// seriesClick: onSeriesClick,
		seriesColors: ["#66DBFF"],
	});
	function labelTemplate(e) {
		var finalStm = "";
		var maxlen = 14;
		var Spl = e.value.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
			lenStm = lenStm + o.length + 1;
			var tb = "";
			if (lenStm <= maxlen) {
				tb = " ";
			} else {
				lenStm = o.length;
				tb = "\n";
			}
			if (i == 0) {
				tb = "";
			}
			finalStm = finalStm + tb + o;
		});  
		return finalStm	 
	}
	alignLegendLeft ();
}
oa.fullchart = function(dataSource, title){
	oa.viewfullgrid(false)
	oa.viewfullchart(true);
	var data = []
	var total
	var flags = []
	var maxCountDS = Enumerable.From(dataSource).Max("$.Count");
  	var dataSeriesSecond = []
	var eventClick = onSeriesClick; 
	if(title == "Barriers to Resolution by Business" || title  == "Barriers to Resolution by Country"){
		eventClick = onSeriesClick2;
	}
	$.each(dataSource, function(i, v){
		if (v.Count !== 0){
			var ninePercent =  (maxCountDS == 0) ? 0 : maxCountDS / ( 100/9 );
    		dataSeriesSecond.push({_id:null,Count:(maxCountDS + ninePercent) - v.Count, label:v.Count})
			data.push(v);
			if(title == 'Comparison Region [% Confirmed Service]' || title == 'Comparison Region [% Validated Service]'){
				flags[v._id] = v.Flag 
	  		}
		}
	})
	total = dataSource.total;
	$("#fullchart").kendoChart({
		seriesDefaults: {
			stack: {
		        type: "100%"
		    },
			overlay: {
				gradient: "none"
			},
			gap: 0.5,
			color: "#36BC9B",
		},
		series: [{
			data:data,
			categoryField: "_id",
			field: "Count",
			border: {
				width: 1.7,
				color: "transparent"
			},
			color: function(e){
				if(title == 'Comparison Region [% Confirmed Service]' || title == 'Comparison Region [% Validated Service]'){
		  			if(flags[e.category] == 'Global'){
		  				return "#005C84"
		  			}else if(flags[e.category] == 'Region'){
		  				return "#3C95B9"
		  			}else{
		  				return "#8ADFFF"
		  			}
	  			}else if (oa.receivingCountry()[0] == e.category) {
					return "#8ADFFF"
				}else{
					return "#36BC9B"
				}
			},
			
		},{ 
            data: dataSeriesSecond,
            field: "Count", 
            color: "#F2F2F2",
            border: {
                width: 1.7,
                color: "transparent"
            },
           		labels: {
					font: "bold 8px Helvetica Neue, Helvetica, Arial, sans-serif",
					color: "#00506D",
					rotation: -90,
					visible: true,
					position:"insideEnd",
					template: function(e){
						if(title == "Barriers to Resolution by Business" || title  == "Barriers to Resolution by Country"){
							return e.dataItem.label.toFixed(0);
						}
						if(e.dataItem.label === 0){
							return 0;
						}else{
							return e.dataItem.label.toFixed(1) + "%";
						}
					},//   
					background: "transparent"
				},
        }],
		categoryAxis :{ 
			labels: {
				font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
				color: "#00506D",
				visible: true,
				mirror: true,
				rotation: -90,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
		valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
		},
		seriesClick: eventClick,
		seriesColors: ["#66DBFF"],
		seriesHover: function(e) { 
			setTimeout(function(){
				$("#fullchart g path").each(function (idx){
					var op = $(this).attr('stroke-opacity');
					if (op == 0.2){
						var display = $(this).attr('d')
						var hover;
						if (oa.receivingCountry()[0] == e.category) {
			            	mainColor = "#8ADFFF"
			            	mainColorHover = "#50D0FF"		    
			            }else if(title == 'Comparison Region [% Confirmed Service]' || title == 'Comparison Region [% Validated Service]'){
			             	if(flags[e.category] == 'Global'){
				                mainColor = "#005C84"
				                mainColorHover = "#002951"
			            	}else if(flags[e.category] == 'Region'){
				                mainColor = "#3C95B9"
				                mainColorHover = "#23576C"
			             	}else{
				                mainColor = "#8ADFFF"
				                mainColorHover = "#50D0FF"
			             	}
			            }else{
			              	mainColor = "#36BC9B"
			                mainColorHover = "#206F5B" 
			            }
						var fillOp;
			            $("#fullchart g path[d='"+ display +"']").each(function (idx){                       
				            var defColor = ($(this).attr('fill'))
				            if(defColor == mainColor){                 
				            	hover  = mainColorHover  
				              	fillOp = 1;                                    
				            }else if(defColor == "#F2F2F2"){
				            	hover  = '#F2F2F2'
				            	fillOp = 0;                      
				            }
			            })
			            $(this)
			            .attr('fill',hover)
			            .attr('fill-opacity', fillOp)
					};
				}); 
			},10);
		}
	});
	function onSeriesClick(e){
		var worstType;
		switch (title){
			case"% Validated all Countries":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'validated'
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab2 = 'pendingvalid';
				flagTab1 = 'validated';
        		dataItemFlag = e.dataItem.Flag;
			break;
			case"% Enriched all Countries":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'enriched'
				tabFirstName = 'Enriched';
				tabSecondName = 'Pending Item';
				flagTab1 = 'enriched';
				flagTab2 = 'pendingenriched';
        		dataItemFlag = e.dataItem.Flag;
			break;
			case"Comparison Region [% Validated Service]":
				categoryname = oa.categoryname();
				product = oa.product();
				if (oa.region() === 0) {
					region = [e.category]
				}else{
					if(e.dataItem.Flag == 'Global'){
						region =  oa.region()
						country = oa.receivingCountry()
					}else if(e.dataItem.Flag == 'Region'){
						region =  [e.category]
						country = oa.receivingCountry()
					}else{
						region = oa.region()
						country = [e.category]
					}
				}
				worstType = 'comparisonvalidated'
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
        		dataItemFlag = e.dataItem.Flag;
			break;
			case"Comparison Region [% Confirmed Service]":
				categoryname = oa.categoryname();
				product = oa.product();
				if (oa.region() === 0) {
					region = [e.category]
				}else{
					if(e.dataItem.Flag == 'Global'){
						country = oa.receivingCountry()
						region =  oa.region();
					}else if(e.dataItem.Flag == 'Region'){
						region =  [e.category]
						country = oa.receivingCountry()
					}else{
						region = oa.region()
						country = [e.category]
					}
				}
				worstType = 'comparisonenriched'
				tabFirstName = 'Enriched';
				tabSecondName = 'Pending Item';
				flagTab1 = 'enriched';
				flagTab2 = 'pendingenriched';
        		dataItemFlag = e.dataItem.Flag;
			break;
		}
		var payload = {
      		Functiontype 		: oa.functionType(),	
			Region 				: region,
			ReceiverCountry     : country,
			ReceiverLegalEntity : oa.receivingLegalEntity(),
			SupplierCountry     : oa.supplycountry(),
			SupplierLegalEntity : oa.supplylegalentity(),
			Suppliertype        : oa.supplytype(),
			Categoryname        : categoryname,
			Productfunction     : product,
			Pfpcritical         : oa.necessary(),
			Cefcritical         : oa.cef(),
			Parentprocessname 	: oa.parentprocessname(),
			GPO 				: oa.globalprocessowner(),
			worstType			: worstType,
		};
		if (title == 'Comparison Region [% Validated Service]' || title == 'Comparison Region [% Confirmed Service]') {
			if([e.dataItem.Flag] == 'Global'){
				var payload = $.extend(payload,{Global : 'Y'});
  			}else if([e.dataItem.Flag] == 'Region'){
				var payload = $.extend(payload,{Global : 'N'});
  			}else{
				var payload = $.extend(payload,{Global : 'N'});
  			}
		};
		ajaxPost("/ociranalysis/popupnewbar",payload , function (res){
			$('#modaltab-name-first').text(tabFirstName);
			$('#modaltab-name-second').text(tabSecondName);
			$('#modaltab').modal('show');
			setTimeout(function() {
				$('#modaltab .k-grid-content').height(300);
			},300)
			$("#pendingtab ul").find('li').removeClass('active')
			$("#pendingtab ul li:eq(0)").addClass('active')
			$("#pendingtab" ).tabs( {active:0});
			$("#grid-chart-1").html("");
			$("#grid-chart-1").kendoGrid({
				dataSource: {
					transport: {
						read:function(option){
						 	res.tab1.forEach(function (d) {
						 		d.type = title
								d.worstType = worstType
								d.receivercountry = e.category
								d.flagTab = flagTab1
								d.Global = payload.Global 
                    			d.flagRegion = dataItemFlag
							})
							option.success(res.tab1);
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					},
				}, 
				columns: [{
					field:"Country",
					title:'PFP Process Name',
					width:100,
					attributes: {
						"class": "field-ellipsis"
					},
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"Count",
					title:'Total',
					width:50,
					attributes: {
						"class": "field-ellipsis align-right"
					},
					template: "#if(Count !== 0){# <a href=\"\\#\" onclick='popupdetail(\"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\",\"#:worstType#\",\"#:flagTab#\",\"#:receivercountry#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
					headerAttributes: {
						"class": "align-right"
					},
				}],
				sortable: true,
				filterable: {
					extra:false, 
					operators: {
						string: {
							contains: "Contains",
							startswith: "Starts with",
							eq: "Is equal to",
							neq: "Is not equal to",
							doesnotcontain: "Does not contain",
							endswith: "Ends with"
						},
					}
				},
				pageable: {
					numeric: false,
					previousNext: false,
					messages: {
						display: "Showing {2} data items"
					}
				},
				height: 380,
				excelExport: function(e) {
			      e.preventDefault();
			      promises[0].resolve(e.workbook);
			    }
			});
			$("#grid-chart-2").html("");
			$("#grid-chart-2").kendoGrid({
				dataSource: {
					transport: {
						read:function(option){
						 	res.pending.forEach(function (d) {
						 		d.type = title
								d.worstType = worstType
								d.receivercountry = e.category
								d.flagTab = flagTab2
								d.Global = payload.Global
                    			d.flagRegion = dataItemFlag
							})
							option.success(res.pending); 
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					},
				}, 
				columns: [{
					field:"Country",
					title:'PFP Process Name',
					width:100,
					attributes: {
						"class": "field-ellipsis"
					},
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"Count",
					title:'Total',
					width:50,
					attributes: {
						"class": "field-ellipsis align-right"
					},
					template: "#if(Count !== 0){# <a href=\"\\#\" onclick='popupdetail(\"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\",\"#:worstType#\",\"#:flagTab#\",\"#:receivercountry#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
					headerAttributes: {
						"class": "align-right"
					},
				}],
				sortable: true,
				filterable: {
					extra:false, 
					operators: {
						string: {
							contains: "Contains",
							startswith: "Starts with",
							eq: "Is equal to",
							neq: "Is not equal to",
							doesnotcontain: "Does not contain",
							endswith: "Ends with"
						},
					}
				},
				pageable: {
					numeric: false,
					previousNext: false,
					messages: {
						display: "Showing {2} data items"
					}
				},
				height: 380,
				excelExport: function(e) {
			    	e.preventDefault();
			    	promises[1].resolve(e.workbook);
			    }
			});
		})
	}
	function onSeriesClick2(e){
		var payload = {
			Functiontype 		: oa.functionType(),
			Region 				: oa.region(),
			ReceiverCountry 	: oa.receivingCountry(),
			ReceiverLegalEntity : oa.receivingLegalEntity(),
			SupplierCountry 	: oa.supplycountry(),
			SupplierLegalEntity : oa.supplylegalentity(), 
			Categoryname 		: oa.categoryname(),
			Suppliertype 		: oa.supplytype(),
			Productfunction 	: oa.product(),
			LegalSignatory 		: oa.LegalSignatory(),
			Parentprocessname 	: oa.parentprocessname(),
			GPO 				: oa.globalprocessowner(),
		};
		console.log(e);
		if(title == "Barriers to Resolution by Business"){
			payload.Categoryname = [e.category];
		}else{
			payload.ReceiverCountry = [e.category];
		}


			$("#grid-pupUp-chart").html("");
		    $("#grid-pupUp-chart").kendoGrid({
		        dataSource: {
		            transport: {
		               read:function(options){
		                    payload.filter = options.data.filter
		                    payload.page = options.data.page
		                    payload.pageSize = options.data.pageSize
		                    payload.skip = options.data.skip
		                    payload.sort = options.data.sort
		                    payload.take = options.data.take
		                    ajaxPost("/ociranalysis/popupbarrier", payload, function(datas){
		                        options.success(datas);  
		                    	$('#modalChart').modal('show');
	                    		setTimeout(function() {
									$('#grid-pupUp-chart .k-grid-content').height(270);
								}, 300);
		                    })
		                }, 
		            },
		            schema: {
		                data: function(data) {      
		                    if (data.Count == 0) {
		                        return dataSource;
		                    } else {
		                        return data.Records;
		                    }   
		                },
		                total: "Count",
		            },
		            pageSize: 10,
		            serverPaging: true,
		            serverSorting: true,
		            serverFiltering: true, 
		            sort: [
		                {field:"receivercountry",dir:"asc"},
		                {field:"suppliercountry",dir:"asc"},
		                {field:"categoryname_",dir:"asc"},
		                {field:"productfunction",dir:"asc"},
		                {field:"parentprocessname",dir:"asc"},
		                {field:"processname",dir:"asc"},
		                {field:"servicedescription",dir:"asc"},
		                {field:"barriertype",dir:"asc"},


		                {field:"suppliername",dir:"asc"},
		                {field:"suppliertype",dir:"asc"},
		                {field:"contractid",dir:"asc"},
		                {field:"slaid",dir:"asc"},
		                {field:"buildingname",dir:"asc"},

		                {field:"teamcostcentre",dir:"asc"}, 
		            ],
		        },
		        height: 350,
		        columns: [
		           {
		                field:"receivercountry",
		                title:'Receiver Country',
		                /*filterable: false,*/
		                width:180,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                },
		                template: "#= receivercountry + ' - ' + receiverlegalentity #",
		            },
		            {
		                field:"suppliercountry",
		                title:'Supplier Country',
		                /*filterable: false,*/
		                width:180,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                },
		                template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
		            },
		            {
		                field:"categoryname_",
		                title:'Business',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"productfunction",
		                title:'Product',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"parentprocessname",
		                title:'Level 1 Process',
		                /*filterable: false,*/
		                width:250,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"processname",
		                title:'Level 2 Process',
		                /*filterable: false,*/
		                width:250,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"servicedescription",
		                title:'Service Description',
		                /*filterable: false,*/
		                width:250,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"barriertype",
		                title:'Barrier Type',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"suppliername",
		                title:'Supplier Name',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"suppliertype",
		                title:'Supplier Type',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }, 
		            {
		                field:"contractid",
		                title:'Contract ID',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }, 
		            {
		                field:"slaid",
		                title:'SLA ID',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }, 
		            {
		                field:"buildingname",
		                title:'Building Name',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }, 
		            {
		                field:"teamcostcentre",
		                title:'Cost Centre',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }
		        ],
		        excel: {
		            // fileName: "PopUpIntraGroupDonut.xlsx",
		            allPages: true
		        },
		        sortable: true,
		        pageable: {
		            refresh: true,
		            pageSizes: true,
		            buttonCount: 1,
		            pageSize: 20,
		             pageSizes: [5, 10, 20],
		        },
		        // filterable: {
		        //     extra:false, 
		        //     operators: {
		        //         string: {
		        //             contains: "Contains",
		        //             startswith: "Starts with",
		        //             eq: "Is equal to",
		        //             neq: "Is not equal to",
		        //             doesnotcontain: "Does not contain",
		        //             endswith: "Ends with"
		        //         },
		        //     }
		        // }, 
		        height: 350,
		    });
	}
}
oa.fullgrid = function(payload){
	oa.viewfullgrid(true)
	oa.viewfullchart(false)
	ajaxPost("/ociranalysis/dgvalidatedcountryfield",payload , function (res){
		var records = []
      	if(res.Data.Records.length > 0 ){
          records.push(res.Data.Records[0]);
          res.Data.Records.splice(0,1);
          r = Enumerable.From(res.Data.Records) 
                  .OrderBy(function (x) { return x.title }) 
                  .ToArray();
 
          records = records.concat(r);
      	}
		var dataSource = [];
		var url = "/ociranalysis/dgvalidatedcountry";
		$("#fullgrid").html("");
		$("#fullgrid").kendoGrid({
			dataSource: {
				transport: {
					read:function(option){
	                    ajaxPost(url, payload, function(datas){
	                        option.success(datas);
	                    })
	                },
	                parameterMap: function(data) {
	                    return JSON.stringify(data);
	                },

				// : {
				// 	read: {
				// 		url: url,
				// 		data: payload,
				// 		dataType: "json",
				// 		type: "POST",
				// 		contentType: "application/json",
				// 	},
				// 	parameterMap: function(data){
				// 		retutransportrn JSON.stringify(data);
				// 	},
				},
				schema: {
					data: function(data) {
						if (data.Count == 0) {
							return dataSource;
						} else {
							return data.Data.Records;
						}
					},
					total: "Data.Count",
				}, 
				serverPaging: false,
				serverSorting: false,
			},
			height: 400,
			resizable: true,
			filterable: {
				extra:false, 
				operators: {
					string: {
						contains: "Contains",
						startswith: "Starts with",
						eq: "Is equal to",
						neq: "Is not equal to",
						doesnotcontain: "Does not contain",
						endswith: "Ends with"
					},
				}
			},
			sortable: true,
			pageable: {
				numeric: false,
				previousNext: false,
				messages: {
					display: "Showing {2} data items"
				}
			},
			columns: records
		});
	})
}
var promises = [
    $.Deferred(),
    $.Deferred()
];
oa.titleFile;
oa.sheetFirstName;
oa.sheetSecondName;
oa.tabFirst = ko.observable(true);
function exportExcel2(){
	var grid;
	if(oa.tabFirst()){
		var grid = $("#grid-chart-1").data("kendoGrid");
	}else{
	 	var grid = $("#grid-chart-2").data("kendoGrid");
	}
	grid.saveAsExcel();
	var payload = {
    Type : "Ociranalysis Summary Drilldown Barchart Grid"
  }
  ajaxPost("/analyticuser/downloadlog", payload, function (res){ })
}
oa.chartReceiverCategory = function(dataSource, title, onClick){

	oa.viewfullgrid(false);
	oa.viewfullchart(false);
			console.log(title);
	var data = []
	var total
	var flags = []
	total = dataSource.total;
	$.each(dataSource, function(i, v){
	  if (v.Count !== 0){
	  	v.Count = Math.abs(v.Count)
	  	if(title == 'Comparison Region [% Confirmed Service]' || title == 'Comparison Region [% Validated Service]'){
			flags[v._id] = v.Flag 
			v.Flag
	  	} 
	  	data.push(v)
	  }
	})
	maxValueAxis = 0
	if(data.length > 0 ){
	  var max = Enumerable.From(data).Max("$.Count");
		var min = Enumerable.From(data).Min("$.Count");
		if(title ==  'Comparison Region [% Confirmed Service]' || title == 'Comparison Region [% Validated Service]' || 
		title == 'Worst 10 [% Validated]' || title == 'Worst 10 [% Enriched]' || title == 'Worst 10% Validated by Business/Function' || 
		title == 'Worst 10% Enriched by Business/Function' || title == 'Best 10 [% Validated]' || title == 'Best 10 [% Enriched]' ||
		title == 'Pending Best 10 [% Validated]' || title == 'Pending Best 10 [% Enriched]' || title == 'Pending Worst 10 [% Validated]' || 
		title == 'Pending Worst 10 [% Enriched]' || title == 'Worst 10 by Process Owner [% Validated Service]' || title == 'Worst 10 by Process Owner [% Confirmed Service]' || title == 'Best 10 by Process Owner [% Validated Service]' || title == 'Best 10 by Process Owner [% Confirmed Service]'){
			lengthCharMax = (String(max.toFixed(2)).length) + 1;
			n = 5.3;
	    }else{
			lengthCharMax =  String(max.toFixed(0)).length;
			n = 5.2;
	    }
		percentage =  (max * (lengthCharMax * n)) / 100 ;
		maxValueAxis = maxValueAxis < 0 ? maxValueAxis : max + percentage ; 
		minValuAxis	 = min	
		if ( data.length == 1){
			$("#receivercategorychart").replaceWith('<div id="receivercategorychart"></div>')
			$("#receivercategorychart").css('height', (data.length * 60) + 'px') 
		}else if (data.length <= 7){
			$("#receivercategorychart").replaceWith('<div id="receivercategorychart"></div>')
			$("#receivercategorychart").css('height', (data.length * 100) + 'px') 
		}else {
			// $("#receivercategorychart").css('height','400px')
		}
	}
	if( title == 'Worst 10 [% Validated]' || title == 'Worst 10 [% Enriched]' || title == 'Worst 10% Validated by Business/Function' || title == 'Worst 10% Enriched by Business/Function' || title == 'Best 10 [% Validated]' || title == 'Best 10 [% Enriched]' || title == 'Pending Best 10 [% Validated]' || title == 'Pending Best 10 [% Enriched]' || title == 'Pending Worst 10 [% Validated]' || title == 'Pending Worst 10 [% Enriched]' || title == 'Worst 10 by Process Owner [% Validated Service]' || title == 'Worst 10 by Process Owner [% Confirmed Service]' || title == 'Best 10 by Process Owner [% Validated Service]' || title == 'Best 10 by Process Owner [% Confirmed Service]' || title == 'Worst 10% Validated by Business/Function'  || title == 'Worst 10% Enriched by Business/Function' || title == 'Comparison Region [% Confirmed Service]' || title == 'Comparison Region [% Validated Service]'){
    	eventClick = onSeriesClick2;
 	}else if(title == 'Systems per business/function' || title == 'Buildings by country' || title == 'Processes per critical service provider' || title == 'Critical Service Providers by FTE' || title == 'Location by FTE' || title == 'Third party suppliers by business' || title == 'Third party suppliers by country'){
		eventClick = undefined;
	}else{
		eventClick = onSeriesClick;
	}
	 $("#receivercategorychart").kendoChart({
		dataSource: {
			data:data,
			dataType: "json"
		},
		legend :{
			position :"top",
			margin:{
				visible:true,
				top:40
			},
			font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
		},
		transitions: false,
		chartArea: {
				height: (data.length == 1)? 55 : (55 * data.length) + 60,
			},
		seriesDefaults: {
			
			type: "bar",
			overlay: {
				gradient: "none"
			},
			tooltip: {
				visible: false,
				template: "#:kendo.toString(value,'N0')#"
			}, 
			labels: {
				font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
				color: "#002951",
				visible: true,
				position:"outsideEnd",
				template : function(e){
					if (title == 'Worst 10 [% Validated]' || title == 'Worst 10 [% Enriched]' || title == 'Worst 10% Validated by Business/Function' || title == 'Worst 10% Enriched by Business/Function' || title == 'Best 10 [% Validated]' || title == 'Best 10 [% Enriched]' || title == 'Pending Best 10 [% Validated]' || title == 'Pending Best 10 [% Enriched]'|| title == 'Pending Worst 10 [% Validated]' || title == 'Pending Worst 10 [% Enriched]' || title == 'Best 10 by Process Owner [% Validated Service]' || title == 'Best 10 by Process Owner [% Confirmed Service]' || title == 'Worst 10 by Process Owner [% Validated Service]' || title == 'Worst 10 by Process Owner [% Confirmed Service]') {
						return  '<tspan style="font:9px Helvetica Neue, Helvetica, Arial, sans-serif;" class="top1">' + e.value.toFixed(2) + "%" +
						'\n <tspan style="font:9px Helvetica Neue, Helvetica, Arial, sans-serif;" class="top2">' + parseInt(e.dataItem.Value.toFixed(0)).toLocaleString()+ '</tspan>'+
						'\n <tspan style="font:10px Helvetica Neue, Helvetica, Arial, sans-serif;" class="centerize-1">Rank ' + e.dataItem.Rank+ '</tspan>'
					}else if (title == '% Validated all Countries' || title == '% Enriched all Countries' || title == 'Comparison Region [% Validated Service]' || title == 'Comparison Region [% Confirmed Service]'){
						return  '<tspan style="font:9px Helvetica Neue, Helvetica, Arial, sans-serif;">' + e.value.toFixed(2) + "%" +
						'\n <tspan style="font:9px Helvetica Neue, Helvetica, Arial, sans-serif;">' + parseInt(e.dataItem.Value.toFixed(0)).toLocaleString()+ '</tspan>'
					}else{
						return parseInt(e.value.toFixed(0)).toLocaleString()
					}
				},			 
				background: "transparent"
			},
			gap: 0.3,
			color: "#005C84",
		},
		render: function(){
			if(data.length > 0){
				setRankPosition()
        	}
        },
		series: [{
			field: "Count",
			border: {
				width: 1,
				color: "transparent"
			},
			color: function(e){
				if(title == 'Comparison Region [% Confirmed Service]' || title == 'Comparison Region [% Validated Service]'){
		  			if(flags[e.category] == 'Global'){
		  				return "#005C84"
		  			}else if(flags[e.category] == 'Region'){
		  				return "#3C95B9"
		  			}else{
		  				return "#8ADFFF"
		  			}
		  		}else if (title.indexOf('[%') > 1 && oa.receivingCountry()[0] == e.category) {
					return "#8ADFFF"
				}else if(title == 'Process by GBS and Others'){
					if(e.dataItem.Color == 'gbs'){
						return "#2F7528"
					}else{
						return "#005C84"
					}
				}else{
					return "#005C84"
				}
			}
		}],
		categoryAxis :{
			field : "_id",
			labels: {
				template: labelTemplate,
				font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
		valueAxis:{
			min: 0,
			max: maxValueAxis, 
			// maxValueAxis,
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
		},
		tooltip: {
			visible: true,
			format: "n0",
		},
		seriesClick: eventClick,
		seriesColors: ["#66DBFF"],
		seriesHover: function(e) {
			setTimeout(function(){
				$("#receivercategorychart g path").each(function (idx){
					var op = $(this).attr('stroke-opacity');
					if (op == 0.2){
						if (title.indexOf('[%') > -1 && oa.receivingCountry()[0] == e.category) {
							$(this)
							.attr('fill','#50D0FF')
							.attr('fill-opacity', 1)
						}else if(title == 'Comparison Region [% Confirmed Service]' || title == 'Comparison Region [% Validated Service]'){
							if(flags[e.category] == 'Global'){
				  				$(this)
								.attr('fill','#002951')
								.attr('fill-opacity', 1)
				  			}else if(flags[e.category] == 'Region'){
				  				$(this)
								.attr('fill','#23576C')
								.attr('fill-opacity', 1)
				  			}else{
				  				$(this)
								.attr('fill','#50D0FF')
								.attr('fill-opacity', 1)
				  			}
				  		}else if(title == 'Process by GBS and Others'){
			                if(e.dataItem.Color == 'gbs'){
			                	$(this)
								.attr('fill','#1f4f1a')
								.attr('fill-opacity', 1)
							}else{
								$(this)
								.attr('fill','#002951')
								.attr('fill-opacity', 1)
							}
						}else{
							$(this)
							.attr('fill','#002951')
							.attr('fill-opacity', 1)
						}
					};
				}); 
			},10);
		}
	});
	var isFound = false
	jQuery('#receivercategorychart g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
		if (isFound) return
		if ($(e).html() == '') isFound = true
		$(e).find('text').attr('x', 0)
	})
	labelChart = [];
	function labelTemplate(e) {
		var finalStm = "";
		var maxlen = 14;
		var Spl = e.value.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
			lenStm = lenStm + o.length + 1;
			var tb = "";
			if (lenStm <= maxlen) {
				tb = " ";
			} else {
				lenStm = o.length;
				tb = "\n";
			}
			if (i == 0) {
				tb = "";
			}
			finalStm = finalStm + tb + o;
		});  
		return finalStm
	}
	function setRankPosition(){
		var chart = $("#receivercategorychart").data("kendoChart");
    	padding = 5
    	newX = parseInt(chart._plotArea.axisY.children[0].box['x2']) + 9.5 + padding
         $('.centerize-1').each(function (idx){
            newY = $(this).parent().parent().attr('Y') - 14
            $(this).parent().parent().attr('fill','#fff').attr('x',newX).attr('y',newY)
        });
        $('.top1').each(function (idx){
            newY = parseInt($(this).parent().parent().attr('Y')) + 6
            $(this).parent().parent().attr('y',newY)
        });
         $('.top2').each(function (idx){
            newY = parseInt($(this).parent().parent().attr('Y')) + 6
            $(this).parent().parent().attr('y',newY)
        });
	}
	var chart = $("#receivercategorychart").data("kendoChart"),
	firstSeries = chart.options.series;
	firstSeries[0].gap = parseFloat(0.3, 10);
	chart.redraw();
	alignLegendLeft();
	function onSeriesClick(e) {
		$("#grid-pupUp-chart").html("");
		
		if(title.toLowerCase() === "barriers to resolution by region" || title.toLowerCase() === "different types  of barriers"){
			console.log(title);
			if(title.toLowerCase() === "barriers to resolution by region" ){
				var payload = {
	      			Functiontype 		: oa.functionType(),
					Region 				: [e.category],
					ReceiverCountry 	: oa.receivingCountry(),
					ReceiverLegalEntity : oa.receivingLegalEntity(),
					SupplierCountry 	: oa.supplycountry(),
					SupplierLegalEntity : oa.supplylegalentity(),
					Suppliertype 		: oa.supplytype(),
					Categoryname 		: oa.categoryname(),
					Productfunction 	: oa.product(),
					Pfpcritical 		: oa.necessary(),
					Cefcritical 		: oa.cef(),
					LegalSignatory 		: oa.LegalSignatory(),
					WorstType 			: oa.filterProductName(),
					Parentprocessname 	: oa.parentprocessname(),
					GPO 				: oa.globalprocessowner(),
				};
			}else{
				var payload = {
	      			Functiontype 		: oa.functionType(),
					Region 				: oa.region(),
					ReceiverCountry 	: oa.receivingCountry(),
					ReceiverLegalEntity : oa.receivingLegalEntity(),
					SupplierCountry 	: oa.supplycountry(),
					SupplierLegalEntity : oa.supplylegalentity(),
					Suppliertype 		: oa.supplytype(),
					Categoryname 		: oa.categoryname(),
					Productfunction 	: oa.product(),
					Pfpcritical 		: oa.necessary(),
					Cefcritical 		: oa.cef(),
					LegalSignatory 		: oa.LegalSignatory(),
					WorstType 			: oa.filterProductName(),
					Parentprocessname 	: oa.parentprocessname(),
					GPO 				: oa.globalprocessowner(),
				};
				payload.Barriertype =  e.category;
			 }

		    $("#grid-pupUp-chart").kendoGrid({
		        dataSource: {
		            transport: {
		               read:function(options){
		                    payload.filter = options.data.filter
		                    payload.page = options.data.page
		                    payload.pageSize = options.data.pageSize
		                    payload.skip = options.data.skip
		                    payload.sort = options.data.sort
		                    payload.take = options.data.take
		                    ajaxPost("/ociranalysis/popupbarrier", payload, function(datas){
		                        options.success(datas);  
		                    	$('#modalChart').modal('show');
	                    		setTimeout(function() {
									$('#grid-pupUp-chart .k-grid-content').height(270);
								}, 300);
		                    })
		                }, 
		            },
		            schema: {
		                data: function(data) {      
		                    if (data.Count == 0) {
		                        return dataSource;
		                    } else {
		                        return data.Records;
		                    }   
		                },
		                total: "Count",
		            },
		            pageSize: 10,
		            serverPaging: true,
		            serverSorting: true,
		            serverFiltering: true, 
		            sort: [
		                {field:"receivercountry",dir:"asc"},
		                {field:"suppliercountry",dir:"asc"},
		                {field:"categoryname_",dir:"asc"},
		                {field:"productfunction",dir:"asc"},
		                {field:"parentprocessname",dir:"asc"},
		                {field:"processname",dir:"asc"},
		                {field:"servicedescription",dir:"asc"},
		                {field:"barriertype",dir:"asc"},


		                {field:"suppliername",dir:"asc"},
		                {field:"suppliertype",dir:"asc"},
		                {field:"contractid",dir:"asc"},
		                {field:"slaid",dir:"asc"},
		                {field:"buildingname",dir:"asc"},

		                {field:"teamcostcentre",dir:"asc"}, 
		            ],
		        },
		        height: 350,
		        columns: [
		           {
		                field:"receivercountry",
		                title:'Receiver Country',
		                /*filterable: false,*/
		                width:180,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                },
		                template: "#= receivercountry + ' - ' + receiverlegalentity #",
		            },
		            {
		                field:"suppliercountry",
		                title:'Supplier Country',
		                /*filterable: false,*/
		                width:180,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                },
		                template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
		            },
		            {
		                field:"categoryname_",
		                title:'Business',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"productfunction",
		                title:'Product',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"parentprocessname",
		                title:'Level 1 Process',
		                /*filterable: false,*/
		                width:250,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"processname",
		                title:'Level 2 Process',
		                /*filterable: false,*/
		                width:250,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"servicedescription",
		                title:'Service Description',
		                /*filterable: false,*/
		                width:250,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"barriertype",
		                title:'Barrier Type',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"suppliername",
		                title:'Supplier Name',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            },
		            {
		                field:"suppliertype",
		                title:'Supplier Type',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }, 
		            {
		                field:"contractid",
		                title:'Contract ID',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }, 
		            {
		                field:"slaid",
		                title:'SLA ID',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }, 
		            {
		                field:"buildingname",
		                title:'Building Name',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }, 
		            {
		                field:"teamcostcentre",
		                title:'Cost Centre',
		                /*filterable: false,*/
		                width:130,
		                attributes: {
		                    "class": "field-ellipsis"
		                },
		                headerAttributes: {
		                    "class": "align-left"
		                }
		            }
		        ],
		        excel: {
		            // fileName: "PopUpIntraGroupDonut.xlsx",
		            allPages: true
		        },
		        sortable: true,
		        pageable: {
		            refresh: true,
		            pageSizes: true,
		            buttonCount: 1,
		            pageSize: 20,
		        	pageSizes: [5, 10, 20],
		        },
		        // filterable: {
		        //     extra:false, 
		        //     operators: {
		        //         string: {
		        //             contains: "Contains",
		        //             startswith: "Starts with",
		        //             eq: "Is equal to",
		        //             neq: "Is not equal to",
		        //             doesnotcontain: "Does not contain",
		        //             endswith: "Ends with"
		        //         },
		        //     }
		        // }, 
		        height: 380,
		    });
		}else{
			if(title.toLowerCase() === "service fte"){
				var url = "/ociranalysis/modalforfte";
				var supplier = oa.supplycountry();
				var product
				var cate
				if ( oa.categoryname().length === 0 ){
					cate = [e.category];
				}else {
					cate = oa.categoryname();
					product = [e.category];
				}
				var seriesColoumns = [{
					field:"_id",
					title:'Function Name',
					width:200,
					attributes: {
						"class": "field-ellipsis"
					},
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"Count",
					title:'FTE',
					width:100,
					attributes: {
						"class": "field-ellipsis align-right"
					},
					template: "#:kendo.toString(Count,'N2')#",
					headerAttributes: {
						"class": "align-right"
					},
				}]
			}else if(title.toLowerCase() === "fte by country"){
				var url = "/ociranalysis/modalforfte";
				var supplier
				var suplegal
				if ( oa.supplycountry().length === 0 ){
					supplier = [e.category];
					entity = oa.supplylegalentity();
				}else {
					supplier = oa.supplycountry()
					entity = [e.category]
					if ( oa.supplylegalentity().length === 0 ){
						suplegal = [e.category];
					}else {
						suplegal = oa.supplylegalentity();
						fname = e.category;
					}
				}
				var seriesColoumns = [{
					field:"_id",
					title:'Function Name',
					width:200,
					attributes: {
						"class": "field-ellipsis"
					},
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"Count",
					title:'FTE',
					width:100,
					attributes: {
						"class": "field-ellipsis align-right"
					},
					headerAttributes: {
						"class": "align-right"
					},
					template: "#:kendo.toString(Count,'N2')#"
				}]
			}else if(title.toLowerCase() === "level 1 by country"){
				var url = "/ociranalysis/getdetailchart";
				var supplier
				var suplegal 
				var fname
				if ( oa.supplycountry().length === 0 ){
					supplier = [e.category];
					suplegal = oa.supplylegalentity(); 
				}else {
					supplier = oa.supplycountry()
					entity = [e.category] 
					if ( oa.supplylegalentity().length === 0 ){
						suplegal = [e.category];
					}else {
						suplegal = oa.supplylegalentity();
						fname = e.category;
						if ( oa.categoryname().length === 0 ){
							cate = [e.category];
						}else {
							cate = oa.categoryname();
							product = [e.category];
						}
					}
				}
				var seriesColoumns = [{
					field:"_id.Parentprocessname",
					title:'Level 1 Process',
					width:200,
					attributes: {
						"class": "field-ellipsis"
					},
					headerAttributes: {
						"class": "align-left"
					},
				}]
			}else if (title.toLowerCase() === "assets utilized"){
				var url = "/ociranalysis/getdetailassetutilized";
				var supplier = oa.supplycountry();
				var Typebar = "";
				var seriesColoumns;
				switch(e.category){
				case 'Buildings':
					Typebar = "BLD";
					seriesColoumns = [{
						field:"_id.buildingid",
						title:'Building ID',
						width: 50,
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						}
					},{
						field:"_id.buildingname",
						title:'Building Name',
						width: 150,
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						},
					}]
				break;
				case 'External Systems':
					Typebar = "ES";
					seriesColoumns = [{
						field:"_id.supplierid",
						title:'Supplier ID',
						width: 50,
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						}
					},{
						field:"_id.suppliername",
						title:'Name',
						width: 150,
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						},
					}]
				break;
				case 'Internal Systems':
					Typebar = "IS";
					seriesColoumns = [{
						field:"_id.supplierid",
						title:'Supplier ID',
						width: 50,
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						}
					},{
						field:"_id.suppliername",
						title:'Name',
						width: 150,
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						},
					}]
				break;
				case 'Data Centers':
					Typebar = "DC";
					seriesColoumns = [{
						field:"_id.hublocationcountry",
						title:'Hub Location',
						width: 50,
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						}
					},{
						field:"_id.systemshublocation",
						title:'Hub Location Country',
						width: 150,
						attributes: {
							"class": "field-ellipsis"
						},
						headerAttributes: {
							"class": "align-left"
						},
					}]
				break;
				}
			}else{
				var url = "/ociranalysis/getdetailchart";
				var supplier = oa.supplycountry();
				var product = [e.category]
				var seriesColoumns = [{
					field:"_id.Parentprocessname",
					title:'Level 1 Process',
					width:200,
					attributes: {
						"class": "field-ellipsis"
					},
					headerAttributes: {
						"class": "align-left"
					},
				}]
			}
	 
			if (title.toLowerCase() === "assets utilized"){
				var payload = {
					Functiontype : oa.functionType(),
					Region : oa.region(),
					ReceiverCountry     : oa.receivingCountry(),
					ReceiverLegalEntity : oa.receivingLegalEntity(),
					SupplierCountry     : supplier,
					SupplierLegalEntity : oa.supplylegalentity(),
					Suppliertype        : oa.supplytype(),
					Categoryname        : oa.categoryname(),
					Productfunction     : oa.product(),
					Pfpcritical         : oa.necessary(),
					Cefcritical         : oa.cef(),
					Parentprocessname 	: oa.parentprocessname(),
					GPO 				: oa.globalprocessowner(),
					Typebar             : Typebar
				};
			}else if (title.toLowerCase() === "level 1 by country") {
				var payload = {
					Functiontype : oa.functionType(),
					Region : oa.region(),
					ReceiverCountry : oa.receivingCountry(),
					ReceiverLegalEntity : oa.receivingLegalEntity(),
					SupplierCountry : supplier,
					SupplierLegalEntity : suplegal,
					Functionname : fname,
					Suppliertype: oa.supplytype(),
					Categoryname : cate,
					Productfunction : product,
					Pfpcritical : oa.necessary(),
					Cefcritical : oa.cef(),
					Parentprocessname 	: oa.parentprocessname(),
					GPO 				: oa.globalprocessowner(),
				};
				console.log(payload);	
			}else if (title.toLowerCase() === "biggest"){
				var payload = {
					Functiontype        : oa.functionType(),
					Region              : oa.region(),
					ReceiverCountry     : oa.receivingCountry(),
					ReceiverLegalEntity : oa.receivingLegalEntity(),
					SupplierCountry     : oa.supplycountry(),
					SupplierLegalEntity : oa.supplylegalentity(),
					Suppliertype        : oa.supplytype(),
					Categoryname        : [],
					Productfunction     : [],
					Pfpcritical         : oa.necessary(),
					Cefcritical         : oa.cef(),
					Parentprocessname 	: oa.parentprocessname(),
					GPO 				: oa.globalprocessowner(),
				};
				if (oa.categoryname().length == 1 ){
					payload.Productfunction = [e.category]
					payload.Categoryname =  oa.categoryname();
				}else{
					payload.Categoryname =  [e.category];
				}
			}else if (title.toLowerCase() === "process by gbs and others"){
				var payload = {
					Functiontype        : oa.functionType(),
					Region              : oa.region(),
					ReceiverCountry     : oa.receivingCountry(),
					ReceiverLegalEntity : oa.receivingLegalEntity(),
					SupplierCountry     : oa.supplycountry(),
					SupplierLegalEntity : oa.supplylegalentity(),
					Suppliertype        : oa.supplytype(),
					Categoryname        : oa.categoryname(),
					Productfunction     : oa.product(),
					Pfpcritical         : oa.necessary(),
					Cefcritical         : oa.cef(),
					Parentprocessname 	: oa.parentprocessname(),
					GPO 				: oa.globalprocessowner(),
				};
				if (e.category.length == 1 ){
					payload.ReceiverCountry =  oa.receivingCountry();
				}else{
					payload.ReceiverCountry =  [e.category];
				}
			}else {
				var payload = {
	      			Functiontype 		: oa.functionType(),
					Region 				: oa.region(),
					ReceiverCountry 	: oa.receivingCountry(),
					ReceiverLegalEntity : oa.receivingLegalEntity(),
					SupplierCountry 	: supplier,
					SupplierLegalEntity : suplegal,
					Functionname 		: fname,
					Suppliertype 		: oa.supplytype(),
					Categoryname 		: cate,
					Productfunction 	: product,
					Pfpcritical 		: oa.necessary(),
					Cefcritical 		: oa.cef(),
					Parentprocessname 	: oa.parentprocessname(),
					GPO 				: oa.globalprocessowner(),
				};
			} 

			$("#grid-pupUp-chart").kendoGrid({
				dataSource: {
					transport: {
						read:function(option){
							ajaxPost(url, payload, function(datas){
								option.success(datas); 
								$('#modalChart').modal('show');
								setTimeout(function() {
								$('#grid-pupUp-chart .k-grid-content').height(270);
								}, 300);
							})
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					},
					sort: [
						{field:"_id.Parentprocessname",dir:"asc"},
						{field:"_id",dir:"asc"},
						{field:"_id.buildingid",dir:"asc"},
						{field:"_id.buildingname",dir:"asc"},
						{field:"_id.supplierid",dir:"asc"},
						{field:"_id.hublocationcountry",dir:"asc"},
						{field:"_id.systemshublocation",dir:"asc"},
					]
				},
				excel: {
					fileName: "Level 1 Processes.xlsx",
					allPages: true
				},
				columns: seriesColoumns,
				sortable: true,
				filterable: {
					extra:false, 
					operators: {
						string: {
							contains: "Contains",
							startswith: "Starts with",
							eq: "Is equal to",
							neq: "Is not equal to",
							doesnotcontain: "Does not contain",
							endswith: "Ends with"
						},
					}
				},
				pageable: {
					numeric: false,
					previousNext: false,
					messages: {
						display: "Showing {2} data items"
					}
				},
				height: 350,
			});
		}


		
	}
	function onSeriesClick2(e){
		var worstType;
		switch (title){
			case"Worst 10 [% Validated]":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'validated'
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
			break;
			case"Worst 10 [% Enriched]":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'enriched'
				tabFirstName = 'Enriched';
				tabSecondName = 'Pending Item';
				flagTab1 = 'enriched';
				flagTab2 = 'pendingenriched';
			break;
			case 'Worst 10% Validated by Business/Function':
				region = oa.region()
				country = oa.receivingCountry();
				if (oa.categoryname().length === 0){
					categoryname = [e.category];
					product = oa.product();
				}else{
					categoryname = oa.categoryname();
					product = [e.category];
				}
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
				worstType = 'businnessvalidated'
			break;
			case 'Worst 10% Enriched by Business/Function':
				region = oa.region()
				country = oa.receivingCountry();
				if (oa.categoryname().length === 0){
					categoryname = [e.category];
					product = oa.product();
				}else{
					categoryname = oa.categoryname();
					product = [e.category];
				}
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
				worstType = 'businnessenriched'
			break;
			case"Best 10 [% Validated]":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'reversevalidated'
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
			break;
			case"Best 10 [% Enriched]":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'reverseenriched'
				tabFirstName = 'Enriched';
				tabSecondName = 'Pending Item';
				flagTab1 = 'enriched';
				flagTab2 = 'pendingenriched';
			break;
			case"Pending Best 10 [% Validated]":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'pendingbestvalidated'
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
			break;
			case"Pending Best 10 [% Enriched]":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'pendingbestenriched'
				tabFirstName = 'Enriched';
				tabSecondName = 'Pending Item';
				flagTab1 = 'enriched';
				flagTab2 = 'pendingenriched';
			break;
			case"Pending Worst 10 [% Validated]":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'pendingworstvalidated'
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
			break;
			case"Pending Worst 10 [% Enriched]":
				region = oa.region()
				country = [e.category];
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'pendingworstenriched'
				tabFirstName = 'Enriched';
				tabSecondName = 'Pending Item';
				flagTab1 = 'enriched';
				flagTab2 = 'pendingenriched';
			break;
			case"Worst 10 by Process Owner [% Validated Service]":
				region = oa.region()
				country = oa.receivingCountry();
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'worstownervalidated'
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
			break;
			case"Worst 10 by Process Owner [% Confirmed Service]":
				region = oa.region()
				country = oa.receivingCountry();
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'worstownerenriched'
				tabFirstName = 'Enriched';
				tabSecondName = 'Pending Item';
				flagTab1 = 'enriched';
				flagTab2 = 'pendingenriched';
			break;
			case"Best 10 by Process Owner [% Validated Service]":
				region = oa.region()
				country = oa.receivingCountry();
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'bestownervalidated'
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
			break;
			case"Best 10 by Process Owner [% Confirmed Service]":
				region = oa.region()
				country = oa.receivingCountry();
				categoryname = oa.categoryname();
				product = oa.product();
				worstType = 'bestownerenriched'
				tabFirstName = 'Enriched';
				tabSecondName = 'Pending Item';
				flagTab1 = 'enriched';
				flagTab2 = 'pendingenriched';
			break;
			case"Comparison Region [% Validated Service]":
				categoryname = oa.categoryname();
				product = oa.product();
				if (oa.region() === 0) {
					region = [e.category]
				}else{
					if(e.dataItem.Flag == 'Global'){
						region =  oa.region()
						country = oa.receivingCountry()
					}else if(e.dataItem.Flag == 'Region'){
						region =  [e.category]
						country = oa.receivingCountry()
					}else{
						region = oa.region()
						country = [e.category]
					}
				}
				worstType = 'comparisonvalidated'
				tabFirstName = 'Validated';
				tabSecondName = 'Pending Item';
				flagTab1 = 'validated';
				flagTab2 = 'pendingvalid';
			break;
			case"Comparison Region [% Confirmed Service]":
				categoryname = oa.categoryname();
				product = oa.product();
				if (oa.region() === 0) {
					region = [e.category]
				}else{
					if(e.dataItem.Flag == 'Global'){
						country = oa.receivingCountry()
						region =  oa.region();
					}else if(e.dataItem.Flag == 'Region'){
						region =  [e.category]
						country = oa.receivingCountry()
					}else{
						region = oa.region()
						country = [e.category]
					}
				}
				worstType = 'comparisonenriched'
				tabFirstName = 'Enriched';
				tabSecondName = 'Pending Item';
				flagTab1 = 'enriched';
				flagTab2 = 'pendingenriched';
			break;
		}
		oa.titleFile = title
		oa.sheetFirstName = tabFirstName
		oa.sheetSecondName = tabSecondName
        dataItemFlag = e.dataItem.Flag;
		var payload = {
      		Functiontype 		: oa.functionType(),	
			Region 				: region,
			ReceiverCountry     : country,
			ReceiverLegalEntity : oa.receivingLegalEntity(),
			SupplierCountry     : oa.supplycountry(),
			SupplierLegalEntity : oa.supplylegalentity(),
			Suppliertype        : oa.supplytype(),
			Categoryname        : categoryname,
			Productfunction     : product,
			Pfpcritical         : oa.necessary(),
			Cefcritical         : oa.cef(),
			Parentprocessname 	: oa.parentprocessname(),
			GPO 				: oa.globalprocessowner(),
			worstType			: worstType,
		};
		var payload = $.extend(payload,{Global : ''});
		if (title == 'Worst 10 by Process Owner [% Validated Service]' || title == 'Worst 10 by Process Owner [% Confirmed Service]' || title == 'Best 10 by Process Owner [% Validated Service]' || title == 'Best 10 by Process Owner [% Confirmed Service]') {
			var payload = $.extend(payload,{Pfpprocessowner : [e.category]});
		};
		if (title == 'Comparison Region [% Validated Service]' || title == 'Comparison Region [% Confirmed Service]') {
			if([e.dataItem.Flag] == 'Global'){
				var payload = $.extend(payload,{Global : 'Y'});
  			}else if([e.dataItem.Flag] == 'Region'){
				var payload = $.extend(payload,{Global : 'N'});
  			}else{
				var payload = $.extend(payload,{Global : 'N'});
  			}
		};
		ajaxPost("/ociranalysis/popupnewbar",payload , function (res){
			$('#modaltab-name-first').text(tabFirstName);
			$('#modaltab-name-second').text(tabSecondName);
			$('#modaltab').modal('show');
			setTimeout(function() {
				$('#modaltab .k-grid-content').height(300);
			},300) 
  		if (tabFirstName == 'Pending Item') {
	        $("#pendingtab ul").find('li').removeClass('active')
	       	$("#pendingtab ul li:eq(0)").addClass('active')
	        $("#pendingtab").tabs({active:0});
	    }else{
	        $("#pendingtab ul").find('li').removeClass('active')
	        $("#pendingtab ul li:eq(1)").addClass('active')
	        $("#pendingtab").tabs({active:1});
    	};
		$("#grid-chart-1").html("");
		$("#grid-chart-1").kendoGrid({
			dataSource: {
				transport: {
					read:function(option){
					 	res.tab1.forEach(function (d) {
					 		d.type = title
							d.worstType = worstType
							d.receivercountry = e.category
							d.flagTab = flagTab1
							d.Global = payload.Global 
                			d.flagRegion = dataItemFlag
						})

						option.success(res.tab1);
					},
					parameterMap: function(data) {
						return JSON.stringify(data);
					},
				},
			}, 
			columns: [{
				field:"Country",
				title:'PFP Process Name',
				width:100,
				attributes: {
					"class": "field-ellipsis"
				},
				headerAttributes: {
					"class": "align-left"
				},
			},{
				field:"Count",
				title:'Total',
				width:50,
				attributes: {
					"class": "field-ellipsis align-right"
				},
				template: "#if(Count !== 0){# <a href=\"\\#\" onclick='popupdetail(\"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\",\"#:worstType#\",\"#:flagTab#\",\"#:receivercountry#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
				headerAttributes: {
					"class": "align-right"
				},
			}],
			sortable: true,
			filterable: {
				extra:false, 
				operators: {
					string: {
						contains: "Contains",
						startswith: "Starts with",
						eq: "Is equal to",
						neq: "Is not equal to",
						doesnotcontain: "Does not contain",
						endswith: "Ends with"
					},
				}
			},
			pageable: {
				numeric: false,
				previousNext: false,
				messages: {
					display: "Showing {2} data items"
				}
			},
			height: 380
		});
		$("#grid-chart-2").html("");
		$("#grid-chart-2").kendoGrid({
			dataSource: {
				transport: {
					read:function(option){
					 	res.pending.forEach(function (d) {
					 		d.type = title
							d.worstType = worstType
							d.receivercountry = e.category
							d.flagTab = flagTab2
							d.Global = payload.Global
                			d.flagRegion = dataItemFlag
						})
						option.success(res.pending); 
					},
					parameterMap: function(data) {
						return JSON.stringify(data);
					},
				},
			}, 
			columns: [{
				field:"Country",
				title:'PFP Process Name',
				width:100,
				attributes: {
					"class": "field-ellipsis"
				},
				headerAttributes: {
					"class": "align-left"
				},
			},{
				field:"Count",
				title:'Total',
				width:50,
				attributes: {
					"class": "field-ellipsis align-right"
				},
				template: "#if(Count !== 0){# <a href=\"\\#\" onclick='popupdetail(\"#:flagRegion#\",\"#:type#\",\"#:Global#\",\"#:Country#\",\"#:worstType#\",\"#:flagTab#\",\"#:receivercountry#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
				headerAttributes: {
					"class": "align-right"
				},
			}],
			sortable: true,
			filterable: {
				extra:false, 
				operators: {
					string: {
						contains: "Contains",
						startswith: "Starts with",
						eq: "Is equal to",
						neq: "Is not equal to",
						doesnotcontain: "Does not contain",
						endswith: "Ends with"
					},
				}
			},
			pageable: {
				numeric: false,
				previousNext: false,
				messages: {
					display: "Showing {2} data items"
				}
			},
			height: 380
			});
		})
	}
};
function popupdetail(flagRegion, type, Global, Country, worstType, flagTab, receivercountry){
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry     : oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(),
		Suppliertype        : oa.supplytype(),
		Productfunction     : oa.product(),
		Pfpcritical         : oa.necessary(),
		Cefcritical         : oa.cef(),
		WorstType			: worstType,
		Owner 			    : Country,
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
		FlagTab			 	: flagTab
	};
	var payload = $.extend(payload,{Global : ''});
	if(type == 'Comparison Region [% Validated Service]' || type == 'Comparison Region [% Confirmed Service]'){
		if(flagRegion == 'Global'){
			payload.ReceiverCountry = oa.receivingCountry()
			payload.Region =  oa.region();
		}else if(flagRegion == 'Region'){
			payload.Region =  [receivercountry]
			payload.ReceiverCountry = oa.receivingCountry()
		}else{
			payload.Region = oa.region()
			payload.ReceiverCountry = [receivercountry]
		}
		payload.Global = Global
		payload.Categoryname = oa.categoryname()
	}else if(type == 'Worst 10% Validated by Business/Function' || type == 'Worst 10% Enriched by Business/Function'){
		payload.ReceiverCountry = oa.receivingCountry()
		payload.Categoryname = [receivercountry]
	}else if (type == 'Worst 10 by Process Owner [% Validated Service]' || type == 'Worst 10 by Process Owner [% Confirmed Service]' || type == 'Best 10 by Process Owner [% Validated Service]' || type == 'Best 10 by Process Owner [% Confirmed Service]') {
		payload.ReceiverCountry = oa.receivingCountry()
	}else if(type == '% Validated all Countries' || type == '% Enriched all Countries'){
		payload.ReceiverCountry = [receivercountry]
		payload.FlagTab = flagTab
	}else{
		payload.ReceiverCountry = [receivercountry]
		payload.Categoryname = oa.categoryname()
	}
	ajaxPost("/ociranalysis/popupnewbar2",payload , function (res){
		$('#modaltab').modal('hide');
		$('#modaldetail').modal('show');
		setTimeout(function() {
			$('#modaldetail .k-grid-content').height(300);
		},300)
		$("#grid-chart-detail").html("");
		$("#grid-chart-detail").kendoGrid({
			dataSource: {
				transport: {
					read:function(option){
						option.success(res);
					},
					parameterMap: function(data) {
						return JSON.stringify(data);
					},
				},
			},
			columns: [{
				field:"phpowner",
				title:'PFP Owner',
				width:100,
				attributes: {
					"class": "field-ellipsis"
				},
				headerAttributes: {
					"class": "align-left"
				},
			},{
				field:"processname",
				title:'Process Name',
				width:100,
				attributes: {
					"class": "field-ellipsis"
				},
				headerAttributes: {
					"class": "align-left"
				},
			},{
				field:"status",
				title:'Status',
				width:50,
			 	attributes: {
			      "class": "align-center"
			    },
			    headerAttributes: {
			      "class": "align-center"
			    },
			}],
			sortable: true,
			filterable: {
				extra:false,
				operators: {
					string: {
						contains: "Contains",
						startswith: "Starts with",
						eq: "Is equal to",
						neq: "Is not equal to",
						doesnotcontain: "Does not contain",
						endswith: "Ends with"
					},
				}
			},
			pageable: {
				numeric: false,
				previousNext: false,
				messages: {
					display: "Showing {2} data items"
				}
			},
			height: 380,
		});
	})
}
oa.exportExcelLv2 =  function(){
	var grid = $("#grid-chart-detail").data("kendoGrid");
	grid.saveAsExcel();
	var payload = {
       Type : "Ociranalysis Summary Drilldown Barchart Grid"
    }
    ajaxPost("/analyticuser/downloadlog", payload, function (res){
    }) 
}
oa.configSeries = function(indexData, selectorId){
	var color = ["#00506D","#0077A3","#50D0FF","#8ADFFF"];
	var visibleData   = $("#"+selectorId).getKendoChart().options.series[0].data[indexData].visible
	$("#"+selectorId).getKendoChart().options.series[0].data[indexData].visible = !visibleData
	$("#"+selectorId).getKendoChart().redraw();
	var datas = $("#"+selectorId).getKendoChart().options.series[0].data
	color = (!visibleData)?color[indexData]: '#9b9898';
	$("#legend-"+selectorId).find("td").eq(indexData).find(".square").css('background',color)
	var totalDataTrue = 0 
	$.each(datas, function(i, val){
		if(val.visible == true){
			totalDataTrue += val.value
		} 
	})
	$.each(datas, function(i, val){
		var percentage = 100 / (totalDataTrue / val.value)
		if(val.visible == true){ 
			$("#legend-"+selectorId+"-precentage_"+i).text(String(percentage.toFixed(0)) +"%")
		}else{
			$("#legend-"+selectorId+"-precentage_"+i).text('');
		}
	}) 
}
oa.chartDonutL3Processes = function(dataSource,title){
	oa.viewfullgrid(false)
	oa.viewfullchart(false);
	var color = ["#00506D","#0077A3","#50D0FF","#8ADFFF","#E6E7E8", "#BCBEC0"];   
	/*if(dataSource.Donut.length == 2){
		seriesColors = ["#00506D","#0077A3"];
	}*/
	
	$("#legend-chart-donutL3Processes table").html('')
	var data = []
	$.each(dataSource.Donut, function(index,value){
		data.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
		switch(value.category){
		case'FMI':
			var dataItem = 'FMI'
		break;
		case'FMI_System':
			var dataItem = 'FMI Systems'
		break;
		case'FMI_TPS':
			var dataItem = 'FMI External'
		break;
		case'Systems':
			var dataItem = 'Systems'
		break;
		case'IGS':
			var dataItem = 'Intra-Group'
		break;
		default:
			var dataItem = 'In-Entity'
		} 
		var percentage = (Math.abs(value.value) != 0) ? 100 / (dataSource.Total / value.value) : 0; 
		var mod = index % 2;
		var indexTr = Math.floor(index / 2)
		if(mod == 0) {
			$("#legend-chart-donutL3Processes").find("table").append("<tr>")
		}
		$("#legend-chart-donutL3Processes").find("table").find("tr").eq(indexTr).append("<td style='width=50%;height:25px;padding:0 10px;'><a onClick='oa.configSeries("+index+",\"chart-donutL3Processes\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right; padding-right:10px; ' id='legend-chart-donutL3Processes-precentage_"+index+"'></span></a></td>") 
		$("#legend-chart-donutL3Processes-precentage_"+index).text(percentage.toFixed(0)+"%")
	})
	if (dataSource.Total == 0) {
		$("#legend-chart-donutL3Processes").hide()	
	}else{
		$("#legend-chart-donutL3Processes").show()	
	};
	$("#chart-donutL3Processes").html('')
	$("#chart-donutL3Processes").kendoChart({
		legend: {
			visible:false,
			labels: {
				font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
				template: "#if(dataItem.category==='FMI_Systems'){# #: 'FMI Systems' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'Intra-Group' # #}else if(dataItem.category=='FMI_TPS'){# #: 'FMI External' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='FMI'){# #: 'FMI' # #}else{# #: 'In-Entity' #&nbsp;# # #}# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; #= removeSpace(kendo.toString(percentage,'P0'))# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
				color: "#0075B2"
			},
			margin:{
				visible:true,
				// left:30,
				top:-60
			},
			
			position: "bottom",
		},
		chartArea: {
			height : 450,
			background: "transparent",
			width : $(".donutSelector").width(),
			margin:{
				top:-30,
				left:-30,
				right:-30,
			},
		},
		seriesDefaults: {
			holeSize: 90,
			labels: {
				visible: false,
				template: "#= removeSpace(kendo.toString(percentage,'P0'))#", 
				background: "transparent"
			}
		},
		series: [{
			type: "donut",
			data: data,
			overlay:{gradient:"none"},
		}],
		valueAxis:{
			visible:false,
			labels: {
				font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
				visible: false,
				format:"{0:P0}",
			},
			majorGridLines: {
				visible: false
			},
		},
		tooltip: {
			visible: true,
			font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
			template: "#=kendo.toString(value,'N0')#"
		}
	});
	$("#inner-content").html('');
};
oa.columnGridDetailAnalysis  = ko.observableArray([]);
oa.payloadGridDetailAnalysis = {}
oa.loadingPopUpgrid = ko.observable(false);

oa.coloumnPopUp = ''
oa.payloadPopUp = ''
oa.sortPopUp = ''

oa.oldColoumnPopUp = ''
oa.oldPayloadPopUp = ''
oa.oldSortPopUp = ''

oa.popUpIndex = 0

oa.backPopUP = ko.observable(true);

oa.loadingPopupGridDetailAnalysis = ko.observable(false);
function backPopUP(){
	oa.loadingPopupGridDetailAnalysis(true);
	oa.backPopUP(false);
	oa.loadingPopUpgrid(true)
	$('#modal-grid-detail-analysis').modal('show');

	$("#grid-detail-analisys").html("");
	ajaxPost("/ociranalysis/processnamesummarydetail",oa.oldPayloadPopUp , function (res){
		oa.loadingPopupGridDetailAnalysis(false); 
		oa.listDataPopUp(res.Data.Records)
		
		$("#grid-detail-analisys").kendoGrid({
			dataSource: {
				data: res.Data.Records,
				sort:oa.oldSortPopUp
			},
			excel: {
				fileName: "Detail Analysis.xlsx",
				allPages: true
			},
			columns: oa.oldColoumnPopUp,
			sortable: true,
			filterable: {
				extra:false, 
				operators: {
					string: {
						contains: "Contains",
						startswith: "Starts with",
						eq: "Is equal to",
						neq: "Is not equal to",
						doesnotcontain: "Does not contain",
						endswith: "Ends with"
					},
				}
			},
			pageable: {
				numeric: false,
				previousNext: false,
				messages: {
					display: "Showing {2} data items"
				}
			},
			height: 380,
		});
		setTimeout(function() {
			$("#grid-detail-analisys").data("kendoGrid").resize();
			oa.coloumnPopUp = oa.oldColoumnPopUp 
			oa.payloadPopUp = 	oa.oldPayloadPopUp
			oa.sortPopUp = 	oa.oldSortPopUp

			oa.oldColoumnPopUp = ''
			oa.oldPayloadPopUp = ''
			oa.oldSortPopUp = ''
		}, 500);
		$("#load-grid-modal").hide("slow")
		oa.loadingPopUpgrid(false)
	})
}
oa.closePopUp = function (){
	oa.coloumnPopUp = ''
	oa.payloadPopUp = ''
	oa.sortPopUp = ''

	oa.oldColoumnPopUp = ''
	oa.oldPayloadPopUp = ''
	oa.oldSortPopUp = ''

	oa.popUpIndex = 0
}

popUpGridDetail = function(index,flag){

	oa.loadingPopupGridDetailAnalysis(true); 
	oa.loading(true)
	oa.loadingPopUpgrid(true)
	oa.flag(flag);
	var payload = {   
		Firstfilter:oa.firstFilter(),
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(),
		Suppliertype 		: oa.supplytype(),
		Categoryname 		: oa.categoryname(),
		LevelProcess 		: "",
		Productfunction 	: oa.product(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef(),
		CountField 			: flag,
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
	} 

	var dataDetailFilter; 
	if(!oa.checkPopUp()){
			var detailFilter = oa.listFieldDetailAnalysis()[index]
	delete detailFilter[flag]
		for(var i in detailFilter){
			if(oa.secondFilter().indexOf(i) > -1){
				delete detailFilter[i]
			}
		}
		dataDetailFilter = detailFilter;
	}else{

		dataDetailFilter = oa.listDataPopUp()[index];
		delete dataDetailFilter['CTR']
		delete dataDetailFilter['SLA']
		delete dataDetailFilter['MSA']
		delete dataDetailFilter['DC']
		delete dataDetailFilter['BDG']
		oa.checkPopUp(false);
	}
	payload.DetailFilter = dataDetailFilter;
	 
	var fields = []
		fields['L1'] = ["parentprocessname","CTR","SLA","MSA"];
		fields['L2'] = ["parentprocessname","processname","CTR","SLA","MSA"];
		fields['L3'] = ["parentprocessname","processname","servicedescription","CTR","SLA","MSA"];
		fields['TEAM'] = ["suppliercountryNlegalEntity","functionname","suppliername","teamunitheadname","servicefte","buildingname","teamcostcentre","SLA","MSA"];
		fields['TPV'] = ["suppliername",
						 "supplierlegalentity",
						 "supplierlegalentity",
						 "vendorid",
						 "servicetype",
						 "contractmanagername",
						 "CTR",
						 "supplierid"];
		fields['IS'] = ["supplierNlegalentity","systemshublocation","suppliername","itbusiness","servicedescription","itameuc","pssheadname","SLA"];
		fields['ES'] = ["supplierNlegalentity","systemshublocation","suppliername","itbusiness","servicedescription","itameuc","pssheadname","CTR","SLA"];
		fields['MSA'] = ["iscrefid" ,"iscdescription","suppliercount","receivercount","SLA"];
		fields['CTR'] = ["supplierlegalentity","contractid","contractdescription","contractavailable","iscontractglobal","contractlibrary","contractmanagername","perpetualcontractresolution","contractexpiry","contractresolutioncritical","contractmeetspra","contractresolutionlangproofed"];
		fields['SLA'] = ["slaid","sladescription","Slaparentreference","slamanagername","slaocircompliant","armslengthchargingstructure","slabasisforrecharge","MSA"];
		fields['DC'] = ["hublocationcountry","systemshublocation","scbownind","shareindhublocation","entityname"];
		fields['BDG'] = ["buildingname","buildingid","suppliercountry","scbownindbuilding","sharedindbuilding","buildingowner","contractidbuilding"];
		fields['FMI'] = ["suppliername","FMI_Access_Type"];

	var coloumnList_DC = [
		{
			field:"hublocationcountry",
			title:"Location Country",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"systemshublocation",
			title:"Hub Location",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"scbownind",
			title:"SCB Owned?",
			width:180,
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
			template:"#if(scbownind == 'NULL'){ ##: 'N' ##} else if ( scbownind == ''){ ##: 'N' ## } else { ##: scbownind ## }#"
		},{
			field:"shareindhublocation",
			title:"Shared with another party?",
			width:180,
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"entityname",
			title:"Data Center Owner",
			width:180,
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		}]
		var coloumnList_BDG = [{
			field:"buildingname",
			title:"Building Name",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"buildingid",
			title:"Building ID",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"suppliercountry",
			title:"Building Country",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"scbownindbuilding",
			title:"SCB Owned?",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"sharedindbuilding",
			title:"Shared with another party?",
			width:240, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"buildingowner",
			title:"Building Owner",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
			template:"#if(scbownindbuilding === 'Y'){ ##: entitynamebuilding ##} else { ##: tpsnamebuilding ## }#"
		},{
			field:"contractidbuilding",
			title:"Contracts",
			width:180, 
			headerAttributes: {
				"class": "align-right"
			},
			attributes: {"class": "field-ellipsis align-right"},
		}]
		var coloumnList_IS_ES =[{
			field:"supplierNlegalentity",
			title:"Vendor Name",
			width:240, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
			template: "#= suppliercountry + ' - ' + supplierlegalentity #",
		}, {
			field:"systemshublocation",
			title:"Systems Hub Location",
			width:240, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"}
		},{
			field:"suppliername",
			title:"System Name",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"itbusiness",
			title:"IT Product or Business Service",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},
		// {
		// 	field:"servicedescription",
		// 	title:"System Description",
		// 	width:180, 
		// 	headerAttributes: {
		// 		"class": "align-left"
		// 	},
		// 	attributes: {"class": "field-ellipsis align-left"},
		// },
		{
			field:"itameuc",
			title:"ITAM/EUC",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"pssheadname",
			title:"PSS Head Name",
			width:180, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},{
			field:"CTR",
			title:"Contracts",
			width:180, 
			headerAttributes: {
				"class": "align-right"
			},
			attributes: {"class": "field-ellipsis align-right"},
			template:"#if(CTR !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"CTR\")'>#:CTR#</a> #}else { ##: CTR ## }#"
		},{
			field:"SLA",
			title:"SLAs",
			width:180, 
			headerAttributes: {
				"class": "align-right"
			},
			attributes: {"class": "field-ellipsis align-right"},
			template:"#if(SLA !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"SLA\")'>#:SLA#</a> #}else { ##: SLA ## }#"
		}
	]
	var columns = [];
	var sorting = [];
	var indexPush = 0
	if(oa.firstFilter() == "FMI" && ( flag == "IS" || flag == "ES" || flag == "TPV")){ 
		if(flag == "IS"){
			var columns = [
				{
					field:"suppliername",
					title:"FMI Name",
					width:180, 
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"systemname",
					title:"System Name",
					width:180, 
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"MSA",
					title:"MSAs",
					width:180, 
					headerAttributes: {
						"class": "align-right"
					},
					attributes: {"class": "field-ellipsis align-right"},
					template:"#if(CTR !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"MSA\")'>#:MSA#</a> #}else { ##: MSA ## }#"
				},{
					field:"SLA",
					title:"SLAs",
					width:180, 
					headerAttributes: {
						"class": "align-right"
					},
					attributes: {"class": "field-ellipsis align-right"},
					template:"#if(SLA !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"SLA\")'>#:SLA#</a> #}else { ##: SLA ## }#"
				}
			];
		}else if(flag == "ES"){
			var columns = [
				{
					field:"suppliername",
					title:"FMI Name",
					width:180, 
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"systemname",
					title:"System Name",
					width:180, 
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"CTR",
					title:"Contracts",
					width:180, 
					headerAttributes: {
						"class": "align-right"
					},
					attributes: {"class": "field-ellipsis align-right"},
					template:"#if(CTR !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"CTR\")'>#:CTR#</a> #}else { ##: CTR ## }#"
				}
			];
		}else{
			var columns = [
				{
					field:"suppliername",
					title:"FMI Name",
					width:180, 
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"systemname",
					title:"Vendor Name",
					width:180, 
					headerAttributes: {
						"class": "align-left"
					},
				},{
					field:"CTR",
					title:"Contracts",
					width:180, 
					headerAttributes: {
						"class": "align-right"
					},
					attributes: {"class": "field-ellipsis align-right"},
					template:"#if(CTR !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"CTR\")'>#:CTR#</a> #}else { ##: CTR ## }#"
				}
			];
		}
	}else{
		if(flag === "IS" || flag === "ES"){
			$.each(coloumnList_IS_ES, function(i, v){
				if (fields[flag].indexOf(v.field) !== -1){
					columns.push(v)
					sorting.push({field:v.field,dir:"asc"})
				}
			})
			if(oa.firstFilter() != "FMI"){
				columns.push({
					field:"supplierid",
					title:"Supplier Id",
					width:150, 
					headerAttributes: {
						"class": "align-right"
					},
					attributes: {"class": "align-right"}
				});
			}
		}else if(flag === "DC"){
			$.each(coloumnList_DC, function(i, v){
				if (fields[flag].indexOf(v.field) !== -1){
					columns.push(v)
					sorting.push({field:v.field,dir:"asc"})
				}
			})
		}else if(flag === "BDG"){
			$.each(coloumnList_BDG, function(i, v){
				if (fields[flag].indexOf(v.field) !== -1){
					columns.push(v)
					sorting.push({field:v.field,dir:"asc"})
				}
			})
		}else{
			$.each(oa.default_listColoumn_detailAnalysis(), function(i, v){
				if (fields[flag].indexOf(v.field) !== -1){
					columns.push(v)
					sorting.push({field:v.field,dir:"asc"})
					if(flag === 'TEAM'){
						switch(v.field){
							case 'suppliername':
								columns[indexPush].title = 'Team Name'
							break;
						} 
					}
					if(flag === 'TPV'){
						switch(v.field){
							case 'suppliername':
								columns[indexPush].title = 'Supplier Name'
							break;
						} 
					}
					indexPush++;
				}
			});
		}
	}

	oa.oldColoumnPopUp = oa.coloumnPopUp;
	oa.oldPayloadPopUp = oa.payloadPopUp;
	oa.oldSortPopUp = 	oa.sortPopUp;
	if(oa.popUpIndex == 0){
		oa.backPopUP(false) 
	}else{
		oa.backPopUP(true) 	
	}
	oa.popUpIndex += 1
	oa.coloumnPopUp = columns
	oa.payloadPopUp = payload
	oa.sortPopUp 		= sorting 
	$("#grid-detail-analisys").html("");
	$("#grid-detail-analisys").css("height", "");
	$('#modal-grid-detail-analysis').modal('show');
	ajaxPost("/ociranalysis/processnamesummarydetail",payload , function (res){
		oa.loadingPopupGridDetailAnalysis(false);
		oa.listDataPopUp(res.Data.Records)
		$("#grid-detail-analisys").kendoGrid({
			dataSource: {
				data: res.Data.Records,
				sort:sorting
			},
			excel: {
				fileName: "Detail Analysis.xlsx",
				allPages: true
			},
			columns: columns,
			sortable: true,
			filterable: {
				extra:false, 
				operators: {
					string: {
						contains: "Contains",
						startswith: "Starts with",
						eq: "Is equal to",
						neq: "Is not equal to",
						doesnotcontain: "Does not contain",
						endswith: "Ends with"
					},
				}
			},
			pageable: {
				numeric: false,
				previousNext: false,
				messages: {
					display: "Showing {2} data items"
				}
			},
			height: 380,
		});
		setTimeout(function() {
			$("#grid-detail-analisys").data("kendoGrid").resize();
		}, 500);
		$("#load-grid-modal").hide("slow")
		oa.checkPopUp(true);
		oa.loadingPopUpgrid(false)
	})
};
oa.exportExcelGridDetailAnalysis =  function(){
	var payload = oa.payloadGridDetailAnalysis;
		payload.filter  = oa.filterGridProcessName();
		payload.Title  	= ((function(){
								results = []
	                        	 _.each(oa.columnGridDetailAnalysis(), function(o){
	                         		if(!_.has(o, "hidden"))
	                         			return results.push(o.title);
	                         		else{
	                         			if(!o.hidden)
	                         				return results.push(o.title);
	                         		}
	                         	});
	                         	return results;
	                       })())


		// _.pluck(oa.columnGridDetailAnalysis(), 'title');

	ajaxPost("/ociranalysis/processnamesummaryexcel", payload, function(res){
        redirectUrl("/static/temp/DetailedAnalysis/"+res.msg);
    });
}
oa.startGridIndex = ko.observable(0);
oa.filterGridProcessName = ko.observableArray([]);
oa.gridProcessName = function() {
	oa.loadingGridDetail(true)
	$("html, body").animate({ scrollTop: $(document).height() }, 3000);
	var payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(),
		Suppliertype 		: oa.supplytype(),
		Categoryname 		: oa.categoryname(),
		LevelProcess 		: "",
		Productfunction 	: oa.product(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef(),
		Firstfilter 		: oa.firstFilter(),
		Secondfilter 		: oa.secondFilter(),
		Defaultfilter 		: oa.defaultFilter(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),	
	}
	oa.payloadGridDetailAnalysis = payload;
	var coloumnData = {
		Count:{
			field:"Count",
			format:"{0:N0}",
			title:"count",
			width:50, 
			headerAttributes: {
				"class": "align-right"
			},
			attributes: {"class": "align-right"},
		},
		Global_Process_Owner:{
			field:"Global_Process_Owner",
			title:"GPO",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		parentprocessname:{
			field:"parentprocessname",
			title:"Level 1 Processes",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		processname:{
			field:"processname",
			title:"Level 2 Processes",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		servicedescription: 
		{
			field:"servicedescription",
			title:"Level 3 Processes",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		itameuc:
		{
			field:"itameuc",
			title:"ITAM/EUC",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		systemshublocation:
		{
			field:"systemshublocation",
			title:"Systems Hub Location",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		suppliercountry:{
			field: "suppliercountry",
			title:"Supplier",
			width:230,
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			},
			template:"#= suppliercountry + ' - ' + supplierlegalentity #"
		},
		suppliercountryNlegalEntity:{
			field: "suppliercountryNlegalEntity",
			title:"Supplier",
			width:230,
			
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			},
			template:"#= suppliercountry + ' - ' + supplierlegalentity #"
		},
		functionname:{
			field:"functionname",
			title:"Function Name",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		suppliername:{
			field:"suppliername",
			title:"Supplier Name",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"},
		},
		teamunitheadname:{
			field:"teamunitheadname",
			title:"Team Unit Head Name",
			width:150,
			headerAttributes: {
				"class": "align-left"
			} 
		},
		supplierlegalentity:{
			field:"supplierlegalentity",
			title:"Supplier Legal Entity",
			width:190,
			hidden: true,
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		contractid:{
			field:"contractid",
			title:"Contract ID",
			width:100, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
		},
		contractdescription:{
			field:"contractdescription",
			title:"Contract Description",
			width:150, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"}
		},
		legalcontractsignatory:{
			field:"legalcontractsignatory",
			title:"Legal Contract Signatory",
			width:150, 
			hidden:true,
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"}
		},
		itbusiness:{
			field:"itbusiness",
			title:"IT Bussiness",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		vendorid:{
			field:"vendorid",
			title:"External Vendor ID",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		servicetype:{
			field:"servicetype",
			title:"Service Type",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		contractavailable:{
			field:"contractavailable",
			title:"Contract Available",
			width:120,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			} 
		},
		iscontractglobal:{
			field:"iscontractglobal",
			title:"Contract Global",
			width:120,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		contractlibrary:{
			field:"contractlibrary",
			title:"Contract Library",
			width:120,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		checker:{
			field:"checker",
			title:"Checker",
			width:120,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		servicefte:{
			field:"servicefte",
			title:"Total FTE",
			width:120,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			},
			format:"{0:N2}" 
		},
		suppliertype:{
			field:"suppliertype",
			title:"Supplier Type",
			template: "#if(suppliertype == 'IGS'){# #: 'Intra-Group' # #}else if(suppliertype == 'TPS'){# #: 'External' # #}else if(suppliertype == 'Teams'){# #: 'In-Entity' # #}else {# #: 'Systems' # #}#",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		iscrefid:{
			field:"iscrefid",
			title:"MSA ID",
			width:100, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
			template: "#if(iscrefid == 'NULL'){# #: '0' # #}else{# #: iscrefid # #}#",
		},
		iscdescription:{
			field:"iscdescription",
			title:"MSA Description",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		slaid:{
			field:"slaid",
			title:"SLA ID",
			width:100, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis align-left"},
			template: "#if(slaid == 'NULL'){# #: '0' # #}else{# #: slaid # #}#",
		},
		sladescription:{
			field:"sladescription",
			title:"SLA Description",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		hublocationcountry:{
			field:"hublocationcountry",
			title:"Location Country",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		buildingid:{
			field:"buildingid",
			title:"Building ID",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		buildingname:{
			field:"buildingname",
			title:"Building Name",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"}
		},
		teamcostcentre:{
			field:"teamcostcentre",
			title:"Cost Center",
			width:250, 
			headerAttributes: {
				"class": "align-right"
			},
			attributes: {"class": "field-ellipsis align-right"}
		},
		suppliercount:{
			field:"suppliercount",
			title:"Supplier Count",
			width:140,
			 headerAttributes: {
				"class": "align-right"
			},
			attributes: {
				"class": "field-ellipsis align-right"
			}
		},
		receivercount:{
			field:"receivercount",
			title:"Receiver Count",
			width:140,
			 headerAttributes: {
				"class": "align-right"
			},
			attributes: {
				"class": "field-ellipsis align-right"
			} 
		},
		L1:{
			field:"L1",
			title:"Level 1 Processes ",
			headerAttributes: {
				"class": "align-right"
			},
			width:150, 
			attributes: {"class": "align-right"},
			template:"#if(L1 !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"L1\")'>#:L1#</a> #}else { ##: L1 ## }#"
		},
		L2:{
			field:"L2",
			title:"Level 2 Processes ",
			headerAttributes: {
				"class": "align-right"
			},
			width:150, 
			attributes: {"class": "align-right"},
			template:"#if(L2 !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"L2\")'>#:L2#</a> #}else { ##: L2 ## }#"
		},
		L3:{
			field:"L3",
			title:"Level 3 Processes ",
			headerAttributes: {
				"class": "align-right"
			},
			width:150, 
			attributes: {"class": "align-right"},
			template:"#if(L3 !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"L3\")'>#:L3#</a> #}else { ##: L3 ## }#"
		},
		TEAM:{
			field:"TEAM",
			title:"Teams",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"},
			template:"#if(TEAM !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"TEAM\")'>#:TEAM#</a> #}else { ##: TEAM ## }#"
		},
		TPV:{
			field:"TPV",
			title:"Third Party Vendors",
			
			headerAttributes: {
				"class": "align-right"
			},
			width:180, 
			attributes: {"class": "align-right"},
			template:"#if(TPV !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"TPV\")'>#:TPV#</a> #}else { ##: TPV ## }#"
		},
		Slaparentreference:{
			field:"Slaparentreference",
			title:"SLA Parent Reference",
			width:140,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			}
		},
		slamanagername:{
			field:"slamanagername",
			title:"SLA Manager Name",
			width:140,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			}
		},
		slaocircompliant:{
			field:"slaocircompliant",
			title:"SLA Compliant",
			width:180,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			}
		},
		armslengthchargingstructure:{
			field:"armslengthchargingstructure",
			title:"Arms-Length Charging Structure",
			width:180,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			}
		},
		slabasisforrecharge:{
			field:"slabasisforrecharge",
			title:"SLA Basis for Recharge",
			width:180,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			}
		},
		CTR:{
			field:"CTR",
			title:"Contracts",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"},
			template:"#if(CTR !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"CTR\")'>#:CTR#</a> #}else { ##: CTR ## }#"
		},
		SLA:{
			field:"SLA",
			title:"SLAs",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"},
			template:"#if(SLA !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"SLA\")'>#:SLA#</a> #} else { ##: SLA ## }#"
		},
		MSA:{ 
			field:"MSA",
			title:"MSAs",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"},
			template:"#if(MSA !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"MSA\")'>#:MSA#</a> #} else { ##: MSA ## }#"
		},
		IS:{
			field:"IS",
			title:"Internal Systems",
			headerAttributes: {
				"class": "align-right"
			},
			width:150, 
			attributes: {"class": "align-right"},
			template:"#if(IS !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"IS\")'>#:IS#</a> #}else { ##: IS ## }#"
		},
		ES:{
			field:"ES",
			title:"External Systems",
			
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"},
			template:"#if(ES !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"ES\")'>#:ES#</a> #}else { ##: ES ## }#"
		},
		DC:{
			field:"DC",
			title:"Data Centres",
			headerAttributes: {
				"class": "align-right"
			},
			width:180,
			attributes: {"class": "align-right"},
			template:"#if(DC !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"DC\")'>#:DC#</a> #}else { ##: DC ## }#"
		},
		BDG:{
			field:"BDG",
			title:"Buildings",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"},
			template:"#if(BDG !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"BDG\")'>#:BDG#</a> #}else { ##: BDG ## }#"
		},
		intellectual:{
			field:"intellectual",
			title:"Intellectual Property",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"}
		},
		ATM:{
			field:"ATM",
			title:"ATMs",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"}
		},
		Custodians:{
			field:"Custodians",
			title:"Custodians",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"}
		},
		Corresp:{
			field:"Corresp",
			title:"Corresp Banks",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"}
		},
		Clearing:{
			field:"Clearing",
			title:"Clearing",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"}
		},
		fte:{
			field:"fte",
			title:"FTE",
			format:"{0:N2}",
			headerAttributes: {
				"class": "align-right"
			},
			width:100, 
			attributes: {"class": "align-right"}
		},
		receivercountry:{
			field: "receivercountry",
			title:"Receiver",
			width:230,
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			},
			template:"#= receivercountry + ' - ' + receiverlegalentity #"
		},
		categoryname_:{
			field:"categoryname_",
			title:"Business/Function",
			width:140,
			headerAttributes: {
				"class": "align-left"
			},
		},
		productfunction:{
			field:"productfunction",
			title:"Product Function",
			width:140,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis"
			}
		},
		perpetualcontractresolution:{
			field:"perpetualcontractresolution",
			title:"Perpetual Contract?",
			width:130,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		contractexpiry:{
			field:"contractexpiry",
			title:"Contract Expirty",
			width:120,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		contractresolutioncritical:{
			field:"contractresolutioncritical",
			title:"Contract Resolution Critical",
			width:180,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		contractmeetspra:{
			field:"contractmeetspra",
			title:"Contract meets PRA?",
			width:140,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		contractresolutionlangproofed:{
			field:"contractresolutionlangproofed",
			title:"Contract Resolution lang Proofed?",
			width:210,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		systemshublocation:{
			field:"systemshublocation",
			title:"Hub Location",
			width:140,
			headerAttributes: {
			"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		scbownind:{
			field:"scbownind",
			title:"SCB Owned?",
			width:140,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			},
			template:"#if(scbownind == 'NULL'){ ##: 'NULL' ##} else if ( scbownind == 'Y'){ ##: entityname ## } else { ##: tpsname ## }#" 
		},
		sharedindbuilding:{
			field:"sharedindbuilding",
			title:"Shared with another party?",
			width:240,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		entityname:{
			field:"entityname",
			title:"Data Center Owner",
			width:140,
			 headerAttributes: {
				"class": "align-left"
			},
			attributes: {
				"class": "field-ellipsis align-left"
			} 
		},
		contractmanagername:{
			field:"contractmanagername",
			title:"Contract Manager Name",
			width:150,
			headerAttributes: {
				"class": "align-left"
			} 
		},
		supplierid:{
			field:"supplierid",
			title:"Supplier Id",
			width:150, 
			headerAttributes: {
				"class": "align-right"
			}, 
		},
		FMI_Access_Type:{
			field:"FMI_Access_Type",
			title:"Access Type",
			width:250, 
			headerAttributes: {
				"class": "align-left"
			},
			attributes: {"class": "field-ellipsis"},
		},
		FMI:{
			field:"FMI",
			title:"FMI",
			width:100, 
			headerAttributes: {
				"class": "align-right"
			},
			attributes: {"class": "align-right"},
			template:"#if(FMI !== 0){# <a href=\"\\#\" onclick='popUpGridDetail(\"#:index#\", \"FMI\")'>#:FMI#</a> #}else { ##: FMI ## }#"
		},
	}
	oa.default_listColoumn_detailAnalysis(coloumnData)
	var newColumn = [];
	var sorting = []
	ajaxPost("/ociranalysis/processnamesummaryfield",payload , function (res){
		var indexingColoumn = 0;
		var indexSupplierCountry = 0;
		var indexSupplierLegalEntity = 0;
		var indexLegalContract = 0;
		var listColumn = []
		for(var i in coloumnData){
			listColumn.push(i)
		}
		$.each(res.Data.Records, function(i,v){
			if(listColumn.indexOf(v) > -1){
				newColumn.push(coloumnData[v]);
				sorting.push({field:v,dir:"asc"})
				switch(v){
					case 'suppliercountry':
						indexSupplierCountry = i - 1;
					break;
					case 'supplierlegalentity':
						indexSupplierLegalEntity = i - 1;
					break;
					case 'legalcontractsignatory':
						indexLegalContract = i - 1;
					break;
				}
			}
		});
		var dataSource = [];
		var url = "/ociranalysis/processnamesummary";
		// var customPageable;
		// var totalData = res.Data.Count;
		// if (totalData < 50 ){
		// 	customPageable = {
		// 		refresh: true,
		// 		pageSizes: true,
		// 		buttonCount: 5,
		// 		pageSizes: [10, 20, 50],
		// 		pageSize: 10, 
		// 	}
		// }else if (totalData > 50 && totalData < 500) {
		// 	customPageable = {
		// 		refresh: true,
		// 		pageSizes: true,
		// 		buttonCount: 5,
		// 		pageSizes: [100, 200, 500],
		// 		pageSize: 100, 
		// 	}
		// }else if (totalData > 500){
		// 	customPageable = {
		// 		refresh: true,
		// 		pageSizes: true,
		// 		buttonCount: 5,
		// 		pageSizes: [500, 1000, 1500],
		// 		pageSize: 500, 
		// 	}
		// } 
		oa.columnGridDetailAnalysis(newColumn); 
		$("#processname-grid").html("");
		$("#processname-grid").kendoGrid({
			dataSource: {
				transport: {
					read:function(options){
					    var par = payload;
					    // options.data.filter.Filters = _.indexOf(options.data.filter, 'filters') > -1 ?  options.data.filter.filters : []; 
                    	var filters = {}
                    	if(options.data.filter){
                    		filters.Filters  = _.map(options.data.filter.filters, function(o){
                    			return {
                    				Field: o.field,
                    				Operator: o.operator,
                    				Value: o.value,
                    			}
                    		});
                    		filters.Logic =  options.data.filter.logic;
                    	 
                    	}
         
                    	par.Filter = filters;
                    	oa.filterGridProcessName(par.filter);
                    	par.page = options.data.page
                   	 	par.pageSize = options.data.pageSize
                    	par.skip = options.data.skip
                    	par.sort = options.data.sort
                    	par.take = options.data.take
					  ajaxPost(url,par,function(res){
					  	 options.success(res);
					  });
					}
				},
				// transport: {
				// 	read: {
	   //                  url: "/live/ociranalysis/processnamesummary",
	   //                  data: payload,
	   //                  dataType: "json",
	   //                  type: "POST",
	   //                  contentType: "application/json",
	   //              },
	   //              parameterMap: function(data) { 
	   //                 return JSON.stringify(data);
	   //              },
	   //          },
				schema: {
					data: function(data) {
						oa.loadingGridDetail(false)
						if (data.Data.Count == 0) {
							return [];
						} else {
							oa.countparent(data.Data.Count)
							index = oa.startGridIndex();
							data.Data.Records.forEach(function (d) {
								d.index = index;
								index++
								oa.startGridIndex(index);
							})
							var arr = oa.listFieldDetailAnalysis().concat(data.Data.Records);
							oa.listFieldDetailAnalysis(arr);
							// oa.listFieldDetailAnalysis.valueHasMutated();
							return data.Data.Records;
						}
					},
					total: function (data) {
                    	return data.Data.Count;
                	}
					// total: "Data.Count",
				}, 
		       	pageSize: 10,
	            serverPaging: true,
	            serverSorting: true,
	            serverFiltering: true,
				// sort: sorting
			},
		   resizable: true,
	        filterable: {
	            extra:false, 
	            operators: {
	                string: {
	                    contains: "Contains",
	                    startswith: "Starts with",
	                    eq: "Is equal to",
	                    neq: "Is not equal to",
	                    doesnotcontain: "Does not contain",
	                    endswith: "Ends with"
	                },
	            }
	        },
	        sortable: true,
	        scrollable:{
	            virtual: true
	        },
	        pageable: {
	            refresh: true,
	            pageSizes: true,
	            buttonCount: 1,
	            pageSize: 20,
	            pageSizes: [5, 10, 20],
	        },
	        columnMenu: false,
			columns: newColumn
		});
	})
};
oa.goback = function(){
	var newurl = localStorage.link + "?back=1";
	window.location.replace(newurl);
};
oa.SummaryBox = ko.observableArray([
									{name:'SummaryBoxCEF',index:0, loading:ko.observable(false)},
									{name:'SummaryBoxLevel1Process',index:1, loading:ko.observable(false)},
									{name:'SummaryBoxSuppliers',index:2, loading:ko.observable(false)},
									{name:'SummaryBoxFTE',index:3, loading:ko.observable(false)},
									{name:'SummaryBoxContract',index:4, loading:ko.observable(false)},
									{name:'SummaryBoxBuildings',index:5, loading:ko.observable(false)},
									{name:'SummaryBoxFMIS',index:6, loading:ko.observable(false)},
									// {name:'SummaryBoxResolution',index:7, loading:ko.observable(false)}
								]);

oa.SummaryBoxCEF = ko.observableArray([]);
oa.SummaryBoxLevel1Process = ko.observableArray([]);
oa.SummaryBoxSuppliers = ko.observableArray([]);
oa.SummaryBoxFTE = ko.observableArray([]);
oa.SummaryBoxContract = ko.observableArray([]);
oa.SummaryBoxBuildings = ko.observableArray([]);
oa.SummaryBoxFMIS = ko.observableArray([]);
oa.SummaryBoxResolution = ko.observableArray([]);
function SexyBox(obj){
	var self = this;
	self.Data = ko.observable(obj);
	self.IsHover = ko.observable(false);
	return self;
}
oa.asd = true;
oa.createSummaryBox = function(payload,prop ){
	_.where( oa.SummaryBox(),{name:prop.type})[0].loading(true);
		ajaxPost("/ociranalysis/getsummaryboxrev01", payload, function (res){
			_.where(oa.SummaryBox(),{name:prop.type})[0].loading(false);
			oa[prop.type]([])
			oa[prop.type].push(new SexyBox({
				name:prop.name,
				unname:prop.unname,
				necessary:res.necessary,
				notnecessary:res.notnecessary 
			}));
		});
}
oa.getSummaryBox = function(){
	var propSummaryBox = [{type:'SummaryBoxCEF',BoxType:'CEF',name:'# of CEFs',unname:'# Non CEFs'},
						  {type:'SummaryBoxLevel1Process',BoxType:'Level1Process',name:'# of Necessary Level 1 Processes',unname:'# of Unnecessary Level 1 Processes'},
						  {type:'SummaryBoxSuppliers',BoxType:'Suppliers', name:'# of Necessary Suppliers',unname:'# of Unnecessary Suppliers'},
						  {type:'SummaryBoxFTE',BoxType:'FTE',name:'# of Necessary FTE Utilized',unname:'# of Unnecessary FTE Utilized',},
						  {type:'SummaryBoxContract',BoxType:'Contract',name:'# of Necessary Contracts',unname:'# of Unnecessary Contracts'},
						  {type:'SummaryBoxBuildings',BoxType:'Buildings' ,name:'# of Necessary Buildings',unname:'# of Unnecessary Buildings'},
						  {type:'SummaryBoxFMIS',BoxType:'FMIS',name:'# of FMIs',unname:'# of Unnecessary FMIs'},
						  // {type:'SummaryBoxResolution',BoxType:'Resolution',  name:'# of Barriers to Resolution',unname:'# of Services Ready for Resolution'}
						];
	var defaultPayload = {
      	Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(),
		Suppliertype 		: oa.supplytype(),
		Categoryname 		: oa.categoryname(),
		Productfunction 	: oa.product(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
	};
	for(var i in propSummaryBox){
		payload = JSON.parse(JSON.stringify( $.extend(defaultPayload, {BoxType:propSummaryBox[i].BoxType})))
		prop =  propSummaryBox[i]
		oa.createSummaryBox(payload, prop)
	}
};
oa.numberFormat =  function(value, numberFormat){
	if (typeof value === 'string') {
		// console.log("---->",value);
		if(value.toLowerCase() === 'null' || value.toLowerCase() === 'n' || value.toLowerCase() === 'n/a' || value.toLowerCase() == ''){
			return 0;
		}
		var regex = "/[^(?:\d*\.)?\d]+/"
		return (String(value).match(/[^(?:\d*\.)?\d]+/) == null)? kendo.toString(value, numberFormat) : String(value); //parseInt(value).toLocaleString():String(value); 
	}else{
		console.log("int------------>",value)
		return kendo.toString(value, numberFormat);
			// console.log("int ---->",value);
		// var regex = "/[^(?:\d*\.)?\d]+/"
		// return (String(value).match(/[^(?:\d*\.)?\d]+/) == null)? kendo.toString(value,"n2") : String(value) ;//parseInt(value).toLocaleString():String(value); 
	}
}
oa.showDetailProductNameCEF = function(name, receivercountry, subgroupid, cefcritical){
	var url = "/ociranalysis/getproductnamecefdetail";
	var payload = {
		ProductFunction: name,
		ReceiverCountry: receivercountry,
		SubGroupid: subgroupid,
	};
	if (cefcritical == "Y"){
		cefcritical = "CEF"
	}else {
		cefcritical = "Non-CEF"
	}
	ajaxPost(url, payload, function (res){
		if (res.assets == undefined) {
			swal("", "Data CEF Not Found", "error")
		}else{
			res.alternativeproviders = oa.numberFormat( res.alternativeproviders, "n0");
			res.customeraccounts = oa.numberFormat( res.customeraccounts, "n0" );
			res.customerscounterparties = oa.numberFormat( res.customerscounterparties , "n0");
			
			res.assets = oa.numberFormat( res.assets, "n2" );
			res.committedfacilities = oa.numberFormat( res.committedfacilities, "n2" );
			res.liabilities = oa.numberFormat( res.liabilities, "n2" );
			
			res.nonretailfunctions = oa.numberFormat( res.nonretailfunctions, "n2" );
			res.notionaloutstandingbookinglocation = oa.numberFormat( res.notionaloutstandingbookinglocation, "n2" );
			res.retailfunctions = oa.numberFormat( res.retailfunctions, "n2" );

			res.tradevalue = oa.numberFormat( res.tradevalue, "n2" );
			res.tradevolume = oa.numberFormat( res.tradevolume, "n2" );

			oa.valueProductFunctionName(res) 

			$("#productNameModal").modal("show");
			if ( cefcritical == "Non-CEF"){
				$("#statusCefcritical").css("color","red")
			}
			$("#statusCefcritical").text(cefcritical)
			$(".receivercountry").text(res.receivercountry);
			$(".receiverlegalentity").text(res.receiverlegalentity);
			$(".projectName").text(res.categoryname + " - " + name);
		};
	})
}
oa.checkFullChart = function(){
	if(oa.viewfullchart()){
		oa.viewfullchart()
		$("#receivercategorychart").show('fast');
		$("#chart-donutL3Processes").show('fast');
		$("#legend-chart-donutL3Processes").show('fast');
	}
}
oa.getSummaryBarChart = function(payload,type){
	var sortBarChart = function(datas){
		$.each(datas,function(index,value){
			for(var i=0; i<(datas.length-1); i++){
				if(datas[i].Count < datas[i+1].Count){
					var old = datas[i+1];
					datas[i+1] = datas[i]
					datas[i] = old
				}
			}
		}) 
		return datas
	}
	var newPayload = $.extend(payload,{Flag:type});
	switch(type){
		case 'Service FTE':
			if(oa.viewfullchart());
			ajaxPost("/ociranalysis/servicefte", newPayload , function (res){
				var datas = res;
				var sortDatas = sortBarChart(datas)
				oa.chartReceiverCategory(sortDatas,type,true);
			});
		break;
		case 'Fte by Country':
			if ( oa.supplycountry() != ''){
				ajaxPost("/ociranalysis/ftebycountrylegal", newPayload , function (res){
					var datas = res;
					var sortDatas = sortBarChart(datas); 
					oa.chartReceiverCategory(sortDatas,type,true);
				})
			}else {
				ajaxPost("/ociranalysis/ftebycountry", newPayload , function (res){
					var datas = res;
					var sortDatas = sortBarChart(datas); 
					oa.chartReceiverCategory(sortDatas,type,true);
				})
			}
		break;
		case 'level 1 by country':
			ajaxPost("/ociranalysis/levelbycountry", newPayload , function (res){
				var datas = res;
				var sortDatas = sortBarChart(datas);
				// max = 10;
				// data = []
				// if(sortDatas.length < 10){
				// 	max = sortDatas.length
				// }
				
				var data = [];
				var max =  res.length;
				for(i=0; i<max; i++){
					data.push({Count:res[i].Count,_id:res[i]._id})
				}	
				oa.chartReceiverCategory(data,type,true);
			})
		break;
		case 'Process by GBS and Others':
			ajaxPost("/ociranalysis/processbygbs", newPayload , function (res){
				var datas = res;
				var sortDatas = sortBarChart(datas);
				// max = 10;
				// data = []
				// if(sortDatas.length < 10){
				// 	max = sortDatas.length
				// }
				
				var data = [];
				var max =  res.length;
				
				for(i=0; i<max; i++){
					data.push({Count:res[i].Count,_id:res[i]._id,Color:res[i].Color})
				}
				// var data = res;
					
				oa.chartReceiverCategory(data,type,true);
			})
		break;
		case 'Assets Utilized':
			ajaxPost("/ociranalysis/getassetsutilized", newPayload , function (res){
				var datas = res;
				var sortDatas = sortBarChart(datas);
				oa.chartReceiverCategory(sortDatas,type,true);
			})
		break;
		case 'Biggest':
			if(oa.categoryname() === ''){
				ajaxPost("/ociranalysis/receivercategory", newPayload , function (res){
					var datas = res;
					var sortDatas = sortBarChart(datas)
					oa.chartReceiverCategory(sortDatas,"Level 1 Process by Business/function:",true);
				})
			}else{
				ajaxPost("/ociranalysis/receivercategoryproduct", newPayload , function (res){
					var data = [];
					// data = []
					// max = 10;
					// if(res.length < 10){
					//  max = res.length
					// }
					
					var max =  res.length;
					for(i=0; i<res.length; i++){
						data.push({Count:res[i].Value,_id:res[i].Country})
					}
					oa.chartReceiverCategory(data,type,true);
				});
			}
		break;
		case "Barriers to Resolution by Region":
			newPayload.Flag = "region";
			ajaxPost("/ociranalysis/barriersbar", newPayload , function (res){
				// data = []
				// max = 10;
				// if(res.Data.length < 10){
				// 	max = res.Data.length
				// }
				// for(i=0; i<max; i++){
				// 	data.push(res.Data[i])
				// }
				// var data = res;
				oa.chartReceiverCategory(res.Data,type,true);
			});
		break;
		case "Different Types  of Barriers":
			newPayload.Flag = "barriertype";
			ajaxPost("/ociranalysis/barriersbar", newPayload , function (res){
				// data = []
				// max = 10;
				// if(res.Data.length < 10){
				// 	max = res.Data.length
				// }
				// for(i=0; i<max; i++){
				// 	data.push(res.Data[i])
				// }
				var data = res;
				oa.chartReceiverCategory(res.Data,type,true);
			});
		break;
		
		case 'Worst 10 [% Validated]':
			var newPayload = $.extend(newPayload,{WorstType : "validated"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case 'Worst 10 [% Enriched]':
			var newPayload = $.extend(newPayload,{WorstType : "enriched"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case 'Worst 10% Validated by Business/Function':
			var newPayload = $.extend(newPayload,{WorstType : "businnessvalidated"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case 'Worst 10% Enriched by Business/Function':
			var newPayload = $.extend(newPayload,{WorstType : "businnessenriched"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case '% Validated all Countries':
			$("#receivercategorychart").hide('fast');
			$("#productgrid").hide('fast');
			$("#chart-donutL3Processes").hide('fast');
			$("#legend-chart-donutL3Processes").hide('fast');
			var newPayload = $.extend(newPayload,{WorstType : "validated"});
			ajaxPost("/ociranalysis/percentvalidated", newPayload , function (res){
				if (res.length == 0) {
					
				}else{
					oa.fullchart(res,type);
				};
			});
		break;
		case '% Enriched all Countries':
			$("#receivercategorychart").hide('fast');
			$("#productgrid").hide('fast');
			$("#chart-donutL3Processes").hide('fast');
			$("#legend-chart-donutL3Processes").hide('fast');
			var newPayload = $.extend(newPayload,{WorstType : "enriched"});
			ajaxPost("/ociranalysis/percentvalidated", newPayload , function (res){
				if (res.length == 0) {
					
				}else{
					oa.fullchart(res,type);
				};
			});
		break;

		case 'Barriers to Resolution by Business':
			$("#receivercategorychart").hide('fast');
			$("#productgrid").hide('fast');
			$("#chart-donutL3Processes").hide('fast');
			$("#legend-chart-donutL3Processes").hide('fast');
			newPayload.Flag = "categoryname_";
			ajaxPost("/ociranalysis/barriersbar", newPayload , function (res){
				if (res.length == 0) {
					
				}else{
					oa.fullchart(res.Data,type);
				};
			});
		break;
		case 'Barriers to Resolution by Country':
			$("#receivercategorychart").hide('fast');
			$("#productgrid").hide('fast');
			$("#chart-donutL3Processes").hide('fast');
			$("#legend-chart-donutL3Processes").hide('fast');
			newPayload.Flag = "receivercountry";
			ajaxPost("/ociranalysis/barriersbar", newPayload , function (res){
				if (res.length == 0) {
					
				}else{
					oa.fullchart(res.Data,type);
				};
			});
		break;




		case 'Best 10 [% Validated]':
			var newPayload = $.extend(newPayload,{WorstType : "reversevalidated"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case 'Best 10 [% Enriched]':
			var newPayload = $.extend(newPayload,{WorstType : "reverseenriched"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case 'Pending Best 10 [% Validated]':
			var newPayload = $.extend(newPayload,{WorstType : "pendingbestvalidated"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				if (res.length == 0) {
					
				}else{
					oa.chartReceiverCategory(res,type,false);
				};
			});
		break;
		case 'Pending Best 10 [% Enriched]':
			var newPayload = $.extend(newPayload,{WorstType : "pendingbestenriched"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				if (res.length == 0) {
					
				}else{
					oa.chartReceiverCategory(res,type,false);
				};
			});
		break;
		case 'Pending Worst 10 [% Validated]':
			var newPayload = $.extend(newPayload,{WorstType : "pendingworstvalidated"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				if (res.length == 0) {
					
				}else{
					oa.chartReceiverCategory(res,type,false);
				};
			});
		break;
		case 'Pending Worst 10 [% Enriched]':
			var newPayload = $.extend(newPayload,{WorstType : "pendingworstenriched"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				if (res.length == 0) {
					
				}else{
					oa.chartReceiverCategory(res,type,false);
				};
			});
		break;
		case 'Comparison Region [% Validated Service]':
			var newPayload = $.extend(newPayload,{WorstType : "validated"});
			ajaxPost("/ociranalysis/comparisonregion", newPayload , function (res){
				if (res.length > 19) {
					$("#receivercategorychart").hide('fast');
					$("#productgrid").hide('fast');
					$("#chart-donutL3Processes").hide('fast');
					$("#legend-chart-donutL3Processes").hide('fast');
					oa.fullchart(res,type,false);
				}else{
					oa.chartReceiverCategory(res,type,false);
				};
			});
		break;
		case 'Comparison Region [% Confirmed Service]':
			var newPayload = $.extend(newPayload,{WorstType : "enriched"});
			ajaxPost("/ociranalysis/comparisonregion", newPayload , function (res){
				if (res.length > 19) {
					$("#receivercategorychart").hide('fast');
					$("#productgrid").hide('fast');
					$("#chart-donutL3Processes").hide('fast');
					$("#legend-chart-donutL3Processes").hide('fast');
					oa.fullchart(res,type,false);
				}else{
					oa.chartReceiverCategory(res,type,false);
				};
			});
		break;
		case 'Worst 10 by Process Owner [% Validated Service]':
			var newPayload = $.extend(newPayload,{WorstType : "worstownervalidated"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case 'Worst 10 by Process Owner [% Confirmed Service]':
			var newPayload = $.extend(newPayload,{WorstType : "worstownerenriched"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case 'Best 10 by Process Owner [% Validated Service]':
			var newPayload = $.extend(newPayload,{WorstType : "bestownervalidated"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case 'Best 10 by Process Owner [% Confirmed Service]':
			var newPayload = $.extend(newPayload,{WorstType : "bestownerenriched"});
			ajaxPost("/ociranalysis/worstvalidated", newPayload , function (res){
				oa.chartReceiverCategory(res,type,false);
			});
		break;
		case 'Systems per business/function': //here
			var newPayload = $.extend(newPayload,{WorstType : ""});
			ajaxPost("/ociranalysis/systemsperbusiness", newPayload , function (res){
				if (res.external.length == 0 && res.inentity.length == 0 && res.intra.length == 0 && res.other.length == 0) {
					$("#receivercategorychart").html("")
				}else{
					var internal = []
					var external = []
					var underreview = []
					var total = []
					max = 10;
					if(res.internal.length < 10){
						max = res.internal.length
					}
					var tenPercent = Enumerable.From(res.internal).Max("$.Value") + ((10 * Enumerable.From(res.internal).Max("$.Value")) / 100) 
					for(i=0; i< res.internal.length; i++){
						internal.push({Count:res.internal[i].Count,_id:res.internal[i].Country,Value:res.internal[i].Value})
						external.push({Count:res.external[i].Count,_id:res.external[i].Country,Value:res.external[i].Value})
						underreview.push({Count:res.underreview[i].Count,_id:res.underreview[i].Country,Value:res.underreview[i].Value})
						total.push(({Count:tenPercent - res.underreview[i].Value, _id:'', Value:res.underreview[i].Value}))
					}
					oa.chartStackedTwoCategory(internal,external,underreview,total);
				}
			});
		break;
		case 'Processes per critical service provider': //here
			var newPayload = $.extend(newPayload,{WorstType : ""});
			ajaxPost("/ociranalysis/getcriticalprovider", newPayload , function (res){
				if (res.gbs.length == 0 && res.inentity.length == 0 && res.intra.length == 0 && res.other.length == 0) {
					$("#receivercategorychart").html("")
				}else{
					var gbs = []
					var inentity = []
					var intra = []
					var other = []
					var total = []
					max = 10;
					if(res.intra.length < 10){
						max = res.intra.length
					}

					var tenPercent = Enumerable.From(res.intra).Max("$.Value") + ((10 * Enumerable.From(res.intra).Max("$.Value")) / 100) 
					// console.log,res[0]);
					for(i=0; i<_.first(_.values(res)).length; i++){
						intra.push({Count:res.intra[i].Count,_id:res.intra[i].Country,Value:res.intra[i].Value})
						inentity.push({Count:res.inentity[i].Count,_id:res.inentity[i].Country,Value:res.inentity[i].Value})
						gbs.push({Count:res.gbs[i].Count,_id:res.gbs[i].Country,Value:res.gbs[i].Value})
						other.push({Count:res.other[i].Count,_id:res.other[i].Country,Value:res.other[i].Value})
						total.push(({Count:tenPercent - res.other[i].Value, _id:'', Value:res.other[i].Value}))
					}
					oa.chartStackedFourCategory(intra,inentity,gbs,other,total);
				};
			});
		break;
		case 'Critical Service Providers by FTE': //here
			var newPayload = $.extend(newPayload,{WorstType : ""});
			ajaxPost("/ociranalysis/getcriticalproviderfte", newPayload , function (res){
				if (res.gbs.length == 0 && res.inentity.length == 0 && res.intra.length == 0 && res.other.length == 0) {
					$("#receivercategorychart").html("")
				}else{
					var gbs = []
					var inentity = []
					var intra = []
					var other = []
					var total = []
					max = 10;
					if(res.intra.length < 10){
						max = res.intra.length
					}
					var tenPercent = Enumerable.From(res.intra).Max("$.Value") + ((10 * Enumerable.From(res.intra).Max("$.Value")) / 100) 

					for(i=0; i<res.internal.length; i++){
						intra.push({Count:res.intra[i].Count,_id:res.intra[i].Country,Value:res.intra[i].Value})
						inentity.push({Count:res.inentity[i].Count,_id:res.inentity[i].Country,Value:res.inentity[i].Value})
						gbs.push({Count:res.gbs[i].Count,_id:res.gbs[i].Country,Value:res.gbs[i].Value})
						other.push({Count:res.other[i].Count,_id:res.other[i].Country,Value:res.other[i].Value})
						total.push(({Count:tenPercent - res.other[i].Value, _id:'', Value:res.other[i].Value}))
					}
					oa.chartStackedFourCategory(intra,inentity,gbs,other,total);
				};
			});
		break;
		case 'Location by FTE': //here
			var newPayload = $.extend(newPayload,{WorstType : ""});
			ajaxPost("/ociranalysis/getlocationfte", newPayload , function (res){
				if (res.gbs.length == 0 && res.inentity.length == 0 && res.intra.length == 0 && res.other.length == 0) {
					$("#receivercategorychart").html("")
				}else{
					var gbs = []
					var inentity = []
					var intra = []
					var other = []
					var total = []
					max = 10;
					if(res.intra.length < 10){
						max = res.intra.length
					}
					var tenPercent = Enumerable.From(res.intra).Max("$.Value") + ((10 * Enumerable.From(res.intra).Max("$.Value")) / 100) 

					for(i=0; i<res.internal.length; i++){
						intra.push({Count:res.intra[i].Count,_id:res.intra[i].Country,Value:res.intra[i].Value})
						inentity.push({Count:res.inentity[i].Count,_id:res.inentity[i].Country,Value:res.inentity[i].Value})
						gbs.push({Count:res.gbs[i].Count,_id:res.gbs[i].Country,Value:res.gbs[i].Value})
						other.push({Count:res.other[i].Count,_id:res.other[i].Country,Value:res.other[i].Value})
						total.push(({Count:tenPercent - res.other[i].Value, _id:'', Value:res.other[i].Value}))
					}
					oa.chartStackedFourCategory(intra,inentity,gbs,other,total);
				};
			});
		break;
		case 'Buildings by country':
			var newPayload = $.extend(newPayload,{WorstType : ""});
			ajaxPost("/ociranalysis/buildingbycountry", newPayload , function (res){
				// data = []
				// max = 10;
				// if(res.length < 10){
				//  max = res.length
				// }
				var data = [];
				var max =  res.length;
				for(i=0; i<max; i++){
					data.push({Count:res[i].Value,_id:res[i].Country})
				}
				// var data = res;
				oa.chartReceiverCategory(data,type,true);
			});
		break;		
		case 'Third party suppliers':
			var newPayload = $.extend(newPayload,{WorstType : ""});
			ajaxPost("/ociranalysis/thirdpartysuppliers", newPayload , function (res){
				// data = []
				// max = 10;
				// if(res.length < 10){
				//  max = res.length
				// }
				var data = [];
				var max =  res.length;
				
				for(i=0; i<max; i++){
					data.push({Count:res[i].Value,_id:res[i].Country})
				}
				
				// var data = res;
				oa.chartReceiverCategory(data,type,true);
			});
		break;
		case 'Third party suppliers by business':
			var newPayload = $.extend(newPayload,{WorstType : ""});
			ajaxPost("/ociranalysis/tpsbybusiness", newPayload , function (res){
				// data = []
				// max = 10;
				// if(res.length < 10){
				//  max = res.length
				// }
				var data = [];
				var max =  res.length;
				
				for(i=0; i<max; i++){
					data.push({Count:res[i].Value,_id:res[i].Country})
				}
				
				var data = res;
				oa.chartReceiverCategory(data,type,true);
			});
		break;
		case 'Third party suppliers by country':
			var newPayload = $.extend(newPayload,{WorstType : ""});
			ajaxPost("/ociranalysis/tpsbycountry", newPayload , function (res){
				// data = []
				// max = 10;
				// if(res.length < 10){
				//  max = res.length
				// }
				var data = [];
				var max =  res.length;
				
				for(i=0; i<max; i++){
					data.push({Count:res[i].Value,_id:res[i].Country})
				}
				
				var data = res;
				oa.chartReceiverCategory(data,type,true);
			});
		break;
		default:
			ajaxPost("/ociranalysis/cefassessmentchart", newPayload , function (res){
				var datas = res;
				var sortDatas = sortBarChart(datas);  
				oa.chartReceiverCategory(sortDatas,type,true);
			})
	}
};
oa.getDataProduct = function(payload){ 
	payload.Flag = "ocir";
	oa.viewfullgrid(false)
	oa.viewfullchart(false);
	oa.viewnonproductgridchart(false);
	var url = "/ociranalysis/getproductnamecef"
	$("#productgrid").kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					ajaxPost(url, payload, function(datas){
						if (datas.length <= 19) {
							$('.k-grid-header').attr('style', 'padding-right: 0px !important');
						};
						option.success(datas);
					})
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {
					if (data.length == 0) {
						return [];
					} else {
						return data; 
					} 
				},
			},
		},
		columns: [{
			field:"_id.productfunction",
			headerAttributes: {
				"class": "align-left"
			},
			title:"Product Name",
			width:130,
			attributes: {
				"class": "field-ellipsis"
			},
			template: "#if(oa.popupvalue()==true){# <a href=\"\\#\" onclick='oa.showDetailProductNameCEF(\"#:_id.productfunction#\",\"#:_id.receivercountry#\",\"#:_id.subgroupid#\",\"#:_id.cefcritical#\")'>#:_id.categoryname_# - #:_id.productfunction#</a> #}else{# #: _id.productfunction # #}#"
		},{
			field:"_id.receivercountry",
			headerAttributes: {
				"class": "align-left"
			},
			title:"Country",
			width:100,
			attributes: {
				"class": "field-ellipsis"
			},
		},{
			field:"_id.cefcritical",
			headerAttributes: {
				"class": "align-left"
			},
			title:"CEF?",
			width:70,
			attributes: {
				"class": "field-ellipsis"
			},
			template: "#if(_id.cefcritical=='Y'){# #: 'Yes' # #}else{# #: 'No' # #}#",
		}],
		filterable: {
			extra:false, 
			operators: {
				string: {
					contains: "Contains",
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to",
					doesnotcontain: "Does not contain",
					endswith: "Ends with"
				},
			}
		},
		sortable: true,
		filterable: {
			extra:false, 
			operators: {
				string: {
					contains: "Contains",
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to",
					doesnotcontain: "Does not contain",
					endswith: "Ends with"
				},
			}
		},
		height: 400,
	});
};
oa.getDataNonProduct = function(payload){ 
	oa.viewfullgrid(false)
	oa.viewfullchart(false);
	oa.viewnonproductgridchart(true);
	;var url = "/ociranalysis/dgmappingteam"
	$("#nonproductgrid").kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					ajaxPost(url, payload, function(datas){
						if (datas.length <= 19) {
							$('.k-grid-header').attr('style', 'padding-right: 0px !important');
						};
						option.success(datas);
					})
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {

					if (data.length == 0) {
						return [];
					} else {
						return data; 
					} 
				},
			},
		},
		columns: [{
			field:"Rank",
			headerAttributes: {
				"class": "align-left"
			},
			title:"Rank",
			width:72,
			attributes: {
				"class": "field-ellipsis rank"
			},
		},{
			field:"Country",
			headerAttributes: {
				"class": "align-left"
			},
			title:"Country",
			width:130,
			attributes: {
				"class": "field-ellipsis"
			},
		},{
			field:"Count",
			headerAttributes: {
				"class": "align-left"
			},
			title:"% Validated",
			width:98,
			attributes: {
				"class": "field-ellipsis"
			},
		}],
		filterable: {
			extra:false, 
			operators: {
				string: {
					contains: "Contains",
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to",
					doesnotcontain: "Does not contain",
					endswith: "Ends with"
				},
			}
		},
		sortable: true,
		filterable: {
			extra:false, 
			operators: {
				string: {
					contains: "Contains",
					startswith: "Starts with",
					eq: "Is equal to",
					neq: "Is not equal to",
					doesnotcontain: "Does not contain",
					endswith: "Ends with"
				},
			}
		},
		height: 400,
		dataBinding: function() {
            record =  0
        }
	});
};
oa.getSummaryBarDonut = function(payload,type){
	switch(type){
		case 'In-Entity vs Intra-Group':
			ajaxPost("/ociranalysis/getdonutservices", payload , function (res){
				oa.chartDonutL3Processes(res,'In-Entity vs Intra-Group');
			}); 
		break;
		case 'In-Entity vs Intra-Group FTE':
			ajaxPost("/ociranalysis/getdonutservicesfte", payload , function (res){
				oa.chartDonutL3Processes(res,'In-Entity vs Intra-Group FTE');
			});
		break;
		default:
			ajaxPost("/ociranalysis/getdonutl3processes", payload , function (res){
				oa.chartDonutL3Processes(res,'Services by ST');
			}); 
	}
};
oa.callGridStatus = ko.observable(false)
oa.getData = function(){
	payload = {
		Functiontype 		: oa.functionType(),
		Region 				: oa.region(),
		ReceiverCountry 	: oa.receivingCountry(),
		ReceiverLegalEntity : oa.receivingLegalEntity(),
		SupplierCountry 	: oa.supplycountry(),
		SupplierLegalEntity : oa.supplylegalentity(),
		Suppliertype 		: oa.supplytype(),
		Categoryname 		: oa.categoryname(),
		Productfunction 	: oa.product(),
		Pfpcritical 		: oa.necessary(),
		Cefcritical 		: oa.cef(),
		LegalSignatory 		: oa.LegalSignatory(),
		Parentprocessname 	: oa.parentprocessname(),
		GPO 				: oa.globalprocessowner(),
	};
	oa.showSummary(true)
	oa.getSummaryBarChart(payload,oa.filterChartBar());
	oa.getDataProduct(payload);
	oa.getSummaryBarDonut(payload,oa.filterDonutBar());
	if(oa.callGridStatus()){
		oa.gridProcessName();
	}
	oa.getSummaryBox();
};
oa.cekCookie = function(){
	var cookie_receiverCountry = readCookie("receiverCountry");
	var cookie_supplierCountry = readCookie("supplierCountry");
	var cookie_supplierType = readCookie("supplierType");
	var cookie_bussines = readCookie("bussiness");
	var cookie_legalEntity = readCookie("receiverLegalEntity");
	var cookie_supplyLegalEntity = readCookie("supplierLegalentity");
	oa.configOnchange("receivingCountry",false);
	oa.configOnchange("receivingLegalEntity",false);
	oa.configOnchange("Supplylegalentity",false);
	oa.configOnchange("Category",false); 
	(cookie_receiverCountry !== null && cookie_receiverCountry !== '' ) ? oa.receivingCountry([cookie_receiverCountry]) :'';
	(cookie_legalEntity !== null  && cookie_legalEntity !== '') ? oa.receivingLegalEntity(cookie_legalEntity.split(',')):'';
	(cookie_supplierCountry !== null  && cookie_supplierCountry !== '') ?   oa.supplycountry([cookie_supplierCountry]) :'';
	(cookie_supplyLegalEntity !== null  && cookie_supplyLegalEntity !== '') ? oa.supplylegalentity(cookie_supplyLegalEntity.split(',')):''; 
	(cookie_supplierType !== null  && cookie_supplierType !== '')?oa.supplytype(cookie_supplierType):'';
	(cookie_bussines !== null  && cookie_bussines !== '')?oa.categoryname([cookie_bussines]):'';
	CNUtimeout = setTimeout(function(){ 
		oa.getData()
		oa.configOnchange("",true)
	},1000);
};
function overval(index){
	return function(){
		$('#nonvalueid'+ index).css("display", "block");
		$('#nontitleid'+ index).css("display", "block");
		$('#valueid'+ index).css("display", "none");
		$('#titleid'+ index).css("display", "none");
		$('#outside'+ index).css("z-index", "1");
		$('#outside'+ index).css("border-top-left-radius", "6px");
		$('#outside'+ index).css("border-bottom-left-radius", "6px");
	}
}
function outval(index){
	return function(){
		$('#nonvalueid'+ index).css("display", "none");
		$('#nontitleid'+ index).css("display", "none");
		$('#valueid'+ index).css("display", "block");
		$('#titleid'+ index).css("display", "block");
		$('#outside'+ index).css("z-index", "0");
		$('#outside'+ index).css("border-top-left-radius", "0px");
		$('#outside'+ index).css("border-bottom-left-radius", "0px");
	}
}
function overval2(index){
	return function(){
		$('#nonvalueid2'+ index).css("display", "block");
		$('#nontitleid2'+ index).css("display", "block");
		$('#valueid2'+ index).css("display", "none");
		$('#titleid2'+ index).css("display", "none");
		$('#outside2'+ index).css("z-index", "1");
		$('#outside2'+ index).css("border-top-left-radius", "6px");
		$('#outside2'+ index).css("border-bottom-left-radius", "6px");
	}
}
function outval2(index){
	return function(){
		$('#nonvalueid2'+ index).css("display", "none");
		$('#nontitleid2'+ index).css("display", "none");
		$('#valueid2'+ index).css("display", "block");
		$('#titleid2'+ index).css("display", "block");
		$('#outside2'+ index).css("z-index", "0");
		$('#outside2'+ index).css("border-top-left-radius", "0px");
		$('#outside2'+ index).css("border-bottom-left-radius", "0px"); 
	}
}
function checkMaxWidth(val,nval,position){
	if((val+nval)==0){
		return 85;
	}
	var res = val / (val+nval)*100;
	if(res>85){
		return 85;
	}
	if (res<15){
		return 15;
	} 
	if(position == "outside" && res<10){
		res += 10 
	}
	return res;
}
oa.downloadGridAnalysis = function(){
	return function(){ 
		var grid = $("#processname-grid").data("kendoGrid");
		receiverExist = oa.defaultFilter().indexOf('Receiver') 
		supplierExist = oa.defaultFilter().indexOf('Supplier') 
		if(receiverExist > -1 && supplierExist > -1){
			grid.columns.splice(0, 2) 
			grid.columns.unshift({
				field: "receivercountry",
				title:"Receiver Country",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			},{
				field: "receiverlegalentity",
				title:"Receiver Legalentity",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			},{
				field: "suppliercountry",
				title:"Supplier",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			},{
				field: "supplierlegalentity",
				title:"supplier Legalentity",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			}) 
		}else if(receiverExist > -1 && supplierExist === -1){
			grid.columns.splice(0, 1) 
			grid.columns.unshift({
				field: "receivercountry",
				title:"Receiver Country",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			},{
				field: "receiverlegalentity",
				title:"Receiver Legalentity",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			}) 
		}else if(supplierExist > -1 && receiverExist === -1){
			grid.columns.splice(0, 1) 
			grid.columns.unshift({
				field: "suppliercountry",
				title:"Supplier",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			},{
				field: "supplierlegalentity",
				title:"supplier Legalentity",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			}) 
		}
		grid.saveAsExcel();
		var payload = {
      Type : "Ociranalysis Detail Drilldown Main Grid"
    }
    ajaxPost("/analyticuser/downloadlog", payload, function (res){
    })
	}
}
oa.downloadPopUpChart = function(){
	return function(){
		var grid = $("#grid-pupUp-chart").data("kendoGrid");
		grid.saveAsExcel();
		var payload = {
      Type : "Ociranalysis Summary Drilldown Barchart Grid"
    }
    ajaxPost("/analyticuser/downloadlog", payload, function (res){
    })
	}
}
oa.downloadDetailAnalysis = function(){
	return function(){
		grid = $("#grid-detail-analisys").data("kendoGrid");
		if(oa.flag() === 'IS' || oa.flag() === 'ES' || oa.flag() === 'TEAM'){
			grid.columns.splice(0, 1)
			grid.columns.unshift({
				field: "suppliercountry",
				title:"Supplier",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			},{
				field: "supplierlegalentity",
				title:"supplier Legalentity",
				width:230,
				headerAttributes: {
					"class": "align-left"
				},
				attributes: {
					"class": "field-ellipsis"
				}
			})
		}
		grid.saveAsExcel();
		var payload = {
      Type : "Ociranalysis Detail Drilldown Detail Grid"
    }
    ajaxPost("/analyticuser/downloadlog", payload, function (res){
    })
	}
}
function getPDF(selector) {
	//kendo.drawing.drawDOM($(selector)).then(function(group){
	kendo.drawing.pdf.saveAs("Product.pdf");
	//});
}
oa.productnamePopup = function(){
	var payload ={
		accessid: "ocir-analysis-product-popup"
	}
	ajaxPost("/aclsysadmin/isauthenticate",payload , function (res){
		if (res.Data == true) {
			oa.popupvalue(true);
		}else{
			oa.popupvalue(false);
		};
	})
}
oa.cekfirstFilter = function(){
	if (oa.supplytype() == 'IGS' || oa.supplytype() == 'Teams' || oa.supplytype() == 'IGS,Teams'|| oa.supplytype() == 'Teams,IGS') { //intragroup & inentity
		$(".yellow1-color" ).addClass("disable-button").addClass( "yellow1-color-disable"); //tpv
		$(".blue3-color" ).addClass("disable-button").addClass( "blue3-color-disable"); //contracts
		$(".light1-color" ).addClass("disable-button").addClass( "light1-color-disable"); //is
		$(".light2-color" ).addClass("disable-button").addClass( "light2-color-disable"); //es
		$(".yellow2-color" ).removeClass("disable-button").removeClass( "yellow2-color-disable"); //teams
	}else if (oa.supplytype() == 'TPS') { //external
		$(".yellow2-color" ).addClass("disable-button").addClass( "yellow2-color-disable"); //teams
		$(".light1-color" ).addClass("disable-button").addClass( "light1-color-disable"); //is
		$(".light2-color" ).addClass("disable-button").addClass( "light2-color-disable"); //es
		$(".yellow1-color" ).removeClass("disable-button").removeClass( "yellow1-color-disable"); //tpv
		$(".blue3-color" ).removeClass("disable-button").removeClass( "blue3-color-disable"); //contracts
	}else if (oa.supplytype() == 'Systems') { // systems
		$(".yellow2-color" ).addClass("disable-button").addClass( "yellow2-color-disable"); //teams
		$(".yellow1-color" ).removeClass("disable-button").removeClass( "yellow1-color-disable"); //tpv
		$(".blue3-color" ).removeClass("disable-button").removeClass( "blue3-color-disable"); //contracts
		$(".light1-color" ).removeClass("disable-button").removeClass( "light1-color-disable"); //is
		$(".light2-color" ).removeClass("disable-button").removeClass( "light2-color-disable"); //es
	}else if (oa.supplytype() == 'TPS,IGS' || oa.supplytype() == 'TPS,Teams' || oa.supplytype() == 'IGS,TPS' || oa.supplytype() == 'Teams,TPS' || oa.supplytype() == 'IGS,TPS,Teams' || oa.supplytype() == 'IGS,Teams,TPS' || oa.supplytype() == 'TPS,IGS,Teams' || oa.supplytype() == 'TPS,Teams,IGS' || oa.supplytype() == 'Teams,TPS,IGS'|| oa.supplytype() == 'Teams,IGS,TPS') { // external + intragroup & inentity
		$(".light1-color" ).addClass("disable-button").addClass( "light1-color-disable"); //is
		$(".light2-color" ).addClass("disable-button").addClass( "light2-color-disable"); //es
		$(".yellow2-color" ).addClass("disable-button").addClass( "yellow2-color-disable"); //teams
		$(".yellow1-color" ).removeClass("disable-button").removeClass( "yellow1-color-disable"); //tpv
		$(".blue3-color" ).removeClass("disable-button").removeClass( "blue3-color-disable"); //contracts
	}else if (oa.supplytype() == 'Systems,IGS' || oa.supplytype() == 'Systems,Teams' || oa.supplytype() == 'IGS,Systems' || oa.supplytype() == 'Teams,Systems' || oa.supplytype() == 'IGS,Systems,Teams' || oa.supplytype() == 'IGS,Teams,Systems' || oa.supplytype() == 'Systems,IGS,Teams' || oa.supplytype() == 'Systems,Teams,IGS' || oa.supplytype() == 'Teams,Systems,IGS'|| oa.supplytype() == 'Teams,IGS,Systems') { // systems + intragroup & inentity
		$(".yellow1-color" ).addClass("disable-button").addClass( "yellow1-color-disable"); //tpv
		$(".light1-color" ).removeClass("disable-button").removeClass( "light1-color-disable"); //is
		$(".light2-color" ).removeClass("disable-button").removeClass( "light2-color-disable"); //es
		$(".yellow2-color" ).removeClass("disable-button").removeClass( "yellow2-color-disable"); //teams
		$(".blue3-color" ).removeClass("disable-button").removeClass( "blue3-color-disable"); //contracts
	}else if (oa.supplytype() == 'TPS,Systems' || oa.supplytype() == 'Systems,TPS') { //external + systems
		$(".yellow2-color" ).addClass("disable-button").addClass( "yellow2-color-disable"); //teams
		$(".light1-color" ).removeClass("disable-button").removeClass( "light1-color-disable"); //is
		$(".light2-color" ).removeClass("disable-button").removeClass( "light2-color-disable"); //es
		$(".yellow1-color" ).removeClass("disable-button").removeClass( "yellow1-color-disable"); //tpv
		$(".blue3-color" ).removeClass("disable-button").removeClass( "blue3-color-disable"); //contracts
	}else{
		$(".yellow1-color" ).removeClass("disable-button").removeClass( "yellow1-color-disable"); //tpv
		$(".yellow2-color" ).removeClass("disable-button").removeClass( "yellow2-color-disable"); //teams
		$(".blue3-color" ).removeClass("disable-button").removeClass( "blue3-color-disable"); //contracts
		$(".light1-color" ).removeClass("disable-button").removeClass( "light1-color-disable"); //is
		$(".light2-color" ).removeClass("disable-button").removeClass( "light2-color-disable"); //es
	};
}
oa.getListTab =  function(){
	ajaxPost("/ociranalysis/getlistbarchart",{}, function (res){
		datas = []
		$.each(res.Data.rows, function(i,v){
			datas.push({text:v.title, value:v.url})
		});
		oa.filterChartBarList(datas)
	});
}
$(function(){
	$('#back-button-modalDetail').click(function(){
		$('#modaldetail').modal('hide');
		$('#modaltab').modal('show');
	})
	oa.flag = ko.observable('');
	oa.getListTab()
	var cookie_receiverCountry   = readCookie("receiverCountry");
	var cookie_supplierCountry   = readCookie("supplierCountry");
	var cookie_supplierType      = readCookie("supplierType");
	var cookie_bussines          = readCookie("bussiness");
	var cookie_legalEntity       = readCookie("receiverLegalEntity");
	var cookie_supplyLegalEntity = readCookie("supplierLegalentity");
	var getdataCall = true;
	arr = [
			{field:'receivingCountry',get:'getReceivingCountry',onchange:'receivingCountry',list:'receivingCountryList',value:cookie_receiverCountry},
			{field:'receivingLegalEntity',get:'getReceivingLegalEntity',onchange:'receivingLegalEntity',list:'receivingLegalEntityList',value:cookie_legalEntity},
			{field:'supplycountry',get:'getSupplyCountry',onchange:'supplyCountry',list:'supplycountryList',value:cookie_supplierCountry},
			{field:'supplylegalentity',get:'getSupplyLegalEntity',onchange:'Supplylegalentity',list:'supplylegalentityList',value:cookie_supplyLegalEntity}, 
			{field:'categoryname',get:'getCategoryName',onchange:'Category',list:'categorynameList',value:cookie_bussines}, 
			{field:'supplytype',get:'getSupplyType',onchange:'supplyType',list:'supplytypeList',value:cookie_supplierType}
		]
	var supplierTypeTPS = false;
	function doSetTimeout(arr) {
		setTimeout(function() { 
			if(arr.field === 'supplytype'){
				var results;
				switch(arr.value){
					case 'IGS':
						results = "Intra-Group"
					break;
					case 'FMI_System':
						results = "FMI System" 
					break;
					case 'FMI_TPS':
						results = "FMI External" 
					break;
					case 'FMI':
						results = "FMI" 
					break;
					case 'Teams':
						results = "In-Entity"
					break;
					default:
						results = "Systems"
				}
				oa[arr.list]([{value:'IGS',text:'Intra-Group'},{value:'FMI',text:'FMI'},{value:'FMI_System',text:'FMI System'},{value:'FMI_TPS',text:'FMI External'},{value:'Teams',text:'In-Entity'},{value:'Systems',text:'Systems'}])
				oa[arr.field]([arr.value])
			}else{ 
				var datas = []
				var data = [];                
				for(var x in arr.value.split(',')){ 
					var newData = arr.value.split(',')[x].replace('~',',')
					datas.push({value:newData,text:newData})
					data.push(newData)
				}
				oa[arr.list](datas)  
				oa[arr.field](data)
			}
		}, 400);
	}
	for(var i in arr){
		if(arr[i].value !== null && arr[i].value !== ''){
			oa.configOnchange(arr[i].onchange,false); 
			doSetTimeout(arr[i]) 
		}
	}
	setTimeout(function() {
		for(var x in arr){
			if(arr[x].value === null   || arr[x].value === ''){
				oa[arr[x].get]()
			}
		}
	}, 400);
	oa.getregion();
	oa.GetProduct();
	oa.getFunction()
	oa.getParentProcessName()
	oa.getGlobalProcessOwner()
	oa.getPfp() 
	oa.getCef() 
	if(getdataCall){
		setTimeout(function() {
			oa.getData();
			oa.onchange.functionType =true;
			oa.onchange.region =true;
			oa.onchange.receivingCountry =true;
			oa.onchange.receivingLegalEntity =true;
			oa.onchange.supplyCountry =true;
			oa.onchange.Supplylegalentity =true;
			oa.onchange.Category =true;
			oa.onchange.supplyType =true;
		},400);
	}
	datas = [{id:'123456789012 STATES OF AMERICA'},{id:'UGANDA'},{id:'UNITED KINGDOM america'},{id:'TAIWAN'}]
	legends = [];
	$.each(datas,function(i,v){
		var finalStm = "";
		var maxlen = 14;
		var Spl = v.id.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
			lenStm = lenStm + o.length + 1;
			var tb = "";
			if (lenStm <= maxlen) {
				tb = " ";
			} else {
				lenStm = o.length;
				tb = "\n";
			}
			if (i == 0) {
				tb = "";
			}
		});  
	})
	oa.productnamePopup();
	oa.cekfirstFilter();
	$('#modal-grid-detail-analysis').on('hidden.bs.modal', function () {
    	oa.loadingGridDetail(false);
    	oa.checkPopUp(false);
    	oa.closePopUp();
	})
});