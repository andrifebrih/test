dig = {}
dig.loading = {
    receiver : ko.observable(false),
    supplier : ko.observable(false)
}
dig.receivingSupplierType = ko.observableArray([]);

dig.supplierSupplierType  = ko.observableArray([]);

dig.receivingCountry     = ko.observable('');
dig.receivingCountryList = ko.observableArray([]);

dig.supplierCountry     = ko.observable('');
dig.supplierCountryList = ko.observableArray([]);

dig.receivingLegalEntity     = ko.observableArray([]);
dig.receivingLegalEntityList = ko.observableArray([]);

dig.supplierLegalEntity      = ko.observableArray([]);
dig.supplierLegalEntityList  = ko.observableArray([]);

dig.receivingCategory     = ko.observableArray([]);
dig.receivingCategoryList = ko.observableArray([]);

dig.supplierCategory     = ko.observableArray([]);
dig.supplierCategoryList = ko.observableArray([]);

dig.receivingProduct     = ko.observableArray([]);
dig.receivingProductList = ko.observableArray([]);

dig.supplierProduct     = ko.observableArray([]);
dig.supplierProductList = ko.observableArray([]);

dig.onchangeReceivingCountry = ko.observable(true);
dig.onchangeSupplierCountry  = ko.observable(true);

dig.receivingReceiverSummary = ko.observableArray([]);
dig.supplierReceiverSummary = ko.observableArray([]);

dig.receivingSupplierSummary = ko.observableArray([]);
dig.supplierSupplierSummary = ko.observableArray([]);

dig.receivingLevelProcess     = ko.observableArray([]);
dig.receivingLevelProcessList = ko.observableArray([]);

dig.supplierLevelProcess     = ko.observableArray([]);
dig.supplierLevelProcessList = ko.observableArray([]);

dig.receivingLevel2Process     = ko.observableArray([]);
dig.receivingLevel2ProcessList = ko.observableArray([]);

dig.supplierLevel2Process     = ko.observableArray([]);
dig.supplierLevel2ProcessList = ko.observableArray([]);

dig.receiverCountryMap = ko.observable();

dig.headerModalReceiver = ko.observable('');
dig.headerModalSupplier = ko.observable('');
dig.templateConfigDonut = {
    legend: {
        visible:false,
        labels: {
            font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            template:'',
            color: "#0075B2"
        },
        margin:{
            visible:true,
            left:-10
        },
    },
    chartArea: {
        height : 100,
        background: "transparent",
        width : 120,
    },
    seriesDefaults: {
        labels: {
            visible: false,
            template: "#= removeSpace(kendo.toString(percentage,'P0'))#",
            font: "9px Helvetica Neue, Arial, sans-serif",
            background: "transparent"
        }
    },
   // / seriesColors: ["#00506D","#0077A3","#50D0FF"],
    series: [{
        type: "donut",
        data: '',
        overlay:{gradient:"none"},
    }],
    valueAxis:{
        visible:false,
        labels: {
            font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            visible: false,
            format:"{0:P0}",
        },
        majorGridLines: {
            visible: false
        },
    },
    tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#=kendo.toString(value,'N0')#"
    },
}; 
dig.configDonut = ko.mapping.fromJS(dig.templateConfigDonut);

dig.receivingHoverCountry = ko.observable('');
dig.receivingTypeHoverCountry = ko.observable('');

dig.supplierHoverCountry = ko.observable('');
dig.supplierTypeHoverCountry = ko.observable('');

dig.showLegendLineReceiver = ko.observable(false);
dig.showLegendLineSupplier = ko.observable(false);

dig.clickSupplierIndex = 0;

dig.loadingMap = {
    receiver : ko.observable(false),
    supplier : ko.observable(false),
}
dig.indexingAjax = {
    receiverSummary: ko.observable(0),
    supplierSummary: ko.observable(0)
}
dig.clickAnalyze = function(value,type){
    return function () {
        var cookies; 
        if(value.hasOwnProperty('receiverLegalEntity') ){
            // var data = dashboard.parseLegalEntity(value)
            var data = value
                // cookies = {receiverCountry:data['country'].trim(), receiverLegalEntity:data['legalEntity'].trim()};
                cookies = {receiverLegalEntity:data['receiverLegalEntity']};
            if(type == 'supplier'){
                $.extend(true,cookies,{supplierCountry:dig.supplierCountry()})
                if(dig.supplierLegalEntity().length > 0){
                    $.extend(true,cookies,{supplierLegalentity:dig.supplierLegalEntity()})
                }
                if(dig.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:dig.supplierCategory()})
                }
            }else{
                if(dig.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:dig.receivingCategory()})
                }
            }
           
            // dashboard.createNewCookie(cookies); 
        }else if(value.hasOwnProperty('supplierLegalentity')){
            // dashboard.createNewCookie(cookies); 
            var data = dashboard.parseLegalEntity(value)
                cookies = {supplierCountry:data['country'].trim(), supplierLegalentity:data['legalEntity'].trim()};
            if(type == 'receiver'){
                $.extend(true,cookies,{receiverCountry:dig.receivingCountry()})
                if(dig.receivingLegalEntity().length > 0){
                    $.extend(true,cookies,{receiverLegalEntity:dig.receivingLegalEntity()})
                }
                if(dig.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:dig.receivingCategory()})  
                }
            }else{
                if(dig.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:dig.supplierCategory()})
                }
            }
                       // dashboard.createNewCookie(cookies); 
        }else if(value.hasOwnProperty('receiverCountry')){
            cookies = value;
            if(type == 'supplier' ){
                $.extend(true,cookies,{supplierCountry:dig.supplierCountry()})
                if(dig.supplierLegalEntity().length > 0){
                    $.extend(true,cookies,{supplierLegalentity:dig.supplierLegalEntity()})
                }
                if(dig.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:dig.supplierCategory()})
                }
            }else{
                if(dig.receivingLegalEntity().length > 0){
                    $.extend(true,cookies,{receiverLegalEntity:dig.receivingLegalEntity()})
                }
                if(dig.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:dig.receivingCategory()})  
                }
               
            }
            // dashboard.createNewCookie(value);
        }else if(value.hasOwnProperty('supplierCountry')){
            cookies = value;
            if(type == 'receiver' ){
                $.extend(true,cookies,{receiverCountry:dig.receivingCountry()})
                if(dig.receivingLegalEntity().length > 0){
                    $.extend(true,cookies,{receiverLegalEntity:dig.receivingLegalEntity()})
                }
                if(dig.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:dig.receivingCategory()})  
                }
            }else{
                if(dig.supplierLegalEntity().length > 0){
                    $.extend(true,cookies,{supplierLegalentity:dig.supplierLegalEntity()})
                }
                if(dig.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:dig.supplierCategory()})
                }
            }
            // dashboard.createNewCookie(value);
        }
        $.extend(true,cookies,{supplierType:'IGS'});

        dashboard.createNewCookie(cookies);
        redirectUrl("/ociranalysis/default")
    }
}

dig.receivingPrepareMap = function(){
    $('#map-int-receiving').remove();
    $(".panelMap-int").append("<div id='map-int-receiving' class='map'> </div>");
}

dig.supplierPrepareMap = function(){
   $('#map-int-supplier').remove();
   $(".panelMap-intSupplier").append("<div id='map-int-supplier' class='map'> </div>");
}

dig.downloadReceivingDetails = function(){
    return function(){
        var grid = $("#grid-popup-reciver-detail").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard Intra-Group Receiver Drilldown Detail"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}

dig.downloadReceiving = function(){
    return function(){
        var grid = $("#popupIntraReceiver").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard Intra-Group Receiver Drilldown"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}

dig.downloadSupplierDetails = function(){
    return function(){
        var grid = $("#grid-popup-supplier-detail").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard Intra-Group Supplier Drilldown Detail"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}

dig.downloadSupplier = function(){
    return function(){
        var grid = $("#popupIntraSupplier").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard Intra-Group Supplier Drilldown"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}

dig.receivingSetHoverValue =  function(country,type){
    var param = {
        ReceivingCountry : dig.receivingCountry(),
        LegalEntity : dig.receivingLegalEntity(),
        Business : dig.receivingCategory(),
        Productfunction : dig.receivingProduct(),
        Parentprocessname : dig.receivingLevelProcess(),
        Processname : dig.receivingLevel2Process(),
        SupplierCountry : country,
        Flag  : type,
        Suppliertype : "IGS",
        Tab : "receiver"
    }

    var titleGrid;
    if (type == "suppliername"){
        titleGrid = "Supplier Name"
    } else if(type == "receivername"){
        titleGrid = "Receiver Name" 
    } else if(type == "functionname"){
        titleGrid = "Function Name" 
    } else {
        titleGrid = " Level 1 Process"
    }

    dig.headerModalReceiver(titleGrid);
    
    var url = "/receiverview/getdetailstooltip"
      $("#popupIntraReceiver").html("");
      $("#popupIntraReceiver").kendoGrid({
         dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, param, function(datas){
                        option.success(datas); 
                        $('#digreceivermodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
         },
         dataBound: function(){
            $('#popupIntraReceiver .k-grid-content').height(315);
        },
         height: 380,
         columns: [{
            field:"_id",
            title:dig.headerModalReceiver(),
            width:200,
            /*filterable: false,*/
            attributes: {
                "class": "field-ellipsis"
            }
        }],
        excel: {
            fileName: dig.headerModalReceiver() + " Intra-Group Receiver.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
}

dig.supplierSetHoverValue =  function(country,type){
    var param = {
        ReceivingCountry :  country,
        LegalEntity : dig.supplierLegalEntity(),
        Business : dig.supplierCategory(),
        Productfunction : dig.supplierProduct(),
        SupplierCountry : dig.supplierCountry(),
        Parentprocessname : dig.supplierLevelProcess(),
        Processname : dig.supplierLevel2Process(),
        Flag  : type,
        Suppliertype : "IGS",
        Tab : "supplier"        
    }

    var titleGrid;
    if (type == "suppliername"){
        titleGrid = "Supplier Name"
    } else if(type == "receivername"){
        titleGrid = "Receiver Name" 
    } else if(type == "functionname"){
        titleGrid = "Function Name" 
    } else {
        titleGrid = " Level 1 Process"
    }

    dig.headerModalSupplier(titleGrid);
    
    var url = "/receiverview/getdetailstooltip"
      $("#popupIntraSupplier").html("");
      $("#popupIntraSupplier").kendoGrid({
         dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, param, function(datas){
                        option.success(datas);
                        $('#digsuppliermodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
         },
         dataBound: function(){
            $('#popupIntraSupplier .k-grid-content').height(315);
        },
         height: 380,
         columns: [{
            field:"_id",
            title:dig.headerModalSupplier(),
            width:200,
            /*filterable: false,*/
            attributes: {
                "class": "field-ellipsis"
            }
        }],
        excel: {
            fileName: dig.headerModalSupplier() + " Intra-Group Supplier.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
}

dig.receivingDetailsModal = function(supplierCountry){
    var payload = {
        ReceivingCountry :  dig.receivingCountry(),
        LegalEntity : dig.receivingLegalEntity(),
        SupplierCountry : supplierCountry,
        Parentprocessname : dig.receivingLevelProcess(),
        Processname : dig.receivingLevel2Process(),
        Flag : "intragroup",
        Tab : "receiver",
        Business : dig.receivingCategory(),
        Productfunction : dig.receivingProduct(),
    };
                 
    var url = "/receiverview/getdetailsrowtooltip";
     
    $("#grid-popup-reciver-detail").html("");
    $("#grid-popup-reciver-detail").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#digreceiverdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id.suppliercountry",dir:"asc"},
                {field:"_id.suppliername",dir:"asc"},
                {field:"_id.parentprocessname",dir:"asc"},
                {field:"_id.functionname",dir:"asc"},
            ],
        },
        dataBound: function(){
            $('#grid-popup-reciver-detail .k-grid-content').height(315);
        }, 
        height: 380,
        excel: {
            fileName : "Receiving Detail Intra-Group.xlsx",
            allPages: true
        },
        columns: [
            {
                field:"_id.suppliercountry",
                title:"Supplier Country",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.supplierlegalentity",
                title:"Supplier Legal Entity",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.suppliername",
                title:"Supplier Name",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.parentprocessname",
                title:"Level 1 Process",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.functionname",
                title:"Function Name",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"fte",
                title:"FTE",
                headerAttributes: {
                    "class": "align-right"
                },
                format:"{0:N2}",
                width:100,
                /*filterable: false,*/
                attributes: {"class": "align-right"}
            }
        ],
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
}

dig.SupplierDetailsModal = function(receivingCountry){
    var payload = {
        ReceivingCountry :  receivingCountry,
        LegalEntity : dig.supplierLegalEntity(),
        SupplierCountry : dig.supplierCountry(),
        Parentprocessname : dig.supplierLevelProcess(),
        Processname : dig.supplierLevel2Process(),
        Flag : "intragroup",
        Business : dig.supplierCategory(),
        Productfunction : dig.supplierProduct(),
        Tab : "supplier",
    };
    
    var url = "/receiverview/getdetailsrowtooltip";
    
    $("#grid-popup-supplier-detail").html("");
    $("#grid-popup-supplier-detail").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#digsupplierdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id.functionname",dir:"asc"},
                {field:"_id.parentprocessname",dir:"asc"},
                {field:"_id.suppliercountry",dir:"asc"},
                {field:"_id.suppliername",dir:"asc"},
            ],
        },
        dataBound: function(){
            $('#grid-popup-supplier-detail .k-grid-content').height(315);
        }, 
        height: 380,
        excel: {
            fileName: "Supplier Detail Intra-Group.xlsx",
            allPages: true
        },
        columns: [
            {
                field:"_id.functionname",
                title:"Function Name",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.parentprocessname",
                title:"Level 1 Process",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.suppliercountry",
                title:"Supplier Country",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
              {
                field:"_id.supplierlegalentity",
                title:"Supplier Legal Entity",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
              {
                field:"_id.suppliername",
                title:"Supplier Name",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"fte",
                title:"FTE",
                format:"{0:N2}",
                headerAttributes: {
                    "class": "align-right"
                },
                width:100,
                /*filterable: false,*/
                attributes: {"class": "align-right"}
            }
        ],
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });    
}

dig.receivingMapDetails = function(dataSource){
    dig.receivingPrepareMap();    
    setTimeout(function(){
        var dSource = dataSource.BubbleSupplier.features;
        var fromlatLng = [dataSource.BoxInfo.Longitude,dataSource.BoxInfo.Latitude];
        var boxLabel = dataSource.BoxInfo
        var receivingCountry = dig.receivingCountry().replace("'", "&#39;");
        var allSupplier = {"SupplierName": 0,"FunctionName":0,"LevelOne":0, "count":0}; 
     
     
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});

         
        var map = L.map('map-int-receiving', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
                zoomControl: false,
        }) 
        L.control.zoom({
            position:'topright'
        }).addTo(map);
      



        oldId = null
        var path = []
        var markerOn;
        for(var i in dSource){
            data = dSource[i]
            if(fromlatLng[1] === dSource[i].geometry.coordinates[1] && fromlatLng[0] === dSource[i].geometry.coordinates[0]){
 
                allSupplier = {"SupplierName": data.properties.SupplierName ,"FunctionName":data.properties.FunctionName,"LevelOne":data.properties.LevelOne, "count":data.properties.count, "FMI":data.properties.FMI};
       
            }
            if(fromlatLng[1] !== dSource[i].geometry.coordinates[1] && fromlatLng[0] !== dSource[i].geometry.coordinates[0] ){      
            if(dSource[i].properties.count <= 5){
                var icon = dashboard.mapGreyIcon;
            }else if(dSource[i].properties.count <= 20){
                var icon = dashboard.mapGreenIcon;
            }  else {
                var icon = dashboard.mapBlueIcon; 
            }
            
            var marker = L.marker([dSource[i].geometry.coordinates[1], dSource[i].geometry.coordinates[0]], {icon: icon,id:i  }).addTo(map);
           
            $(marker._icon).addClass('markerReceiver-'+i);
            var templatePopUp = ["<span style='color:#0644a0'>Supplier Country Data</span>",
                                "<a href='#supplier_"+data.properties.SecondaryID+"'><b>"+ data.properties.SecondaryID + "</b></a>",
                                "# of Suppliers : <a onclick='dig.receivingSetHoverValue(\""+data.properties.SecondaryID+"\",\"suppliername\")' href='#'>"+data.properties.SupplierName+" </a>",
                                "# of Functions : <a onclick='dig.receivingSetHoverValue(\""+data.properties.SecondaryID+"\",\"functionname\")' href='#'>"+data.properties.FunctionName+"  </a>",
                                "Total FTE : "+ kendo.toString(data.properties.count, 'N2'),
                                
                                "# of Level 1 Processes : <a onclick='dig.receivingSetHoverValue(\""+data.properties.SecondaryID+"\",\"Level1Process\")' href='#'> "+data.properties.LevelOne+"  </a>",   
                                "<table width='100%'>" +
                                "<tr>"+
                                "<td width='50%'><a onclick='dig.receivingDetailsModal(\""+data.properties.SecondaryID+"\")' href='#'>Details</a></td>"+
                                "</tr>"+
                                "<tr>"+
                                "<td width='50%'><a onclick='hideMarkerReceiver(\""+i+"\")' >Hide</a></td>"+
                                "</tr>"+
                                "</table>"].join("<br>") 
            marker.bindPopup(templatePopUp); 
            marker.on('mouseover', function (e) {       
                markerOn = this
                this.openPopup();
            });

            coordinatesProp = {latFrom:fromlatLng[1] ,latTo:dSource[i].geometry.coordinates[1] ,lngFrom:fromlatLng[0],lngTo:dSource[i].geometry.coordinates[0]}
            coordinate = dashboard.getLatLngCenter(coordinatesProp);
            
            path.push(L.curve(['M',[fromlatLng[1],fromlatLng[0] ],
                                'Q',[coordinate.latCenter,coordinate.lngCenter],
                                    [dSource[i].geometry.coordinates[1],dSource[i].geometry.coordinates[0]]],{weight: 2,color:data.properties.Color,className: 'lineReceiver-'+i}).addTo(map));
            }
        } 
          var templatePopUpReceivingCountry = 
                            [
                           "<a href='#supplier_"+dig.receivingCountry()+"'><b>"+ dig.receivingCountry()+ "</b></a><span style='color:#0644a0'> as Receiver</span>",
                            "# of Suppliers : <a onclick='dig.receivingSetHoverValue(\"\",\"suppliername\")' href='#'>"+boxLabel.SupplierName+"</a>",
                            "# of Functions : <a onclick='dig.receivingSetHoverValue(\"\",\"functionname\")' href='#'>"+boxLabel.FunctionName+"</a>",
                            "Total FTE : "+  kendo.toString(boxLabel.FTE, 'N2'),
                            "# of Level 1 Processes : <a onclick='dig.receivingSetHoverValue(\"\",\"Level1Process\")' href='#'>"+boxLabel.LevelOne+" </a>",
                            "<a onclick='dig.receivingDetailsModal()' href='#'>Details</a></br>",

                            "<a href='#supplier_"+dig.receivingCountry()+"'><b>"+ dig.receivingCountry()+ "</b></a><span style='color:#0644a0'> as  Supplier</span>",
                            "# of Suppliers : <a onclick='dig.receivingSetHoverValue(\""+receivingCountry+"\",\"suppliername\")' href='#'>"+ allSupplier.SupplierName+"</a>",
                            "# of Functions : <a onclick='dig.receivingSetHoverValue(\""+receivingCountry+"\",\"functionname\")' href='#'>"+ allSupplier.FunctionName+"</a>",
                            "# Total FTE :"+kendo.toString(allSupplier.count, 'N2')+"",
                            "# of Level 1 Processes : <a onclick='dig.receivingSetHoverValue(\""+receivingCountry+"\",\"Level1Process\")' href='#'>"+allSupplier.LevelOne+"</a>",
                            "<a onclick='dig.receivingDetailsModal(\""+receivingCountry+"\")' href='#'>Details</a></br>"
                            ]
                            .join("<br>") 
        defMarker = L.marker([fromlatLng[1], fromlatLng[0]], {icon: dashboard.receiverIcon}).addTo(map)
            .bindPopup(templatePopUpReceivingCountry).openPopup();
        defMarker.on('mouseover', function (e) {
                this.openPopup();
        });
        hideMarkerReceiver = function(index){
        
     
            markerOn.closePopup()
            $('.markerReceiver-'+index).hide('fast')
            $('.lineReceiver-'+index).attr('stroke-opacity',0)
            idCountry =  dSource[index].properties.SecondaryID.replace(/'| |,/g,'_');
            
            $('#supplier_'+idCountry).hide('fast') 
     
        }
    },100)
};

dig.supplierMapDetails = function(dataSource){
    dig.supplierPrepareMap();    
    setTimeout(function(){
        var dSource = dataSource.BubbleSupplier.features;
        var fromlatLng = [dataSource.BoxInfo.Longitude,dataSource.BoxInfo.Latitude];
        var boxLabel = dataSource.BoxInfo
        var supplierCountry = dig.supplierCountry().replace("'", "&#39;");
        var allSupplier = {"SupplierName": 0,"FunctionName":0,"LevelOne":0, "count":0}; ; 
     
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});


         
        var map = L.map('map-int-supplier', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
            zoomControl: false,
        }) 
        
        L.control.zoom({
             position:'topright'
        }).addTo(map);
       
        var path = []
        for(var i in dSource){
            data = dSource[i]
            if(fromlatLng[1] === dSource[i].geometry.coordinates[1] && fromlatLng[0] === dSource[i].geometry.coordinates[0]){
 
                allSupplier = {"SupplierName": data.properties.SupplierName ,"FunctionName":data.properties.FunctionName,"LevelOne":data.properties.LevelOne, "count":data.properties.count, "FMI":data.properties.FMI};
       
            }
            if(fromlatLng[1] !== dSource[i].geometry.coordinates[1] && fromlatLng[0] !== dSource[i].geometry.coordinates[0] ){      
            if(dSource[i].properties.count <= 5){
                var icon =  dashboard.mapGreyIcon;
            }else if(dSource[i].properties.count <= 20){
                var icon =  dashboard.mapGreenIcon;
            }  else {
                var icon =  dashboard.mapBlueIcon; 
            }
            
            var marker = L.marker([dSource[i].geometry.coordinates[1], dSource[i].geometry.coordinates[0]], {icon: icon,id:i}).addTo(map);
            $(marker._icon).addClass('markerSuplier-'+i);
            var templatePopUp = [
                            "<span style='color:#0644a0'>Receiver Country Data</span>",
                            "<a href='#receiver_"+data.properties.SecondaryID+"'><b>"+ data.properties.SecondaryID + "</b></a>",
                            "# of Suppliers : <a onclick='dig.supplierSetHoverValue(\""+data.properties.SecondaryID+"\",\"suppliername\")' href='#'> "+ data.properties.SupplierName +"  </a>",
                            "# of Functions : <a onclick='dig.supplierSetHoverValue(\""+data.properties.SecondaryID+"\",\"functionname\")' href='#'>"+ data.properties.FunctionName +" </a>",
                            "Total FTE : "+ kendo.toString( data.properties.count, 'N2'),
                            "# of Level 1 Processes : <a onclick='dig.supplierSetHoverValue(\""+data.properties.SecondaryID+"\",\"Level1Process\")' href='#'> "+ data.properties.LevelOne +" </a>",
                            "<table width='100%'>" +
                            "<tr>"+
                            "<td width='50%'><a onclick='dig.SupplierDetailsModal(\""+data.properties.SecondaryID+"\")' href='#'>Details</a></td>"+
                            "</tr>"+
                            "<tr>"+
                            "<td width='50%'><a onclick='hideMarkerSupplier(\""+i+"\")' href='#'>Hide</a></td>"+
                            "</tr>"+
                            "</table>"].join("<br>")
            marker.bindPopup(templatePopUp);
            marker.on('mouseover', function (e) {
                id = e.target.options.id 
                
                $('.lineSupplier'+id).attr('stroke-opacity',0)
                oldId = id
      
                this.openPopup();
            });
            marker.on('mouseout', function (e) {
                if(oldId != null){
                    $('.lineSupplier'+oldId).attr('stroke-opacity',1)
                }
            });
           
            coordinatesProp = {latFrom:fromlatLng[1] ,latTo:dSource[i].geometry.coordinates[1] ,lngFrom:fromlatLng[0],lngTo:dSource[i].geometry.coordinates[0]}
            coordinate = dashboard.getLatLngCenter(coordinatesProp);
            path.push(L.curve(['M',[fromlatLng[1],fromlatLng[0] ],
                               'Q',[coordinate.latCenter,coordinate.lngCenter],
                                    [dSource[i].geometry.coordinates[1],dSource[i].geometry.coordinates[0]]],{weight: 2,color:data.properties.Color,className: 'lineSupplier-'+i}).addTo(map));
            }
        } 
         var templatePopUpReceivingCountry = [
                        "<a href='#receiver_"+dig.supplierCountry()+"'><b>"+ dig.supplierCountry() + "</b></a><span style='color:#0644a0'> as Supplier</span>",
                        "# of Receivers :  <a onclick='dig.supplierSetHoverValue(\"\",\"receivername\")' href='#'> "+boxLabel.SupplierName+"</a>",
                        "# of Functions :  <a onclick='dig.supplierSetHoverValue(\"\",\"functionname\")' href='#'>"+boxLabel.FunctionName+"</a>",
                        "Total FTE : "+  kendo.toString(boxLabel.FTE, 'N2'),
                        "# of Level 1 Processes : <a onclick='dig.supplierSetHoverValue(\"\",\"Level1Process\")' href='#'>  "+boxLabel.LevelOne+"</a>",
                        "<a onclick='dig.SupplierDetailsModal()' href='#'>Details</a></br>",

                        "<a href='#receiver_"+dig.supplierCountry()+"'><b>"+ dig.supplierCountry() + "</b></a><span style='color:#0644a0'> as Receiver</span>",
                        "# of Suppliers :<a onclick='dig.supplierSetHoverValue(\""+supplierCountry+"\",\"suppliername\")' href='#'>"+allSupplier.SupplierName+"</a>",
                        "# of Functions :<a onclick='dig.supplierSetHoverValue(\""+supplierCountry+"\",\"functionname\")' href='#'>"+allSupplier.FunctionName+"</a>",
                        "# Total FTE :"+ kendo.toString(allSupplier.count, 'N2')+"",
                        "# of Level 1 Processes : <a onclick='dig.supplierSetHoverValue(\""+supplierCountry+"\",\"Level1Process\")' href='#'> "+allSupplier.LevelOne+"</a>",
                        "<a onclick='dig.SupplierDetailsModal(\""+supplierCountry+"\")' href='#'>Details</a></br>",
                    ].join("<br>")  
        defMarker =  L.marker([fromlatLng[1], fromlatLng[0]], {icon: dashboard.supplierIcon}).addTo(map)
            .bindPopup(templatePopUpReceivingCountry).openPopup();
        defMarker.on('mouseover', function (e) {
                this.openPopup();
        }); 
        hideMarkerSupplier = function(index){
        
          
            
            $('.markerSuplier-'+index).hide('fast')
            $('.lineSupplier-'+index).attr('stroke-opacity',0)
            idCountry =  dSource[index].properties.SecondaryID.replace(/'| |,/g,'_');
            
            $('#receiver_'+idCountry).hide('fast') 
            
        }
    },100)
};

dig.receivingMap = function(dataSource){
    dig.receivingPrepareMap()

    setTimeout(function(){
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});

        var map = L.map('map-int-receiving', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
            zoomControl: false,
        })
        L.control.zoom({
             position:'topright'
        }).addTo(map);
       
        var geoJson = dataSource.features;
        $.each(geoJson, function(i,v){
            if(v.properties.count <= 5){
                var icon = dashboard.mapGreyIcon;;
            }else if(v.properties.count <= 20){
                var icon = dashboard.mapGreenIcon;
            }  else {
                var icon = dashboard.mapBlueIcon ; 
            }
            var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}).addTo(map);
            marker.Country = v.properties.SecondaryID
            marker.on('click', function(e){ 
                dig.receivingCountry(e.target.Country);
                dig.receivingGetData();
            });
        })
    },100)
};
dig.supplierMap = function(dataSource){
    dig.supplierPrepareMap()
 

    setTimeout(function(){
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});

        var map = L.map('map-int-supplier', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
                zoomControl: false,
        })
        L.control.zoom({
             position:'topright'
        }).addTo(map);
       
        var geoJson = dataSource.features;
        $.each(geoJson, function(i,v){
            if(v.properties.count <= 5){
                var icon = dashboard.mapGreyIcon;;
            }else if(v.properties.count <= 20){
               
                var icon = dashboard.mapGreenIcon;
            }  else {
                 var icon = dashboard.mapBlueIcon ; 
            }
            var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}).addTo(map);
            marker.Country = v.properties.SecondaryID
            marker.on('click', function(e){ 
                dig.supplierCountry(e.target.Country);
                dig.suppliergGetData();
            });
        })
    },100)   
};
dig.configSeries = function(indexClass, indeexData, selectorId){
            var color = ["#00506D","#0077A3","#50D0FF"]
            var visibleData   = $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data[indeexData].visible
            $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data[indeexData].visible = !visibleData
            $("#"+selectorId+"_"+indexClass).getKendoChart().redraw();
            var datas = $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data
            color = (!visibleData)?color[indeexData]: '#9b9898';
            $("#legend-"+selectorId +"_"+indexClass).find("li").eq(indeexData).find(".square").css('background',color)
            var totalDataTrue = 0 
            $.each(datas, function(i, val){            
                if(val.visible == true){
                    totalDataTrue += val.value
                } 
            })

            $.each(datas, function(i, val){            
                var percentage = 100 / (totalDataTrue / val.value) 
                if(val.visible == true){ 
                    $("#legend-donut-"+selectorId+"-precentage_"+ indexClass +"_"+i).text(String(percentage.toFixed(0)) +"%")
                }else{
                    $("#legend-donut-"+selectorId+"-precentage_"+ indexClass +"_"+i).text("")
                }
            }) 
}
dig.sortData = function(dataSource){ 
        $.each(dataSource,function(index,value){
            for(var i=0; i<(dataSource.length-1); i++){
                if(dataSource[i].Country.toLowerCase() > dataSource[i+1].Country.toLowerCase()){
                    var old = dataSource[i+1];
                    dataSource[i+1] = dataSource[i]
                    dataSource[i] = old
                }
            }
        }) 
        return dataSource
}
dig.downloadPopUpDonut = function(){
    return function(){
        var grid = $("#grid-popup-intra-group-donut").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard Intra-Group Receiver Drilldown Donut"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}
dig.downloadPopUpDonutSupplier = function(){
    return function(){
        var grid = $("#grid-popup-intra-group-donut-supplier").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard Intra-Group Supplier Drilldown Donut"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}

 
dig.popUpDonut =  function(payload){ 
    $('#modal-intra-group-donut').modal('show');
    $("#grid-popup-intra-group-donut").html("");
    $("#grid-popup-intra-group-donut").kendoGrid({
        dataSource: {
            transport: {
               read:function(options){
                    payload.filter = options.data.filter
                    payload.page = options.data.page
                    payload.pageSize = options.data.pageSize
                    payload.skip = options.data.skip
                    payload.sort = options.data.sort
                    payload.take = options.data.take
                    ajaxPost("/receiverview/getpopupdonutintra", payload, function(datas){
                        options.success(datas);  
                    })
                }, 
            },
            schema: {
                data: function(data) {      
                    if (data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Records;
                    }   
                },
                total: "Count",
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true, 
            sort: [
                {field:"receivercountry",dir:"asc"},
                {field:"suppliercountry",dir:"asc"},
                {field:"categoryname_",dir:"asc"},
                {field:"productfunction",dir:"asc"},
                {field:"parentprocessname",dir:"asc"},
                {field:"processname",dir:"asc"},
                {field:"servicedescription",dir:"asc"},
                {field:"barriertype",dir:"asc"},


                {field:"suppliername",dir:"asc"},
                {field:"suppliertype",dir:"asc"},
                {field:"contractid",dir:"asc"},
                {field:"slaid",dir:"asc"},
                {field:"buildingname",dir:"asc"},

                {field:"teamcostcentre",dir:"asc"}, 
            ],
        },
        height: 380,
        columns: [
           {
                field:"receivercountry",
                title:'Receiver Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= receivercountry + ' - ' + receiverlegalentity #",
            },
            {
                field:"suppliercountry",
                title:'Supplier Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
            },
            {
                field:"categoryname_",
                title:'Business',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"productfunction",
                title:'Product',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"parentprocessname",
                title:'Level 1 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"processname",
                title:'Level 2 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"servicedescription",
                title:'Service Description',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"barriertype",
                title:'Barrier Type',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"suppliername",
                title:'Supplier Name',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"suppliertype",
                title:'Supplier Type',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }, 
            {
                field:"contractid",
                title:'Contract ID',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }, 
            {
                field:"slaid",
                title:'SLA ID',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }, 
            {
                field:"buildingname",
                title:'Building Name',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }, 
            {
                field:"teamcostcentre",
                title:'Cost Centre',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }
        ],
        excel: {
            fileName: "PopUpIntraGroupDonut.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1,
            pageSize: 20,
            pageSizes: [5, 10, 20],
        },
        // filterable: {
        //     extra:false, 
        //     operators: {
        //         string: {
        //             contains: "Contains",
        //             startswith: "Starts with",
        //             eq: "Is equal to",
        //             neq: "Is not equal to",
        //             doesnotcontain: "Does not contain",
        //             endswith: "Ends with"
        //         },
        //     }
        // }, 
        height: 380,
    });
}

dig.popUpDonutSupplier =  function(payload){ 
    $('#modal-intra-group-donut-supplier').modal('show'); 
    $("#grid-popup-intra-group-donut-supplier").html("");
    $("#grid-popup-intra-group-donut-supplier").kendoGrid({
        dataSource: {
            transport: {
               read:function(options){
                    payload.filter = options.data.filter
                    payload.page = options.data.page
                    payload.pageSize = options.data.pageSize
                    payload.skip = options.data.skip
                    payload.sort = options.data.sort
                    payload.take = options.data.take
                    ajaxPost("/receiverview/getpopupdonutintra", payload, function(datas){
                        options.success(datas); 
                        // setTimeout(function() {
                        //         $("#grid-popup-intra-group-donut").data("kendoGrid").resize();  
                        // }, 500);
                    })
                },
                // parameterMap: function(data) {
                //    return JSON.stringify(data);
                // },
            },
            schema: {
                data: function(data) {      
                    if (data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Records;
                    }   
                },
                total: "Count",
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
            sort: [
                {field:"receivercountry",dir:"asc"},
                {field:"suppliercountry",dir:"asc"},
                {field:"categoryname_",dir:"asc"},
                {field:"productfunction",dir:"asc"},
                {field:"parentprocessname",dir:"asc"},
                {field:"processname",dir:"asc"},
                {field:"servicedescription",dir:"asc"},
                {field:"barriertype",dir:"asc"},


                {field:"suppliername",dir:"asc"},
                {field:"suppliertype",dir:"asc"},
                {field:"contractid",dir:"asc"},
                {field:"slaid",dir:"asc"},
                {field:"buildingname",dir:"asc"},

                {field:"teamcostcentre",dir:"asc"}, 
            ],
        },
        // height: 380,
        columns: [
           {
                field:"receivercountry",
                title:'Receiver Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= receivercountry + ' - ' + receiverlegalentity #",
            },
            {
                field:"suppliercountry",
                title:'Supplier Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
            },
            {
                field:"categoryname_",
                title:'Business',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"productfunction",
                title:'Product',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"parentprocessname",
                title:'Level 1 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"processname",
                title:'Level 2 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"servicedescription",
                title:'Service Description',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"barriertype",
                title:'Barrier Type',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"suppliername",
                title:'Supplier Name',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"suppliertype",
                title:'Supplier Type',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }, 
            {
                field:"contractid",
                title:'Contract ID',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }, 
            {
                field:"slaid",
                title:'SLA ID',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }, 
            {
                field:"buildingname",
                title:'Building Name',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }, 
            {
                field:"teamcostcentre",
                title:'Cost Centre',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }
        ],
        excel: {
            fileName: "PopUpIntraGroupDonut.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1,
            pageSize: 20,
            pageSizes: [5, 10, 20],
        },
        // filterable: {
        //     extra:false, 
        //     operators: {
        //         string: {
        //             contains: "Contains",
        //             startswith: "Starts with",
        //             eq: "Is equal to",
        //             neq: "Is not equal to",
        //             doesnotcontain: "Does not contain",
        //             endswith: "Ends with"
        //         },
        //     }
        // },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        // height: 380,
    });
}
dig.receivingCreateSummary =  function(payload){
    dig.loading.receiver(true);
    increaseIndexingAjx(dig.indexingAjax.receiverSummary);
    payload.Index = dig.indexingAjax.receiverSummary(); 

    ajaxPost("/receiverview/summaryreceiverintragroup",payload, function (res){        
        
        dig.loading.receiver(false);
        if(res.Index != dig.indexingAjax.receiverSummary())
            return;


        var receivers = [];
        var suppliers = [];

        $.each(res.Country, function(index,v){

            var data ={ 
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                NumSLA:kendo.toString(v.NumSLA,"n0"),
                DetailsDonut: v.DetailsDonut,
                TotalDonut: v.TotalDonut,
                Legal: [],
            };
            for(var i in v.DetailsLegal){
                data.Legal.push({
                    keyID:index+"-"+i,

                    Country:v.Country,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    NumSLA:kendo.toString(v.DetailsLegal[i].NumSLA,"n0"),
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal,
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                });
            }
            receivers.push(data);
        });

        dig.receivingReceiverSummary(receivers);
        dataSupplier = dig.sortData(res.Supplier)

        $.each(dataSupplier, function(index,v){
            idCountry =  v.Country.replace(/'| |,/g,'_');
 
        
            var data ={
                idCountry:idCountry,
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                NumSLA:kendo.toString(v.NumSLA,"n0"),
                DetailsDonut : v.DetailsDonut,
                Legal: [],
                TotalDonut: v.TotalDonut,
            };
            for(var i in v.DetailsLegal){

                data.Legal.push({
                    Country:v.Country,
                    keyID:index+"-"+i,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    NumSLA:kendo.toString(v.DetailsLegal[i].NumSLA,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal
                });
            }
            suppliers.push(data);
        });
        dig.receivingSupplierSummary(suppliers);
        var color=["#00506D","#0077A3","#50D0FF"];
        

        $.each(receivers, function(i,v){
            var dataReceiver = []
            $.each(v.DetailsDonut, function(index,value){
                dataReceiver.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                $("#legend_donut_dig-receiver_"+i+" ul").append("<li>"+
                                                      "<a onClick='dashboard.configDonutSeries(\"dig-receiver\","+i+","+index+")'>"+
                                                      "<div class='square' style='background:"+color[index]+"'></div>"+ 
                                                         dataItem+
                                                      "<span style='float:right' id='legend_donut_dig-receiver_precentage_"+ i +"_"+index+"'>"+
                                                         percentage.toFixed(0)+"<b>%</b>"+
                                                      "</span>"+
                                                      "</a>"+
                                                      "</li>") 
             





                // $("#legend-dig_receiver_"+i+" ul").append("<li><a onClick='dig.configSeries("+i+","+index+",\"dig_receiver\")'>
                //   <div class='square' style='background:"+color[index]+"'>
                //   </div>"+ dataItem+"<span style='float:right' id='legend-donut-dig_receiver-precentage_"+ i +"_"+index+"'>
                //   </span></a></li>") 
                // $("#legend-donut-dig_receiver-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
            receiverClick = function(e){

                switch(e.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                }
                var payload = {
                    Business : dig.receivingCategory(),
                    Productfunction : dig.receivingProduct(),
                    Country : v.Country,
                    FilterCountry : dig.receivingCountry(),
                    FilterLegal : dig.receivingLegalEntity(),
                    Flag : "receiver",
                    LegalEntity : [],
                    Parentprocessname: dig.receivingLevelProcess(),
                    Processname : dig.receivingLevel2Process(),
                    Posisi: "receiverview",
                    Tab : "intra",
                    Type: dataItem,
                }; 
                dig.popUpDonut(payload)
            }
            var configDonut = ko.mapping.toJS(dig.configDonut);
            configDonut.series[0].data = dataReceiver;
            configDonut.seriesClick = receiverClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
           
            $("#donut_dig-receiver_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dateLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dateLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    
                    switch(data.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0;   
                    $("#legend-dig_receiver-entity_"+value.keyID+" ul").append("<li><a onClick='dig.configSeries(\""+value.keyID+"\","+number+",\"dig_receiver-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-dig_receiver-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-dig_receiver-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                receiverEntityClick = function(e){
            
                     var legalEntity  = value.CountryLegal.split("~")[0];
                    // legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    // Country = Country.trim()
                    switch(e.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    }
                    var payload = {
                        Business : dig.receivingCategory(),
                        Productfunction : dig.receivingProduct(),
                        Country : value.Country,
                        FilterCountry : dig.receivingCountry(),
                        FilterLegal : dig.receivingLegalEntity(),
                        Flag : "receiver",
                        LegalEntity : [legalEntity],
                        Parentprocessname: dig.receivingLevelProcess(),
                        Processname : dig.receivingLevel2Process(),
                        Posisi: "receiverview",
                        Tab : "intra",
                        Type: dataItem,
                    };
                    dig.popUpDonut(payload)
                }
                var configDetailsDonut = ko.mapping.toJS(dig.configDonut);
                configDetailsDonut.series[0].data = dateLegal;
                configDetailsDonut.seriesClick = receiverEntityClick;
                configDetailsDonut.legend.labels.template ="#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
                $("#dig_receiver-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        })
        $.each(suppliers, function(i,v){
            var dataSuplier = []
            $.each(v.DetailsDonut, function(index,value){
                dataSuplier.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                $("#legend-dig_supplier_"+i+" ul").append("<li><a onClick='dig.configSeries("+i+","+index+",\"dig_supplier\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-dig_supplier-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-dig_supplier-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
            supplierClick = function(e){

                switch(e.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                }
                var payload = {
                    Business : dig.receivingCategory(),
                    Productfunction : dig.receivingProduct(),
                    Country : v.Country,
                    FilterCountry : dig.receivingCountry(),
                    FilterLegal : dig.receivingLegalEntity(),
                    Flag : "supplier",
                    LegalEntity : [],
                    Parentprocessname: dig.receivingLevelProcess(),
                    Processname : dig.receivingLevel2Process(),
                    Posisi: "receiverview",
                    Tab : "intra",
                    Type: dataItem,
                }; 
                
                dig.popUpDonut(payload)
            }
            var configDonut = ko.mapping.toJS(dig.configDonut);
            configDonut.series[0].data = dataSuplier;
            configDonut.seriesClick = supplierClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
            $("#dig_supplier_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dataSupplierLegal = []
                $.each(value.DetailsDonut, function(number,data){
                   
                    dataSupplierLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                
                    switch(data.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    } 

                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0;   
                   
                    $("#legend-dig_supplier-entity_"+value.keyID+" ul").append("<li><a onClick='dig.configSeries(\""+value.keyID+"\","+number+",\"dig_supplier-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-dig_supplier-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-dig_supplier-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                supplierEntityClick = function(e){
                    var legalEntity  = value.CountryLegal.split("~")[0];
                    legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    Country = Country.trim()
                    switch(e.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    }
                    var payload = {
                        Business : dig.receivingCategory(),
                        Productfunction : dig.receivingProduct(),
                        Country : value.Country,
                        FilterCountry : dig.receivingCountry(),
                        FilterLegal : dig.receivingLegalEntity(),
                        Flag : "supplier",
                        LegalEntity : [legalEntity],
                        Parentprocessname: dig.receivingLevelProcess(),
                        Processname : dig.receivingLevel2Process(),
                        Posisi: "receiverview",
                        Tab : "intra",
                        Type: dataItem,
                    };
                    dig.popUpDonut(payload)
                } 
                var configDetailsDonut = ko.mapping.toJS(dig.configDonut);
                configDetailsDonut.seriesClick = supplierEntityClick;
                configDetailsDonut.series[0].data = dataSupplierLegal;
                configDetailsDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
         
                $("#dig_supplier-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        })
    });
}

dig.supplierCreateSummary =  function(payload){
    dig.loading.supplier(true);
    increaseIndexingAjx(dig.indexingAjax.supplierSummary);
    payload.Index = dig.indexingAjax.supplierSummary(); 
    ajaxPost("/receiverview/summaryreceiverintragroup",payload, function (res){
        dig.loading.supplier(false);
        if(res.Index != dig.indexingAjax.supplierSummary())
            return;
        
        var receivers = [];
        var suppliers = [];
        $.each(res.Country, function(index,v){
            idCountry =  v.Country.replace(/'| |,/g,'_');
            var data ={
                idCountry: idCountry,
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                NumSLA:kendo.toString(v.NumSLA,"n0"),
                DetailsDonut : v.DetailsDonut,
                Legal: [],
                TotalDonut: v.TotalDonut,
            };
            for(var i in v.DetailsLegal){
                data.Legal.push({
                    keyID:index+"-"+i,
                      Country : v.Country,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    NumSLA:kendo.toString(v.DetailsLegal[i].NumSLA,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal
                });
            }
            receivers.push(data);
        });
        
        dataSupplier = dig.sortData(res.Supplier)
        $.each(dataSupplier, function(index,v){
            var data ={
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                NumSLA:kendo.toString(v.NumSLA,"n0"),
                DetailsDonut : v.DetailsDonut,
                Legal: [],
                TotalDonut: v.TotalDonut,
            };
            for(var i in v.DetailsLegal){
                data.Legal.push({
                    keyID:index+"-"+i,
                      Country : v.Country,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    NumSLA:kendo.toString(v.DetailsLegal[i].NumSLA,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,

                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal
                });
            }
            suppliers.push(data);
        });

        dig.supplierReceiverSummary(receivers);
        dig.supplierSupplierSummary(suppliers);
        
         var color=["#00506D","#0077A3","#50D0FF"];
        $.each(receivers, function(i,v){
            var dataReceiver = []
            $.each(v.DetailsDonut, function(index,value){
                dataReceiver.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                $("#legend-dig_supreceiver_"+i+" ul").append("<li><a onClick='dig.configSeries("+i+","+index+",\"dig_supreceiver\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-dig_supreceiver-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-dig_supreceiver-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })

            receiverClick = function(e){

                switch(e.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                }
                var payload = {
                    Business : dig.supplierCategory(),
                    Productfunction : dig.supplierProduct(),
                    Country : v.Country,
                    FilterCountry : dig.supplierCountry(),
                    FilterLegal : dig.supplierLegalEntity(),
                    Flag : "receiver",
                    LegalEntity : [],
                    Parentprocessname: dig.supplierLevelProcess(),
                    Processname : dig.supplierLevel2Process(),
                    Posisi: "supplierview",
                    Tab : "intra",
                    Type: dataItem,
                }; 
                dig.popUpDonutSupplier(payload)
            }

            var configDonut = ko.mapping.toJS(dig.configDonut);
            configDonut.series[0].data = dataReceiver;
            configDonut.seriesClick = receiverClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
            
            $("#dig_supreceiver_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                 var dateLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dateLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    
                    switch(data.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0; 

                    $("#legend-dig_supreceiver-entity_"+value.keyID+" ul").append("<li><a onClick='dig.configSeries(\""+value.keyID+"\","+number+",\"dig_supreceiver-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-dig_supreceiver-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-dig_supreceiver-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                receiverEntityClick = function(e){
                    var legalEntity  = value.CountryLegal;
                    var Country  = v.Country;
                    // var legalEntity  = value.CountryLegal.split("~")[0];
                    // legalEntity = legalEntity.trim()
                    // var Country  = value.CountryLegal.split("~")[1];
                    // Country = Country.trim()

                    switch(e.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    }
                    var payload = {
                        Business : dig.supplierCategory(),
                        Productfunction : dig.supplierProduct(),
                        Country : Country,
                        FilterCountry : dig.supplierCountry(),
                        FilterLegal : dig.supplierLegalEntity(),
                        Flag : "receiver",
                        LegalEntity : [legalEntity],
                        Parentprocessname: dig.supplierLevelProcess(),
                        Processname : dig.supplierLevel2Process(),
                        Posisi: "supplierview",
                        Tab : "intra",
                        Type: dataItem,
                    };
                     dig.popUpDonutSupplier(payload)
                }
                var configDetailsDonut = ko.mapping.toJS(dig.configDonut);
                configDetailsDonut.series[0].data = dateLegal;
                configDetailsDonut.seriesClick = receiverEntityClick;
                configDetailsDonut.legend.labels.template ="#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
                $("#dig_supreceiver-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        });

        $.each(suppliers, function(i,v){
            var dataSuplier = []
            $.each(v.DetailsDonut, function(index,value){
                dataSuplier.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                    
                $("#legend-dig_supsupplier_"+i+" ul").append("<li><a onClick='dig.configSeries("+i+","+index+",\"dig_supsupplier\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-dig_supsupplier-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-dig_supsupplier-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
            supplierClick = function(e){

                switch(e.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                }
                var payload = {
                    Business : dig.supplierCategory(),
                    Productfunction : dig.supplierProduct(),
                    Country : v.Country,
                    FilterCountry : dig.supplierCountry(),
                    FilterLegal : dig.supplierLegalEntity(),
                    Flag : "supplier",
                    LegalEntity : [],
                    Parentprocessname: dig.supplierLevelProcess(),
                    Processname : dig.supplierLevel2Process(),
                    Posisi: "supplierview",
                    Tab : "intra",
                    Type: dataItem,
                }; 
              dig.popUpDonutSupplier(payload)
            }
            var configDonut = ko.mapping.toJS(dig.configDonut);
            configDonut.series[0].data = dataSuplier;
             configDonut.seriesClick = supplierClick;
             configDonut.legend.labels.template ="#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
            $("#dig_supsupplier_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dateLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dateLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    
                    switch(data.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0; 

                    $("#legend-dig_supsupplier-entity_"+value.keyID+" ul").append("<li><a onClick='dig.configSeries(\""+value.keyID+"\","+number+",\"dig_supsupplier-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-dig_supsupplier-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-dig_supsupplier-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                supplierEntityClick = function(e){
            
                     var legalEntity  = value.CountryLegal.split("~")[0];
                    legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    Country = Country.trim()
                    switch(e.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    }
                    var payload = {
                        Business : dig.supplierCategory(),
                        Productfunction : dig.supplierProduct(),
                        Country : Country,
                        FilterCountry : dig.supplierCountry(),
                        FilterLegal : dig.supplierLegalEntity(),
                        Flag : "supplier",
                        LegalEntity : [legalEntity],
                        Parentprocessname: dig.supplierLevelProcess(),
                        Processname : dig.supplierLevel2Process(),
                        Posisi: "supplierview",
                        Tab : "intra",
                        Type: dataItem,
                    };
                     dig.popUpDonutSupplier(payload)
                    
                    
                } 
                var configDetailsDonut = ko.mapping.toJS(dig.configDonut);
                configDetailsDonut.seriesClick = supplierEntityClick;
                configDetailsDonut.series[0].data = dateLegal;
                configDetailsDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
             
                $("#dig_supsupplier-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        });
    }); 
    // ajaxPost("/receiverview/summarysupplierintragroup",payload, function (res){
        
       
        

    //     $.each(suppliers, function(i,v){
    //         var configDonut = ko.mapping.toJS(dig.configDonut);
    //         configDonut.series[0].data = v.DetailsDonut;
    //         configDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA' # #}else{# #: 'Non-compliant SLA' # #}#",
            
    //         $("#dig_supsupplier_"+i).kendoChart(configDonut)
    //         $.each(v.Legal,function(index,value){
    //             var configDetailsDonut = ko.mapping.toJS(dig.configDonut);
    //             configDetailsDonut.series[0].data = value.DetailsDonut;
    //             configDetailsDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA' # #}else{# #: 'Non-compliant SLA' # #}#",
    //             $("#dig_supsupplier-entity_"+value.keyID).kendoChart(configDetailsDonut)
    //         })
    //     })
    // }); 
}

dig.receivingGetData =  function(){

    if(dig.receivingCountry() == ''){
         var payload={
            Business :  dig.receivingCategory(),
            Productfunction : dig.receivingProduct(),
            LegalEntity : dig.receivingLegalEntity(),
            Parentprocessname : dig.receivingLevelProcess(),
            Processname : dig.receivingLevel2Process(),
            Flag: "IGS"
        }
        var url = "/receiverview/getdefaultreceiver";
        dig.loadingMap.receiver(true);
        ajaxPost(url, payload, function (res){
            dig.loadingMap.receiver(false);
            dig.receivingMap(res)
        });
        dig.showLegendLineReceiver(false)
    }else{
       
        var payload={
            Business :  dig.receivingCategory(),
            Productfunction : dig.receivingProduct(),
            ReceivingCountry :  dig.receivingCountry(),
            Parentprocessname : dig.receivingLevelProcess(),
            Processname : dig.receivingLevel2Process(),
            LegalEntity : dig.receivingLegalEntity(),
        }
       
        var url = "/receiverview/getdetailsreceiver";
        dig.loadingMap.receiver(true);
        ajaxPost(url, payload, function (res){
            dig.loadingMap.receiver(false);
            dig.receivingMapDetails(res)
        });
        dig.showLegendLineReceiver(true)
    }
    var payload = {
        ReceivingCountry :  dig.receivingCountry(),
        LegalEntity : dig.receivingLegalEntity(),
        Business : dig.receivingCategory(),
        Productfunction : dig.receivingProduct(),
        Parentprocessname : dig.receivingLevelProcess(),
        Processname : dig.receivingLevel2Process(),
        Flag: "Receiver",
    }
    dig.receivingCreateSummary(payload)
    localStorage.setItem('filter', JSON.stringify(payload));
};

dig.suppliergGetData =  function(){
    if(dig.supplierCountry() == ''){
        var payload={
            Business :  dig.supplierCategory(),
            Productfunction : dig.supplierProduct(),
            Flag: "IGS",
            Parentprocessname : dig.supplierLevelProcess(),
            Processname : dig.supplierLevel2Process(),
            LegalEntity : dig.supplierLegalEntity()
        }
        var url = "/supplierview/getdefaultsupplier";
        dig.loadingMap.supplier(true);
        ajaxPost(url, payload, function (res){
            dig.loadingMap.supplier(false);
            dig.supplierMap(res)
        });
        dig.showLegendLineSupplier(false);
    }else{
        var payload={
            Business :  dig.supplierCategory(),
            Productfunction : dig.supplierProduct(),
            ReceivingCountry :  dig.supplierCountry(),
            Parentprocessname : dig.supplierLevelProcess(),
            Processname : dig.supplierLevel2Process(),
            LegalEntity : dig.supplierLegalEntity(),
        }
       
        var url = "/supplierview/getdetailssupplier"; 
        dig.loadingMap.supplier(true);
        ajaxPost(url, payload, function (res){
            dig.loadingMap.supplier(false);
            dig.supplierMapDetails(res)
        });
        dig.showLegendLineSupplier(true);
    }
    var payload ={
        ReceivingCountry :  dig.supplierCountry(),
        LegalEntity : dig.supplierLegalEntity(),
        Business : dig.supplierCategory(),
        Productfunction : dig.supplierProduct(),
        Parentprocessname : dig.supplierLevelProcess(),
        Processname : dig.supplierLevel2Process(),
        Flag: "Supplier",
    } 
    dig.supplierCreateSummary(payload)
    localStorage.setItem('filter', JSON.stringify(payload));
};

dig.getReceivingCountry = function(){
    var payload = {
        LegalEntity : dig.receivingLegalEntity(),
        Business :  dig.receivingCategory(),
        Productfunction : dig.receivingProduct(),
        Parentprocessname : dig.receivingLevelProcess(),
        Processname : dig.receivingLevel2Process(),
        Flag : 'intragroup',
    };
    var url = "/receiverview/getreceivercountry";
    ajaxPost(url,payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        dig.receivingCountryList(receivingCountries);
    });
};

dig.getSupplierCountry = function(){
    var payload = {
        LegalEntity : dig.supplierLegalEntity(),
        Business :  dig.supplierCategory(),
        Productfunction : dig.supplierProduct(),
        Parentprocessname : dig.supplierLevelProcess(),
        Processname : dig.supplierLevel2Process(),
        Flag : 'intragroup',
    };
    var url = "/supplierview/getsuppliercountry";
    ajaxPost(url,payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        dig.supplierCountryList(receivingCountries);
    });
};

dig.getReceivingLegalEntity = function(){
    var payload = {
        ReceivingCountry : dig.receivingCountry(),
        Business :  dig.receivingCategory(),
        Productfunction : dig.receivingProduct(),
        Parentprocessname : dig.receivingLevelProcess(),
        Processname : dig.receivingLevel2Process(),
        Flag : 'intragroup',

    };
    var url = "/receiverview/getlegalentityreceiverintra";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        
        dig.receivingLegalEntityList(legalEntities) 
    });
};

dig.getSupplierLegalEntity = function(){
    var payload = {
        ReceivingCountry : dig.supplierCountry(),
        Business :  dig.supplierCategory(),
        Productfunction : dig.supplierProduct(),
        Parentprocessname : dig.supplierLevelProcess(),
        Processname : dig.supplierLevel2Process(),
        Flag : 'intragroup',
    };
    var url = "/supplierview/getlegalentitysupplierintra";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        dig.supplierLegalEntityList(legalEntities) 
    });
};

dig.getReceivingCategory = function(){
    var payload = {
        ReceivingCountry : dig.receivingCountry(),
        LegalEntity : dig.receivingLegalEntity(),
        Productfunction : dig.receivingProduct(),
        Parentprocessname : dig.receivingLevelProcess(),
        Processname : dig.receivingLevel2Process(),
        Flag : 'intragroup',
    };
    var url = "/receiverview/getcategoryintra";
    ajaxPost(url,payload, function (res){
        var receivingCategory = [];
        $.each(res, function(i,v){
            receivingCategory.push({text:v._id, value:v._id})
        });
        dig.receivingCategoryList(receivingCategory);
    });
};

dig.getSupplierCategory = function(){
    var payload = {
        ReceivingCountry : dig.supplierCountry(),
        LegalEntity : dig.supplierLegalEntity(),
        Productfunction : dig.supplierProduct(),
        Parentprocessname : dig.supplierLevelProcess(),
        Processname : dig.supplierLevel2Process(),
        Flag : 'intragroup',

    };
    var url = "/supplierview/getcategoryintra";
    ajaxPost(url,payload, function (res){
        var supplierCategory = [];
        $.each(res, function(i,v){
            supplierCategory.push({text:v._id, value:v._id})
        });
        dig.supplierCategoryList(supplierCategory);
    });
};

dig.getReceivingProduct = function(){
    var payload = {
        ReceivingCountry : dig.receivingCountry(),
        LegalEntity : dig.receivingLegalEntity(),
        Business : dig.receivingCategory(),
        Parentprocessname : dig.receivingLevelProcess(),
        Processname : dig.receivingLevel2Process(),
        Flag : 'intragroup',
    };
    var url = "/receiverview/getproductfunction";
    ajaxPost(url,payload, function (res){
        var receivingProduct = [];
        $.each(res, function(i,v){
            receivingProduct.push({text:v._id, value:v._id})
        });
        dig.receivingProductList(receivingProduct);
    });
};

dig.getSupplierProduct = function(){
    var payload = {
        ReceivingCountry : dig.supplierCountry(),
        LegalEntity : dig.supplierLegalEntity(),
        Business : dig.supplierCategory(),
        Parentprocessname : dig.supplierLevelProcess(),
        Processname : dig.supplierLevel2Process(),
        Flag : 'intragroup',

    };
    var url = "/supplierview/getproductfunction";
    ajaxPost(url,payload, function (res){
        var supplierProduct = [];
        $.each(res, function(i,v){
            supplierProduct.push({text:v._id, value:v._id})
        });
        dig.supplierProductList(supplierProduct);
    });
};

dig.getReceivingLevelProcess = function(){
    var payload = {
        ReceivingCountry :  dig.receivingCountry(),
        LegalEntity : dig.receivingLegalEntity(),
        Business : dig.receivingCategory(),
        Productfunction : dig.receivingProduct(),
        Processname : dig.receivingLevel2Process(),
        Flag : 'intragroup',
    };

    var url = "/receiverview/getparentprocessintra";
    ajaxPost(url,payload, function (res){
        var levelProcess = [];
        $.each(res, function(i,v){
            levelProcess.push({text:v._id, value:v._id})
        });
        dig.receivingLevelProcessList(levelProcess);
    });
};
dig.getSupplierLevelProcess = function(){
    var payload = {
        ReceivingCountry :  dig.supplierCountry(),
        LegalEntity : dig.supplierLegalEntity(),
        Business : dig.supplierCategory(),
        Productfunction : dig.supplierProduct(),
        Processname : dig.supplierLevel2Process(),
        Flag : 'intragroup',
    };

    var url = "/supplierview/getparentprocessintra";
    ajaxPost(url,payload, function (res){
        var levelProcess = [];
        $.each(res, function(i,v){
            levelProcess.push({text:v._id, value:v._id})
        });
        dig.supplierLevelProcessList(levelProcess);
    });
};

dig.getReceivingLevel2Process = function(){
    var payload = {
        ReceivingCountry :  dig.receivingCountry(),
        LegalEntity : dig.receivingLegalEntity(),
        Business : dig.receivingCategory(),
        Productfunction : dig.receivingProduct(),
        Parentprocessname : dig.receivingLevelProcess(),
        Flag : 'intragroup',
    };

    var url = "/receiverview/getprocessname";
    ajaxPost(url,payload, function (res){
        var level2Process = [];
        $.each(res, function(i,v){
            level2Process.push({text:v._id, value:v._id})
        });
        dig.receivingLevel2ProcessList(level2Process);
    });
};
dig.getSupplierLevel2Process = function(){
    var payload = {
        ReceivingCountry :  dig.supplierCountry(),
        LegalEntity : dig.supplierLegalEntity(),
        Productfunction : dig.supplierProduct(),
        Business : dig.supplierCategory(),
        Parentprocessname : dig.supplierLevelProcess(),
        Flag : 'intragroup',
    };

    var url = "/supplierview/getprocessname";
    ajaxPost(url,payload, function (res){
        var level2Process = [];
        $.each(res, function(i,v){
            level2Process.push({text:v._id, value:v._id})
        });
        dig.supplierLevel2ProcessList(level2Process);
    });
};

dig.receivingCountry.subscribe(function(newValue){
    dig.onchangeReceivingCountry(false)

    if (dig.receivingCountry() == '') {
        dig.receivingLegalEntity([]);
        dig.receivingCategory([]);
    };
    
    dig.getReceivingLegalEntity();
    dig.getReceivingCategory();
    dig.getReceivingProduct();
    dig.receivingGetData();
    dig.getReceivingLevelProcess();
    dig.getReceivingLevel2Process();

    dashboard.createNewCookie({receiverCountry:dig.receivingCountry()}); 
    CNUtimeout = setTimeout(function(){
        dig.onchangeReceivingCountry(true) 
    },1000);
});

dig.supplierCountry.subscribe(function(newValue){
    dig.onchangeSupplierCountry(false)
    
    if (dig.supplierCountry() == '') {
        dig.supplierLegalEntity([]);
        dig.supplierCategory([]);
    };

    dig.getSupplierLegalEntity();
    dig.getSupplierCategory();
    dig.getSupplierProduct();
    dig.suppliergGetData();
    dig.getSupplierLevelProcess();
    dig.getSupplierLevel2Process();

    dashboard.createNewCookie({supplierCountry:dig.supplierCountry()});
    CNUtimeout = setTimeout(function(){ 
        dig.onchangeSupplierCountry(true)
    },1000);
});

dig.receivingLegalEntity.subscribe(function(newValue){
    if(dig.onchangeReceivingCountry() === true){
        dashboard.createNewCookie({receiverCountry:dig.receivingCountry(),receiverLegalEntity:newValue.toString()}); 
        dig.receivingGetData();
    }
    dig.getReceivingCountry();
    dig.getReceivingCategory();
    dig.getReceivingProduct();
    dig.getReceivingLevelProcess();
    dig.getReceivingLevel2Process();
});

dig.supplierLegalEntity.subscribe(function(newValue){
    if(dig.onchangeSupplierCountry() === true){
        dashboard.createNewCookie({supplierCountry:dig.supplierCountry(),supplierLegalentity:newValue.toString()}); 
        dig.suppliergGetData();
    }
    dig.getSupplierCountry();
    dig.getSupplierCategory();
    dig.getSupplierProduct();
    dig.getSupplierLevelProcess();
    dig.getSupplierLevel2Process();
});

dig.receivingCategory.subscribe(function(newValue){
    if(dig.onchangeReceivingCountry() === true){
        dig.receivingGetData();
    }
    dig.getReceivingCountry();
    dig.getReceivingLegalEntity();
    dig.getReceivingProduct();
    dig.getReceivingLevelProcess();
    dig.getReceivingLevel2Process();
});

dig.supplierCategory.subscribe(function(newValue){
    if(dig.onchangeSupplierCountry() === true){
        dig.suppliergGetData();
    }
    dig.getSupplierCountry();
    dig.getSupplierLegalEntity();
    dig.getSupplierProduct();
    dig.getSupplierLevelProcess();
    dig.getSupplierLevel2Process();
});

dig.receivingProduct.subscribe(function(newValue){
    if(dig.onchangeReceivingCountry() === true){
        dig.receivingGetData();
    }
    dig.getReceivingCountry();
    dig.getReceivingLegalEntity();
    dig.getReceivingCategory();
    dig.getReceivingLevelProcess();
    dig.getReceivingLevel2Process();
});

dig.supplierProduct.subscribe(function(newValue){
    if(dig.onchangeSupplierCountry() === true){
        dig.suppliergGetData();
    }
    dig.getSupplierCountry();
    dig.getSupplierLegalEntity();
    dig.getSupplierCategory();
    dig.getSupplierLevelProcess();
    dig.getSupplierLevel2Process();
});

dig.receivingLevelProcess.subscribe(function(newValue){
    if(dig.onchangeReceivingCountry() === true){
        dig.receivingGetData();
    }
    dig.getReceivingCountry();
    dig.getReceivingLegalEntity();
    dig.getReceivingCategory();
    dig.getReceivingProduct();
    dig.getReceivingLevel2Process();
});

dig.supplierLevelProcess.subscribe(function(newValue){
    if(dig.onchangeReceivingCountry() === true){
        dig.suppliergGetData();
    }
    dig.getSupplierCountry();
    dig.getSupplierLegalEntity();
    dig.getSupplierCategory();
    dig.getSupplierProduct();
    dig.getSupplierLevel2Process();
});

dig.receivingLevel2Process.subscribe(function(newValue){
    if(dig.onchangeReceivingCountry() === true){
        dig.receivingGetData();
    }
    dig.getReceivingCountry();
    dig.getReceivingLegalEntity();
    dig.getReceivingCategory();
    dig.getReceivingProduct();
    dig.getReceivingLevelProcess();
});

dig.supplierLevel2Process.subscribe(function(newValue){
    if(dig.onchangeReceivingCountry() === true){
        dig.suppliergGetData();
    }
    dig.getSupplierCountry();
    dig.getSupplierLegalEntity();
    dig.getSupplierCategory();
    dig.getSupplierProduct();
    dig.getSupplierLevelProcess();
});


dig.expand = function(type,index){
    return function(){
      var classUp = 'glyphicon-chevron-up'
      var classDown = 'glyphicon-chevron-down'
       $("#"+type+"-legal_"+index).slideToggle( "slow", function() {
            $("#"+type+"-expand-"+index).hasClass(classDown) ? $("#"+type+"-expand-"+index).addClass(classUp).removeClass(classDown): $("#"+type+"-expand-"+index).addClass(classDown).removeClass(classUp);
       });
    }
}

dig.expandSupplier = function(type,index){
    return function(){
      var classUp = 'glyphicon-chevron-up'
      var classDown = 'glyphicon-chevron-down'
        $("#"+type+"-legalsup_"+index).slideToggle( "slow", function() {
            $("#"+type+"-expandsup-"+index).hasClass(classDown) ? $("#"+type+"-expandsup-"+index).addClass(classUp).removeClass(classDown): $("#"+type+"-expandsup-"+index).addClass(classDown).removeClass(classUp);
        });
    }
}

dig.init = function(){ //initReceiving
    localStorage.setItem('tab', 'intra-group');
    localStorage.setItem('subTab', 'dig-receiver');
    dig.getReceivingCountry();
    dig.getReceivingLegalEntity();
    dig.getReceivingCategory();
    dig.getReceivingProduct();
    dig.getReceivingLevelProcess();
    dig.getReceivingLevel2Process();
    dig.receivingGetData();
}
dig.initSupplier = function(){
    localStorage.setItem('tab', 'intra-group');
    localStorage.setItem('subTab', 'dig-supplier');
    if(dig.clickSupplierIndex === 0){
        dig.getSupplierCountry();
        dig.getSupplierLegalEntity();
        dig.getSupplierCategory();
        dig.getSupplierProduct();
        dig.getSupplierLevelProcess();
        dig.getSupplierLevel2Process();
        dig.suppliergGetData(); 
        dig.clickSupplierIndex += 1;
    }else{
        dig.supplierPrepareMap();
        dig.suppliergGetData(); 
    }
}

dig.setSubtab = function(){
    localStorage.setItem('subTab', 'dig-receiver');
    dig.receivingPrepareMap();
    dig.receivingGetData();
}