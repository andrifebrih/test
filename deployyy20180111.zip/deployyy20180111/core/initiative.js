var initiative = {};
initiative.colorTemplate = ["000F46", "005C84", "0075B2", "334279", "3F9C35", "69BE28", "939598", "D48200", "72CF68"];

// initiative.visible = ko.observable(true);
initiative.index = ko.observableArray([])
initiative.column = ko.observableArray([])
initiative.rowMax = ko.observable(0);
initiative.category = ko.observableArray([])
initiative.alldata = ko.observableArray([])
initiative.matrix = ko.observableArray([])
initiative.toggle = ko.observable(false)
initiative.activeCategoryName = "";
// initiative.payload = {
//     Receivercountry : ko.observableArray([]),
//     Suppliercountry : ko.observableArray([]),
//     Receiverlegal : ko.observableArray([]),
//     Supplierlegal : ko.observableArray([]),
//     Classification : ko.observableArray([]),
// }
initiative.filter = {
    receivingCountry : ko.observable(''),
    receivingCountryList : ko.observableArray([]),
    receivingLegalEntity : ko.observableArray([]),
    receivingLegalEntityList : ko.observableArray([]),
    supplyCountry : ko.observable(''),
    supplyCountryList : ko.observableArray([]),
    supplyLegalEntity : ko.observableArray([]),
    supplyLegalEntityList : ko.observableArray([]),
    classification : ko.observableArray([]),
    classificationList : ko.observableArray([]),
    categoryName: ko.observableArray([]),
    productFunction: ko.observableArray([]),
    fmiCategoryName: ko.observableArray([]),
}

initiative.ReceiverCountry = function(){
    var payload ={
        Receiverlegalentity : initiative.filter.receivingLegalEntity(),
        Suppliercountry : initiative.filter.supplyCountry(),
        Supplierlegalentity : initiative.filter.supplyLegalEntity(),
        Classification : initiative.filter.classification(),
    }
    ajaxPost("/initiative/filterreceivercountry", payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        initiative.filter.receivingCountryList(receivingCountries);
    })
}

initiative.ReceiverLegalEntity = function(){
    var payload ={
        Receivercountry : initiative.filter.receivingCountry(),
        Suppliercountry : initiative.filter.supplyCountry(),
        Supplierlegalentity : initiative.filter.supplyLegalEntity(),
        Classification : initiative.filter.classification(),
    }
    ajaxPost("/initiative/filterreceiverlegal", payload, function (res){
        var receivingLegals = [];
        $.each(res, function(i,v){
            receivingLegals.push({text:v._id, value:v._id})
        });
        initiative.filter.receivingLegalEntityList(receivingLegals);
    })
}

initiative.SupplierCountry = function(){
    var payload ={
        Receivercountry : initiative.filter.receivingCountry(),
        Receiverlegalentity : initiative.filter.receivingLegalEntity(),
        Supplierlegalentity : initiative.filter.supplyLegalEntity(),
        Classification : initiative.filter.classification(),
    }
    ajaxPost("/initiative/filtersuppliercountry", payload, function (res){
        var supplyCountries = [];
        $.each(res, function(i,v){
            supplyCountries.push({text:v._id, value:v._id})
        });
        initiative.filter.supplyCountryList(supplyCountries);
    })
}

initiative.SupplierLegalEntity = function(){
    var payload ={
        Receivercountry : initiative.filter.receivingCountry(),
        Receiverlegalentity : initiative.filter.receivingLegalEntity(),
        Suppliercountry : initiative.filter.supplyCountry(),
        Classification : initiative.filter.classification(),
    }
    ajaxPost("/initiative/filtersupplierlegal", payload, function (res){
        var supplyLegals = [];
        $.each(res, function(i,v){
            supplyLegals.push({text:v._id, value:v._id})
        });
        initiative.filter.supplyLegalEntityList(supplyLegals);
    })
}

initiative.Classification = function(){
    var payload ={
        Receivercountry : initiative.filter.receivingCountry(),
        Receiverlegalentity : initiative.filter.receivingLegalEntity(),
        Suppliercountry : initiative.filter.supplyCountry(),
        Supplierlegalentity : initiative.filter.supplyLegalEntity(),
    }
    ajaxPost("/initiative/filterclassification", payload, function (res){
        var classifications = [];
        $.each(res, function(i,v){
            classifications.push({text:v._id, value:v._id})
        });
        initiative.filter.classificationList(classifications);
    })
}

initiative.filter.receivingCountry.subscribe(function(newValue) {
    initiative.getData(function(res) {
      initiative.setupCategoryName(res.RowCategory);
    })
    initiative.SupplierCountry()
    initiative.ReceiverLegalEntity()
    initiative.SupplierLegalEntity()
    initiative.Classification()
})

initiative.filter.receivingLegalEntity.subscribe(function(newValue) {
    initiative.getData(function(res) {
      initiative.setupCategoryName(res.RowCategory);
    })
    initiative.ReceiverCountry()
    initiative.SupplierLegalEntity()
    initiative.SupplierCountry()
    initiative.Classification()
})

initiative.filter.supplyCountry.subscribe(function(newValue) {
    initiative.getData(function(res) {
      initiative.setupCategoryName(res.RowCategory);
    })
    initiative.ReceiverCountry()
    initiative.ReceiverLegalEntity()
    initiative.SupplierLegalEntity()
    initiative.Classification()
})

initiative.filter.supplyLegalEntity.subscribe(function(newValue) {
    initiative.getData(function(res) {
      initiative.setupCategoryName(res.RowCategory);
    })
    initiative.ReceiverCountry()
    initiative.ReceiverLegalEntity()
    initiative.SupplierCountry()
    initiative.Classification()
})

initiative.filter.classification.subscribe(function(newValue) {
    initiative.getData(function(res) {
      initiative.setupCategoryName(res.RowCategory);
    })
    initiative.ReceiverCountry()
    initiative.ReceiverLegalEntity()
    initiative.SupplierCountry()
    initiative.SupplierLegalEntity()
})

initiative.setupColumn = function(cols) {
  var columns = []
  _.each(cols, function(o,i) {
      columns.push({value:o, index:i, color: initiative.colorTemplate[i]});
  })
  initiative.column(columns)
}

initiative.setupCategoryName = function(cats) {
  var categories = []
  _.each(cats, function(i, o) {
      var child = []
      _.each(i, function(x){
          child.push({status:ko.observable(true),title: x})
      })
      categories.push({
        parent:o,
        active: ko.observable(false),
        child:child
      })
  })
  initiative.category(categories)
  if(initiative.toggle()) initiative.getHeight()
  else initiative.resetHeight()
}

initiative.getData = function(callback){
    var payload = {
        Receivercountry : initiative.filter.receivingCountry(),
        Receiverlegalentity : initiative.filter.receivingLegalEntity(),
        Suppliercountry : initiative.filter.supplyCountry(),
        Supplierlegalentity : initiative.filter.supplyLegalEntity(),
        Categoryname_: initiative.filter.categoryName(),
        Productfunction: initiative.filter.productFunction(),
        Classification : initiative.filter.classification(),
        FMI_CATEGORY_NAME: initiative.filter.fmiCategoryName(),
        MatrixForm: initiative.toggle(),
    }

    // var activeCat = _.find(initiative.category(), function(o) { return o.active });
    // console.log(activeCat)
    // payload['Categoryname_'] = activeCat.parent;
    // payload['Productfunction'] = [];
    // _.each(activeCat.child, function(c) {
    //   if(c.status) {
    //     payload['Productfunction'].push(c.title);
    //   }
    // })

    ajaxPost("/initiative/getdata", payload, function (res){
      initiative.setupColumn(res.Columns);
      var matrix = [];
      var index = [];
      if (initiative.toggle()) {
          datas = _.groupBy(res.Data, function(o){ return o.FMI_CATEGORY_NAME +'#'+ o.Categoryname_ });
          var columns = res.Columns;
          var category = _.map(res.RowCategory, function(o,i) {
            return i
          });
          for(i = 0; i < category.length; i++) {
            matrix[i] = []
          }
          _.each(category, function(cat, catIdx) {
            _.each(columns, function(col,colIdx) {
              if(datas[col+'#'+cat]){
                matrix[catIdx][colIdx] = {
                  column: col,
                  columIndex: colIdx,
                  category: cat,
                  categoryIndex: catIdx,
                  data: datas[col+'#'+cat]
                }
              } else {
                matrix[catIdx][colIdx] = {}
              }
            })
            index.push(catIdx)
          })
          initiative.index(index)
          console.log(matrix)
      }else{
          var datas = _.groupBy(res.Data, function(o){ return o.FMI_CATEGORY_NAME });
          var max = 0;
          _.each(datas, function(o) {
              if(o.length > max) {
                  max = o.length;
              }
          });

          for(r = 0; r < max; r++) {
              var col = [];
              _.each(res.Columns, function(o) {
                  if(datas[o][r]) {
                      col.push(datas[o][r])
                  } else {
                      col.push({})
                  }
              })
              matrix.push(col);
          }
      }
      initiative.matrix(matrix);
      if(initiative.toggle()) initiative.getHeight()
      else initiative.resetHeight()
      if(typeof callback == "function") callback(res)
    })
}

initiative.clickCheckbox = function(val, title){
    var status = val();
    var productFunction = initiative.filter.productFunction();
    if(status == true) {
      productFunction = _.without(productFunction, title);
    } else {
      productFunction.push(title);
    }
    val(!val());
    initiative.filter.productFunction(productFunction);
    initiative.getData();
}

initiative.resetCategory = function() {
  _.each(initiative.category(), function(c) {
    c.active(false);
    _.each(c.child, function(ch) {
      ch.status(true);
    })
  })
}

initiative.clickCategoryChild = function(thisclass, categories){
    if(initiative.activeCategoryName != categories.parent) {
      initiative.resetCategory();
      categories.active(true);
      initiative.filter.categoryName([categories.parent]);
      initiative.filter.productFunction(_.pluck(categories.child, 'title'));
      initiative.activeCategoryName = categories.parent;
      initiative.getData();
    }
}

initiative.clickToogleButton = function(){
    var currentToggle = initiative.toggle();
    initiative.toggle(!currentToggle)
    initiative.getData()
}

initiative.resetHeight = function() {
  _.each(initiative.category(), function(v,i){
    $(".category-"+i).height("auto");
  })
}

initiative.getHeight = function(){
  if(initiative.activeCategoryName !== "") {
    _.each(initiative.category(), function(v,i){
        if(v.parent == initiative.activeCategoryName) {
          var height = $('[datacategory="'+v.parent+'"]').height()
          var distance =$('.category-'+i).offset().top - $('.category-0').offset().top;
          console.log(distance)
          $('[datacategory="'+v.parent+'"]').css("padding-top", distance+"px")
          $('.category-'+i).height(height)
        } else {
          $('.category-'+i).height("auto")
        }
    })
  } else {
    _.each(initiative.category(), function(v,i){
        var height = $('.data-'+i).height()
        $('.category-'+i).height(height)
    })
  }
}

initiative.clearFilter = function() {
  initiative.activeCategoryName = "";
  initiative.resetCategory();
  initiative.resetHeight();
  initiative.filter.categoryName([]);
  initiative.filter.productFunction([]);
  initiative.getData();
}

$(function(){
    initiative.getData(function(res) {
      initiative.setupCategoryName(res.RowCategory);
    });
    initiative.ReceiverCountry()
    initiative.ReceiverLegalEntity()
    initiative.SupplierCountry()
    initiative.SupplierLegalEntity()
    initiative.Classification()
});
