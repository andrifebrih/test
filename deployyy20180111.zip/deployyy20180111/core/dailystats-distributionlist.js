var wg = {};
wg.listEmail = ko.observableArray([])
wg.emailValue = ko.observable({mailsubject:"[OCIR Reporting]", mailmsg:"", mailto:[], mailcc:[]});

wg.CreateTokenInputEmail = function(){
  $("#emailTo").tokenInput([], { 
    zindex: 700,
    noResultsText: "Add New Email",
    allowFreeTagging: true,
    placeholder: 'Type Email Here',
    tokenValue: 'id',
    propertyToSearch: 'key',
    theme: "facebook",
    onAdd: function (item) {
      if (validateEmailFormat(item.key)){
        wg.emailTo.push(item);  
        $("#alertMessage1").hide();
      }else {
        $("#alertMessage1").text(item.key+" is not valid email !");
        $("#alertMessage1").show()
        this.tokenInput("remove", {id: item.key});
        setTimeout(function() {
          $("#alertMessage1").hide();
        }, 5000);
      }
    },
    onDelete: function (item) {
      wg.emailTo.remove(item);  
    }
  });

  $("#emailCc").tokenInput([], { 
    zindex: 700,
    noResultsText: "Add New Email",
    allowFreeTagging: true,
    placeholder: 'Type Email Here',
    tokenValue: 'id',
    propertyToSearch: 'key',
    theme: "facebook",
    onAdd: function (item) {
      if (validateEmailFormat(item.key)){
        wg.emailCc.push(item);  
        $("#alertMessage2").hide();
      }else {
        $("#alertMessage2").text(item.key+" is not valid email !");
        $("#alertMessage2").show()
        this.tokenInput("remove", {id: item.key});
        setTimeout(function() {
          $("#alertMessage2").hide();
        }, 5000);
      }
    },
    onDelete: function (item) {
      wg.emailCc.remove(item);  
    }
  });
}
function changeEmailTo(e){
  wg.emailValue().mailto = e.sender._values
};
function changeEmailCC(e){
  wg.emailValue().mailcc = e.sender._values
};
wg.sendMail =  function(){
   $('#modalEmail').modal('hide'); 
    mailTo = [];
    mailcc = [];
    for(i in  wg.emailValue().mailto){
      for(j in wg.listEmail()){
        if(wg.emailValue().mailto[i] ==  wg.listEmail()[j].fullname){
          if( wg.listEmail()[j].status == 0){
            mailTo.push(wg.listEmail()[j].email)
          }else{
            for(x in  wg.listEmail()[j].member){
              mailTo.push(wg.listEmail()[j].member[x].email)
            }
          }
        }
      }
    }
    for(i in  wg.emailValue().mailcc){
      for(j in wg.listEmail()){
        if(wg.emailValue().mailcc[i] ==  wg.listEmail()[j].fullname){
          if( wg.listEmail()[j].status == 0){
            mailcc.push(wg.listEmail()[j].email)
          }else{
            for(x in  wg.listEmail()[j].member){
              mailcc.push(wg.listEmail()[j].member[x].email)
            }
          }
        }
      }
    } 
 


    if(dailystats.tab() == "country"){
      $sel = $(".content-tab-country");
      $grid = $("#gridcountry");
    }
    else{
      $sel = $(".content-tab-business");
      $grid = $("#gridbussiness");
    }
    
   
    var normalizeSelector =  function(){
      $grid.height("400px");
      $('.k-grid').data('kendoGrid').refresh()
      $sel.find(".section-top").text("");
      $sel.find(".section-bottom").text("");
      $sel.find(".filter").css({"padding":"0px"})
      $sel.find(".grid").css({"padding":"0px"})
    };
    $grid.height("");
    $('.k-grid').data('kendoGrid').refresh()
    $sel.find(".section-top").text("&nbsp;");
    $sel.find(".section-bottom").text("&nbsp;");
    $sel.find(".filter").css({"padding-right":"10px","padding-left":"10px"})
    $sel.find(".grid").css({"padding-right":"10px","padding-left":"10px"})
    kendo.drawing.drawDOM($sel,{
      paperSize: "a3",
      landscape :true, 
    })
    .then(function (group) {
      return kendo.drawing.exportPDF(group);
    })
    .done(function (data) {
 
      var payload = {
        Subject:wg.emailValue().mailsubject,
        Body: wg.emailValue().mailmsg,
        To:mailTo,
        Cc:mailcc, 
        Menu:'dailystatus',
        Attachment : data,
      } 
      $.ajax({
          url: "/live/ociranalysis/sendemailwidget",
          type: 'post',
          data: JSON.stringify(payload),
          dataType: 'json',
          contentType: "application/json; charset=utf-8",
          success:function(res){
            swal(res.Message, "", "success");
          }
      });
      normalizeSelector();
    });
 
}
wg.getEmail =  function(){
  ajaxPost("/widgetanalysis/getlistemail", "", function (res){
    wg.listEmail(res.Data);
    wg.listEmail().push(
                          {_id:"Pss_Head_EMail",email:"Pss_Head_EMail",fullname:"Pss Head",status:0},
                          {_id:"Master_Critical_Person_Email",email:"Master_Critical",fullname:"Master Critical",status:0},
                          {_id:"PFP_Process_Owner_Email",email:"PFP_Process_Owner_Email",fullname:"PFP Process",status:0},
                          {_id:"Team_Sme_email",email:"Team_Sme_email",fullname:"Team Sme",status:0},
                          {_id:"Pss_Manager_Name_email",email:"Pss_Manager_Name_email",fullname:"Pss Manager",status:0},
                          {_id:"Pfp_Critical_Person_Email",email:"Pfp_Critical_Person_Email",fullname:"Pfp Critical",status:0},
                          {_id:"Contract_Manager_Email ",email:"Contract_Manager_Email ",fullname:"Contract Manager",status:0},
                          {_id:"Sla_Manager_Email",email:"Sla_Manager_Email",fullname:"Sla Manager",status:0}
                        );
    wg.listEmail.valueHasMutated();
    $("#emailTo").kendoMultiSelect({
      dataTextField: "fullname",
      dataValueField: "fullname",
 
      footerTemplate: 'Total #: instance.dataSource.total() # items found',
      itemTemplate: '<span class="k-state-default header-text">#: data.fullname #<p class="footer-text">#: data.email #</p></span>',
      tagTemplate:  '<span class="selected-value"></span><span>#:data.fullname#</span>',
      change: changeEmailTo,
      dataSource: {
          data :wg.listEmail()
      },
      height: 200
    });
    $("#emailCC").kendoMultiSelect({
      dataTextField: "email",
      dataValueField: "fullname",
 
      footerTemplate: 'Total #: instance.dataSource.total() # items found',
      itemTemplate: '<span class="k-state-default header-text">#: data.fullname #<p class="footer-text">#: data.email #</p></span>',
      tagTemplate:  '<span class="selected-value"></span><span>#:data.fullname#</span>',
      change: changeEmailCC,
      dataSource: {
          data :wg.listEmail()
      },
      height: 200
    });

     
  })
};








wg.DLinputData = {template:ko.observableArray([]) ,DLName:ko.observable(''),type:ko.observable('Public'),status:ko.observable('Active'),owned:ko.observable(''),remarks:ko.observable(''),members:[]}
wg.DLmemberFilterList = [];
wg.DLinputsearch      = ko.observable('')
wg.DLtype             = ko.observableArray([{ text:"Public"},{ text:"Private"}]);
wg.DLconfDeleteMembers = ko.mapping.fromJS([])
wg.DLdataMembers      = [];
wg.DLdataMembersAll   = [];
wg.DLdataMembersSearch  = [];
wg.DLsearchStatus     = ko.observable(false)

wg.DLtemplate     = ko.observable('');
wg.DLtemplateList = ko.observableArray([])


wg.getDl =  function(){
   $("#grid-distribution-list").html('')
    $("#grid-distribution-list").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              ajaxPost('/distributionlist/getdistributionlist', {}, function(datas){
                option.success(datas);
              })
            },
            parameterMap: function(data) {
              return JSON.stringify(data);
            },
          },
          schema: {
            data: function(data) {
              if (data.Data.length == 0) {
                return [];
              } else { 
                return data.Data;
              }
            },
            total: "Data.length",
          }, 
        }, 
        columns: [
         {
            title: "No",
            template: "#= ++record #",
            width: 20,
            headerAttributes: {
             "class": "align-center header-grid"
            }, attributes: {
              "class": "align-center number"
            }
          }, 
          {
            field:"DLName",
            title:'DL Name',
            width:100, 
            headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
            {
            field:"type",
            title:'Type',
            width:30, 
            headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "align-left" 
            }
          },
          {
            field:"owned",
            title:'Owned By',
            width:75, 
             headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
          {
            field:"lastmodifiedby",
            title:'Last Modified By',
            width:100, 
             headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
          {
            field:"lastmodifiedon",
            title:'Last Modified On',
            width:100, 
            template: "#if(lastmodifiedon != ''){# #:  kendo.toString(new Date(getUTCDate(getUTCDateFull(lastmodifiedon))), 'dd/MM/yy') # #} #",
            attributes: {
              "class": "field-ellipsis align-center"
            }
          },
          {
            field:"noofmembers",
            title:'No. of Members',
            width:60,
            headerAttributes: {
                "class": "align-right"
            },
            attributes: {
                "class": "align-right"
            }
          },
          {
            field:"remarks",
            title:'Remarks',
            width:60,
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "align-left"
            }
          },
          { 
            width:25,
            // filterable: false,
            headerAttributes: {
              "class": "align-center"
            },
            attributes: {
              "class": "align-center"
            },
 
            template: "## <button  class=\"btn btn-sm pull-left btn-primary\" id=\"raady-button\"  onClick='wg.editDL(\"#:DLName #\" )'><span class=\"icon-custome glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button> ##",
          
          }
        ],
        resizable: true,
      
          sortable: true,
          scrollable:{
            virtual: true
          }, 
          pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1, 
            pageSize: 15,
          }, 
          dataBinding: function() {
            record = (this.dataSource.page() -1) * this.dataSource.pageSize();
          }
    });
}

wg.getDlName = function(){
 var payload = {
    Id : dailystats.filters.value.template()
  }
  ajaxPost("/widgetanalysis/getdlname", payload, function (res){
    wg.emailValue().mailto = res.Data
    $("#emailCC").data("kendoMultiSelect").value([]);
    $("#emailTo").data("kendoMultiSelect").value([]);
    $("#emailTo").data("kendoMultiSelect").value(res.Data);
  })
}

wg.DLgridDetails =  function(dataSource){
  
  $("#grid-member").html('')
  $("#grid-member").kendoGrid({
        dataSource: {
          transport: {
                read:function(option){
                  option.success(dataSource); 
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
          },  
          schema: {
            data: function(data) {
              if (data.length == 0) {
                  return [];
              } else {
                  return data; 
              } 
            },
                // total: "Data.Count",
          },
        },  
        columns: [
          {
            field:"fullname",
            title:'Member Name',
            width:100, 
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"loginid",
            title:'PSID',
            width:70, 
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"email",
            title:'email',
            width:100, 
            attributes: {
              "class": "field-ellipsis"
            }
          },
      
          // {
          //   title:'',
          //   width:25,
          //   // filterable: false,
          //   headerAttributes: {
          //    "class": "align-center"
            // },
            // attributes: {
            //   "class": "align-center"
            // },
 
            // template: "## <button  class=\"btn btn-sm pull-left btn-primary\" id=\"raady-button\"  onClick='dl.edit(\"#:DLName #\" )'>Edit</button> ##",
            // template: "## <button  class=\"btn btn-sm pull-left btn-cancel \" id=\"raady-button\"  onClick='deleteRowDetails(\"#:_id #\",\"#:fullname #\",\"#:email #\" )'><span class=\"small-icon-custome glyphicon glyphicon-remove\" aria-hidden=\"true\"></button> ##",
           
          
          // }
        ],
        sortable: true,
         resizable: true,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                      display: "Showing {2} data items"
                  }
              }, 
  });
}

wg.DLsave =  function(){
  payload = {}
  var templates = []
  for(i in wg.DLinputData.template()){
    templates.push({templateName:wg.DLinputData.template()[i]})
  } 
  payload.templates = templates
  payload.DLName    = wg.DLinputData.DLName()
  payload.type      = wg.DLinputData.type()
  payload.remarks   = wg.DLinputData.remarks()
  payload.status    = wg.DLinputData.status()
  payload.members   = wg.DLdataMembers  

  ajaxPost("/distributionlist/savedistributionlist", payload, function (res){
     if(res.IsError){
        return swal("Confirmation!", res.Message, "error");
     }else{ 
        $('#grid-distribution-list').data('kendoGrid').dataSource.read({});
    
        return swal({
              title: "Confirmation!",
              text: res.Message,
              type: "success", 
            },
            function(isConfirm){
              $('#modalDL').modal('show');
              $('#addDL').modal('hide');
              
          });  
     }  
  })
}

wg.editDL =  function(dlName){
  ajaxPost("/distributionlist/getmembernameedit", {id:dlName}, function (res){
    wg.DLdataMembersAll = res.Data;
   
  })
  ajaxPost("/distributionlist/editdistributionlist",{id:dlName}, function (res){
    template = []
    for(i in res.Data.templates){
     
      template.push(res.Data.templates[i].templateName)
    }
 
    wg.DLinputData.template(template) 
    wg.DLinputData.DLName( res.Data.DLName) 
    wg.DLinputData.remarks(res.Data.remarks)  
    wg.DLinputData.type(res.Data.type)  
    wg.DLinputData.status(res.Data.status)  
    wg.DLdataMembers = res.Data.members 

    ko.mapping.fromJS(wg.DLdataMembers, wg.DLconfDeleteMembers)
    wg.DLgridDetails(wg.DLdataMembers)
    wg.inputsearch('')

  $('#modalDL').modal('hide');
    $('#addDL').modal('show');
      
    $("#grid-data-members").html('')
    
  });
}
wg.DLgetMemberList =  function(){
  memberName = [];
  for(i in dl.memberNameList ){
    memberName.push(dl.memberNameList[i].fullname)
  }
  dl.DLmemberFilterList = memberName;
}
wg.DLgetMember =  function(){
  ajaxPost("/distributionlist/getmembername", "", function (res){
      wg.DLdataMembersAll = res.Data
  })
}
wg.addDL = function(){ 
  wg.DLinputData.DLName('')
  wg.DLinputData.type('Public')
  wg.DLinputData.remarks('')
  wg.DLinputData.status('Active')   
  wg.DLdataMembers = [] 
  wg.DLgridDetails([]) 
  wg.DLinputsearch('')
  wg.DLgetMember()
  wg.DLgetOwned()
  ko.mapping.fromJS([], wg.DLconfDeleteMembers)
  $("#grid-member").html('')
  $("#grid-data-members").html('')
  
  $("#inputsearch").kendoAutoComplete({
    dataSource:   wg.DLmemberFilterList,
    filter: "contains",
    placeholder: "Search",
  });

  $('#modalDL').modal('hide');
    $('#addDL').modal('show');


}
function dlAddByemail(){
  wg.DLaddMember(wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch(),wg.DLinputsearch());
}
function emailvalidate(value){
  var email = value.toLowerCase()
  var re = /^[a-z][a-zA-Z0-9_.]*(\.[a-zA-Z][a-zA-Z0-9_.]*)?@sc\.com?$/;
  if(re.test(email))
    $("#dlAddByemail").show('fast')
  else 
    $("#dlAddByemail").hide('fast')
}
wg.DLgetOwned =  function(){
  ajaxPost("/distributionlist/getowned", "", function (res){
    wg.DLinputData.owned(res.Data[0].fullname)
  })
}
wg.DLaddMember =  function(id,fullname,email,loginid){
  wg.DLdataMembers.push({_id:id,fullname:fullname,email:email,loginid:loginid})
  for(var i in wg.DLdataMembersAll){
    if( wg.DLdataMembersAll[i]._id == id){
      wg.DLdataMembersAll.splice(i,1)
    }
  }
  for(var i in wg.DLdataMembersSearch){
    if( wg.DLdataMembersSearch[i]._id == id){
      wg.DLdataMembersSearch.splice(i,1)
    }
  }
  if(wg.DLsearchStatus()){
    wg.DLgridDataMembers(wg.DLdataMembersSearch)
  }

  ko.mapping.fromJS(wg.DLdataMembers, wg.DLconfDeleteMembers)
  wg.DLgridDetails(wg.DLdataMembers)
}
wg.DLgridDataMembers = function(dataSource){
 
  $("#grid-data-members").html('')
  $("#grid-data-members").kendoGrid({
        dataSource: {
          transport: {
                read:function(option){
                  option.success(dataSource); 
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
          },  
          schema: {
            data: function(data) {
              if (data.length == 0) {
                  return [];
              } else {
                  return data; 
              } 
            },
                // total: "Data.Count",
          },
        },  
        columns: [

          {
            title:'',
            width:17,
            headerAttributes: {
              "class": "align-center"
            },
            attributes: {
              "class": "align-center add"
            },
 
            
            template: "## <button  class=\"btn btn-sm pull-left btn-add-member   \" id=\"raady-button\"   onClick='wg.DLaddMember(\"#:_id #\",\"#:fullname #\",\"#:email #\",\"#:loginid #\")' >Add</button> ##",
           
 
          },
          {
            field:"fullname",
            title:'Member Name',
            width:100, 
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"loginid",
            title:'PSID',
            width:70, 
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"email",
            title:'Email',
            width:100, 
             headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
       
        
        ],
        resizable: true,
        sortable: true,
 
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                      display: "Showing {2} data items"
                  }
              }, 
    });
}
wg.DLsearch =  function(){
  data = []
  wg.DLinputsearch($('#searchMember').val())
  $.each(wg.DLdataMembersAll, function(i,v){
    if(v.fullname.toLowerCase().indexOf(wg.DLinputsearch().toLowerCase()) > -1){
      data.push({"_id" : v._id,"email": v.email,"fullname": v.fullname,loginid:v.loginid});
    }
  }) 
  wg.DLsearchStatus(true);
  wg.DLdataMembersSearch = data;
  wg.DLgridDataMembers(wg.DLdataMembersSearch);
}
wg.DLcancel =  function(){
   $('#addDL').modal('hide');
    $('#modalDL').modal('show');
   
}
function deleteRowDetails(id,fullname,email,loginid){
  return function(){
 
    for(i in wg.DLdataMembers){
      if(id == wg.DLdataMembers[i]._id){
        wg.DLdataMembers.splice(i,1); 
      }
    } 
    wg.DLdataMembersAll.push({"_id" :id,"email":email,"fullname": fullname,loginid:loginid});
    if(fullname.toLowerCase().indexOf(wg.DLinputsearch().toLowerCase()) > -1){
        wg.DLdataMembersSearch.push({"_id" :id,"email":email,"fullname": fullname,loginid:loginid});
    }
    if(wg.DLsearchStatus()){
      wg.DLgridDataMembers(wg.DLdataMembersSearch)
    }

    ko.mapping.fromJS(wg.DLdataMembers, wg.DLconfDeleteMembers)
    wg.DLgridDetails(wg.DLdataMembers)
  }
}