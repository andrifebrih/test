var configColor = {}; 
configColor.list 		 = ko.observableArray([]);
configColor.listOriginal = ko.observableArray([]);
configColor.getConfig =  function(){
	configColor.list([])
	configColor.listOriginal([])
	ajaxPost("/configcolor/getconfigcolor", "", function (res){
 		_.map(res.Data, function(o){
 
			
			configColor.list().push(_.clone({_id:o._id,Red:ko.observable(o.Red),Amber:ko.observable(o.Amber),Green:ko.observable(o.Green),}));
			configColor.listOriginal().push(_.clone({_id:o._id,Red:ko.observable(o.Red),Amber:ko.observable(o.Amber),Green:ko.observable(o.Green),}));
 		});
 		configColor.list.valueHasMutated()
		configColor.listOriginal.valueHasMutated()
 		// var data = _.clone(res.Data)
 	// 	configColor.list(_.clone(data));
		// configColor.listOriginal(_.clone(data));
    });
};
configColor.Change =  function(e,idx,type){
	console.log("change")
	var max =  e.sender.options.max;
	var min =  e.sender.options.min;

	if(e.sender._old > max){
	 
		configColor.list()[idx][type](configColor.listOriginal()[idx][type])	
	}
	if(e.sender._old < min){
		 
		configColor.list()[idx][type](configColor.listOriginal()[idx][type])	
	}
	configColor.list.valueHasMutated()
	 		
}
 
configColor.Save = function(){
 
 	_.map(configColor.list(), function(o,i){
 
 		o.Red(parseInt(o.Red()));
		o.Amber(parseInt(o.Amber()));
		o.Green(parseInt(o.Green()));

		if(o.Red() > o.Amber()){
	 		o.Red(configColor.listOriginal()[i].Red()) 
		}
		if( o.Red() > o.Green() ){ 
	 		o.Red(configColor.listOriginal()[i].Red())  
		}
		if(o.Amber() < o.Red() ){ 
	 		o.Amber(configColor.listOriginal()[i].Amber()) 
		}
		if( o.Amber() > o.Green() ){ 
	 		o.Amber(configColor.listOriginal()[i].Amber()) 
		}
		if(o.Green() < o.Red() ){
		 
	 		o.Green(configColor.listOriginal()[i].Green()) 
		}
		if( o.Green() < o.Amber()){
			 
	 		o.Green(configColor.listOriginal()[i].Green()) 
		}
 	});
 
	ajaxPost("/configcolor/saveconfigcolor",  configColor.list(), function (res){
 		if(!res.IsError){
 			configColor.getConfig();
 			return swal("Saved!", "", "success");
 		}

    });
 	 
};
configColor.Reset =  function(){
	configColor.getConfig();
};
$(function(){
	configColor.getConfig();		
});