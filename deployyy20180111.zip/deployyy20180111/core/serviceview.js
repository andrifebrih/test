var sv = {};

sv.serviceprocess = ko.observableArray([]),
sv.serviceprocessValue = ko.observable(),
sv.allData = ko.observable(false),
sv.templateSummary = {
  NoOfSupplier:"",
  TotalTrx:""
}

sv.summary = ko.mapping.fromJS(sv.templateSummary)
sv.getserviceprocess = function(e){
    var url = "/serviceview/getservice";
    ajaxPost(url,{}, function (res){
      var service = []
      $.each(res, function(index, result){		
 			  service.push({"name" : result._id,"text": result._id});
		  });
		sv.serviceprocess(service)
    });
}

sv.chartReceiverCountry =  function(dataSource){
      $("#receivercountrychart").kendoChart({
        dataSource: {
            data:dataSource,
            dataType: "json"
        },

        title: {
            text: "Processes by Receiver Countries:",
            visible:true,
             font: "14px calibri",
        },
        legend :{
            position :"top",
        },
        seriesDefaults:{
            type:"column",
        },
        series : [{
            field: "Count",
        }],
        categoryAxis :{
            field : "_id",
            labels: {
                rotation: -90,
            },
            majorGridLines: {
                visible: false
            }
        },
        valueAxis:{
          labels: {
                visible: true,
                format: "n0",
            },
        },
        tooltip: {
            visible: true,
            format: "n0",
        },
        seriesColors: ["#317DB5"],
    });
}

sv.chartProductFunction =  function(dataSource){
   $.each(dataSource,function(i,val){
        var str= val._id
        var res = str.substring(0, 15);
       val._id = res;
    })
      $("#productfunctionchart").kendoChart({
        dataSource: {
            data:dataSource,
            dataType: "json"
        },
        title: {
            text: "Processes by Product Function:",
            visible:true,
             font: "14px calibri",
        },
        legend :{
            position :"top",
        },
        seriesDefaults:{
            type:"bar",
        },
        series : [{
            field: "Count",
        }],
        categoryAxis :{
            field : "_id",            
        },
        valueAxis:{
            labels: {
                visible: true,
                format: "n0",
                rotation: "auto"
            },
        },
        tooltip: {
            visible: true,
            format: "n0",
        },
        seriesColors: ["#317DB5"],
    });
}

sv.chartService  =  function(dataSource){
    var data = []
    $.each(dataSource, function(i, val){    
        data.push({"category" : val._id,"value": val.Count});
    });

    $("#servicechart").kendoChart({
        title: {
            position: "top",
            text: "Process Supply Type :",

            font: "14px calibri"
        },
        legend: {
            position: "bottom"  
        },
        chartArea: {
            background: ""
        },
        seriesDefaults: {
            labels: { 
                position: "outsideEnd",
                visible: true,
                background: "transparent",
                template: "#= kendo.toString(percentage,'P2') #",
                font: "11px Arial,Helvetica,sans-serif"
            }
        },
        series: [{
            type: "pie",
            startAngle: 150,
            data: data
        }],
        seriesColors:ecisColors,
        tooltip: {
            visible: true,
            template: "#= '<b>' + dataItem.category  + '</br>' + kendo.toString( dataItem.value) + '</b>' #",
            font: "11px Arial,Helvetica,sans-serif"
        }
    });
}

sv.ServicesByProcessesGrid = function(param) {
    var dataSource = [];
    var url = "/serviceview/processnamesuppliertype";
    $("#grid-processes").html("");
    $("#grid-processes").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) {
                    if (data.Data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Data.Records;
                    }
                },
                total: "Data.Count",
            },
            pageSize: 15,
            serverPaging: false,
            serverSorting: false,
        },
        height: 400,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        excel: {
            fileName: "Count of Services by Supply Category.xlsx",
            allPages: true
        },
        columnMenu: false,
        columns: [{
            field:"Processname",
            title:"Row Label",
            width:200,
            attributes: {
                "class": "field-ellipsis"
            }
        },{
            field:"IGS",
            title:"IGS",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Systems",
            title:"Systems",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Teams",
            title:"Teams",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"TPS",
            title:"TPS",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Total",
            title:"Total",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        }]
    });
}

sv.ServicesBySuppliersGrid = function(param) {
    var dataSource = [];
    var url = "/serviceview/suppliernamesuppliertype";
    $("#grid-suppliers").html("");
    $("#grid-suppliers").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) {
                    if (data.Data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Data.Records;
                    }
                },
                total: "Data.Count",
            },
            pageSize: 15,
            serverPaging: false,
            serverSorting: false,
        },
        height: 400,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        excel: {
            fileName: "Count of Services by Suppliers and Supply Category.xlsx",
            allPages: true
        },
        columnMenu: false,
        columns: [{
            field:"Processname",
            title:"Row Label",
            width:200,
            attributes: {
                "class": "field-ellipsis"
            }
        },{
            field:"IGS",
            title:"IGS",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Systems",
            title:"Systems",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Teams",
            title:"Teams",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"TPS",
            title:"TPS",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Total",
            title:"Total",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        }]
    });
}

sv.getData = function(){
    var payload = {
        Service: sv.serviceprocessValue()
    }
    ajaxPost("/serviceview/receiverservice", payload , function (res){
        sv.chartReceiverCountry(res);
    })
    ajaxPost("/serviceview/servicebyproductfunction", payload , function (res){
        sv.chartProductFunction(res);
    })
    ajaxPost("/serviceview/suppliertype", payload , function (res){
        sv.chartService(res);
    })
    sv.ServicesByProcessesGrid(payload)
    sv.ServicesBySuppliersGrid(payload)
}

sv.changeService= function(e){
    var dataItem = this.dataItem(e.item);
    var summary = ko.mapping.toJS(sv.summary)

    sv.serviceprocessValue(dataItem.name);
    sv.getData();
    sv.allData(true);

    ajaxPost("/serviceview/summary", {Service: sv.serviceprocessValue()} , function (res){
        summary.NoOfSupplier = res.NoOfSupplier
        summary.TotalTrx = res.TotalTrx
        ko.mapping.fromJS(summary,sv.summary)
    })
}

sv.FullReceiver = function(){
    var detail = $("#detailContainer");
    detail.data("kendoWindow").title("Services by Product Function Full Screen");
}

$(function(){
    sv.getserviceprocess();
    sv.getData()
    $("#export-processes").click(function () {
        var grid = $("#grid-processes").data("kendoGrid");
        grid.saveAsExcel();
    });
    $("#export-suppliers").click(function () {
        var grid = $("#grid-suppliers").data("kendoGrid");
        grid.saveAsExcel();
    });
    $("#detailContainer").kendoWindow({
        modal: true,
        width: 1000+"px",
        height:700+"px",
        actions: ["Close"],
        title: "Group Details",
        visible:false,
        position: {
            top: 100,
        },
    }).data("kendoWindow");
});

