var Rawocir  = {
	servicedescription: ko.observable(""),
	DatePict : ko.observable(""),
	filterReceivercountry: ko.observableArray([]),
	filterReceiverlegalentity: ko.observableArray([]),
	filterCategoryname : ko.observableArray([]),
	filterSuppliercountry : ko.observableArray([]),
	filterSupplierlegalentity : ko.observableArray([]),
	filterSuppliertype : ko.observableArray([]),
	filterSuppliername : ko.observableArray([]),
	filterProcessname : ko.observableArray([]),

	receivercountry: ko.observableArray([]),
	receiverlegalentity: ko.observableArray([]),
	categoryname : ko.observableArray([]),
	suppliercountry : ko.observableArray([]),
	supplierlegalentity : ko.observableArray([]),
	Suppliertype : ko.observableArray([]),
	Suppliername : ko.observableArray([]),

	productfunction: ko.observable(""),
	productfunctionList: ko.observableArray([]),
};

Rawocir.Search = function(){
	Rawocir.ShowDataGridKendo();
}

Rawocir.ShowDataGridPost = function() {
	var param =  {
		
    };
    var url = "/dbrawocir/getdatarawocir";
    ajaxPost(url, param, function(res){
    	Rawocir.ShowPostChart(res.Data.Records);
    });
}

Rawocir.ShowPostChart = function(dataSource){
	var EmptyData = [];
	$("#gridrawocircallpost").kendoGrid({
            dataSource: {
                   	data : dataSource,
                   	schema: {
                        data: function(data) {
                        	// console.log(data);
                            if (data == 0) {
                                return EmptyData;
                            } else {
                                return data;
                            }
                        },
                        total: function(total){
                        	console.log(total.length);
                        	return total.length;
                        },
                    },
                    pageSize: 15,
                    // serverPaging: true,
                    // serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                columnMenu: false,
            columns: [
                {
                    field:"Receivercountry",
                    title:"Receivercountry",
                    width:200
                }, {
                    field:"Receiverlegalentity",
                    title:"Receiverlegalentity",
                    width:200
                },
                {
                    field:"Categoryname",
                    title:"Categoryname",
                    width:200
                },
                {
                    field:"Productfunctionid",
                    title:"Productfunctionid",
                    width:200
                },
                {
                    field:"Productfunction",
                    title:"Productfunction",
                    width:200
                },
                {
                    field:"Suppliercountry",
                    title:"Suppliercountry",
                    width:200
                },
                {
                    field:"Supplierlegalentity",
                    title:"Supplierlegalentity",
                    width:200
                },
                {
                    field:"Suppliertype",
                    title:"Suppliertype",
                    width:200
                },
                {
                    field:"IdRaw",
                    title:"IdRaw",
                    width:200
                },
                {
                    field:"Suppliername",
                    title:"Suppliername",
                    width:200
                },
                {
                    field:"Processid",
                    title:"Processid",
                    width:200
                },
                {
                    field:"Processname",
                    title:"Processname",
                    width:200
                },
                {
                    field:"Processownerpsid",
                    title:"Processownerpsid",
                    width:200
                },
                {
                    field:"Processownername",
                    title:"Processownername",
                    width:200
                },
                {
                    field:"Unitheadcriticalpersonname",
                    title:"Unitheadcriticalpersonname",
                    width:200
                },
                {
                    field:"Servicedescription",
                    title:"Servicedescription",
                    width:200
                },
                {
                    field:"Teamcostcentre",
                    title:"Teamcostcentre",
                    width:200
                },
                {
                    field:"Itproduct",
                    title:"Itproduct",
                    width:200
                },
                {
                    field:"Itameuc",
                    title:"Itameuc",
                    width:200
                },
                {
                    field:"Globalteamname",
                    title:"Globalteamname",
                    width:200
                },
                {
                    field:"Doi",
                    title:"Doi",
                    width:200
                },
                {
                    field:"Contractid",
                    title:"Contractid",
                    width:200
                },
                {
                    field:"Slaid",
                    title:"Slaid",
                    width:200
                },
                {
                    field:"Servicefte",
                    title:"Servicefte",
                    width:200
                }]
    });
}

Rawocir.ShowDataGridKendo = function() {
	var param =  {
		"Product" : Rawocir.productfunction(),
		"Receivercountry" : Rawocir.filterReceivercountry()
		//"Period" : Rawocir.DatePict(),
		//"Status" : $('#cok').bootstrapSwitch('state')
    };
    console.log(param);

    var dataSource = [];
    var url = "/dbrawocir/getdatarawocir";
    $("#gridrawocirdirect").html("");
    $("#gridrawocirdirect").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",

                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            if (data.Data.Count == 0) {
                                return dataSource;
                            } else {
                                return data.Data.Records;
                            }
                        },
                        total: "Data.Count",
                    },
                    pageSize: 10,
                    serverPaging: true,
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5,
                     pageSizes: [5, 10, 20],
                },
                columnMenu: false,
             columns: [{
                    field:"Receivercountry",
                    title:"Receivercountry",
                    width:150
                }, 
                {
                    field:"Receiverlegalentity",
                    title:"Receiverlegalentity",
                    width:300
                },
                {
                    field:"Categoryname",
                    title:"Categoryname",
                    width:150
                },
                {
                    field:"Productfunctionid",
                    title:"Productfunctionid",
                    width:150
                },
                {
                    field:"Productfunction",
                    title:"Productfunction",
                    width:150
                },
                {
                    field:"Suppliercountry",
                    title:"Suppliercountry",
                    width:170
                },
                {
                    field:"Supplierlegalentity",
                    title:"Supplierlegalentity",
                    width:300
                },
                {
                    field:"Suppliertype",
                    title:"Suppliertype",
                    width:150
                },
                {
                    field:"IdRaw",
                    title:"IdRaw",
                    width:200
                },
                {
                    field:"Suppliername",
                    title:"Suppliername",
                    width:300
                },
                {
                    field:"Processid",
                    title:"Processid",
                    width:200
                },
                {
                    field:"Processname",
                    title:"Processname",
                    width:900
                },
                {
                    field:"Processownerpsid",
                    title:"Processownerpsid",
                    width:200
                },
                {
                    field:"Processownername",
                    title:"Processownername",
                    width:200
                },
                {
                    field:"Unitheadcriticalpersonname",
                    title:"Unitheadcriticalpersonname",
                    width:200
                },
                {
                    field:"Servicedescription",
                    title:"Servicedescription",
                    width:700
                },
                {
                    field:"Teamcostcentre",
                    title:"Teamcostcentre",
                    width:100
                },
                {
                    field:"Itproduct",
                    title:"Itproduct",
                    width:100
                },
                {
                    field:"Itameuc",
                    title:"Itameuc",
                    width:100
                },
                {
                    field:"Globalteamname",
                    title:"Globalteamname",
                    width:150
                },
                {
                    field:"Doi",
                    title:"Doi",
                    width:100
                },
                {
                    field:"Contractid",
                    title:"Contractid",
                    width:100
                },
                {
                    field:"Slaid",
                    title:"Slaid",
                    width:100
                },
                {
                    field:"Servicefte",
                    title:"Servicefte",
                    width:130
                }]
    });
}

Rawocir.GetDropdownlist = function(){

    var url = "/dbrawocir/getfunct";
    ajaxPost(url, {}, function(res){
    	// console.log(res);
    	for (var i in res){
    		Rawocir.productfunctionList.push({
    			"text" :res[i]._id.productfunction,
    			"value" : res[i]._id.productfunctionid
    		});
    	}
    });
    
    // ajaxPost("/dbrawocir/getreceiverlegalentity", {}, function(res){
    //     for (var i in res){
    // 		Rawocir.receiverlegalentity.push({
    // 			"text" :res[i]._id.receiverlegalentity,
    // 			"value" : res[i]._id.receiverlegalentity
    // 		});
    // 	}
    // });
    // ajaxPost("/dbrawocir/getcategoryname", {}, function(res){
    //     for (var i in res){
    // 		Rawocir.categoryname.push({
    // 			"text" :res[i]._id.categoryname,
    // 			"value" : res[i]._id.categoryname
    // 		});
    // 	}
    // });
    // ajaxPost("/dbrawocir/getsuppliercountry", {}, function(res){
    //     for (var i in res){
    // 		Rawocir.suppliercountry.push({
    // 			"text" :res[i]._id.suppliercountry,
    // 			"value" : res[i]._id.suppliercountry
    // 		});
    // 	}
    // });
}

Rawocir.GetReceivecountry = function(){
	ajaxPost("/dbrawocir/getreceivecountry", {}, function(res){
        for (var i in res){
    		Rawocir.receivercountry.push({
    			"text" :res[i]._id.receivercountry,
    			"value" : res[i]._id.receivercountry
    		});
    	}
    });
}
Rawocir.chartReceiverCategory =  function(){
    $("#receivercategorychart").kendoChart({
        dataSource: {
            transport: {
                        read: {
                            url: "../content/dataviz/js/spain-electricity.json",
                            dataType: "json"
                        }
                    },
                    sort: {
                        field: "year",
                        dir: "asc"
                    }
        },

        title: {
            text: "Process Receiver Categories",
            font: "14px Helvetica Neue, Helvetica, Arial, sans-serif",
            visible:false
        },
        legend :{
          position :"bottom",
          labels: {
              font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
          },
        },
        chartArea :{
          height: 250,
        },
        seriesDefaults:{
          type:"column",
        },
        series : 
        [{
                    field: "nuclear",
                    name: "Nuclear"
                }, {
                    field: "hydro",
                    name: "Hydro"
                }, {
                    field: "wind",
                    name: "Wind"
                }],
        categoryAxis :{
          field: "year",
                    labels: {
                        rotation: -90
                    },
                    majorGridLines: {
                        visible: false
                    }
        },
        valueAxis:{
            majorUnit: 10000,
            labels: {
              font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
              visible: true,
              format:"{0:N0}",
            },
        },
        tooltip: {
            visible: true,
            format: "n0",
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        },
        seriesColors:ecisColors,
      });
$(document).ready(function () {
	$('#cok').bootstrapSwitch('state', true);
	//Rawocir.GetDropdownlist();
	//Rawocir.GetReceivecountry();
	// Rawocir.ShowDataGridPaost();
	//Rawocir.ShowDataGridKendo();
    Rawocir.chartReceiverCategory();
});