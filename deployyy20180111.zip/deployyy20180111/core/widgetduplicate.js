wgDuplicate = {};
wgDuplicate.loadTemplateProcess = ko.observable(false);
wgDuplicate.template = ko.observableArray([]);
wgDuplicate.test 	 = ko.observable("Test");
wgDuplicate.total 	 = ko.observable(0);
wgDuplicate.DonutseriesColors = ["#00506D","#0077A3","#50D0FF","#8ADFFF","#E6E7E8", "#BCBEC0"]; 
wgDuplicate.process = {
	date : ko.observable(true),
	template : ko.observable(true)
}
wgDuplicate.pullRequest = ko.observable(0);
wgDuplicate.pullRequest.subscribe(function(newValue){
	if(wgDuplicate.pullRequest() == 0){
		wgDuplicate.GetBase64();
	}
})
wgDuplicate.base64Pdf = ko.observable("");
function getTemplateActive(page){
	return wgDuplicate.template()[page];
};
function getDataViZActive(page, index){
	return wgDuplicate.template()[page].mainpage.dataViz[index]
};
function getSummaryActive(page, index){ 
	return wgDuplicate.template()[page].mainpage.summary[index]
}; 
function getFilterActive(page){
	return wgDuplicate.template()[page].filter;
};
function capitalize(string){
	// console.log(string,"-------------")
	// if(string == undefined || string == "")
		return string;
	// return string.replace(/\b\w/g, function(l){ return l.toUpperCase() })
};
function limitResultBar(dataSource,limit){
	limit -= 1;
	if(dataSource.length < limit)
		return dataSource;
	var results = []
	for(i=0; i<=limit; i++){
		results.push(dataSource[i])
	}
	return results;
};
function limitResultGrid(dataSource,limit){
	limit -= 1;
	if(dataSource.length < limit)
		return dataSource;
	var results = []
	for(i=0; i<=limit; i++){
		results.push(dataSource[i])
	}
	return results;
};
function getDate(){
	var d = new Date();
	var Months 		= ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
	var Days 		= ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
	
	var year	 	= d.getFullYear();
	var month 		= Months[parseInt(d.getMonth())];
	var date 		= d.getDate();
	var formatDate 	= date +" "+month+" "+ year + " " +d.getHours() + ":" + ((d.getMinutes() < 10)? "0"+ d.getMinutes() : d.getMinutes() + ":" + d.getSeconds())
    return formatDate;
};
function formatDateGeneate(date){
	return 'Report generated on: ' + getDate() +"</br>"+date[0]+"</br>"+date[1];
};




wgDuplicate.GetTemplate = function(id){
	ajaxPost("/widgetduplicate/getdetailstemplatename", {id:id}, function(res){
		 
		if(res.Data.TemplateName != undefined){
			wgDuplicate.loadTemplateProcess(true);
			wgDuplicate.Loadtemplate(res.Data);	
		}
	})
}
wgDuplicate.Loadtemplate =  function(template){
	var newTemplate = [];
	ajaxPost("/widgetduplicate/getdategenerate", {}, function(res){ 
 		wgDuplicate.process.date(false)
		_.each(template.details, function(v){
		v.mainpage.fulDataViz 		= ko.observable(v.mainpage.fulDataViz);
		v.mainpage.fulDataVizIndex 	= ko.observable(v.mainpage.fulDataVizIndex);
		v.mainpage.fulDataVizLoading 	= ko.observable(v.mainpage.fulDataVizLoading);

		_.each(v.mainpage.dataViz, function(dataviz){
			if(dataviz.active == true)
				wgDuplicate.pullRequest(wgDuplicate.pullRequest() + 1);
			dataviz.active 		=  ko.observable(dataviz.active);
			dataviz.type 		=  ko.observable(dataviz.type); 
			dataviz.showFilter  =  ko.observable(dataviz.showFilter);
			dataviz.loading 	=  ko.observable(dataviz.loading); 
			dataviz.filter 		=  {
				value: ko.observable(dataviz.filter.value),
				text: ko.observable(dataviz.filter.text),
			};
		}); 
		_.each(v.mainpage.summary, function(summary){
			if(summary.active == true)
				wgDuplicate.pullRequest(wgDuplicate.pullRequest() + 1);
			summary.active 		=  ko.observable(summary.active);
			summary.value 		=  ko.observable(summary.value); 
			summary.showFilter  =  ko.observable(summary.showFilter);
			summary.loading 	=  ko.observable(summary.loading); 
			summary.filter 		=  {
				value: ko.observable(summary.filter.value),
				text: ko.observable(summary.filter.text),
			};
		});
		newTemplate.push({
			filter   : v.filter, 
			mainpage : v.mainpage
		});
		}); 
		wgDuplicate.template(newTemplate)
		wgDuplicate.total(newTemplate.length);
		_.each(wgDuplicate.template(), function(o,i){ 
			wgDuplicate.loadTemplateSummary(i, o.mainpage.summary);
			wgDuplicate.loadTemplateDataviz(i, o.mainpage.dataViz);
		});
		
		$('.date-generate').html(""); 
		$('.date-generate').html(formatDateGeneate(res.Data));
	});
};
wgDuplicate.generatePayload =  function(filter){ 
	var payload = {};
	_.each(filter, function(val,key){
		payload[key]  = val.value; 
	})
	return payload;
}
wgDuplicate.generateSummry = function(page, index){
	var config  = getSummaryActive(page, index); 
	config.loading(true);
	var payload = wgDuplicate.generatePayload(getTemplateActive(page).filter);
	payload.BoxType = config.filter.value(); 
	ajaxPost("/widgetduplicate/getwidgetsummarybox",payload, function(res){
		config.loading(false);
		config.active(true); 
		config.value( (res.Data == null)? 0 : res.Data );

   	 	wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
	});
};
wgDuplicate.generateDataviz      =  function(type, page, index){
 	// wgDuplicate.checkFullDataViz(page)
	switch(type.toLowerCase()){
		case"bar":
			wgDuplicate.generateDatavizBar(page, index);
		break;
		case"donut":
			wgDuplicate.generateDatavizDonut(page, index);
		break;
		case"grid":
			wgDuplicate.generateDatavizGrid(page, index);
		break;
	};
};

// BAR 
wgDuplicate.generateDatavizBar   =  function(page, index){
	// $("#opt-bar-modal").modal('hide'); 
 
	var config = getDataViZActive(page, index);
		config.active(true);
		config.type("bar");
		config.loading(true);

	var payload = wgDuplicate.generatePayload(getTemplateActive(page).filter);
	var filter  = config.filter.value();  

	switch(filter){
		// normal Bar
		case "Biggest":
			if(payload.Categoryname.length == 0){
				ajaxPost("/widgetduplicate/receivercategory", payload, function(res){
					config.loading(false);
					wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
				});
			}else{
				ajaxPost("/widgetduplicate/receivercategoryproduct", newPayload , function (res){
                    config.loading(false);
					_.each(res, function(o){
						o._id = o.Country;
					});
					wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
                });
			}
		break;
		case "Service FTE":
			ajaxPost("/widgetduplicate/servicefte", payload, function(res){
				config.loading(false);
				wgDuplicate.creataNormalBar(config.id, page, filter,_.sortBy(res, "Count").reverse());
			});
		break;
		case "Fte by Country":
			if(payload.SupplierCountry.length == 0){
				ajaxPost("/widgetduplicate/ftebycountry", payload , function (res){
                    config.loading(false);
					wgDuplicate.creataNormalBar(config.id, page, filter,_.sortBy(res, "Count"));           
                });
			}else{
				ajaxPost("/widgetduplicate/ftebycountrylegal", payload , function (res){
                    config.loading(false);
					wgDuplicate.creataNormalBar(config.id, page, filter,_.sortBy(res, "Count"));   
                }); 
			}
		break;
		case 'level 1 by country':
			ajaxPost("/widgetduplicate/levelbycountry", payload, function(res){
				config.loading(false);
				wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
			});
		break;
		case "Process by GBS and Others":
			ajaxPost("/widgetduplicate/processbygbs", payload , function (res){
				config.loading(false);
				wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break; 
		case "Assets Utilized":
			ajaxPost("/widgetduplicate/getassetsutilized", payload , function (res){
				config.loading(false);
				wgDuplicate.creataNormalBar(config.id, page, filter,_.sortBy(res, "Count").reverse());
            });
		break;
		case 'Third party suppliers':
            payload.WorstType = "";
			ajaxPost("/widgetduplicate/thirdpartysuppliers", payload , function (res){
				config.loading(false);
				_.each(res, function(o){
					o._id = o.Country;
				});
				wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break;
		case 'Third party suppliers by business':
            payload.WorstType = "";
			ajaxPost("/widgetduplicate/tpsbybusiness", payload , function (res){
				config.loading(false);
				_.each(res, function(o){
					o._id = o.Country;
				});
				wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break;
		case 'Third party suppliers by country':
            payload.WorstType = "";
			ajaxPost("/widgetduplicate/tpsbycountry", payload , function (res){
				config.loading(false);
				_.each(res, function(o){
					o._id = o.Country;
				});
				wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break;
		case "Barriers to Resolution by Region":
			payload.Flag = "region";
			ajaxPost("/widgetduplicate/barriersbar", payload , function (res){
				config.loading(false); 
				wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res.Data, "Count").reverse(),10));
            });
		break;
		case "Different Types  of Barriers":
			payload.Flag = "barriertype";
			ajaxPost("/widgetduplicate/barriersbar", payload , function (res){
				config.loading(false); 
				wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res.Data, "Count").reverse(),10));
            });
		break;

		// Bar with label
		case "Worst 10 [% Validated]":
			payload.WorstType = "validated";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case "Worst 10 [% Enriched]":
			payload.WorstType = "enriched";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case "Worst 10% Validated by Business/Function":
			payload.WorstType = "businnessvalidated";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case "Worst 10% Enriched by Business/Function":
			payload.WorstType = "businnessenriched";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
		case 'Best 10 [% Validated]' :
            payload.WorstType = "reversevalidated";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
		case 'Best 10 [% Enriched]' :
            payload.WorstType = "reverseenriched";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Pending Best 10 [% Validated]':
            payload.WorstType = "pendingbestvalidated";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
		case 'Pending Best 10 [% Enriched]':
            payload.WorstType = "pendingbestenriched";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
	    case 'Pending Worst 10 [% Validated]':
            payload.WorstType = "pendingworstvalidated";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break; 
		case 'Pending Worst 10 [% Enriched]':
            payload.WorstType = "pendingworstenriched";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Worst 10 by Process Owner [% Validated Service]':
            payload.WorstType = "worstownervalidated";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Worst 10 by Process Owner [% Confirmed Service]':
            payload.WorstType = "worstownerenriched";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Best 10 by Process Owner [% Validated Service]':
            payload.WorstType = "bestownervalidated";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Best 10 by Process Owner [% Confirmed Service]':
            payload.WorstType = "bestownerenriched";
			ajaxPost("/widgetduplicate/worstvalidated", payload , function (res){
				config.loading(false);
				wgDuplicate.createBarWithLabel(config.id, page, filter, res);
            });
		break;
		case 'Buildings by country':
            payload.WorstType = "";
			ajaxPost("/widgetduplicate/buildingbycountry", payload , function (res){
				config.loading(false);
				_.each(res, function(o){
					o._id = o.Country;
				});
				wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
            });
		break; 
		
		//barfull
		case 'Barriers to Resolution by Business': 
			config.loading(false); 

            var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);     
            	template.mainpage.fulDataVizLoading(true);     
            payload.Flag = "categoryname_";
            ajaxPost("/widgetduplicate/barriersbar", payload , function (res){

            	template.mainpage.fulDataVizLoading(false); 
            	var id = "fullDataViz"+page;
				wgDuplicate.createFullBar(id, filter, res.Data);
            });
        break; 
        case 'Barriers to Resolution by Country': 
			config.loading(false);


            var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);     
            	template.mainpage.fulDataVizLoading(true);     
            payload.Flag = "receivercountry";
            ajaxPost("/widgetduplicate/barriersbar", payload , function (res){
            	
            	template.mainpage.fulDataVizLoading(false); 
            	var id = "fullDataViz"+page;
				wgDuplicate.createFullBar(id, filter, res.Data);
            });
        break; 
    	case '% Validated all Countries': 
			config.loading(false);

            var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);     
            	template.mainpage.fulDataVizLoading(true);     
            payload.WorstType = "validated";
            ajaxPost("/widgetduplicate/percentvalidated", payload , function (res){
            	 
            	template.mainpage.fulDataVizLoading(false); 
            	var id = "fullDataViz"+page;
				wgDuplicate.createFullBar(id, filter, res);
            });
        break; 
        case '% Enriched all Countries':
        	config.loading(false);


            var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);     
            	template.mainpage.fulDataVizLoading(true);     
            payload.WorstType = "enriched";
            ajaxPost("/widgetduplicate/percentvalidated", payload , function (res){
            	 
            	template.mainpage.fulDataVizLoading(false); 
            	var id = "fullDataViz"+page;
				wgDuplicate.createFullBar(id, filter, res);
            });
        break;
       
        //barfull with condition
        case 'Comparison Region [% Validated Service]':     
		    payload.WorstType = "validated";
        	ajaxPost("/widgetduplicate/comparisonregion", payload , function (res){
            	if(res.length >= 19){
            		config.loading(false);

            		var template = getTemplateActive(page);
		            	template.mainpage.fulDataVizIndex(index);
		            	template.mainpage.fulDataViz(true);      	
	            	var id = "fullDataViz"+page;
					wgDuplicate.createFullBar(id, filter, res);
            	}else{
            		config.loading(false);
					wgDuplicate.createBarWithLabel(config.id, filter, res);
            	}
            });
        break;
		case 'Comparison Region [% Confirmed Service]':     
		    payload.WorstType = "enriched";
        	ajaxPost("/widgetduplicate/comparisonregion", payload , function (res){
            	if(res.length >= 19){
            		config.loading(false);

            		var template = getTemplateActive(page);
		            	template.mainpage.fulDataVizIndex(index);
		            	template.mainpage.fulDataViz(true);      	
	            	var id = "fullDataViz"+page;
					widget.createFullBar(id, filter, res);
            	}else{
            		config.loading(false);
					wgDuplicate.createBarWithLabel(config.id, filter, res);
            	}
            });
        break;

        // stacked bar
        case "Systems per business/function":
        	payload.Flag = filter;
            ajaxPost("/widgetduplicate/systemsperbusiness", payload , function (res){
            	config.loading(false); 
            	wgDuplicate.createStackedBar(config.id, filter, widget.mappingDataStackedBar(res));
            });
        break;
        case "Processes per critical service provider":
        	payload.Flag = filter;
            ajaxPost("/widgetduplicate/getcriticalprovider", payload , function (res){
            	config.loading(false); 
            	wgDuplicate.createStackedBar(config.id, filter, widget.mappingDataStackedBar(res));
            });
        break;
        case "Critical Service Providers by FTE":
        	payload.Flag = filter;
            ajaxPost("/widgetduplicate/getcriticalproviderfte", payload , function (res){
            	config.loading(false); 
            	wgDuplicate.createStackedBar(config.id, filter, widget.mappingDataStackedBar(res));
            });
        break;
        case "Location by FTE":
        	payload.Flag = filter;
            ajaxPost("/widgetduplicate/getlocationfte", payload , function (res){
            	config.loading(false); 
            	wgDuplicate.createStackedBar(config.id, filter, widget.mappingDataStackedBar(res));
            });
        break;
        // cefassessmentchart
        default:
			payload.Flag = filter;
			ajaxPost("/widgetduplicate/cefassessmentchart", payload , function (res){
				config.loading(false);
				wgDuplicate.creataNormalBar(config.id, page, filter,limitResultBar(_.sortBy(res, "Count").reverse(),10));
			})
	}
};
wgDuplicate.creataNormalBar 		= function(id, page, type,dataSource){ 
 
	var $id = $("#"+id).find(".content");
 
	var max = (dataSource.length == 0) ? 0 : _.max(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var min = (dataSource.length == 0) ? 0 : _.min(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	if(max == 0 && min == 0)
		dataSource  = [];
 	
 	if(dataSource.length == 1){ 
		$id.css('height', (dataSource.length * 60) + 'px');
    }else if (dataSource.length <= 7){ 
		$id.css('height', (dataSource.length * 52) + 'px'); 
    }else{
		$id.css('height','370px');  
    }
	
	// var eventClick  = seriesClick; 
	var filter 		= getFilterActive(page);
	// switch(type){
	// 	case"Buildings by country":
	// 	case"Third party suppliers":
	// 	case"Third party suppliers by business":
	// 	case"Third party suppliers by country": 
	// 	// case"Barriers to Resolution by Region":
	// 	// case"Different Types  of Barriers": 
	// 		eventClick = undefined;
	// 		hoverType  = 0; 
	//  	break;
	// }

 
	$id.html('');
 
    $id.kendoChart({
        dataSource: {
            data:dataSource,
            dataType: "json"
        },
        legend :{
            position :"top",
            margin:{
                visible:true,
                top:40
            },
            font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
        },
        chartArea: { 
        	width:331,
        },
        transitions: false,
        seriesDefaults: {
            type: "bar",
            overlay: {
            	gradient: "none"
            },
            tooltip: {
            	visible: false,
            	template: "#:kendo.toString(value,'N0')#"
            },
            labels: {
				font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
				color: "#0075B2",
				visible: true, 
				position:"outsideEnd",
				background: "transparent",
				template : function(e){ 
					return parseInt(e.value.toFixed(0)).toLocaleString()
              	},
            }, 
            gap: 0.3, 
        },
        series: [{
            field: "Count",
            border: {
                width: 1,
                color: "transparent"
            },
			color: function(e){
				if(type == 'Process by GBS and Others'){
					if(e.dataItem.Color == 'gbs'){
						return "#2F7528"
					}else{
						return "#005C84"
					}
				}else{
					return "#005C84"
				} 
			} 
        }],
        categoryAxis :{
            field : "_id",
            labels: {
                template: labelTemplate,
                font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            majorGridLines: {
				visible: false
            },
            line:{
                visible:false
            }
        },
        valueAxis:{
            min:0,
            max: max * 1.2,

            majorGridLines: {
              visible: false,
            },
        
            line: {
              visible: false
            },
           
            labels:{
              visible:false,
            },
        },
        tooltip: {
            visible: true,
            format: "n0",
        },  
        seriesHover: function(e) { 
        	// if(eventClick)
        	// 	$id.css("cursor","pointer");
        	// else
        	// 	$id.css("cursor","default");

        	setTimeout(function(){
        		$id.find("g path").each(function (idx){
        			var op = $(this).attr('stroke-opacity');
        			if (op == 0.2){
                		if(filter.ReceiverCountry == e.category){
							$(this)
							.attr('fill','#50D0FF')
							.attr('fill-opacity', 1)
						}else if(type == 'Process by GBS and Others'){
							if(e.dataItem.Color == 'gbs'){
								$(this)
								.attr('fill','#1f4f1a')
								.attr('fill-opacity', 1)
							}else{
								$(this)
								.attr('fill','#002951')
								.attr('fill-opacity', 1)
							}
						}else{
							$(this)
							.attr('fill','#002951')
							.attr('fill-opacity', 1)
						}

					}	
        		});
        	},100);
        },
        seriesColors: ["#66DBFF"],
    });
    var isFound = false
    jQuery('#'+id+' .content g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
        if (isFound) return
        if ($(e).html() == '') isFound = true
        $(e).find('text').attr('x', 0)
	});
    function labelTemplate(e) { 
		var finalStm = "";
		var maxlen = 14;
		var Spl = e.value.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
		    lenStm = lenStm + o.length + 1;
		    var tb = "";
		    if (lenStm <= maxlen) {
		        tb = " ";
		    } else {
		        lenStm = o.length;
		        tb = "\n";
		    }
		    if (i == 0) {
		        tb = "";
		    }
		    finalStm = finalStm + tb + o;
		}); 
		return finalStm
    }; 
    wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
};
wgDuplicate.createBarWithLabel =  function(id, page, type, dataSource){
	$id = $("#"+id).find(".content"); 

	var max = (dataSource.length == 0) ? 0 : _.max(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var min = (dataSource.length == 0) ? 0 : _.min(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var dataSourceAdditional = [];
		
	if(max == 0 && min == 0)
		dataSource  = [];
 	else
 		_.each(dataSource, function(v){
			var twentyPercent =  (max == 0) ? 0 : max / ( 100/20 );
			dataSourceAdditional.push({_id:null,val:(max + twentyPercent) - v.Count, label:v.Count,label2:v.Value});
		});
 	
 	if(dataSource.length == 1){ 
		$id.css('height', (dataSource.length * 60) + 'px');
    }else if (dataSource.length <= 7){ 
		$id.css('height', (dataSource.length * 52) + 'px'); 
    }else{
		$id.css('height','370px');  
    } 
    
    $id.html('');
   	$id.kendoChart({ 
	    legend :{
			position :"top",
			margin:{
				visible:true,
				top:40
			},
			font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif"
	    },
	    transitions: false,
	    seriesDefaults: {
	    	type: "bar",
			stack: {
				type: "100%"
			},
			overlay: {
				gradient: "none"
			},
			gap: 0.5,
			color: "#36BC9B",
		},
	    series: [
		    {
				data:dataSource,
				categoryField: "_id",
	      		field: "Count", 
	      		border: {
	        		width: 1.7,
	        		color: "transparent"
	      		},
		    	color: function(e){
					return "#005C84"
	      		},
	      		labels: {
					font: "8px Helvetica Neue, Helvetica, Arial, sans-serif",
					color: "#fff", 
					visible: function(e){
						switch(type){ 
							case"Comparison Region [% Validated Service]":
							case"Comparison Region [% Confirmed Service]":
								return false;
							break;
							default:
								return true;
						}
					},
					position:"InsideEnd",
					template: function(e){ 
						return "Rank " + e.dataItem.Rank;
						 
					},
					background: "transparent"
				},
			}, 
			{ 
				data: dataSourceAdditional,
				field: "val", 
				color: "#FFFFFF",
		        border: {
		            width: 1.7,
		            color: "transparent"
		        },
				labels: {
					font: "bold 8px Helvetica Neue, Helvetica, Arial, sans-serif",
					color: "#005C84", 
					visible: true,
					position:"InsideEnd",
					template: function(e){
					 
						return e.dataItem.label.toFixed(1) + "%\n"+ e.dataItem.label2.toFixed(1) + "%";
						 
					},//   
					background: "transparent"
				},
			}
		],
	    categoryAxis :{ 
			labels: {
				template: labelTemplate,
				font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
				color: "#000",
				visible: true, 
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
	    valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
	    },  
	    // seriesClick: seriesClick,    
	    seriesColors: ["#66DBFF"],
	    render: function(){
			setTimeout(function(){
		        kendo.resize($id);
			},400);
	    }
	}); 
	var isFound = false
    jQuery('#'+id+' .content g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
        if (isFound) return
        if ($(e).html() == '') isFound = true
        $(e).find('text').attr('x', 0)
	});
    function labelTemplate(e) { 
		var finalStm = "";
		var maxlen = 14;
		var Spl = e.value.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
		    lenStm = lenStm + o.length + 1;
		    var tb = "";
		    if (lenStm <= maxlen) {
		        tb = " ";
		    } else {
		        lenStm = o.length;
		        tb = "\n";
		    }
		    if (i == 0) {
		        tb = "";
		    }
		    finalStm = finalStm + tb + o;
		}); 
		return finalStm
    };
    wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
};
wgDuplicate.createFullBar =  function(id, type, dataSource){
	var max = (dataSource.length == 0) ? 0 : _.max(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var min = (dataSource.length == 0) ? 0 : _.min(dataSource, function(dataSource){ return dataSource.Count; }).Count;
	var dataSourceAdditional = [];
	
	if(max == 0 && min == 0)
		dataSource = [];
	else{
		_.each(dataSource, function(v){
			var ninePercent =  (max == 0) ? 0 : max / ( 100/9 );
			dataSourceAdditional.push({_id:null,Count:(max + ninePercent) - v.Count, label:v.Count});
		});
	}
	// var evantClick = undefined;
	// switch(type){ 
	// 	case "Barriers to Resolution by Business":
	// 	case "Barriers to Resolution by Country": 
	// 		eventClick = seriesClick;
	// 	break;
 //    }
	$id = $("#"+id).find(".content");
	$id.html('');
  	$id.kendoChart({ 
	    legend :{
			position :"top",
			margin:{
				visible:true,
				top:40
			},
			font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif"
	    },
	    transitions: false,
	    seriesDefaults: {
			stack: {
				type: "100%"
			},
			overlay: {
				gradient: "none"
			},
			gap: 0.5,
			color: "#36BC9B",
		},
	    series: [
		    {
				data:dataSource,
				categoryField: "_id",
	      		field: "Count", 
	      		border: {
	        		width: 1.7,
	        		color: "transparent"
	      		},
		    	color: function(e){
					return "#36BC9B"
	      		},
	      		labels: {
					font: "8px Helvetica Neue, Helvetica, Arial, sans-serif",
					color: "#fff",
					rotation: -90,
					visible: false,
					position:"insideEnd",
					template: function(e){
						
						if(type == "Barriers to Resolution by Business" || type  == "Barriers to Resolution by Country"){
							return e.value.toFixed(0);
						}
						if(e.value === 0){
							return 0;
						}else{
							return e.value.toFixed(1) + "%";
						}
					},
					background: "transparent"
				},
			}, 
			{ 
				data: dataSourceAdditional,
				field: "Count", 
				color: "#F2F2F2",
		        border: {
		            width: 1.7,
		            color: "transparent"
		        },
				labels: {
					font: "bold 8px Helvetica Neue, Helvetica, Arial, sans-serif",
					color: "#00506D",
					rotation: -90,
					visible: true,
					position:"insideEnd",
					template: function(e){
						if(type == "Barriers to Resolution by Business" || type  == "Barriers to Resolution by Country"){
							return e.dataItem.label.toFixed(0);
						}
						if(e.dataItem.label === 0){
							return 0;
						}else{
							return e.dataItem.label.toFixed(1) + "%";
						}
					},//   
					background: "transparent"
				},
			}
		],
	    categoryAxis :{

			labels: {
				font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
				color: "#00506D",
				visible: true,
				mirror: true,
				rotation: -90,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
	    valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
	    },      
	    seriesColors: ["#66DBFF"], 
	    render: function(){
			setTimeout(function(){
		        kendo.resize($id);
			},400);
	    }
	});
    wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
};
wgDuplicate.createStackedBar = function(id, type, series){
    var $id = $("#"+id).find(".content");
    var ds = series[0].data;
	if(ds.length == 1){ 
		$id.css('height', (ds.length * 60) + 'px');
    }else if (ds.length <= 7){ 
		$id.css('height', (ds.length * 52) + 'px'); 
    }else{
		$id.css('height','370px');  
    } 

	$id.html('');
    $id.kendoChart({
		legend :{
			position :"bottom",
			font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
		},
		chartArea: { 
			width:331,
		},
		transitions: false,
		seriesDefaults: {
			type: "bar",
			stack:true,
				overlay: {
					gradient: "none"
			},
			gap: 0.5,
			color: "transparent",
		},
		series: series,
		categoryAxis :{ 
			labels: {
				font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
				template: labelTemplate,
				visible: true,
				background: "transparent",
			},
			majorGridLines: {
				visible: false
			},
			line:{
				visible:false
			}
		},
		valueAxis:{
			majorGridLines: {
				visible: false,
			},
			line: {
				visible: false
			},
			labels:{
				visible:false,
			},
		}, 
		seriesColors: ["#66DBFF"],
	});
	function labelTemplate(e) {
		var finalStm = "";
		var maxlen = 14;
		var Spl = e.value.split(" ");
		var lenStm = 0;
		$.each(Spl, function(i, o){
			lenStm = lenStm + o.length + 1;
			var tb = "";
			if (lenStm <= maxlen) {
				tb = " ";
			} else {
				lenStm = o.length;
				tb = "\n";
			}
			if (i == 0) {
				tb = "";
			}
			finalStm = finalStm + tb + o;
		});  
		return finalStm  
	}
    wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
};
wgDuplicate.mappingDataStackedBar = function(dataSource){
	var results = [];
	var config = {
		internal:
		{ 
			name :"Internal",
			color : "#00506D"
		},
		external:
		{ 
			name :"External",
			color : "#2F7528"
		},
		underreview:
		{ 
			name :"Under Review",
			color : "#939598"
		},
		additional:
		{ 
			name:"Additional",
			color : "#fff"
		},
		hub:
		{ 
			name:"HUB",
			color : "#0075B0"
		},
		inentity:
		{ 
			name:"In-Entity",
			color : "#009FDA"
		},
		gbs:
		{ 
			name:"GBS",
			color : "#3F9C35"
		},
		other:
		{ 
			name:"Other",
			color : "#A6A6A6"
		},
		intra:{
			name :"HUb",
			color : "#0075B0"
		}
	};
	var series = {
		categoryField: "Country",
		field: "Count",
		border: {
			width: 0,
		},  
		tooltip: {
			visible: true,
			template: "#= kendo.toString(value,'N0') #"
		},
	};
	additionalSeries = [];
	var idx = 0;
	var o = _.sortBy(o, "Count").reverse()
	_.each(dataSource, function(o, i){
		if(idx == 0){
			var max =(o.length == 0) ? 0 : _.max(o, function(o){ return o.Value; }).Value;
			var tenPercent =  max + ((10 * max) / 100);
			var ds = [];
			for(var j=0; j<10; j++){
				ds.push({Count:tenPercent - o[j].Value, Country:o[j].Country, Value:o[j].Value})
			}

			additionalSeries = {
				categoryField: "Country",
				field: "Count",
				border: {
					width: 0,
				},
				data 	:ds,
				color 	:"#FFF",
				labels 	:{ 
			        position:"insideEnd ",
	                template: "#= kendo.toString(dataItem.Value,'N0') #",
	                visible: true
				}
			};
		}	 
		var s = _.clone(series);
			s.data = limitResultBar(o,10);
			s.name = config[i].name;
			s.color = config[i].color; 
		results.push(s);
		idx++;
	}); 
	results.push(additionalSeries);
	return results;
};

// DONUT
wgDuplicate.generateDatavizDonut =  function(page, index){

	var config = getDataViZActive(page, index);
		config.active(true);
		config.type("donut");
		config.loading(true);

	var payload = wgDuplicate.generatePayload(getTemplateActive(page).filter);
	var filter  = config.filter.value();
	switch(filter){
		case"In-Entity vs Intra-Group":
			ajaxPost("/widgetduplicate/getdonutservices", payload , function (res){
				config.loading(false);
				wgDuplicate.createDonut(config.id,filter, res);
			});
		break;
		case"In-Entity vs Intra-Group FTE":
			ajaxPost("/widgetduplicate/getdonutservicesfte", payload , function (res){
				config.loading(false);
				wgDuplicate.createDonut(config.id, filter, res);
			});
		break;
		case"% of Services by Service Type":
			ajaxPost("/widgetduplicate/getdonutl3processes", payload , function (res){
				config.loading(false);
				wgDuplicate.createDonut(config.id, filter, res);
			});
		break;
	};
};
wgDuplicate.createDonut =  function(id, Type, dataSource){
 	$id = $("#"+id).find(".content");
 	$id.append("<div id='çhart'></div>"); 
 	 
 	 
	var legend = "<table class='donut_legend_custom' width='100%'>"; 
   	_.each(dataSource.Donut, function(o, i){
   		var title = o.category;
   		switch(o.category){
	        case'FMI':
				title = 'FMI'
	        break;
	        case'FMI_System':
				title = 'FMI Systems'
	        break;
	        case'FMI_TPS':
				title = 'FMI External'
	        break;
	        case'Systems':
				title = 'Systems'
	        break;
	        case'IGS':
				title = 'Intra-Group'
	        break;
	        default:
				title = 'In-Entity'
        } 
   		o.color = wgDuplicate.DonutseriesColors[i];
   		o.visible = true;
   		if(i == 0 || (i % 2) == 0)
   			legend += "</tr><tr>";
   		var percentage = (Math.abs(o.value) == 0) ? 0 : 100 / (dataSource.Total / o.value); 
   		legend +=   "<td width='50%'>"+
   						"<a class='legend-donut-"+i+"' >"+
							"<span class='pull-left title' style='color:"+o.color+"'><i class='fa fa-square' aria-hidden='true'></i>" +title+ "</span>"+
	   						"<span class='pull-right percentage' style='color:"+o.color+"'>"+percentage.toFixed(0)+"%</span>"+
   						"</a>"
   					"</td>";
   	});

 	legend += "<table>";
 	
 	$id.append(legend); 
 	
 	$chart = $id.find("#çhart");
 	$chart.html('')
    $chart.kendoChart({
        legend: {
            visible:false,
            labels: {
                font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
                template: "#if(dataItem.category==='FMI_Systems'){# #: 'FMI Systems' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'Intra-Group' # #}else if(dataItem.category=='FMI_TPS'){# #: 'FMI External' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='FMI'){# #: 'FMI' # #}else{# #: 'In-Entity' #&nbsp;# # #}# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; #= removeSpace(kendo.toString(percentage,'P0'))# &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;",
                color: "#0075B2"
            },
            margin:{
                visible:true,
                left:100,
                top:-30
            },
            position: "bottom",
        },
        chartArea: {
            height : 310,
            background: "transparent",
            width : 325,
            margin:{
                left:0,
                top:-40
            },
        },
        seriesDefaults: {
            holeSize: 60,
            labels: {
                visible: false,
                template: "#= removeSpace(kendo.toString(percentage,'P0'))#", 
                background: "transparent"
            }
        }, 
        series: [{
            type: "donut",
            data: dataSource.Donut ,
            overlay:{gradient:"none"},
        }],
        valueAxis:{
            visible:false,
            labels: {
                font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                visible: false,
                format:"{0:P0}",
            },
            majorGridLines: {
                visible: false
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            template: "#=kendo.toString(value,'N0')#"
        }
    });
    wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
};

// GRID
wgDuplicate.generateDatavizGrid  =  function(page, index){
	// $("#opt-grid-modal").modal('hide'); 

	var config = getDataViZActive(page, index);
		config.active(true);
		config.type("grid");
		config.loading(true);

	var payload = wgDuplicate.generatePayload(getTemplateActive(page).filter);
	var filter  = config.filter.value();
 	 
	switch(filter){
		case"Products":
			var url = "/widgetduplicate/getproductnamecef";
			wgDuplicate.createGridProduct(config.id, url, payload, config.loading);	
		break;
		case"countrybusinnessvalidated":
		case"countrybusinnessenriched":
			config.loading(false); 
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);      	
			payload.WorstType = filter;
        	var id = "fullDataViz"+page
			wgDuplicate.createGridFull(id, payload, template.mainpage.fulDataViz);
		break;

		case"countryValidated":
			config.loading(false); 
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);    
        	var id = "fullDataViz"+page;

			payload.Flag = "validated";
			getTemplateActive(page).filter.dailystatus.value = true;
			ajaxPost("/widgetduplicate/reportdailystatscountrysek", payload, function(res){
				wgDuplicate.createGridDailyStatusByCuntry(id,res.Data ,payload.Flag);
			});
		break;
		case"businessvalidated":
			config.loading(false); 
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);  
        	var id = "fullDataViz"+page;

			payload.Flag = "validated";
			getTemplateActive(page).filter.dailystatus.value =true;
			ajaxPost("/widgetduplicate/reportdailystatssek", payload, function(res){ 
				wgDuplicate.createGridDailyStatusByBusiness(id,res.Data ,payload.Flag);
			});
		break;
		case"countryConfirmed":
			config.loading(false); 
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);  
        	var id = "fullDataViz"+page;

			payload.Flag = "confirmed";
			getTemplateActive(page).filter.dailystatus.value = true;
			ajaxPost("/widgetduplicate/reportdailystatscountrysek", payload, function(res){
				wgDuplicate.createGridDailyStatusByCuntry(id,res.Data ,payload.Flag);
			});
		break;
		case"businessConfirmed":
			config.loading(false); 
    		var template = getTemplateActive(page);
            	template.mainpage.fulDataVizIndex(index);
            	template.mainpage.fulDataViz(true);  
        	var id = "fullDataViz"+page;

			payload.Flag = "confirmed";
			getTemplateActive(page).filter.dailystatus.value = true;
			ajaxPost("/widgetduplicate/reportdailystatssek", payload, function(res){ 
				wgDuplicate.createGridDailyStatusByBusiness(id,res.Data ,payload.Flag);
			});
		break;
		default:
			payload.WorstType = filter;
			var url = "/widgetduplicate/dgmappingteam"; 
			wgDuplicate.createGridNormal(config.id, url, payload, config.loading);	
	};
};
wgDuplicate.createGridProduct =  function(id, url, payload, loading){
	var $id = $("#"+id).find(".content"); 
		$id.html('');;
	$id.append("<div class='grid-preview product-grid'></div>");
	$grid = $id.find(".grid-preview");
	$grid.html('');
	$grid.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					ajaxPost(url, payload, function(datas){
						loading(false);
						wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
						option.success(limitResultGrid(datas,10));
					});
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data; 
                    } 
                },
			}
		},
		columns:[ 
            {
                field:"_id.productfunction",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"Product Name",
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                template: "<a href=\"\\#\" onclick='widget.popUpGridproduct(\"#:_id.productfunction#\",\"#:_id.receivercountry#\",\"#:_id.subgroupid#\",\"#:_id.cefcritical#\")'>#:_id.productfunction#</a>"
                	
            },
            {
                field:"_id.receivercountry",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"Country",
                width:100,
                attributes: {
                    "class": "field-ellipsis"
                },
            },
            {
                field:"_id.cefcritical",
                headerAttributes: {
                    "class": "align-left"
                },
                title:"CEF?",
                width:70,
                attributes: {
                    "class": "field-ellipsis"
                },
                template: "#if(_id.cefcritical=='Y'){# #: 'Yes' # #}else{# #: 'No' # #}#",
            },
        ],
		sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        height: 400,
	}); 
}; 
wgDuplicate.createGridNormal = function(id, url, payload, loading){
	var $id = $("#"+id).find(".content"); 
		$id.html('');
	$id.append("<div class='grid-preview normal-grid'></div>");
	$grid = $id.find(".grid-preview");
	$grid.html('');
	$grid.kendoGrid({
		dataSource: {
			transport: {
				read:function(option){
					ajaxPost(url, payload, function(datas){
						wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
						
						loading(false);  
						option.success(limitResultGrid(datas,10));
					});
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {
                    if (data.length == 0) {
                        return [];
                    } else {
                        return data; 
                    } 
                },
			}
		},
		columns:[ 
			{
				field:"Rank",
				headerAttributes: {
					"class": "align-left"
				},
				title:"Rank",
				width:75,
				attributes: {
					"class": "field-ellipsis rank"
				},
			},
			{
				field:"Country",
				headerAttributes: {
					"class": "align-left"
				},
				title:"Country",
				width:130,
				attributes: {
					"class": "field-ellipsis"
				},
			// template: "#if(oa.popupvalue()==true){# <a href=\"\\#\" onclick='oa.showDetailProductNameCEF(\"#:_id.productfunction#\",\"#:_id.receivercountry#\",\"#:_id.subgroupid#\",\"#:_id.cefcritical#\")'>#:_id.productfunction#</a> #}else{# #: _id.productfunction # #}#"
			},
			{
				field:"Count",
				headerAttributes: {
					"class": "align-left"
				},
				title:"% Validated",
				width:105,
				attributes: {
					"class": "field-ellipsis"
				},
			}, 			
		],
		sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        height: 400,
	});
}; 
wgDuplicate.createGridFull =  function(id, payload, loading){
	ajaxPost("/widgetduplicate/dgvalidatedcountryfield", payload, function(res){
		var columns = res.Data.Records;
		var $id = $("#"+id).find(".content");
			$id.html('');
			$id.append("<div class='grid-preview full-grid'></div>");
		var $grid = $id.find(".grid-preview");
		$grid.html(""); 
		$grid.kendoGrid({
			dataSource: {
				transport: {
					read:function(option){ 
						ajaxPost("/widgetduplicate/dgvalidatedcountry", payload, function(datas){ 

						    wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
							option.success(limitResultGrid(datas,10));
						}); 
					},
					parameterMap: function(data) {
						return JSON.stringify(data);
					},
				},
				schema: {
					data: function(data) {
	                    if (data.length == 0) {
	                        return [];
	                    } else {
	                        return data; 
	                    } 
	                },
				}
			},
			columns:columns,
			sortable: true,
	        filterable: {
	            extra:false, 
	            operators: {
	                string: {
	                    contains: "Contains",
	                    startswith: "Starts with",
	                    eq: "Is equal to",
	                    neq: "Is not equal to",
	                    doesnotcontain: "Does not contain",
	                    endswith: "Ends with"
	                },
	            }
	        },
	        height: 400,
		});
    	wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
	});
}; 
wgDuplicate.createGridDailyStatusByCuntry =  function(id, dataSource,Flag){
	var newDs = mappingData(dataSource);
	var $id = $("#"+id).find(".content");
   		$id.append("<div class='grid-pdf'></div>");
    $sel = $id.find(".grid-pdf")
    var Theader = [
      "<thead>",
        "<tr class='tbl-header'>",
          "<td colspan='2'>Static</td>",
          "<td colspan='3'>All</td>",
          "<td colspan='3'>Teams</td>",
          "<td colspan='3'>Systems</td>",
          "<td colspan='3'>FMIs</td>",
          "<td colspan='3'>TPS</td>",
          "<td colspan='2'>Total</td>",
        "<tr>",
        "<tr class='tbl-header'>",
          //Static
          "<td>Region</td>",
          "<td>T1 Country</td>",
          //ALL
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          
          //Teams
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          
          //Systems
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          
          //FMIs
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          
          //TPS
          "<td>#</td>",
          "<td>#<br/>"+capitalize(Flag)+"</td>",
          "<td>%<br/>"+capitalize(Flag)+"</td>",
           
          "<td>%<br/>"+capitalize(Flag)+"</td>",
          "<td>RAG</td>",
        "<tr>",
      "</thead>",
    ].join(" "); 
    var Tbody = [];
    var columnAtas = 0
    var counter = 0;
    var pageTbl = 0;
    $.each(newDs, function(i,o){
   
		Tbody.push([]);
		Tbody[pageTbl].push("<tr class='none'><td  colspan='22'>&nbsp;</td></tr>")    
		var rowspan = o.detail.length; 
		Tbody[pageTbl].push("<tr ><td style='border-left: 1px solid #000!important;' class='region' rowspan='"+rowspan+"'>"+o.Label+"</td>");
		 
		$.each(o.detail, function(index,v){
			counter +=1;

			if(index > 0){
				Tbody[pageTbl].push("<tr style='border-top: 1px solid #000;border-bottom: 1px solid #000;'>");
			}
			Tbody[pageTbl].push("<td class='main' align='left'>"+v.Label+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");

			Tbody[pageTbl].push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
			Tbody[pageTbl].push("<td class='main "+v.RAG+"' style='border-right: 1px solid #000!important;'>&nbsp;</td>"); 
			Tbody[pageTbl].push("</tr>");

		}); 
		if(counter == 15 || i == (newDs.length - 1)){
			if(counter > 0){
				$sel.append("<div class='dailystatus-grid'><table  class='dailystatus-grid'id='table-dailystatus"+pageTbl+"' style='margin-top:40px;' width='100%'>"+Theader+Tbody[pageTbl].join(" ")+"<table></div>");
			} else{
			  $sel.append("<div class='dailystatus-grid'><table  class='dailystatus-grid' id='table-dailystatus"+pageTbl+"' width='100%'>" + Theader + Tbody[pageTbl].join(" ") + "<table></div>");
			} 

			if(i != newDs.length - 1){
			    $sel.append("<div class='page-break'></div>")
			}else{
			    var marginTop = 670 - $('#table-dailystatus'+pageTbl).height();  
			    // $(".date-pdf").css({"margin-top":marginTop});
			}
			counter = 0;
			pageTbl +=1;
		}  
    });

    wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
};


function mappingData(dataSource){
 
	var results = [];
	var counter = 0;
	var newDs = [];
	var ds    = {label:"",detail:[]};
	var counter = 0;
	var page = 15
	for(var i in dataSource){
		var o = dataSource[i];
		for(var n in o.detail){
			counter+=1;
			var v = o.detail[n]
			ds.detail.push(v)
			if(n == (o.detail.length-1)){
				ds.Label = o.Label;
				newDs.push(ds); 
				ds = {label:"",detail:[]};
			}
			if(counter == page){
				ds.Label = o.Label;
				newDs.push(ds); 
				counter=0;
				ds = {label:"",detail:[]};
			}
		}
	}
 
	return newDs;
}; 
wgDuplicate.createGridDailyStatusByBusiness =  function(id, dataSource,Flag){ 
	var $id = $("#"+id).find(".content");
   		$id.append("<div class='grid-pdf'></div>");
    $sel = $id.find(".grid-pdf")
	var Theader = [
		"<thead>",
		"<tr class='tbl-header'>",
		"<td>Static</td>",
		"<td colspan='3'>All</td>",
		"<td colspan='3'>Teams</td>",
		"<td colspan='3'>Systems</td>",
		"<td colspan='3'>FMIs</td>",
		"<td colspan='3'>TPS</td>",
		"<td colspan='2'>Total</td>",
		"<tr>",
		"<tr class='tbl-header'>",
		"<td>Bussiness/Function</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>#</td>",
		"<td>#<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>%<br/>"+capitalize(Flag)+"</td>",
		"<td>RAG</td>",
		"<tr>",
		"</thead>",
	].join(" "); 
	var Tbody = []; 


	var tblIndex = 0;
	var counter = 0
	for(var i in dataSource){ 
		var v  = dataSource[i];

		Tbody.push("<tr>");
		Tbody.push("<td class='region' align='left'>"+v.Label+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.AllColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.AllColumn2,'n1')+"</td>");

		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TeamsColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TeamsColumn2,'n1')+"</td>");

		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.SystemsColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.SystemsColumn2,'n1')+"</td>");

		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.FMIColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.FMIColumn2,'n1')+"</td>");

		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn0,'n0')+"</td>");
		Tbody.push("<td class='main' align='right'>"+kendo.toString(v.TPSColumn1,'n0')+"</td>");
		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.TPSColumn2,'n1')+"</td>");

		Tbody.push("<td class='main col-percentage ' align='right'>"+kendo.toString(v.Total,'n1')+"</td>");
		Tbody.push("<td class='main "+v.RAG+"' style='border-right: 1px solid #000!important;'>&nbsp;</td>"); 

		Tbody.push("</tr>");

		counter += 1;
		if(counter == 15 || i == (dataSource.length - 1)){
			tblIndex += 1;
			counter = 0;

			if(tblIndex > 1){
				$sel.append("<div class='dailystatus-grid'><table    id='table-dailystatus"+tblIndex+"' style='margin-top:40px;' width='100%'>"+Theader+Tbody.join(" ")+"<table></div>");
			}else{
				$sel.append("<div class='dailystatus-grid'><table    id='table-dailystatus"+tblIndex+"' width='100%'>"+Theader+Tbody.join(" ")+"<table></div>");  
			}
			if(i != (dataSource.length - 1)){
				$sel.append("<div class='page-break'></div>"); 
			}
			Tbody = [];
		}
	}

    wgDuplicate.pullRequest(wgDuplicate.pullRequest() - 1);
}; 
wgDuplicate.loadTemplateSummary =  function(page, summary){
	_.each(summary, function(o,i){	 
		if(o.active())
			wgDuplicate.generateSummry(page, i);
	});
};
wgDuplicate.loadTemplateDataviz =  function(page, dataviz){
	_.each(dataviz, function(o,i){ 
	 
		if(o.active())
			wgDuplicate.generateDataviz(o.type(), page, i);
	});
};
wgDuplicate.downloadPdf =  function(){
}
wgDuplicate.GetBase64 =  function(){
		kendo.drawing.drawDOM($(".app-content"),{
			forcePageBreak	: ".page-break",
			paperSize 	: "a3",
			landscape 	: true,
			margin 		: {top:"5mm",left:"-2cm",right:"-2cm",bottom:"0cm"},
		})
	    .then(function (group) {
			return kendo.drawing.exportPDF(group);
	    })
		.done(function (data) { 
			wgDuplicate.base64Pdf( data);
			wgDuplicate.process.template(false);
		});
}