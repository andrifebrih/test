var sm = {};

sm.listCustomScenario = ko.observableArray([]);
sm.valueNewCustomScenario = ko.observable('');

sm.valueCustomScenario = ko.observable('');
sm.valueScenarioType = ko.observableArray([]);

sm.receivingCountry     = ko.observable([]);
sm.receivingCountryList = ko.observableArray([]);

sm.receivingLegalEntityList  = ko.observableArray([]);
sm.receivingLegalEntityListResult  = ko.observableArray([]);
sm.receivingLegalEntity      = ko.observableArray([]);

sm.supplycountryList    = ko.observableArray([]);
sm.supplycountry        = ko.observableArray([]);

sm.supplylegalentityList   = ko.observableArray([]);
sm.supplylegalentityListResult   = ko.observableArray([]);
sm.supplylegalentity       = ko.observableArray([]);

sm.categorynameList = ko.observableArray([]);
sm.categoryname     = ko.observableArray([]);

sm.productList =  ko.observableArray([]);
sm.product = ko.observableArray([]);

sm.valueCriticalStatus = ko.observableArray(['N']);
sm.cefList = ko.observableArray([{value:"Y",text:"Yes"},{value:"N",text:"No"}]);
sm.dataSummaryBox = ko.observableArray([]);

sm.loadingScenario = ko.observable(false)
sm.loadingScenarioGrid = ko.observable(false)
sm.changeResultScenario = ko.observable(false)

sm.supplyCountryResult = ko.observableArray([]);
sm.supplyLegalEntityResult = ko.observableArray([]);

sm.receivingLegalEntityResult = ko.observableArray([]);
sm.receiverCountryResult = ko.observableArray([]);

sm.statusTab = ko.observable('impactRecipient')

sm.statusGridScenario = ({sla: false, ctr: false, msa: false, lvl1: false, lvl2: false, lvl3: false, teams: false, tpv: false, is: false, es: false, dc: false, bld: false})

sm.changeCustomScenario = function(e){
  // console.log(e.sender._old)
  sm.valueCustomScenario(e.sender._old)
  var payload = {
    Id : sm.valueCustomScenario()[0]
  }
  if (sm.valueCustomScenario().length !== 0){
    ajaxPost("/scenarios/getdetailsscenarios",payload , function (res){
      sm.valueCriticalStatus(res.Data.valueCriticalStatus)
      sm.receivingCountry(res.Data.receivingCountry)
      sm.receivingLegalEntity(res.Data.receivingLegalEntity)
      sm.supplycountry(res.Data.supplierCountry)
      sm.supplylegalentity(res.Data.supplierLegalEntity) 
      sm.categoryname(res.Data.bussines)
      sm.product(res.Data.product) 
      sm.valueScenarioType(res.Data.scenarioType)
      sm.getDataSummary()
      sm.createGridScenarioSLAS()   
      });
  }else {
    sm.resetValueScenario()    
  }

}

sm.resetValueScenario = function(){
  sm.valueCustomScenario([])
  sm.receivingCountry([])
  sm.receivingLegalEntity([])
  sm.supplycountry([])
  sm.supplylegalentity([]) 
  sm.categoryname([])
  sm.product([])
  sm.valueScenarioType([])
  sm.valueCriticalStatus([])
  sm.supplyCountryResult([])
  sm.supplyLegalEntityResult([])
  sm.receiverCountryResult([])
  sm.receivingLegalEntityResult([])
  sm.getDataSummary()
  sm.createGridScenarioSLAS()
  // $("#formResultScenario").hide(1000)
}

sm.onChangeScenarioType = function(e){
  sm.valueScenarioType(e.sender._old)
  //sm.getSupplierCountry()
  //sm.getlegalentitysupplier()
  sm.getReceiverCountry()
  sm.getLegalentityReceiver()
  sm.getcategory()
  sm.getproductfunction()
  sm.getDataSummary()
}

sm.onChangeBusinessFunction = function(e){
  sm.categoryname(e.sender._old)
  if (sm.categoryname().length === 0){
    sm.getcategory()
  }
  //sm.getSupplierCountry()
  //sm.getlegalentitysupplier()
  sm.refreshScenario() 
  sm.getReceiverCountry()
  sm.getLegalentityReceiver()  
  sm.getproductfunction()
  sm.getDataSummary()  
}

sm.onChangeProduct = function(e){
  sm.product(e.sender._old)
  if (sm.product().length === 0){
    sm.getproductfunction()
  }
  //sm.getSupplierCountry()
  //sm.getlegalentitysupplier()
  sm.getReceiverCountry()
  if (sm.statusTab() == "impactSupplier"){
    sm.getlegalentitysupplier()
  }else {
    sm.getLegalentityReceiver()  
  }
  sm.getcategory()
  sm.refreshScenario()  
  sm.getDataSummary()
}

sm.onChangeSupplierCountry = function(e){
  sm.supplycountry(e.sender._old)
  if (sm.supplycountry().length === 0){
    sm.getSupplierCountry()  
  }
  // sm.getSupplierCountry()
  // sm.getlegalentitysupplier()
  // sm.getReceiverCountry()
  // sm.getLegalentityReceiver()
  // sm.getcategory()
  // sm.getproductfunction()
  sm.supplylegalentity([])
  sm.getlegalentitysupplier()
  sm.refreshScenario()
  sm.getDataSummary()
}

sm.onChangeSupplierLegalEntity = function(e){
  sm.supplylegalentity(e.sender._old)
  if (sm.supplylegalentity().length === 0){
    sm.getlegalentitysupplier()  
  }

  sm.refreshScenario()
  sm.getDataSummary()
  //sm.getSupplierCountry()
  // //sm.getlegalentitysupplier()
  // sm.getReceiverCountry()
  // sm.getLegalentityReceiver()
  // sm.getcategory()
  // sm.getproductfunction() 
}

sm.onChangeReceiverCountry = function(e){
  sm.receivingCountry(e.sender._old)
  if (sm.receivingCountry().length === 0){
    sm.getReceiverCountry()  
  }
  //sm.getSupplierCountry()
  //sm.getlegalentitysupplier()
  // sm.getReceiverCountry()
  sm.receivingLegalEntity([])
  sm.getLegalentityReceiver()
  sm.getcategory()
  sm.getproductfunction()
  sm.refreshScenario()
  sm.getDataSummary()
}

sm.onChangeReceiverLegalEntity = function(e){
  sm.receivingLegalEntity(e.sender._old)
  if (sm.receivingLegalEntity().length === 0){
    sm.getLegalentityReceiver()  
  }
  //sm.getSupplierCountry()
  //sm.getlegalentitysupplier()
  sm.getReceiverCountry()
  // sm.getLegalentityReceiver()
  sm.getcategory()
  sm.getproductfunction()
  sm.refreshScenario()
  sm.getDataSummary()
}

sm.onChangeSupplierCountry2 = function(e){
  sm.supplyCountryResult(e.sender._old)
  sm.getlegalentitysupplierResult()  
  sm.changeResultScenario(true)
  sm.supplyLegalEntityResult([])
  sm.getcategory()
  sm.getproductfunction()
  sm.refreshScenario()
  sm.getDataSummary()
}

sm.onChangeSupplierLegalEntity2 = function(e){
  sm.supplyLegalEntityResult(e.sender._old)
  if (sm.supplyLegalEntityResult().length == 0){
    sm.getlegalentitysupplierResult()  
  }
  sm.changeResultScenario(true)
  sm.getcategory()
  sm.getproductfunction()
  sm.refreshScenario()
  sm.getDataSummary()
}


sm.onChangeReceiverCountry2 = function(e){
  sm.receiverCountryResult(e.sender._old)
  sm.getLegalentityReceiverResult()
  sm.refreshScenario()
  sm.changeResultScenario(true)
  sm.receivingLegalEntityResult([])
  sm.getcategory()
  sm.getproductfunction()
  sm.getDataSummary()
}

sm.onChangeReceiverLegalEntity2 = function(e){
  sm.receivingLegalEntityResult(e.sender._old)
  if (sm.receivingLegalEntityResult().length == 0){
    sm.getLegalentityReceiverResult()
  }
  sm.changeResultScenario(true)
  sm.getcategory()
  sm.getproductfunction()
  sm.refreshScenario()
  sm.getDataSummary()
}

sm.onChangeCriticalStatus = function(e){
  console.log(e);
  sm.valueCriticalStatus([e.sender._old])
  //sm.getSupplierCountry()
  //sm.getlegalentitysupplier()
  sm.getReceiverCountry()
  sm.getLegalentityReceiver()
  sm.getcategory()
  sm.getproductfunction()
  sm.refreshScenario()
  sm.getDataSummary()     
}

sm.getReceiverCountry = function(){
  payload = {

  }

  ajaxPost("/ociranalysis/getreceivercountry",payload, function (res){
    var receivingCountryList = [];
    $.each(res, function(i,v){
        receivingCountryList.push({text:v._id, value:v._id})
    });
    sm.receivingCountryList(receivingCountryList);
  });

}

sm.getSupplierCountry = function(){
  payload = {
   
  }

  ajaxPost("/scenarios/getsuppliercountry",payload, function (res){
    var supplycountryList = [];
    $.each(res, function(i,v){
        supplycountryList.push({text:v._id, value:v._id})
    });
    sm.supplycountryList(supplycountryList);
  });

}

sm.getLegalentityReceiver = function(){
  payload = {
    ReceiverCountry : sm.receivingCountry() == undefined ? [] : sm.receivingCountry(),
    ReceiverLegalEntity : [],
    SupplierCountry : sm.supplycountry() == undefined ? [] : sm.supplycountry(),
    SupplierLegalEntity : sm.supplylegalentity(), 
    Categoryname : sm.categoryname(),
    Suppliertype: '',
    Productfunction : sm.product()
  }
  
  sm.receivingLegalEntityList([]); 
  ajaxPost("/ociranalysis/getlegalentityreceiver",payload, function (res){
    var receivingLegalEntityList = [];
    $.each(res, function(i,v){
        receivingLegalEntityList.push({text:v._id, value:v._id})
    });
    sm.receivingLegalEntityList(receivingLegalEntityList);
  });
}

sm.getLegalentityReceiverResult = function(){
  payload = {
    ReceiverCountry : sm.receiverCountryResult(),
    ReceiverLegalEntity : [],
    SupplierCountry : sm.supplycountry(),
    SupplierLegalEntity : sm.supplylegalentity(), 
    Categoryname : sm.categoryname(),
    Suppliertype: '',
    Productfunction : sm.product()
  }

  sm.receivingLegalEntityListResult([]);
  ajaxPost("/ociranalysis/getlegalentityreceiver",payload, function (res){
      var receivingLegalEntityListResult = [];
      $.each(res, function(i,v){
          receivingLegalEntityListResult.push({text:v._id, value:v._id})
      });
      sm.receivingLegalEntityListResult(receivingLegalEntityListResult);
  });  
}

sm.getlegalentitysupplier = function(){
  payload = {
    ReceiverCountry : sm.receivingCountry() == undefined ? [] : sm.receivingCountry(),
    ReceiverLegalEntity : sm.receivingLegalEntity(),
    SupplierCountry : sm.supplycountry() == undefined ? [] : sm.supplycountry(),
    SupplierLegalEntity : [], 
    Categoryname : sm.categoryname(),
    Suppliertype: '',
    Productfunction : sm.product()
  }  
  sm.supplylegalentity([]);
  ajaxPost("/ociranalysis/getlegalentitysupplier",payload, function (res){
      var supplylegalentityList = [];
      $.each(res, function(i,v){
          supplylegalentityList.push({text:v._id, value:v._id})
      });
      sm.supplylegalentityList(supplylegalentityList);
  });
}

sm.getlegalentitysupplierResult = function(){
  payload = {
    ReceiverCountry : sm.receivingCountry(),
    ReceiverLegalEntity : sm.receivingLegalEntity(),
    SupplierCountry : sm.supplyCountryResult() ,
    SupplierLegalEntity : [], 
    Categoryname : sm.categoryname(),
    Suppliertype: '',
    Productfunction : sm.product()
  }  
  
  sm.supplylegalentityListResult([]); 
  ajaxPost("/scenarios/getsupplierlegal",payload, function (res){
    var supplylegalentityListResult = [];
    $.each(res, function(i,v){
        supplylegalentityListResult.push({text:v._id, value:v._id})
    });
    sm.supplylegalentityListResult(supplylegalentityListResult);
  });
}

sm.getcategory = function(){
  if (sm.statusTab() == "impactRecipient"){
    payload = {
      ReceiverCountry : sm.receivingCountry(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierCountry : sm.supplyCountryResult(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(), 
      Categoryname : sm.categoryname(),
      Suppliertype: '',
      Productfunction : sm.product()
    }  
  }else {
    payload = {
      ReceiverCountry : sm.receiverCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierCountry : sm.supplycountry(),
      SupplierLegalEntity : sm.supplylegalentity(), 
      Categoryname : sm.categoryname(),
      Suppliertype: '',
      Productfunction : sm.product()
    }
  }

  ajaxPost("/ociranalysis/getcategory",payload, function (res){
      var categorynameList = [];
      $.each(res, function(i,v){
          categorynameList.push({text:v._id, value:v._id})
      });
      sm.categorynameList(categorynameList);
  });  
}
 
sm.getproductfunction = function(){
  if (sm.statusTab() == "impactRecipient"){
    payload = {
      ReceiverCountry : sm.receivingCountry(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierCountry : sm.supplyCountryResult(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(), 
      Categoryname : sm.categoryname(),
      Suppliertype: '',
      Productfunction : sm.product()
    }  
  }else {
    payload = {
      ReceiverCountry : sm.receiverCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierCountry : sm.supplycountry(),
      SupplierLegalEntity : sm.supplylegalentity(), 
      Categoryname : sm.categoryname(),
      Suppliertype: '',
      Productfunction : sm.product()
    }
  }
  

  ajaxPost("/ociranalysis/getproductfunction",payload, function (res){
    var productList = [];
    $.each(res, function(i,v){
        productList.push({text:v._id, value:v._id})
    });
    sm.productList(productList);
  });  
}

sm.getListCustomScenario = function(){
  var payload = {
    Id : ""
  };
  ajaxPost("/scenarios/getscenarios",payload , function (res){
    // console.log(res);
    sm.listCustomScenario(res.Data)
  })
}

sm.saveCustomScenario = function(){
  var validator = $("#validatorScenario").data("kendoValidator");
  var payload = {
    scenarioname :sm.valueNewCustomScenario(),
    scenarioType: sm.valueScenarioType(),
    bussines: sm.categoryname(),
    supplierCountry: sm.supplycountry(),
    supplierLegalEntity : sm.supplylegalentity(),
    receivingCountry: sm.receivingCountry(),
    receivingLegalEntity: sm.receivingLegalEntity(),
    product:sm.product(),
    valueCriticalStatus: sm.valueCriticalStatus()
  }

  if(validator ==  undefined){
     validator = $("#validatorScenario").kendoValidator().data("kendoValidator");
  }
  
  if (validator.validate()){
    ajaxPost("/scenarios/savescenarios",payload , function (res){
      // console.log(res);
      if (!res.IsError){
        setTimeout(function() {
          swal("Success","Data have been saved", "success");
          sm.valueNewCustomScenario('')
          sm.getListCustomScenario()  
          sm.resetValueScenario();
        }, 1000);
      }
    })  
  }else {
    swal("Error!","Unable to validate process", "error"); 
  }
}
sm.createSummaryBox= function(payload, prop){ 
  ajaxPost("/widgetanalysis/getwidgetsummarybox",payload , function (res){
    $("#Sumbox"+(prop.index+1)).text(kendo.toString(res.Data,'N0'))
      sm.loadingSummary[prop.type] = false;
      if(!sm.loadingSummary['cef'] && !sm.loadingSummary['level1Process'] && !sm.loadingSummary['suppliers'] && !sm.loadingSummary['fte'] && !sm.loadingSummary['contract'] && !sm.loadingSummary['buildings'] && !sm.loadingSummary['fmis']&& !sm.loadingSummary['resolution'] ){
         sm.loadingScenario(false)
      }
  });
}
sm.getDataSummary = function(){
  var arrBoxType = [{index:0, BoxType:"CEF|necessary",type:'cef'},
                    {index:1, BoxType:"Level1Process|necessary",type:'level1Process'},
                    {index:2, BoxType:"Suppliers|necessary",type:'suppliers'},
                    {index:3, BoxType:"FTE|necessary",type:'fte'},
                    {index:4, BoxType:"Contract|necessary",type:'contract'},
                    {index:5, BoxType:"Buildings|necessary",type:'buildings'}, 
                    {index:6, BoxType:"FMIS|necessary",type:'fmis'}, 
                    {index:7, BoxType:"Resolution|necessary",type:'resolution'}]

  if(sm.statusTab() == 'impactRecipient'){
    var defaultPayload = {
      Cefcritical : sm.valueCriticalStatus(),
      ReceiverCountry : sm.receivingCountry(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      Categoryname : sm.categoryname(),
      Productfunction : sm.product(),
      SupplierCountry : sm.supplycountry(),
      SupplierCountry : sm.supplyCountryResult(),
      SupplierLegalEntity : sm.supplyLegalEntityResult()  
    }
  }else{
    var defaultPayload = {
      Cefcritical : sm.valueCriticalStatus(),
      ReceiverCountry : sm.receiverCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      Categoryname : sm.categoryname(),
      Productfunction : sm.product(),
      SupplierCountry : sm.supplycountry(),
      SupplierLegalEntity : sm.supplylegalentity()  
    }
  }
  sm.loadingSummary = {'cef':true,'level1Process':true,'suppliers':true,'fte':true,'contract':true,'buildings':true,'fmis':true,'resolution':true};

  sm.loadingScenario(true)
  for(var i in arrBoxType){
    payload = JSON.parse(JSON.stringify( $.extend(defaultPayload, {BoxType:arrBoxType[i].BoxType})))
    sm.createSummaryBox(payload, arrBoxType[i])
  }
  // sm.loadingScenario(false)
  // sm.loadingScenario(true)
  // sm.dataSummaryBox([])
  // ajaxPost("/widgetanalysis/getwidgetsummarybox",payload1 , function (res){
  //     var temp = {
  //       summary: '',
  //       value : ''
  //     }
  //     temp.summary = arrBoxType[0]
  //     temp.value = res.Data
  //     sm.dataSummaryBox().push(temp)
  //     ajaxPost("/widgetanalysis/getwidgetsummarybox",payload2 , function (res){
  //       var temp = {
  //         summary: '',
  //         value : ''
  //       }
  //       temp.summary = arrBoxType[1]
  //       temp.value = res.Data
  //       sm.dataSummaryBox().push(temp)
  //       ajaxPost("/widgetanalysis/getwidgetsummarybox",payload3 , function (res){
  //         var temp = {
  //           summary: '',
  //           value : ''
  //         }
  //         temp.summary = arrBoxType[2]
  //         temp.value = res.Data
  //         sm.dataSummaryBox().push(temp)

  //         ajaxPost("/widgetanalysis/getwidgetsummarybox",payload4 , function (res){
  //           var temp = {
  //             summary: '',
  //             value : ''
  //           }  
  //           temp.summary = arrBoxType[3]
  //           temp.value = res.Data
  //           sm.dataSummaryBox().push(temp)

  //           ajaxPost("/widgetanalysis/getwidgetsummarybox",payload5 , function (res){
  //             var temp = {
  //               summary: '',
  //               value : ''
  //             }  
  //             temp.summary = arrBoxType[4]
  //             temp.value = res.Data
  //             sm.dataSummaryBox().push(temp)

  //             ajaxPost("/widgetanalysis/getwidgetsummarybox",payload6 , function (res){
  //               var temp = {
  //                 summary: '',
  //                 value : ''
  //               }  

  //               temp.summary = arrBoxType[5]
  //               temp.value = res.Data
  //               sm.dataSummaryBox().push(temp) 

  //               ajaxPost("/widgetanalysis/getwidgetsummarybox",payload7 , function (res){
  //                 var temp = {
  //                   summary: '',
  //                   value : ''
  //                 }
  //                 temp.summary = arrBoxType[6]
  //                 temp.value = res.Data
  //                 sm.dataSummaryBox().push(temp)

  //                 ajaxPost("/widgetanalysis/getwidgetsummarybox",payload8 , function (res){
  //                   var temp = {
  //                     summary: '',
  //                     value : ''
  //                   }
  //                   temp.summary = arrBoxType[7]
  //                   temp.value = res.Data
  //                   sm.dataSummaryBox().push(temp)
                    
                    // $("#formResultScenario").show(1000)
                    // sm.viewResultScenario(true)
                    // if (sm.dataSummaryBox().length !== 8){
                    //   var uniq = []
                    //   for (var i in sm.dataSummaryBox()){
                    //     if (i == 0){
                    //       uniq.push(sm.dataSummaryBox()[i])
                    //     }else if (sm.dataSummaryBox()[i].summary !== sm.dataSummaryBox()[i-1].summary){
                    //       uniq.push(sm.dataSummaryBox()[i])
                    //     }
                    //   }
                    //   sm.dataSummaryBox(uniq)  
                    // }
                    
  //                   $.each(sm.dataSummaryBox(), function(i, v){
  //                     $("#Sumbox"+(i+1)).text(kendo.toString(v.value,'N0'))
  //                     // console.log(v)
  //                   })
  //                   sm.loadingScenario(false)
  //                 })
  //               })
  //             })
  //           })
  //         })
  //       })
  //     })

  // })    
  // sm.changeResultScenario(false)
}

sm.createGridScenarioSLAS = function(){
  // $("html, body").animate({ scrollTop: $(document).height() }, 3000); 
  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "sla"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "sla"
    };
  }

  var url = "/scenarios/getdatagrid";
  
  if (sm.statusGridScenario.sla == false){

    $("#gridtab1SLA").html("");
    $("#gridtab1SLA").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res)
                      option.success(res.Data);
                      sm.loadingScenarioGrid(false)
                      setTimeout(function() {
                        $("#gridtab1SLA").data("kendoGrid").resize();  
                      }, 1000);  
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.slaid", dir:"asc"},{field: "_id.sladescription", dir:"asc"},{field: "_id.Slaparentreference", dir:"asc"},{field: "_id.slamanagername", dir:"asc"},{field: "_id.slaocircompliant", dir:"asc"},{field: "_id.armslengthchargingstructure", dir:"asc"},{field: "_id.slabasisforrecharge", dir:"asc"},{field: "_id.iscrefid", dir:"asc"}]  
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        scrollable:{
            virtual: true
        },
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1
        },
        columns: [{
            field:"_id.slaid",
            headerAttributes: {
                "class": "align-left"
            },
            title:"SLA ID",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:150,

          },{
            field:"_id.sladescription",
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
            title:"SLA Description",
          },{
            field:"_id.Slaparentreference",
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
            title:"SLA Parent Reference",
          },{
            field:"_id.slamanagername",
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
            title:"Manager Name",
          },{
            field:"_id.slaocircompliant",
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
            title:"SLA Compliant",
          },{
            field:"_id.armslengthchargingstructure",
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
            title:"Arms Length Charging Structure",
          },{
            field:"_id.slabasisforrecharge",
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
            title:"SLA Basis for Recharge",
          },{
            field:"_id.iscrefid",
            headerAttributes: {
                "class": "align-right"
            },
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
            title:"MSA",
          } 
        ],
      });
      sm.statusGridScenario.sla = true
  }
  
}

sm.createGridScenarioContract = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "contract"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "contract"
    };
  }

  if (sm.statusGridScenario.ctr == false){

    $("#gridtab2Contract").html("");
    $("#gridtab2Contract").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res)
                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);
                      setTimeout(function() {
                        $("#gridtab2Contract").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10 ,
          sort: [{field: "_id.contractid", dir:"asc"},{field: "_id.supplierlegalentity", dir:"asc"},{field: "_id.contractdescription", dir:"asc"},{field: "_id.legalcontractsignatory", dir:"asc"},{field: "_id.contractavailable", dir:"asc"},{field: "_id.contractlibrary", dir:"asc"},{field: "_id.checker", dir:"asc"},{field: "_id.perpetualcontractresolution", dir:"asc"},{field: "_id.contractexpiry", dir:"asc"},{field: "_id.contractresolutioncritical", dir:"asc"},{field: "_id.contractmeetspra", dir:"asc"},{field: "_id.contractresolutionlangproofed", dir:"asc"}]   
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.contractid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"Contract ID",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width: 100,
          },{
            field:"_id.supplierlegalentity",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Supplier Legal Entity",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.contractdescription",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Contract Description",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 240,
          },{
            field:"_id.legalcontractsignatory",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Legal Contract Signatory",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.contractavailable",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Contract Available",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.iscontractglobal",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Global Contract?",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.contractlibrary",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Contract Library",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.checker",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Contract Manager",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.perpetualcontractresolution",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Perpetual Contract?",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.contractexpiry",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Contract Expirty",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.contractresolutioncritical",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Contract Resolution Critical",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.contractmeetspra",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Contract meets PRA?",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.contractresolutionlangproofed",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Contract Resolution lang Proofed?",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          } 
        ],
      });
    sm.statusGridScenario.ctr = true
   } 
  
}

sm.createGridScenarioMsas = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "msa"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "msa"
    };
  }

  if (sm.statusGridScenario.msa == false){

    $("#gridtab3MSAs").html("");
    $("#gridtab3MSAs").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res)
                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);
                      setTimeout(function() {
                        $("#gridtab3MSAs").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.iscrefid", dir:"asc"},{field: "_id.iscdescription", dir:"asc"},{field: "_id.suppliercount", dir:"asc"},{field: "_id.receivercount", dir:"asc"},{field: "_id.slaid", dir:"asc"}]     
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.iscrefid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"MSAs ID",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:100,
          },{
            field:"_id.iscdescription",
            headerAttributes: {
                "class": "align-left"
            },
            title:"MSAs Description",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
          },{
            field:"_id.suppliercount",
            headerAttributes: {
                "class": "align-right"
            },
            title:"Supplier Count",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
          },{
            field:"_id.receivercount",
            headerAttributes: {
                "class": "align-right"
            },
            title:"Receiver Count",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
          },{
            field:"_id.slaid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"SLAs",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
          } 
        ],
      });
     sm.statusGridScenario.msa = true 
    }
}

sm.createGridScenarioLevel1 = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "level1"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "level1"
    };
  }

  if (sm.statusGridScenario.lvl1 == false){ 

    $("#gridtab4lvl1").html("");
    $("#gridtab4lvl1").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res)
                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);
                      setTimeout(function() {
                        $("#gridtab4lvl1").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.parentprocessname", dir:"asc"},{field: "_id.contractid", dir:"asc"},{field: "_id.iscrefid", dir:"asc"},{field: "_id.slaid", dir:"asc"}]     
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.parentprocessname",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Level 1 Processes",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
          },{
            field:"_id.contractid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"Contracts",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
          },{
            field:"_id.iscrefid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"SLAs",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
          },{
            field:"_id.slaid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"MSAs",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
          } 
        ],
      });
      sm.statusGridScenario.lvl1 = true
    }
}

sm.createGridScenarioLevel2 = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "level2"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "level2"
    };
  }

  if (sm.statusGridScenario.lvl2 == false){ 

    $("#gridtab4lvl2").html("");
    $("#gridtab4lvl2").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res)
                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);
                      setTimeout(function() {
                        $("#gridtab4lvl2").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.parentprocessname", dir:"asc"},{field: "_id.processname", dir:"asc"}, {field: "_id.contractid", dir:"asc"},{field: "_id.iscrefid", dir:"asc"},{field: "_id.slaid", dir:"asc"}]     
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.parentprocessname",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Level 1 Processes",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
          },{
            field:"_id.processname",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Level 2 Processes",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width:180,
          },{
            field:"_id.contractid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"Contracts",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
          },{
            field:"_id.iscrefid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"SLAs",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
          },{
            field:"_id.slaid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"MSAs",
            attributes: {
                "class": "field-ellipsis align-right"
            },
            width:180,
          } 
        ],
      });
    sm.statusGridScenario.lvl2 = true
   } 
}

sm.createGridScenarioLevel3 = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "level3"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "level3"
    };
  }

  if (sm.statusGridScenario.lvl3 == false){

  $("#gridtab4lvl3").html("");
  $("#gridtab4lvl3").kendoGrid({
      dataSource: {
        transport: {
          read:function(option){
            sm.loadingScenarioGrid(true)
            ajaxPost("/scenarios/getdatagrid", payload, function(res){
              // console.log("isi :", res)
                    option.success(res.Data);
                    sm.loadingScenarioGrid(false);
                    setTimeout(function() {
                      $("#gridtab4lvl3").data("kendoGrid").resize();  
                    }, 500);
                });
              },
          parameterMap: function(data) {
             return JSON.stringify(data);
            },                                                
          },
          schema: {
            data: function(data) {
                if (data.length == 0) {
                    return [];
                } else {
                    return data; 
                } 
              },
          },
        /*serverFiltering: true,*/
        pageSize: 10,
        sort: [{field: "_id.parentprocessname", dir:"asc"},{field: "_id.processname", dir:"asc"}, {field: "_id.servicedescription", dir:"asc"},{field: "_id.contractid", dir:"asc"},{field: "_id.iscrefid", dir:"asc"},{field: "_id.slaid", dir:"asc"}]     
      },
      height: 350,
      filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
      scrollable: true,
      sortable: true,
      excel: {
          fileName: "Level 1 Processes Name.xlsx",
          allPages: true
      },
      columnMenu: false,
      pageable: {
          refresh: true,
          pageSizes: true,
          buttonCount: 5
      },
      columns: [{
          field:"_id.parentprocessname",
          headerAttributes: {
              "class": "align-left"
          },
          title:"Level 1 Processes",
          attributes: {
              "class": "field-ellipsis align-left"
          },
          width:180,
        },{
          field:"_id.processname",
          headerAttributes: {
              "class": "align-left"
          },
          title:"Level 2 Processes",
          attributes: {
              "class": "field-ellipsis align-left"
          },
          width:180,
        },{
          field:"_id.servicedescription",
          headerAttributes: {
              "class": "align-left"
          },
          title:"Level 3 Processes",
          attributes: {
              "class": "field-ellipsis align-left"
          },
          width:180,
        },{
          field:"_id.contractid",
          headerAttributes: {
              "class": "align-right"
          },
          title:"Contracts",
          attributes: {
              "class": "field-ellipsis align-right"
          },
          width:180,
        },{
          field:"_id.iscrefid",
          headerAttributes: {
              "class": "align-right"
          },
          title:"SLAs",
          attributes: {
              "class": "field-ellipsis align-right"
          },
          width:180,
        },{
          field:"_id.slaid",
          headerAttributes: {
              "class": "align-right"
          },
          title:"MSAs",
          attributes: {
              "class": "field-ellipsis align-right"
          },
          width:180,
        } 
      ],
    });
    sm.statusGridScenario.lvl3 = true    
  }  
}

sm.createGridScenarioTeams = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "teams"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "teams"
    };
  }

  if (sm.statusGridScenario.teams == false){  

    $("#gridtab7teams").html("");
    $("#gridtab7teams").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res.Data[0]._id)

                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);

                      setTimeout(function() {
                        $("#gridtab7teams").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.suppliercountry", dir: "asc"},{field: "_id.functionname", dir: "asc"},{field: "_id.suppliername", dir: "asc"},{field: "_id.checker", dir: "asc"},{field: "_id.servicefte", dir: "asc"},{field: "_id.buildingname", dir: "asc"},{field: "_id.teamcostcentre", dir: "asc"},{field: "_id.iscrefid", dir: "asc"},{field: "_id.slaid", dir: "asc"}]
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.suppliercountry",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Supplier",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
            template: "#= _id.suppliercountry + ' - ' + _id.supplierlegalentity #",
          },{
            field:"_id.functionname",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Function Name",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.suppliername",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Team Name",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.checker",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Unite Head",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.servicefte",
            headerAttributes: {
                "class": "align-right"
            },
            title:"Total FTE",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            },
            format:"{0:N0}"
          },{
            field:"_id.servicefte",
            headerAttributes: {
                "class": "align-right"
            },
            title:"% of FTE Utilized",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            },
            hidden: true
          },{
            field:"_id.buildingname",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Building Name",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.teamcostcentre",
            headerAttributes: {
                "class": "align-right"
            },
            title:"Cost Center",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            }
          },{
            field:"_id.iscrefid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"SLAs",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            }
          },{
            field:"_id.slaid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"MSAs",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            }
          } 
        ],
      });
    sm.statusGridScenario.teams = true
  }

}

sm.createGridScenarioTPV = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "tpv"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "tpv"
    };
  }

  if (sm.statusGridScenario.tpv == false){


    $("#gridtab8TPV").html("");
    $("#gridtab8TPV").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res.Data[0]._id)

                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);

                      setTimeout(function() {
                        $("#gridtab8TPV").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.supplierlegalentity", dir: "asc"},{field: "_id.vendorid", dir: "asc"},{field: "_id.servicetype", dir: "asc"},{field: "_id.checker", dir: "asc"},{field: "_id.contractid", dir: "asc"}]
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.vendorid",
            headerAttributes: {
                "class": "align-left"
            },
            title:"External Vendor ID",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-rigth"
            }
          },{
            field:"_id.supplierlegalentity",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Supplier Legal Entity",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.servicetype",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Service Type",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.checker",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Supplier Manager",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.contractid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"Contracts",
            width: 180,
            attributes: {
                "class": "-ellipsis align-right"
            }
          }
        ],
      });
    sm.statusGridScenario.tpv = true    
  }
}

sm.createGridScenarioIS = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "internal"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "internal"
    };
  }

  if (sm.statusGridScenario.is == false){

    $("#gridtab9IS").html("");
    $("#gridtab9IS").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res.Data[0]._id)

                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);

                      setTimeout(function() {
                        $("#gridtab9IS").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.suppliercountry", dir: "asc"},{field: "_id.suppliername", dir: "asc"},{field: "_id.itbusiness", dir: "asc"},{field: "_id.servicedescription", dir: "asc"},{field: "_id.itameuc", dir: "asc"},{field: "_id.servicefte", dir: "asc"},{field: "_id.checker", dir: "asc"},{field: "_id.contractid", dir: "asc"}]
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.suppliercountry",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Vendor Name",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
            template: "#= _id.suppliercountry + ' - ' + _id.supplierlegalentity #",
          },{
            field:"_id.suppliername",
            headerAttributes: {
                "class": "align-left"
            },
            title:"System Name",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.itbusiness",
            headerAttributes: {
                "class": "align-left"
            },
            title:"IT Product or Business Service",
            width: 240,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.servicedescription",
            headerAttributes: {
                "class": "align-left"
            },
            title:"System Description",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.itameuc",
            headerAttributes: {
                "class": "align-right"
            },
            title:"ITAM/EUC",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            },
          },{
            field:"_id.checker",
            headerAttributes: {
                "class": "align-left"
            },
            title:"PSS Head",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.slaid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"SLAs",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            }
          } 
        ],
      });
    sm.statusGridScenario.is = true    
  }
}

sm.createGridScenarioES = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "external"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "external"
    };
  }

  if (sm.statusGridScenario.es == false){

    $("#gridtab10ES").html("");
    $("#gridtab10ES").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res.Data[0]._id)

                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);

                      setTimeout(function() {
                        $("#gridtab10ES").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.suppliercountry", dir: "asc"},{field: "_id.suppliername", dir: "asc"},{field: "_id.itbusiness", dir: "asc"},{field: "_id.servicedescription", dir: "asc"},{field: "_id.itameuc", dir: "asc"},{field: "_id.servicefte", dir: "asc"},{field: "_id.checker", dir: "asc"},{field: "_id.slaid", dir: "asc"},{field: "_id.contractid", dir: "asc"}]
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.suppliercountry",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Vendor Name",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
            template: "#= _id.suppliercountry + ' - ' + _id.supplierlegalentity #",
          },{
            field:"_id.suppliername",
            headerAttributes: {
                "class": "align-left"
            },
            title:"System Name",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.itbusiness",
            headerAttributes: {
                "class": "align-left"
            },
            title:"IT Product or Business Service",
            width: 240,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.servicedescription",
            headerAttributes: {
                "class": "align-left"
            },
            title:"System Description",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.itameuc",
            headerAttributes: {
                "class": "align-right"
            },
            title:"ITAM/EUC",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            },
          },{
            field:"_id.checker",
            headerAttributes: {
                "class": "align-left"
            },
            title:"PSS Head",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.contractid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"Contracts",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            },
            // template: "#Contracts#"
          },{
            field:"_id.slaid",
            headerAttributes: {
                "class": "align-right"
            },
            title:"SLAs",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-right"
            }
          } 
        ],
      });
    sm.statusGridScenario.es = true 
  }
}

sm.createGridScenarioDC = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "data"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "data"
    };
  }

  if (sm.statusGridScenario.dc == false){

    $("#gridtab11DC").html("");
    $("#gridtab11DC").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res.Data[0]._id)

                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);

                      setTimeout(function() {
                        $("#gridtab11DC").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.hublocationcountry", dir: "asc"},{field: "_id.systemshublocation", dir: "asc"},{field: "_id.scbownindbuilding", dir: "asc"},{field: "_id.sharedindbuilding", dir: "asc"},{field: "_id.entitynamebuilding", dir: "asc"}]
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.hublocationcountry",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Location Country",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.systemshublocation",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Hub Location",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.scbownindbuilding",
            headerAttributes: {
                "class": "align-left"
            },
            title:"SCB Owned?",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.sharedindbuilding",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Shared with another party?",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.entitynamebuilding",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Data Center Owner",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            },
          } 
        ],
      });
    sm.statusGridScenario.dc = true
  }
}

sm.createGridScenarioBuilding = function(){
  $("html, body").animate({ scrollTop: $(document).height() }, 3000); 

  if (sm.statusTab() === "impactRecipient"){
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receivingCountry(),
      SupplierCountry     : sm.supplyCountryResult(),
      ReceiverLegalEntity : sm.receivingLegalEntity(),
      SupplierLegalEntity : sm.supplyLegalEntityResult(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "bld"
    };
  }else {
    var payload = {
      Scenario            : sm.valueCustomScenario(),
      ReceivingCountry    : sm.receiverCountryResult(),
      SupplierCountry     : sm.supplycountry(),
      ReceiverLegalEntity : sm.receivingLegalEntityResult(),
      SupplierLegalEntity : sm.supplylegalentity(),
      Business            : sm.categoryname(),
      Product             : sm.product(),
      Critical            : sm.valueCriticalStatus(),
      Flag                : "bld"
    };
  }

  if (sm.statusGridScenario.bld == false){ 

    $("#gridtab12Building").html("");
    $("#gridtab12Building").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              sm.loadingScenarioGrid(true)
              ajaxPost("/scenarios/getdatagrid", payload, function(res){
                // console.log("isi :", res.Data[0]._id)

                      option.success(res.Data);
                      sm.loadingScenarioGrid(false);

                      setTimeout(function() {
                        $("#gridtab12Building").data("kendoGrid").resize();  
                      }, 500);
                  });
                },
            parameterMap: function(data) {
               return JSON.stringify(data);
              },                                                
            },
            schema: {
              data: function(data) {
                  if (data.length == 0) {
                      return [];
                  } else {
                      return data; 
                  } 
                },
            },
          /*serverFiltering: true,*/
          pageSize: 10,
          sort: [{field: "_id.buildingid", dir: "asc"},{field: "_id.buildingname", dir: "asc"},{field: "_id.hublocationcountry", dir: "asc"},{field: "_id.scbownindbuilding", dir: "asc"},{field: "_id.sharedindbuilding", dir: "asc"},{field: "_id.buildingownerid", dir: "asc"},{field: "_id.contractid", dir: "asc"}]
        },
        height: 350,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        excel: {
            fileName: "Level 1 Processes Name.xlsx",
            allPages: true
        },
        columnMenu: false,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        columns: [{
            field:"_id.buildingid",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Building ID",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.buildingname",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Building Name",
            attributes: {
                "class": "field-ellipsis align-left"
            },
            width: 180,
          },{
            field:"_id.hublocationcountry",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Building Country",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.scbownindbuilding",
            headerAttributes: {
                "class": "align-left"
            },
            title:"SCB Owned?",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            }
          },{
            field:"_id.sharedindbuilding",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Shared with another party?",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            },
          },{
            field:"_id.buildingownerid",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Building Owner",
            width: 180,
            attributes: {
                "class": "field-ellipsis align-left"
            },
          },{
            field:"_id.contractid",
            headerAttributes: {
                "class": "align-left"
            },
            title:"Contracts",
            width: 180,
            attributes: {
                "class": "align-left"
            },
          } 
        ],
      });
    sm.statusGridScenario.bld = true
  }
}

sm.refreshScenario = function(){
 sm.statusGridScenario.sla = false
 sm.statusGridScenario.ctr = false
 sm.statusGridScenario.msa = false
 sm.statusGridScenario.lvl1 = false
 sm.statusGridScenario.lvl2 = false
 sm.statusGridScenario.lvl3 = false
 sm.statusGridScenario.teams = false
 sm.statusGridScenario.tpv = false
 sm.statusGridScenario.is = false
 sm.statusGridScenario.es = false
 sm.statusGridScenario.dc = false
 sm.statusGridScenario.bld = false
 
 sm.createGridScenarioSLAS();
 // sm.getDataSummary();   
}

sm.impactSupplier = function(){
  $('#stateReceiver').hide(); 
  $('#stateSupplier').show();
  sm.statusTab('impactSupplier');
  
  var temp = sm.receivingCountry();
  sm.receivingCountry(undefined);
  sm.supplycountry(temp);
  sm.supplylegalentity([]);
  sm.receivingLegalEntity([]);
  sm.getlegalentitysupplier();
  sm.getcategory();

  sm.supplyCountryResult([])
  sm.supplyLegalEntityResult([])
  sm.receiverCountryResult([])
  sm.receivingLegalEntityResult([])
  // var supplierlegalentity = 
  // sm.supplycountry(undefined);
  // sm.receivingCountry(supplyCountry);
  // sm.getLegalentityReceiver();
  sm.getDataSummary();
  sm.refreshScenario();
  // sm.createGridScenarioSLAS();
}

sm.impactReceiver = function(){
  $('#stateReceiver').show(); 
  $('#stateSupplier').hide(); 
  sm.statusTab('impactRecipient')

  var temp = sm.supplycountry();
  sm.supplycountry(undefined);
  sm.receivingCountry(temp);
  sm.receivingLegalEntity([]);
  sm.supplylegalentity([]);
  sm.getLegalentityReceiver();
  sm.getcategory();

  sm.supplyCountryResult([])
  sm.supplyLegalEntityResult([])
  sm.receiverCountryResult([])
  sm.receivingLegalEntityResult([])

  // sm.receivingCountry(undefined);
  // sm.supplycountry(receiverCountry); 
  // sm.getlegalentitysupplier();
  sm.getDataSummary();
  sm.refreshScenario();
  // sm.createGridScenarioSLAS();
}
sm.exportExcel = function(){
  return function(){
    if (sm.statusTab() === "impactRecipient"){
      var payload = {
        Scenario            : sm.valueCustomScenario(),
        ReceiverCountry    : sm.receivingCountry(),
        SupplierCountry     : sm.supplyCountryResult(),
        ReceiverLegalEntity : sm.receivingLegalEntity(),
        SupplierLegalEntity : sm.supplyLegalEntityResult(),
        Business            : sm.categoryname(),
        Product             : sm.product(),
        Critical            : sm.valueCriticalStatus() 
      };
    }else {
      var payload = {
        Scenario            : sm.valueCustomScenario(),
        ReceiverCountry    : sm.receiverCountryResult(),
        SupplierCountry     : sm.supplycountry(),
        ReceiverLegalEntity : sm.receivingLegalEntityResult(),
        SupplierLegalEntity : sm.supplylegalentity(),
        Business            : sm.categoryname(),
        Product             : sm.product(),
        Critical            : sm.valueCriticalStatus()
      };
    }
    ajaxPost("/scenarios/getexcelgrid", payload, function (res){
        redirectUrl("/static/temp/ScenariosGrid/"+res.msg)
        // var port=document.location.port;
        // var host = document.location.hostname;
        // if(port==""){ 
          
        //    // window.location.href = "http://"+document.location.hostname+"/static/temp/ScenariosGrid/"+res.msg;
        // }else{ 
        //    // window.location.href = "http://"+document.location.hostname+":"+port+"/static/temp/ScenariosGrid/"+res.msg;  
        // }
    })
    // var payload = {
    //     Type : "Scenario Grid"
    // }
    // ajaxPost("/analyticuser/downloadlog", payload, function (res){
    // })
  }
};
sm.expand = function(flag){
  var classUp = 'glyphicon-chevron-up'
  var classDown = 'glyphicon-chevron-down'
  $(".icon"+flag).slideToggle("fast", function(){
    $(".icon"+flag).hasClass(classDown) ? $(".icon"+flag).addClass(classUp).removeClass(classDown) : $(".icon"+flag).addClass(classDown).removeClass(classUp)
    $(".icon"+flag).show()
  })
}

$(function(){
  sm.getReceiverCountry();
  sm.getSupplierCountry();
  sm.getLegalentityReceiver();
  // sm.getlegalentitysupplier();
  sm.getcategory();
  sm.getproductfunction();
  sm.getListCustomScenario();
  sm.getDataSummary();
  sm.createGridScenarioSLAS();
  // sm.impactSupplier();

});