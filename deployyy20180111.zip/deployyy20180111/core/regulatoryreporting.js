rr = {}

rr.reportNameList  = ko.observableArray([
                                        {value:"Status of Critical Contract Remediation",text:"Status of Critical Contract Remediation"}
                                        ]); 
rr.reportName = ko.observableArray([]);

rr.receiverCountryList = ko.observableArray([]);
rr.receiverCountry = ko.observable('');

rr.supplierCountryList = ko.observableArray([]);
rr.supplierCountry = ko.observable('');

rr.receiverLegalList = ko.observableArray([]);
rr.receiverLegal = ko.observable([]);

rr.supplierLegalList = ko.observableArray([]);
rr.supplierLegal = ko.observableArray([]);

rr.businessList = ko.observableArray([]);
rr.business = ko.observable('');

rr.productList = ko.observableArray([]);
rr.product = ko.observableArray([]);

rr.emailTo = ko.observableArray([]);
rr.emailCc = ko.observableArray([]);

rr.emailValue = ko.observable({mailsubject:"", mailmsg:"", mailto:[], mailcc:[] ,pdffile:"", excelfile:"", excelfolder:""});
rr.loadingProcess = ko.observable(false);

rr.showGridReceiver = ko.observable(true);
rr.showGridSupplier = ko.observable(true);

rr.listFilter = ko.observableArray([]);
rr.valueFilter = ko.observable('');
rr.valueCreateNewFilter = ko.observable('');

var CNUtimeout = setTimeout(function(){
    },1000)

rr.getReceiverCountry =  function(){
    var payload = {         
        ReceiverLegalEntity : rr.receiverLegal(),
        SupplierCountry : rr.supplierCountry(),
        SupplierLegalEntity : rr.supplierLegal(),
        Categoryname : rr.business(),
        Productfunction : rr.product(), 
    } 
    var url = "/regulatoryreporting/getreceivercountry";
    ajaxPost(url,payload, function (res){
        var receiverCountries = [];
        $.each(res, function(i,v){
            receiverCountries.push({text:v._id, value:v._id})
        });
        rr.receiverCountryList(receiverCountries);
    })
};
rr.getReceiverLegal =  function(){
    var payload = {
        ReceiverCountry : rr.receiverCountry(), 
        SupplierCountry : rr.supplierCountry(),
        SupplierLegalEntity : rr.supplierLegal(),
        Categoryname : rr.business(),
        Productfunction : rr.product(), 
    }
    var url = "/regulatoryreporting/getreceiverlegalentity";
    ajaxPost(url,payload, function (res){
        var receiverLegals = [];
        $.each(res, function(i,v){
            receiverLegals.push({text:v._id, value:v._id})
        });
        if(receiverLegals.length == 1){
            console.log("getReceiverLegal")
            rr.showGridReceiver(false);
        }
        rr.receiverLegalList(receiverLegals);
    })
};
rr.getSupplierCountry =  function(){
    var payload = {
        ReceiverCountry : rr.receiverCountry(),
        ReceiverLegalEntity : rr.receiverLegal(), 
        SupplierLegalEntity : rr.supplierLegal(),
        Categoryname : rr.business(),
        Productfunction : rr.product(), 
    }  
    var url = "/regulatoryreporting/getsuppliercountry";
    ajaxPost(url,payload, function (res){
        var supplierCountries = [];
        $.each(res, function(i,v){
            supplierCountries.push({text:v._id, value:v._id})
        });
        rr.supplierCountryList(supplierCountries);
    })
};
rr.getSupplierlegal =  function(){
    var payload = {
        ReceiverCountry : rr.receiverCountry(),
        ReceiverLegalEntity : rr.receiverLegal(),
        SupplierCountry : rr.supplierCountry(), 
        Categoryname : rr.business(),
        Productfunction : rr.product(), 
    }  
    var url = "/regulatoryreporting/getsupplierlegalentity";
    ajaxPost(url,payload, function (res){
        var supplierLegals = [];
        $.each(res, function(i,v){
            supplierLegals.push({text:v._id, value:v._id})
        });
        if(supplierLegals.length == 1){
            rr.showGridSupplier(false);
        }
        rr.supplierLegalList(supplierLegals);
    })
};
rr.getBusiness = function(){
    var payload = {
        ReceiverCountry : rr.receiverCountry(),
        ReceiverLegalEntity : rr.receiverLegal(),
        SupplierCountry : rr.supplierCountry(),
        SupplierLegalEntity : rr.supplierLegal(),
        Productfunction : rr.product(), 
    }
    var url = "/regulatoryreporting/getbusinessfunction";
    ajaxPost(url,payload, function (res){
        var business = []
        $.each(res, function(index, result){
            business.push({"text" : result._id,"value": result._id});
        });
        rr.businessList(business);
    });
};
rr.getProduct = function(){
    var payload = {
        ReceiverCountry : rr.receiverCountry(),
        ReceiverLegalEntity : rr.receiverLegal(),
        SupplierCountry : rr.supplierCountry(),
        SupplierLegalEntity : rr.supplierLegal(),
        Categoryname : rr.business()
    } 

    var url = "/regulatoryreporting/getproduct";
    ajaxPost(url,payload, function (res){
        var product = []
        $.each(res, function(index, result){
            product.push({"text" : result._id,"value": result._id});
        });
        rr.productList(product);
    });
};
rr.createGrid = function(payload){
    var dataSource = [];
    var url = "/regulatoryreporting/getdatagridregulatory";
    var coloumns = [{
        field:"servicedescription",
        title:"Service Description", 
        width:200,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "field-ellipsis"
        }
    },{
        field:"productfunction",
        title:"Product",
        width:150,
        headerAttributes: {
            "class": "align-left"
        },
       
    },{
        field:"barrierstartdate",
        title:"Barrier Start Date", 
        template: "#if(barrierstartdate != ''){# #:  kendo.toString(new Date(getUTCDate(getUTCDateFull(barrierstartdate))), 'dd-MM-yyyy') # #} #",
        width:150,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "align-left"
        }
        
    },{
        field:"countdays",
        title:"No. Of Days", 
        width:150,
        headerAttributes: {
            "class": "align-right"
        },
        attributes: {
            "class": "align-right"
        }
    }]
    if(rr.showGridReceiver() ==  true && rr.showGridSupplier() == true){
        coloumns.unshift({
            field:"receiver",
            title:"Receiver Country", 
            width:200,
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis"
            }
        },{
            field:"supplier",
            title:"Supplier Country", 
            width:200,
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis"
            }
        })
    }else if(rr.showGridReceiver() ==  true && rr.showGridSupplier() == false){
        coloumns.unshift({
            field:"receiver",
            title:"Receiver Country", 
            width:200,
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis"
            }
        })
    }else if(rr.showGridReceiver() ==  false && rr.showGridSupplier() == true){
        coloumns.unshift({
            field:"supplier",
            title:"Supplier Country", 
            width:200,
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis"
            }
        })
    }
    coloumns.unshift({
        field:"number",
        title:"Serial No",
        width:100,
        headerAttributes: {
            "class": "align-right"
        },
        attributes: {
            "class": "align-right"
        } 
    })    
    $("#grid-report").html("");
    $("#grid-report").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: payload,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) {
                    if (data.length == 0) {
                        return dataSource;
                    } else {
                        index = 1;
                        data.forEach(function (d) { 
                            d.number =  index;
                            d.supplier = d.suppliercountry + ' - ' + d.supplierlegalentity
                            d.receiver = d.receivercountry + ' - ' + d.receiverlegalentity
                            index++;
                        })
                        return data 
                    }
                }, 
            },
            pageSize: 10,
            serverPaging: false,
            serverSorting: false,
        }, 
        resizable: true,
        scrollable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 10
        },
        columnMenu: false,
        columns: coloumns
    });
};
rr.getData = function(){
    var payload = { 
        ReceivingCountry    : rr.receiverCountry(),
        SupplierCountry     : rr.supplierCountry(), 
        ReceiverLegalEntity : rr.receiverLegal(), 
        SupplierLegalEntity : rr.supplierLegal(),
        Business            : rr.business(),
        Product             : rr.product()
    }; 
    rr.createGrid(payload);
};
rr.download =  function(type){
    return function(){
      var payload = {
            ReceiverCountry : rr.receiverCountry(),  
            ReceiverLegalEntity : rr.receiverLegal(),
            SupplierCountry : rr.supplierCountry(),
            SupplierLegalEntity : rr.supplierLegal(),
            Categoryname : rr.business(),
            Productfunction : rr.product()
        };
        if(type == "excel"){
            rr.loadingProcess(true);
            ajaxPost("/regulatoryreporting/getexcel",payload , function (res){
                var port=document.location.port;
                var host = document.location.hostname;
                if(port==""){
                  rr.loadingProcess(false);  
                  redirectUrl("/static/temp/RegulatoryReporting/"res.msg)
                   // window.location.href = "http://"+document.location.hostname+"/static/temp/RegulatoryReporting/"+res.msg;
                }else{
                    rr.loadingProcess(false);   
                    redirectUrl("/static/temp/RegulatoryReporting/"res.msg)
                    // window.location.href = "http://"+document.location.hostname+":"+port+"/static/temp/RegulatoryReporting/"+res.msg;  
                }
            })
            var payload = {
              Type : "RegulatoryReporting Grid Excel"
            }
            ajaxPost("/analyticuser/downloadlog", payload, function (res){
            })
        }else {
          rr.loadingProcess(true);
          ajaxPost("/rptpdfregulator/controlrpt",payload , function (res){
                // console.log(res)
                // var port = document.location.port;
                // var host = document.location.hostname;
                if(port == ""){ 
                    rr.loadingProcess(false)
                    redirectUrl("/static/temp/pdf/"res.msg)
                   // window.open("http://"+document.location.hostname+"/static/temp/pdf/"+res.Data)
                }else{ 
                    rr.loadingProcess(false) 
                    redirectUrl("/static/temp/pdf/"res.msg) 
                   // window.open("http://"+document.location.hostname+":"+port+"/static/temp/pdf/"+res.Data)
                }
            })
            var payload = {
              Type : "RegulatoryReporting Grid PDF"
            }
            ajaxPost("/analyticuser/downloadlog", payload, function (res){
            })
        }
    }
};
rr.sendEmail = function(){
    var payloadFile = {
        ReceiverCountry : rr.receiverCountry(),  
        ReceiverLegalEntity : rr.receiverLegal(),
        SupplierCountry : rr.supplierCountry(),
        SupplierLegalEntity : rr.supplierLegal(),
        Categoryname : rr.business(),
        Productfunction : rr.product()
    };
  
    for (var i in rr.emailTo()){ 
        rr.emailValue().mailto.push(rr.emailTo()[i].id)
    }

    for (var i in rr.emailCc()){ 
        rr.emailValue().mailcc.push(rr.emailCc()[i].id)
    }  
    rr.loadingProcess(true);
    ajaxPost("/regulatoryreporting/getexcel",payloadFile , function (res1){
        rr.emailValue().excelfile = res1.msg
        rr.emailValue().excelfolder = "RegulatoryReporting"
        ajaxPost("/rptpdfregulator/controlrpt",payloadFile , function (res2){
            rr.emailValue().pdffile = res2.Data
            ajaxPost("/reportpdf/sendmail",rr.emailValue() , function (res3){
                if (!res3.IsError){
                    rr.loadingProcess(false); 
                    swal("Email Sent", "", "success");
                    $("#ModalEmail").modal("hide");
                    rr.resetField();
                }else {
                    rr.loadingProcess(false);
                    swal("Error!",res3.Data, "error"); 
                }
            })    
        })
    }) 
}

rr.resetField = function(){
  rr.emailValue().mailsubject = ""; 
  rr.emailValue().mailmsg = "" ;
  rr.emailValue().mailto = []; 
  rr.emailValue().mailcc = [];
  rr.emailValue().pdffile = "" ;
  rr.emailValue().excelfile = "" ;
  rr.emailValue().excelfolder = "";
  $("#emailCc").tokenInput("clear");
  $("#emailTo").tokenInput("clear");
  $("#subjectMail").val("");
  $("#msgMail").val("");
}

rr.receiverCountry.subscribe(function(newValue){
    rr.getReceiverLegal();
    rr.getSupplierCountry(); 
    rr.getBusiness();
    rr.getProduct();
    if(rr.receiverCountry() == ''){
        rr.getReceiverCountry();
    }
    CNUtimeout = setTimeout(function(){
                   rr.getData();
                 },2000);
});
rr.receiverLegal.subscribe(function(newValue){
    rr.getSupplierCountry();  
    rr.getBusiness();
    rr.getProduct();
    if(rr.receiverLegal().length == 0){
        rr.getReceiverLegal();
    }
    if(rr.receiverLegal().length == 1){
        console.log("receiverLegal")
        rr.showGridReceiver(false)
    }else{
        rr.showGridReceiver(true)
    }
    CNUtimeout = setTimeout(function(){
                   rr.getData();
                 },2000);
});
rr.supplierCountry.subscribe(function(newValue){
    rr.getReceiverCountry(); 
    rr.getSupplierlegal(); 
    rr.getBusiness();
    rr.getProduct();
    if(rr.supplierCountry == ''){
        rr.getSupplierCountry();
    }
     CNUtimeout = setTimeout(function(){
                   rr.getData();
                 },2000);
});
rr.supplierLegal.subscribe(function(newValue){
    rr.getReceiverCountry();
    rr.getBusiness();
    rr.getProduct();
    if(rr.supplierLegal().length == 0){
        rr.getSupplierlegal(); 
    } 
    if(rr.supplierLegal().length == 1){
        console.log("supplierLegal")
        rr.showGridSupplier(false) 
    }else{
        rr.showGridSupplier(true) 
    }  
     CNUtimeout = setTimeout(function(){
                   rr.getData();
                 },2000);   
});
rr.business.subscribe(function(newValue){
    rr.getReceiverCountry();
    rr.getReceiverLegal();
    rr.getSupplierCountry();
    rr.getSupplierlegal(); 
    rr.getProduct();
    if(rr.business().length == 0){
        rr.getBusiness();
    }  
     CNUtimeout = setTimeout(function(){
                   rr.getData();
                 },2000);
});
rr.product.subscribe(function(newValue){
    rr.getReceiverCountry();
    rr.getReceiverLegal();
    rr.getSupplierCountry();
    rr.getSupplierlegal(); 
    rr.getBusiness();
    if(rr.product().length == 0){
        rr.getProduct();
    }  
     CNUtimeout = setTimeout(function(){
                   rr.getData();
                 },2000);
});
rr.CreateTokenInputEmail = function(){
    $("#emailTo").tokenInput([], { 
        zindex: 700,
        noResultsText: "Add New Email",
        allowFreeTagging: true,
        placeholder: 'Type Email Here',
        tokenValue: 'id',
        propertyToSearch: 'key',
        theme: "facebook",
        onAdd: function (item) {
            if (validateEmailFormat(item.key)){
                rr.emailTo.push(item);  
                $("#alertMessage1").hide();
            }else {
                $("#alertMessage1").text(item.key+" is not valid email !");
                $("#alertMessage1").show()
                this.tokenInput("remove", {id: item.key});
                setTimeout(function() {
                    $("#alertMessage1").hide();
                }, 5000);
            }
        },
        onDelete: function (item) {
            rr.emailTo.remove(item);  
        }
    });

    $("#emailCc").tokenInput([], { 
        zindex: 700,
        noResultsText: "Add New Email",
        allowFreeTagging: true,
        placeholder: 'Type Email Here',
        tokenValue: 'id',
        propertyToSearch: 'key',
        theme: "facebook",
        onAdd: function (item) {
            if (validateEmailFormat(item.key)){
                rr.emailCc.push(item);  
                $("#alertMessage2").hide();
            }else {
                $("#alertMessage2").text(item.key+" is not valid email !");
                $("#alertMessage2").show()
                this.tokenInput("remove", {id: item.key});
                setTimeout(function() {
                    $("#alertMessage2").hide();
                }, 5000);
                }
            },
        onDelete: function (item) {
            rr.emailCc.remove(item);  
        }
    });
}
rr.saveFilter = function(){
    var payload = {
        Report: rr.reportName(),
        receiverCountry: rr.receiverCountry(),
        ReceiverLegal: rr.receiverLegal(),
        SupplierCountry: rr.supplierCountry(),
        SupplierLegal: rr.supplierLegal(),
        Business: rr.business(),
        Product: rr.product(),
        Submenu : "RegulatryReporting",
        Name : rr.valueCreateNewFilter()
    }

    var status = 0

    var validator = $("#newFilterName").data("kendoValidator");

    if(validator ==  undefined){
        validator = $("#newFilterName").kendoValidator().data("kendoValidator");
    }

    if (validator.validate()){
        $.each(rr.listFilter(), function(k, v){   
            if (v._id == "RegulatryReporting"+rr.valueCreateNewFilter()){
                swal({   
                    title: "Are you sure?",   
                    text: "Filter name already exist",   
                    type: "warning",   
                    showCancelButton: true,   
                    confirmButtonColor: "#3F9E35",   
                    confirmButtonText: "Yes, edit it!",   
                    cancelButtonText: "No, cancel",   
                    closeOnConfirm: false,   
                    closeOnCancel: false 
                }, 
                function(isConfirm){   
                    if (isConfirm) {     
                        save();   
                    } else {     
                        swal("Cancelled", "", "error");
                        return;   
                    } 
                });
            }else {
                status = status+1;
                if (status == rr.listFilter().length){
                    save();
                }
            }
        });
    }else {
        swal("Error!","Filter name cannot be empty", "error"); 
    }
  
    function save(){
        ajaxPost("/reportcontrolverification/savereportconfig",payload , function (res){
            if (res.Success){
                swal("Success", "Filter name saved", "success");
                rr.valueCreateNewFilter('');   
                rr.getListFilter();
            }else {
                swal("Error!",'failed to save', "error"); 
            }
        })
    }   
}

rr.changeFilterValue = function(e){  
    var selected = e.sender._selectedValue; 
    rr.valueFilter(selected);

    if (selected !== ''){
        $.each(rr.listFilter(), function(k, v){      
            if (v._id == selected){
                rr.reportName(v.Report)
                rr.receiverCountry(v.receiverCountry)
                rr.receiverLegal(v.ReceiverLegal)
                rr.supplierCountry(v.SupplierCountry)
                rr.supplierLegal(v.SupplierLegal)
                rr.business(v.Business)
                rr.product(v.Product)
            }
        })  
    }else{
        rr.reportName('')
        rr.receiverCountry('')
        rr.receiverLegal([])
        rr.supplierCountry('')
        rr.supplierLegal([])
        rr.business('')
        rr.product([])
    } 
}

rr.getListFilter = function(){
    var payload = {
        Submenu : "RegulatryReporting"
    };
    ajaxPost("/reportcontrolverification/getnameconfig",payload , function (res){
    rr.listFilter(res);
    })
}

$(function(){ 
    rr.getReceiverCountry();
    rr.getSupplierCountry();
    rr.getProduct();
    rr.getData();

    date =  model.getDateMinOne()
    fullDate =  model.getDaysName(date.getDay()) +", "+ date.getDate() + " "+ model.getMonthName(date.getMonth()) + " " + date.getFullYear(); 
    $("#fullDate-text").text(fullDate)

    rr.CreateTokenInputEmail();
    rr.getListFilter();
})