var cv = {};

cv.receivingcountry = ko.observableArray([]),
cv.receivingcountryValue = ko.observable(),
cv.suppliercountryValue = ko.observable(),
cv.allData = ko.observable(false),
cv.templateSummary = {
  NoOfSupplier:"",
  TotalTrx:""
}

cv.summary = ko.mapping.fromJS(cv.templateSummary)
cv.getReceivingCountry = function(e){
    var url = "/countryview/getddlcountry";
    ajaxPost(url,{}, function (res){
      var country = []
      $.each(res, function(index, result){		
 			  country.push({"name" : result._id,"text": result._id});
		  });
		cv.receivingcountry(country);
    });
    cv.checkData();
}


cv.chartReceiverCategory =  function(dataSource){
      $("#receivercategorychart").kendoChart({
        dataSource: {
            data:dataSource,
            dataType: "json"
        },

        title: {
            text: "Process Receiver Categories",
            visible:true,
             font: "14px calibri",
        },
        legend :{
            position :"top",
        },
        seriesDefaults:{
            type:"column",
        },
        series : 
        [
            {
              field: "Count",
            },
        ],
        categoryAxis :{
            field : "_id",
            labels: {
                rotation: -90,
            },
            majorGridLines: {
                visible: false
            }
        },
        valueAxis:{
          labels: {
                visible: true,
                format: "n0",
            },
        },
        tooltip: {
            visible: true,
            format: "n0",
        },
        seriesColors: ["#317DB5"],
      });
}

cv.chartSupplierCountry =  function(dataSource){
    var sourcesAttr = []    
    for(var i in dataSource){ 
        var dataCount = dataSource[i].Count;
        var dataCountry = dataSource[i]._id;
        var attr = {
            Count: dataCount,
            Country: dataCountry
        };
     sourcesAttr.push(attr);
    }
  
    $("#chartsuppliercountry").kendoChart({
        dataSource: {
            data:sourcesAttr
        },
        title: {
            text: "Supplier Country",
            position: "top",
            font: "14px calibri",
            visible: true

        },
        legend :{
            position :"bottom",
            labels: {
                font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        // chartArea :{
        //     height: 300,
        // },
        seriesDefaults:{
            type:"column",
        },
        series : [{
            field: "Count",
        }],
        categoryAxis :{
            field : "Country",
            labels: {
                rotation: -90,
                font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        },
        seriesColors: ["#317DB5"],
    });
}

cv.chartSupplierType  =  function(dataSource){
  var data = []
  $.each(dataSource, function(i, val){    
    data.push({"category" : val._id,"value": val.Count});
  });

  $("#suppliertypeChart").kendoChart({
        title: {
            position: "top",
            text: "Process Supply Type :",

            font: "14px calibri"
        },
        legend: {
            position: "bottom"  
             
      },
        chartArea: {
            background: ""
        },
        seriesDefaults: {
            labels: { 
                position: "outsideEnd",
                visible: true,
                background: "transparent",
                template: "#= kendo.toString(percentage,'P2') #",
                font: "11px Arial,Helvetica,sans-serif"
            }
        },
        series: [{
            type: "pie",
            startAngle: 150,
            data: data
        }],
        seriesColors:ecisColors,
        tooltip: {
            visible: true,
            template: "#= '<b>' + dataItem.category  + '</br>' + kendo.toString( dataItem.value) + '</b>' #",
                 font: "11px Arial,Helvetica,sans-serif"
        }
     });
}

cv.ServicesByProcessesGrid = function(param) {
    var dataSource = [];
    var url = "/countryview/processnamesuppliertype";
    $("#grid-processes").html("");
    $("#grid-processes").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) {
                    if (data.Data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Data.Records;
                    }
                },
                total: "Data.Count",
            },
            pageSize: 15,
            serverPaging: false,
            serverSorting: false,
        },
        height: 400,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        excel: {
            fileName: "Count of Services by Processes and Supply Category.xlsx",
            allPages: true
        },
        columnMenu: false,
        columns: [
            {
                field:"Processname",
                title:"Row Label",
                width:200,
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"IGS",
                title:"IGS",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
            {
                field:"Systems",
                title:"Systems",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
            {
                field:"Teams",
                title:"Teams",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
            {
                field:"TPS",
                title:"TPS",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
            {
                field:"Total",
                title:"Total",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
        ]
    });
}

cv.ServicesBySuppliersGrid = function(param) {
  
    var dataSource = [];
    var url = "/countryview/suppliernamesuppliertype";
    $("#grid-suppliers").html("");
    $("#grid-suppliers").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) {
                    if (data.Data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Data.Records;
                    }
                },
                total: "Data.Count",
            },
            pageSize: 15,
            serverPaging: false,
            serverSorting: false,
        },
        height: 400,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        excel: {
            fileName: "Count of Services by Suppliers and Supply Category.xlsx",
            allPages: true
        },
        columnMenu: false,
         columns: [
            {
                field:"Processname",
                title:"Row Label",
                width:200,
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"IGS",
                title:"IGS",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
            {
                field:"Systems",
                title:"Systems",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
            {
                field:"Teams",
                title:"Teams",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
            {
                field:"TPS",
                title:"TPS",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
            {
                field:"Total",
                title:"Total",
                width:50,
                filterable: false,
                attributes: {"class": "align-right"}
            },
        ]
    });
}

cv.getData = function(){   
    var payload = {
        Country: cv.receivingcountryValue()
    }
    ajaxPost("/countryview/receivercategory", payload , function (res){
        cv.chartReceiverCategory(res);
    })
    ajaxPost("/countryview/suppliercountries", payload , function (res){
        cv.chartSupplierCountry(res);
    })
    ajaxPost("/countryview/suppliertype", payload , function (res){
        cv.chartSupplierType(res);
    })
    cv.ServicesByProcessesGrid(payload)
    cv.ServicesBySuppliersGrid(payload)
}

cv.changeReceivingCount= function(e){
  var dataItem = this.dataItem(e.item);
  cv.receivingcountryValue(dataItem.name);
  cv.getAlldata();
}
 
cv.getAlldata = function(){
    var summary = ko.mapping.toJS(cv.summary);
    var payload = {
        Country: cv.receivingcountryValue()
    };
    cv.getData();    
    if (cv.receivingcountryValue() == undefined) {
        cv.allData(false);
        swal({title: "No Data", type: "error"});
    }else if (payload.Country == "NULL") {
        cv.allData(false);
        swal({title: "No Data", type: "error"});
    }else{
        cv.allData(true);  
        ajaxPost("/countryview/summary", {Country: cv.receivingcountryValue()} , function (res){
            summary.NoOfSupplier = res.NoOfSupplier
            summary.TotalTrx = res.TotalTrx
            ko.mapping.fromJS(summary,cv.summary)
        })
    }    
}

cv.getQueryString = function ( field, url ) {
    var href = url ? url : window.location.href;
    var reg = new RegExp( '[?&]' + field + '=([^&#]*)', 'i' );
    var string = reg.exec(href);
    return string ? string[1] : null;
};

cv.checkData = function(){
    qStringUrl  = cv.getQueryString('country');
    nStringUrl = decodeURI(qStringUrl);
    if(nStringUrl !== "null"){
        var dropdownlist = $("#receiverc").data("kendoDropDownList");
        dropdownlist.bind("dataBound", function(e) {
            var allReceivingCountry = [];
            for (var i in cv.receivingcountry()) {
                var countryname = cv.receivingcountry()[i].name;
            allReceivingCountry.push(countryname);        
            }
            if ($.inArray(nStringUrl, allReceivingCountry) != -1) {
                cv.receivingcountryValue(nStringUrl);
                cv.getAlldata();            
            }else{
                cv.allData(false);
                swal({title: "No Data", type: "error"});
            }
        });
    }else{
        cv.allData(false);
    }
}
$(function(){
    cv.getReceivingCountry();
    $("#export-processes").click(function () {
        var grid = $("#grid-processes").data("kendoGrid");
        grid.saveAsExcel();
    });
    $("#export-suppliers").click(function () {
        var grid = $("#grid-suppliers").data("kendoGrid");
        grid.saveAsExcel();
    });
});