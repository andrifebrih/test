fmi = {}

fmi.receivingSupplierType = ko.observable('FMI');
// fmi.receivingSupplierTypeList = ko.observableArray([{value:"FMI",text:"FMI"},
                                                    // {value:"FMI_TPS",text:"FMI External"},]);

fmi.supplierSupplierType  = ko.observable('FMI');
// fmi.supplierSupplierTypeList  = ko.observableArray([{value:"FMI",text:"FMI"},
                                                    // {value:"FMI_TPS",text:"FMI External"},]);

fmi.receivingClassification = ko.observableArray([]);
fmi.receivingClassificationList = ko.observableArray([]);

fmi.supplierClassification  = ko.observableArray([]);
fmi.supplierClassificationList  = ko.observableArray([]);

fmi.receivingCountry     = ko.observable('');
fmi.receivingCountryList = ko.observableArray([]);

fmi.supplierCountry     = ko.observable('');
fmi.supplierCountryList = ko.observableArray([]);

fmi.receivingLegalEntity     = ko.observableArray([]);
fmi.receivingLegalEntityList = ko.observableArray([]);

fmi.supplierLegalEntity      = ko.observableArray([]);
fmi.supplierLegalEntityList  = ko.observableArray([]);

fmi.receivingCategory     = ko.observableArray([]);
fmi.receivingCategoryList = ko.observableArray([]);

fmi.supplierCategory     = ko.observableArray([]);
fmi.supplierCategoryList = ko.observableArray([]);

fmi.onchangeReceivingCountry = ko.observable(true);
fmi.onchangeSupplierCountry  = ko.observable(true);

fmi.receivingReceiverSummary = ko.observableArray([]);
fmi.supplierReceiverSummary = ko.observableArray([]);

fmi.receivingSupplierSummary = ko.observableArray([]);
fmi.supplierSupplierSummary = ko.observableArray([]);

fmi.receivingLevelProcess     = ko.observableArray([]);
fmi.receivingLevelProcessList = ko.observableArray([]);

fmi.supplierLevelProcess     = ko.observableArray([]);
fmi.supplierLevelProcessList = ko.observableArray([]);

fmi.receivingSupplierName     = ko.observableArray([]);
fmi.receivingSupplierNameList = ko.observableArray([]);

fmi.supplierSupplierName     = ko.observableArray([]);
fmi.supplierSupplierNameList = ko.observableArray([]);

fmi.receivingFMIType     = ko.observableArray([]);
fmi.receivingFMITypeList = ko.observableArray([]);

fmi.supplierFMIType     = ko.observableArray([]);
fmi.supplierFMITypeList = ko.observableArray([]);

fmi.receiverCountryMap = ko.observable();

fmi.headerModalReceiver = ko.observable('');
fmi.headerModalSupplier = ko.observable('');
fmi.templateConfigDonut = {
    legend: {
        visible:false,
        labels: {
            font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            template:'',
            color: "#0075B2"
        },
        margin:{
            visible:true,
            left:-10
        },
    },
    chartArea: {
        height : 100,
        background: "transparent",
        width : 120,
    },
    seriesDefaults: {
        labels: {
            visible: false,
            template: "#= removeSpace(kendo.toString(percentage,'P0'))#",
            font: "9px Helvetica Neue, Arial, sans-serif",
            background: "transparent"
        }
    },
   // / seriesColors: ["#00506D","#0077A3","#50D0FF"],
    series: [{
        type: "donut",
        data: '',
        overlay:{gradient:"none"},
    }],
    valueAxis:{
        visible:false,
        labels: {
            font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            visible: false,
            format:"{0:P0}",
        },
        majorGridLines: {
            visible: false
        },
    },
    tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#=kendo.toString(value,'N0')#"
    },
}; 
fmi.configDonut = ko.mapping.fromJS(fmi.templateConfigDonut);
 

fmi.receivingHoverCountry = ko.observable('');
fmi.receivingTypeHoverCountry = ko.observable('');

fmi.supplierHoverCountry = ko.observable('');
fmi.supplierTypeHoverCountry = ko.observable('');

fmi.showLegendLineReceiver = ko.observable(false);
fmi.showLegendLineSupplier = ko.observable(false);

fmi.clickSupplierIndex = 0;

fmi.clickAnalyze = function(value,type){
    return function () {
        var cookies;
        // console.log("isi value: ", value)
        if(value.hasOwnProperty('receiverLegalEntity') ){
            // var data = dashboard.parseLegalEntity(value)
            var data = value
                // cookies = {receiverCountry:data['country'].trim(), receiverLegalEntity:data['legalEntity'].trim()};
                cookies = {receiverLegalEntity:data['receiverLegalEntity']};
            if(type == 'supplier'){
                $.extend(true,cookies,{supplierCountry:fmi.supplierCountry()})
                if(fmi.supplierLegalEntity().length > 0){
                    $.extend(true,cookies,{supplierLegalentity:fmi.supplierLegalEntity()})
                }
                if(fmi.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:fmi.supplierCategory()})
                }
            }else{
                if(fmi.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:fmi.receivingCategory()})
                }
            }
           
            // dashboard.createNewCookie(cookies); 
        }else if(value.hasOwnProperty('supplierLegalentity')){
            // dashboard.createNewCookie(cookies); 
            var data = dashboard.parseLegalEntity(value)
                cookies = {supplierCountry:data['country'].trim(), supplierLegalentity:data['legalEntity'].trim()};
            if(type == 'receiver'){
                $.extend(true,cookies,{receiverCountry:fmi.receivingCountry()})
                if(fmi.receivingLegalEntity().length > 0){
                    $.extend(true,cookies,{receiverLegalEntity:fmi.receivingLegalEntity()})
                }
                if(fmi.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:fmi.receivingCategory()})  
                }
            }else{
                if(fmi.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:fmi.supplierCategory()})
                }
            }
                       // dashboard.createNewCookie(cookies); 
        }else if(value.hasOwnProperty('receiverCountry')){
            cookies = value;
            if(type == 'supplier' ){
                $.extend(true,cookies,{supplierCountry:fmi.supplierCountry()})
                if(fmi.supplierLegalEntity().length > 0){
                    $.extend(true,cookies,{supplierLegalentity:fmi.supplierLegalEntity()})
                }
                if(fmi.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:fmi.supplierCategory()})
                }
            }else{
                if(fmi.receivingLegalEntity().length > 0){
                    $.extend(true,cookies,{receiverLegalEntity:fmi.receivingLegalEntity()})
                }
                if(fmi.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:fmi.receivingCategory()})  
                }
               
            }
            // dashboard.createNewCookie(value);
        }else if(value.hasOwnProperty('supplierCountry')){
            cookies = value;
            if(type == 'receiver' ){
                $.extend(true,cookies,{receiverCountry:fmi.receivingCountry()})
                if(fmi.receivingLegalEntity().length > 0){
                    $.extend(true,cookies,{receiverLegalEntity:fmi.receivingLegalEntity()})
                }
                if(fmi.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:fmi.receivingCategory()})  
                }
            }else{
                if(fmi.supplierLegalEntity().length > 0){
                    $.extend(true,cookies,{supplierLegalentity:fmi.supplierLegalEntity()})
                }
                if(fmi.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:fmi.supplierCategory()})
                }
            }
            // dashboard.createNewCookie(value);
        }
        $.extend(true,cookies,{supplierType:'FMI'});

        dashboard.createNewCookie(cookies);
        redirectUrl("/ociranalysis/default")
    }
};

fmi.receivingPrepareMap = function(){
    $('#map-fmi-receiving').remove();
    $(".panelMap-fmi").append("<div id='map-fmi-receiving' class='map'> </div>");
};

fmi.supplierPrepareMap = function(){
   $('#map-fmi-supplier').remove();
   $(".panelMap-fmiSupplier").append("<div id='map-fmi-supplier' class='map'> </div>");
};

fmi.downloadReceivingDetails = function(){
    return function(){
        var grid = $("#grid-popup-reciver-detailfmi").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard FMI Receiver Drilldown Detail"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

fmi.downloadReceiving = function(){
    return function(){
        var grid = $("#popupfmiReceiver").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard FMI Receiver Drilldown"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

fmi.downloadSupplierDetails = function(){
    return function(){
        var grid = $("#grid-popup-supplier-detailfmi").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard FMI Supplier Drilldown Detail"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

fmi.downloadSupplier = function(){
    return function(){
        var grid = $("#popupfmiSupplier").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard FMI Supplier Drilldown"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

fmi.receivingFMIValue =  function(country,type){
    // $("#popupfmiReceiver").remove();
    var column = [];
    if(type == "receiver"){
        if(country == ""){
            column = [
                {
                    field:"_id.suppliername",
                    title:"FMI Name",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.receivercountry",
                //     title:"Receiver Country",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.receiverlegalentity",
                //     title:"Receiver Legal Entity",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"_id.FMI_CATEGORY_NAME",
                    title:"FMI Type",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.FMI_Access_Type",
                //     title:"Access Type",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.parent",
                //     title:"System Name",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"FMI_Transaction_Amount",
                    title:"FMI Transaction Amount",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                },{
                    field:"FMI_Transaction_Volume",
                    title:"FMI Transaction Volume",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                }
            ];
        }else{
            column = [
                {
                    field:"_id.suppliername",
                    title:"FMI Name",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.suppliercountry",
                //     title:"Supplier Country",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.supplierlegalentity",
                //     title:"Supplier Legal Entity",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"_id.FMI_CATEGORY_NAME",
                    title:"FMI Type",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.FMI_Access_Type",
                //     title:"Access Type",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.parent",
                //     title:"System Name",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"FMI_Transaction_Amount",
                    title:"FMI Transaction Amount",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                },{
                    field:"FMI_Transaction_Volume",
                    title:"FMI Transaction Volume",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                }
            ];
        }
    }else{
         if(country == ""){
            column = [
                {
                    field:"_id.suppliername",
                    title:"FMI Name",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.suppliercountry",
                //     title:"Supplier Country",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.supplierlegalentity",
                //     title:"Supplier Legal Entity",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"_id.FMI_CATEGORY_NAME",
                    title:"FMI Type",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.FMI_Access_Type",
                //     title:"Access Type",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.parent",
                //     title:"System Name",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"FMI_Transaction_Amount",
                    title:"FMI Transaction Amount",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                },{
                    field:"FMI_Transaction_Volume",
                    title:"FMI Transaction Volume",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                }
            ];
        }else{
            column = [
                {
                    field:"_id.suppliername",
                    title:"FMI Name",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.receivercountry",
                //     title:"Receiver Country",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.receiverlegalentity",
                //     title:"Receiver Legal Entity",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"_id.FMI_CATEGORY_NAME",
                    title:"FMI Type",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.FMI_Access_Type",
                //     title:"Access Type",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.parent",
                //     title:"System Name",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"FMI_Transaction_Amount",
                    title:"FMI Transaction Amount",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                },{
                    field:"FMI_Transaction_Volume",
                    title:"FMI Transaction Volume",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                }
            ];
        }
    }
    $("#amount-receiver-popup").css({"display":""});
    var param = {
        Business : fmi.receivingCategory(),
        Suppliername : fmi.receivingSupplierName(),
        LegalEntity : fmi.receivingLegalEntity(),
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        ReceivingCountry : fmi.receivingCountry(),
        SupplierCountry : country,
        Fmitype : fmi.receivingFMIType(),
        Tab : "receiver"
    }
    // param.
    var url = "/receiverview/getfmitooltip"
      $("#popupfmiReceiver").html("");
      $("#popupfmiReceiver").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, param, function(datas){
                        option.success(datas); 
                        $('#fmireceivermodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
        },
        dataBound: function(){
            $('#popupfmiReceiver .k-grid-content').height(315);
        },
        height: 380,
        columns: column,
        excel: {
            fileName: " FMI Receiver.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
};

fmi.supplierFMIValue =  function(country,type){
    $("#amount-supplier-popup").css({"display":""});
    var column = [];
    if(type == "receiver"){
         if(country == ""){
            column = [
                {
                    field:"_id.suppliername",
                    title:"FMI Name",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.suppliercountry",
                //     title:"Supplier Country",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.supplierlegalentity",
                //     title:"Supplier Legal Entity",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"_id.FMI_CATEGORY_NAME",
                    title:"FMI Type",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.FMI_Access_Type",
                //     title:"Access Type",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.parent",
                //     title:"System Name",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"FMI_Transaction_Amount",
                    title:"FMI Transaction Amount",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                },{
                    field:"FMI_Transaction_Volume",
                    title:"FMI Transaction Volume",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                }
            ];
        }else{
            column = [
                {
                    field:"_id.suppliername",
                    title:"FMI Name",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.receivercountry",
                //     title:"Receiver Country",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.receiverlegalentity",
                //     title:"Receiver Legal Entity",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"_id.FMI_CATEGORY_NAME",
                    title:"FMI Type",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.FMI_Access_Type",
                //     title:"Access Type",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.parent",
                //     title:"System Name",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"FMI_Transaction_Amount",
                    title:"FMI Transaction Amount",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                },{
                    field:"FMI_Transaction_Volume",
                    title:"FMI Transaction Volume",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                }
            ];
        }
    }else{
       

        if(country == ""){
            column = [
                {
                    field:"_id.suppliername",
                    title:"FMI Name",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.receivercountry",
                //     title:"Receiver Country",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.receiverlegalentity",
                //     title:"Receiver Legal Entity",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"_id.FMI_CATEGORY_NAME",
                    title:"FMI Type",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.FMI_Access_Type",
                //     title:"Access Type",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.parent",
                //     title:"System Name",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"FMI_Transaction_Amount",
                    title:"FMI Transaction Amount",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                },{
                    field:"FMI_Transaction_Volume",
                    title:"FMI Transaction Volume",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                }
            ];
        }else{
            column = [
                {
                    field:"_id.suppliername",
                    title:"FMI Name",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.suppliercountry",
                //     title:"Supplier Country",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.supplierlegalentity",
                //     title:"Supplier Legal Entity",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"_id.FMI_CATEGORY_NAME",
                    title:"FMI Type",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    }
                // },{
                //     field:"_id.FMI_Access_Type",
                //     title:"Access Type",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                // },{
                //     field:"_id.parent",
                //     title:"System Name",
                //     width:170,
                //     /*filterable: false,*/
                //     attributes: {
                //         "class": "field-ellipsis"
                //     }
                },{
                    field:"FMI_Transaction_Amount",
                    title:"FMI Transaction Amount",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                },{
                    field:"FMI_Transaction_Volume",
                    title:"FMI Transaction Volume",
                    format:"{0:N0}",
                    width:170,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis align-right"
                    }
                }
            ];
        }
    }
    var param = {
        ReceivingCountry :  country,
        Suppliername : fmi.receivingSupplierName(),
        LegalEntity : fmi.supplierLegalEntity(),
        Business : fmi.supplierCategory(),
        SupplierCountry : fmi.supplierCountry(),
        Parentprocessname : fmi.supplierLevelProcess(),
    
        Flag  : type,
        Fmitype : fmi.supplierFMIType(),
        Suppliertype : "FMI",
        Tab : "supplier" 
    }
    param.Suppliertype = fmi.supplierSupplierType();
    param.Classification = fmi.supplierClassification();
    var url = "/receiverview/getfmitooltip"
      $("#popupfmiSupplier").html("");
      $("#popupfmiSupplier").kendoGrid({
         dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, param, function(datas){
                        option.success(datas); 
                        $('#fmisuppliermodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
         },
         dataBound: function(){
            $('#popupfmiSupplier .k-grid-content').height(315);
        },
         height: 380,
         columns: column ,
        excel: {
            fileName: " FMI Receiver.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
};

fmi.receivingSetHoverValue =  function(country,type){
    // $("#popupfmivalue").remove();
   $("#amount-receiver-popup").css({"display":"none"});
    var param = {
        ReceivingCountry : fmi.receivingCountry(),
        Suppliername : fmi.receivingSupplierName(),
        LegalEntity : fmi.receivingLegalEntity(),
        Business : fmi.receivingCategory(),
        Parentprocessname : fmi.receivingLevelProcess(),
        SupplierCountry : country,
        Flag  : type,
        Fmitype : fmi.receivingFMIType(),
        Suppliertype : "FMI",
        Tab : "receiver"
    }
    param.Suppliertype =  fmi.receivingSupplierType();
    param.Classification = fmi.receivingClassification();
    var titleGrid;
    if (type == "suppliername"){
        titleGrid = "Supplier Name"
    } else if(type == "functionname"){
        titleGrid = "Function Name" 
    } else {
        titleGrid = " Level 1 Process"
    }

    fmi.headerModalReceiver(titleGrid);
    
    var url = "/receiverview/getdetailstooltip"
      $("#popupfmiReceiver").html("");
      $("#popupfmiReceiver").kendoGrid({
         dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, param, function(datas){
                        option.success(datas); 
                        $('#fmireceivermodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
         },
         dataBound: function(){
            $('#popupfmiReceiver .k-grid-content').height(315);
        },
         height: 380,
         columns: [{
            field:"_id",
            title:fmi.headerModalReceiver(),
            width:200,
            /*filterable: false,*/
            attributes: {
                "class": "field-ellipsis"
            }
        }],
        excel: {
            fileName: fmi.headerModalReceiver() + " FMI Receiver.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
};

fmi.supplierSetHoverValue =  function(country,type){
    $("#amount-supplier-popup").css({"display":"none"});
    var param = {
        ReceivingCountry :  country,
        Suppliername : fmi.supplierSupplierName(),
        LegalEntity : fmi.supplierLegalEntity(),
        Business : fmi.supplierCategory(),
        SupplierCountry : fmi.supplierCountry(),
        Parentprocessname : fmi.supplierLevelProcess(),

        Flag  : type,
        Fmitype : fmi.receivingFMIType(),
        Suppliertype : "FMI",
        Tab : "supplier"        
    }
    param.Suppliertype =  fmi.supplierSupplierType();
    param.Classification = fmi.supplierClassification();
    var titleGrid;
    if (type == "suppliername"){
        titleGrid = "Supplier Name"
    } else if(type == "functionname"){
        titleGrid = "Function Name" 
    } else {
        titleGrid = " Level 1 Process"
    }

    fmi.headerModalSupplier(titleGrid);
    
    var url = "/receiverview/getdetailstooltip"
      $("#popupfmiSupplier").html("");
      $("#popupfmiSupplier").kendoGrid({
         dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, param, function(datas){
                        option.success(datas);
                        $('#fmisuppliermodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
         },
         dataBound: function(){
            $('#popupfmiSupplier .k-grid-content').height(315);
        },
         height: 380,
         columns: [{
            field:"_id",
            title:fmi.headerModalSupplier(),
            width:200,
            /*filterable: false,*/
            attributes: {
                "class": "field-ellipsis"
            }
        }],
        excel: {
            fileName: fmi.headerModalSupplier() + " FMI Supplier.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
};

fmi.receivingVendorModal = function(supplierCountry){
    var suppliercountry =   suppliercountry || "";
    var payload = {
        ReceivingCountry    : fmi.receivingCountry(),
        LegalEntity         : fmi.receivingLegalEntity(),
        SupplierCountry     : supplierCountry,
        Parentprocessname   : fmi.receivingLevelProcess(),
        Suppliertype        : fmi.receivingSupplierType(),
        Classification      : fmi.receivingClassification(),
        Flag                : "vendorname",
        Tab                 : "receiver",
        Business            : fmi.receivingCategory(),
        Suppliername        : fmi.receivingSupplierName(),
        Fmitype             : fmi.receivingFMIType(),
    };   
    var url = "/receiverview/getdetailstooltip"; 
    $("#grid-popup-reciver-detailfmi").html("");
    $("#grid-popup-reciver-detailfmi").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas); 
                        $('#fmireceiverdetailsmodalt').modal('show');
                            setTimeout(function() {
                                $("#grid-popup-reciver-detailfmi").data("kendoGrid").resize();  
                        }, 500); 
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id",dir:"asc"},
            ],
        },
        height: 380,
        columns: [
            {
                field:"_id",
                title:"Vendor",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            }, 
        ],
        excel: {
            fileName: "popupfmiReceiverVendor.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        }, 
        height: 380,
    });
};
fmi.receivingSupplierVendorModal =  function(receivingCountry){
  var payload = {
        ReceivingCountry    :  receivingCountry,
        LegalEntity         : fmi.supplierLegalEntity(),
        SupplierCountry     : "",
        Parentprocessname   : fmi.supplierLevelProcess(),
        Suppliertype        : fmi.supplierSupplierType(),
        Classification      : fmi.supplierClassification(),
        Suppliername        : fmi.supplierSupplierName(),
        Flag                : "vendorname",
        Tab                 : "receiver",
        Business            : fmi.supplierCategory(),
        Fmitype             : fmi.supplierFMIType(),
    }; 

    var url = "/receiverview/getdetailstooltip";
    $("#grid-popup-reciver-detailfmi").html("");
    $("#grid-popup-reciver-detailfmi").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas); 
                        $('#fmireceiverdetailsmodalt').modal('show');
                            setTimeout(function() {
                                $("#grid-popup-reciver-detailfmi").data("kendoGrid").resize();  
                        }, 500); 
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id",dir:"asc"},
            ],
        },
        height: 380,
        columns: [
            {
                field:"_id",
                title:"Vendor",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            }, 
        ],
        excel: {
            fileName: "popupfmiReceiverVendor.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        }, 
        height: 380,
    });
};
fmi.receivingDetailsModal = function(supplierCountry){
    var supplierCountry =   supplierCountry || "";
    var payload = {
        ReceivingCountry    :  fmi.receivingCountry(),
        LegalEntity         : fmi.receivingLegalEntity(),
        SupplierCountry     : supplierCountry,
        Parentprocessname   : fmi.receivingLevelProcess(),
        Suppliertype        : fmi.receivingSupplierType(),
        Classification      : fmi.receivingClassification(),
        Flag                : "FMI",
        Tab                 : "receiver",
        Business            : fmi.receivingCategory(),
        Suppliername        : fmi.receivingSupplierName(),
        Fmitype             : fmi.receivingFMIType(),
    };   
    var url = "/receiverview/getfmidetailstooltip"; 
    $("#grid-popup-reciver-detailfmi").html("");
    $("#grid-popup-reciver-detailfmi").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas); 
                        $('#fmireceiverdetailsmodalt').modal('show');
                            setTimeout(function() {
                                $("#grid-popup-reciver-detailfmi").data("kendoGrid").resize();  
                        }, 500); 
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id.suppliername",dir:"asc"},
                {field:"_id.suppliercountry",dir:"asc"},
                {field:"_id.supplierlegalentity",dir:"asc"},
                {field:"_id.FMI_CATEGORY_NAME",dir:"asc"},
                {field:"_id.FMI_Access_Type",dir:"asc"}
            ],
        },
        height: 380,
        columns: [
            {
                field:"_id.suppliername",
                title:"FMI Name",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.receivercountry",
                title:"Receiver Country",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.receiverlegalentity",
                title:"Receiver Legal Entity",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.suppliercountry",
                title:"Supplier Country",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.supplierlegalentity",
                title:"Supplier Legal Entity",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.FMI_CATEGORY_NAME",
                title:"FMI Type",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.FMI_Access_Type",
                title:"Access Type",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.vendorname",
                title:"Vendor",
                width:170,
                template: function(e){
                    if(e._id.vendorname == "")
                        return "Not Available";
                    return e._id.vendorname;
                },               /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"FMI_Transaction_Amount",
                title:"FMI Transaction Amount",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"FMI_Transaction_Volume",
                title:"FMI Transaction Volume",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
        ],
        excel: {
            fileName: "popupfmiReceiver.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
};
fmi.receivingSupplierDetailsModal = function(receivingCountry){
    var payload = {
        ReceivingCountry :  receivingCountry,
        LegalEntity : fmi.supplierLegalEntity(),
        SupplierCountry : "",
        Parentprocessname : fmi.supplierLevelProcess(),
        Suppliertype: fmi.supplierSupplierType(),
        Classification: fmi.supplierClassification(),
        Suppliername : fmi.supplierSupplierName(),
        Flag : "FMI",
        Tab : "receiver",
        Business : fmi.supplierCategory(),
        Fmitype : fmi.supplierFMIType(),
    };
 
    
    var url = "/receiverview/getfmidetailstooltip";
    
    $("#grid-popup-supplier-detailfmi").html("");
    $("#grid-popup-supplier-detailfmi").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#fmisupplierdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id.suppliername",dir:"asc"},
                {field:"_id.suppliercountry",dir:"asc"},
                {field:"_id.supplierlegalentity",dir:"asc"},
                {field:"_id.FMI_CATEGORY_NAME",dir:"asc"},
                {field:"_id.FMI_Access_Type",dir:"asc"}
            ],
        },
        dataBound: function(){
            $('#grid-popup-supplier-detailfmi .k-grid-content').height(315);
        }, 
        height: 380,
        excel: {
            fileName: "Supplier Detail FMI.xlsx",
            allPages: true
        },
        columns: [
            {
                field:"_id.suppliername",
                title:"FMI Name",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.receivercountry",
                title:"Receiver Country",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.receiverlegalentity",
                title:"Receiver Legal Entity",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.suppliercountry",
                title:"Supplier Country",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.supplierlegalentity",
                title:"Supplier Legal Entity",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.FMI_CATEGORY_NAME",
                title:"FMI Type",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.FMI_Access_Type",
                title:"Access Type",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
        ],
        excel: {
            fileName: "popupfmiSupplier.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });    
};


fmi.SupplierVendorModal  = function(receivingCountry){
    var receivingCountry =   receivingCountry || "";
    var payload = {
        ReceivingCountry    : receivingCountry,
        LegalEntity         : fmi.supplierLegalEntity(),
        SupplierCountry     : fmi.supplierCountry(),
        Parentprocessname   : fmi.supplierLevelProcess(),
        Suppliertype        : fmi.supplierSupplierType(),
        Classification      : fmi.supplierClassification(),
        Suppliername        : fmi.supplierSupplierName(),
        Flag                : "vendorname",
        Tab                 : "supplier",
        Business            : fmi.supplierCategory(),
        Fmitype             : fmi.supplierFMIType(),
    };
    
    var url = "/receiverview/getdetailstooltip";
    $("#grid-popup-supplier-detailfmi").html("");
    $("#grid-popup-supplier-detailfmi").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#fmisupplierdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id",dir:"asc"}, 
            ],
        },
        dataBound: function(){
            $('#grid-popup-supplier-detailfmi .k-grid-content').height(315);
        }, 
        height: 380,
        excel: {
            fileName: "popupfmiSupplierVendor.xlsx",
            allPages: true
        },
        columns: [
            {
                field:"_id",
                title:"Vendor",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            } 
        ],
        excel: {
            fileName: "popupfmiSupplier.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    }); 
};
fmi.supplierReceivingVendorModal = function(supplierCountry){
    var payload = {
        ReceivingCountry : "",
        LegalEntity : fmi.receivingLegalEntity(),
        SupplierCountry : supplierCountry,
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        Flag : "vendorname",
        Tab : "supplier",
        Business : fmi.receivingCategory(),
        Fmitype : fmi.receivingFMIType(),
        Suppliername : fmi.receivingSupplierName(),
    };  
    var url = "/receiverview/getdetailstooltip";
    $("#grid-popup-supplier-detailfmi").html("");
    $("#grid-popup-supplier-detailfmi").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#fmisupplierdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id",dir:"asc"}, 
            ],
        },
        dataBound: function(){
            $('#grid-popup-supplier-detailfmi .k-grid-content').height(315);
        }, 
        height: 380,
        excel: {
            fileName: "popupfmiSupplierVendor.xlsx",
            allPages: true
        },
        columns: [
            {
                field:"_id",
                title:"Vendor",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            } 
        ],
        excel: {
            fileName: "popupfmiSupplier.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    }); 
};
fmi.SupplierDetailsModal = function(receivingCountry){
    var receivingCountry =   receivingCountry || "";
    var payload = {
        ReceivingCountry :  receivingCountry,
        LegalEntity : fmi.supplierLegalEntity(),
        SupplierCountry : fmi.supplierCountry(),
        Parentprocessname : fmi.supplierLevelProcess(),
        Suppliertype: fmi.supplierSupplierType(),
        Classification: fmi.supplierClassification(),
        Suppliername : fmi.supplierSupplierName(),
        Flag : "FMI",
        Tab : "supplier",
        Business : fmi.supplierCategory(),
        Fmitype : fmi.supplierFMIType(),
    };
    
    var url = "/receiverview/getfmidetailstooltip";
    $("#grid-popup-supplier-detailfmi").html("");
    $("#grid-popup-supplier-detailfmi").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#fmisupplierdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id.suppliername",dir:"asc"},
                {field:"_id.receivercountry",dir:"asc"},
                {field:"_id.receiverlegalentity",dir:"asc"},
                {field:"_id.FMI_CATEGORY_NAME",dir:"asc"},
                {field:"_id.FMI_Access_Type",dir:"asc"}
            ],
        },
        dataBound: function(){
            $('#grid-popup-supplier-detailfmi .k-grid-content').height(315);
        }, 
        height: 380,
        excel: {
            fileName: "Supplier Detail FMI.xlsx",
            allPages: true
        },
        columns: [
            {
                field:"_id.suppliername",
                title:"FMI Name",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.receivercountry",
                title:"Receiver Country",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.receiverlegalentity",
                title:"Receiver Legal Entity",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.suppliercountry",
                title:"Supplier Country",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.supplierlegalentity",
                title:"Supplier Legal Entity",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.FMI_CATEGORY_NAME",
                title:"FMI Type",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.FMI_Access_Type",
                title:"Access Type",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.vendorname",
                title:"Vendor",
                width:170,
                template: function(e){
                    if(e._id.vendorname == "")
                        return "Not Available";
                    return e._id.vendorname;
                },               /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"FMI_Transaction_Amount",
                title:"FMI Transaction Amount",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"FMI_Transaction_Volume",
                title:"FMI Transaction Volume",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            }
        ],
        excel: {
            fileName: "popupfmiSupplier.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });    
};
fmi.supplierReceivingDetailsModal = function(supplierCountry){
    var payload = {
        ReceivingCountry : "",
        LegalEntity : fmi.receivingLegalEntity(),
        SupplierCountry : supplierCountry,
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        Flag : "FMI",
        Tab : "supplier",
        Business : fmi.receivingCategory(),
        Fmitype : fmi.receivingFMIType(),
        Suppliername : fmi.receivingSupplierName(),
    };  
    var url = "/receiverview/getfmidetailstooltip"; 
    $("#grid-popup-reciver-detailfmi").html("");
    $("#grid-popup-reciver-detailfmi").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas); 
                        $('#fmireceiverdetailsmodalt').modal('show');
                            setTimeout(function() {
                                $("#grid-popup-reciver-detailfmi").data("kendoGrid").resize();  
                        }, 500); 
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id.suppliername",dir:"asc"},
                {field:"_id.receivercountry",dir:"asc"},
                {field:"_id.receiverlegalentity",dir:"asc"},
                {field:"_id.FMI_CATEGORY_NAME",dir:"asc"},
                {field:"_id.FMI_Access_Type",dir:"asc"}
            ],
        },
        height: 380,
        columns: [
            {
                field:"_id.suppliername",
                title:"FMI Name",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.receivercountry",
                title:"Receiver Country",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.receiverlegalentity",
                title:"Receiver Legal Entity",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.suppliercountry",
                title:"Supplier Country",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.supplierlegalentity",
                title:"Supplier Legal Entity",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.FMI_CATEGORY_NAME",
                title:"FMI Type",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },{
                field:"_id.FMI_Access_Type",
                title:"Access Type",
                width:170,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
        ],
        excel: {
            fileName: "popupfmiReceiver.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
};



fmi.receivingMapDetails = function(dataSource){
    fmi.receivingPrepareMap();    
        // fmi.receivingLegendShow(false);
    var dSource = dataSource.BubbleSupplier.features;
    var fromlatLng = [dataSource.BoxInfo.Longitude,dataSource.BoxInfo.Latitude];
    var boxLabel = dataSource.BoxInfo
    var receivingCountry = fmi.receivingCountry().replace("'", "&#39;");
   
    var greenIcon = L.icon({
                        iconUrl: '/live/static/img/marker-green.png',
                        iconSize:     [20, 45], // size of the icon 
                    });    
    var blueIcon = L.icon({
                        iconUrl: '/live/static/img/marker-blue.png',
                        iconSize:     [20, 45], // size of the icon 
                    }); 
    var greyIcon = L.icon({
                        iconUrl: '/live/static/img/marker-grey.png',
                        iconSize:     [20, 45], // size of the icon 
                    });
    var receiverIcon = L.icon({
                        iconUrl: '/live/static/img/receiver-marker2.png',
                        iconSize:     [20, 30], // size of the icon 
                    });
    // var mbAttr = 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
    //         '<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
    //         'Imagery © <a href="http://mapbox.com">Mapbox</a>',
    //     mbUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpandmbXliNDBjZWd2M2x6bDk3c2ZtOTkifQ._QA7i5Mpkd_m30IGElHziw';

    // var grayscale   = L.tileLayer(mbUrl, {id: 'mapbox.light', attribution: mbAttr,minZoom: 2});
    var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});
     
    var map = L.map('map-fmi-receiving', {
        center: [1,38],
        zoom: 2,
        layers: grayscale,
            zoomControl: false,
    }) 
      L.control.zoom({
         position:'topright'
    }).addTo(map);
    var allSupplier = {"SupplierName": 0,"FunctionName":0,"LevelOne":0, "count":0, "FMI":0}; 
  
    var path = []
    for(var i in dSource){
        data = dSource[i]
        if(fromlatLng[1] === dSource[i].geometry.coordinates[1] && fromlatLng[0] === dSource[i].geometry.coordinates[0]){
 
            allSupplier = {Vendor: data.properties.Vendor, "SupplierName": data.properties.SupplierName ,"FunctionName":data.properties.FunctionName,"LevelOne":data.properties.LevelOne, "count":data.properties.count, "FMI":data.properties.FMI};
       
        }
        if(fromlatLng[1] !== dSource[i].geometry.coordinates[1] && fromlatLng[0] !== dSource[i].geometry.coordinates[0] ){      
            if(dSource[i].properties.count <= 5){
                var icon = greyIcon;
            }else if(dSource[i].properties.count <= 20){
                var icon =greenIcon;
            }  else {
                var icon = blueIcon; 
            }
        
            var marker = L.marker([dSource[i].geometry.coordinates[1], dSource[i].geometry.coordinates[0]], {icon: icon}).addTo(map);
            var templatePopUp = ["<span style='color:#0644a0'>Supplier Country Data</span>",
                                "<a href='#supplier_"+data.properties.SecondaryID+"'><b>"+ data.properties.SecondaryID + "</b></a>",
                                "# of Suppliers : <a onclick='fmi.receivingSetHoverValue(\""+data.properties.SecondaryID+"\",\"suppliername\")' href='#'>"+data.properties.SupplierName+" </a>",
                                "# of Functions : <a onclick='fmi.receivingSetHoverValue(\""+data.properties.SecondaryID+"\",\"functionname\")' href='#'>"+data.properties.FunctionName+"  </a>",
                                // "Total FTE : "+ kendo.toString(data.properties.count, 'N2'),
                                "# of Level 1 Processes : <a onclick='fmi.receivingSetHoverValue(\""+data.properties.SecondaryID+"\",\"Level1Process\")' href='#'> "+data.properties.LevelOne+"  </a>",   
                                "# of FMI  : <a onclick='fmi.receivingFMIValue(\""+data.properties.SecondaryID+"\",\"fmi\")' href='#'> "+data.properties.FMI+"  </a>",
                                "# of Vendors :  <a onclick='fmi.receivingVendorModal(\""+data.properties.SecondaryID+"\")' href='#'> "+data.properties.Vendor+" </a>",
                                "<a onclick='fmi.receivingDetailsModal(\""+data.properties.SecondaryID+"\")' href='#'>Details</a>"].join("<br>");   

            marker.bindPopup(templatePopUp);
            marker.on('mouseover', function (e) {
                this.openPopup();
            });
            latSelisih = Math.abs( Math.abs(fromlatLng[1]) -  Math.abs(dSource[i].geometry.coordinates[1]))
            lngSelisih = Math.abs( Math.abs(fromlatLng[0]) -  Math.abs(dSource[i].geometry.coordinates[0]))
            var x = 0;
            if(latSelisih >= 1 && latSelisih <= 5){
                if (lngSelisih >= 1 && lngSelisih <= 5 ){
                    x = 1
                }else if (lngSelisih > 5 && lngSelisih <= 16 ){
                    x = 4   
                }else{
                    x = 9
                }
                
                
            }else if(latSelisih > 5 && latSelisih <= 10 ){
                if (lngSelisih >= 1 && lngSelisih <= 5 ){
                    x = 1
                }else if (lngSelisih > 5 && lngSelisih <= 10 ){
                    x = 4   
                }else{
                    x = 9
                }
                
            }else if ((latSelisih > 10 && latSelisih <= 15 ) && (lngSelisih > 10 && lngSelisih <= 15 ) ){
                x = 10
            }else{
                if (lngSelisih >= 1 && lngSelisih <= 5 ){
                    x = 1
                }else if (lngSelisih > 5 && lngSelisih <= 10 ){
                    x = 4   
                }else{
                    x = 9
                }
            }
           
            latCenter = ((fromlatLng[1] + dSource[i].geometry.coordinates[1]) / 2) + x
           
            if(Math.abs(lngSelisih <= 15)){
                lngCenter = ((fromlatLng[0] + dSource[i].geometry.coordinates[0]) / 2 ) + x
               
            }else{
                lngCenter = ((fromlatLng[0] + dSource[i].geometry.coordinates[0]) / 2 )     
            }
     
            path.push(L.curve(['M',[fromlatLng[1],fromlatLng[0] ],
                                'Q',[latCenter,lngCenter],
                                    [dSource[i].geometry.coordinates[1],dSource[i].geometry.coordinates[0]]],{color:data.properties.Color}).addTo(map));
        }
    } 

    var templatePopUpReceivingCountry = 
                        [
                       "<a href='#supplier_"+fmi.receivingCountry()+"'><b>"+ fmi.receivingCountry()+ "</b></a><span style='color:#0644a0'> as Receiver</span>",
                        "# of Suppliers : <a onclick='fmi.receivingSetHoverValue(\"\",\"suppliername\")' href='#'>"+boxLabel.SupplierName+"</a>",
                        "# of Functions : <a onclick='fmi.receivingSetHoverValue(\"\",\"functionname\")' href='#'>"+boxLabel.FunctionName+"</a>",
                        // "Total FTE : "+  kendo.toString(boxLabel.FTE, 'N2'),
                        "# of Level 1 Processes : <a onclick='fmi.receivingSetHoverValue(\"\",\"Level1Process\")' href='#'>"+boxLabel.LevelOne+" </a>",
                        "# of FMI : <a onclick='fmi.receivingFMIValue(\"\",\"fmi\")' href='#'> "+boxLabel.FMI+"  </a>",   
                         "# of Vendors : <a onclick='fmi.receivingVendorModal()' href='#'>"+boxLabel.Vendor+"  </a>", 
                        "<a onclick='fmi.receivingDetailsModal()' href='#'>Details</a></br>",
                        

                        "<a href='#supplier_"+fmi.receivingCountry()+"'><b>"+ fmi.receivingCountry()+ "</b></a><span style='color:#0644a0'> as  Supplier</span>",
                        "# of Suppliers : <a onclick='fmi.receivingSetHoverValue(\""+receivingCountry+"\",\"suppliername\")' href='#'>"+ allSupplier.SupplierName+"</a>",
                        "# of Functions : <a onclick='fmi.receivingSetHoverValue(\""+receivingCountry+"\",\"functionname\")' href='#'>"+ allSupplier.FunctionName+"</a>",
                        // "# Total FTE :"+kendo.toString(allSupplier.count, 'N2')+"",
                        "# of Level 1 Processes : <a onclick='fmi.receivingSetHoverValue(\""+receivingCountry+"\",\"Level1Process\")' href='#'>"+allSupplier.LevelOne+"</a>",
                        "# of FMI : <a onclick='fmi.receivingFMIValue(\""+receivingCountry+"\",\"fmi\")' href='#'> "+allSupplier.FMI+"  </a>",  
                        "# of Vendors : <a onclick='fmi.receivingVendorModal(\""+receivingCountry+"\")' href='#'> "+allSupplier.Vendor+"  </a>", 
                        "<a onclick='fmi.receivingDetailsModal(\""+receivingCountry+"\")' href='#'>Details</a>"
                       
                        ]
                        .join("<br>") 
    defMarker = L.marker([fromlatLng[1], fromlatLng[0]], {icon: receiverIcon}).addTo(map)
        .bindPopup(templatePopUpReceivingCountry).openPopup();
    defMarker.on('mouseover', function (e) {
            this.openPopup();
    });

    $('path[class="leaflet-interactive"]').attr('stroke-width',"2"); 
    // L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxNWVubjg2MDA2NWZta2tnc2NocnF4ZyJ9.NDWpdAW4qO42qUdRBNIa5Q';
    // var mapLeaflet = L.mapbox.map('map-int-receiving', 'mapbox.light',{'worldCopyJump': true, minZoom: 2}).setView([1,38], 2)
    
    // var geoJson = dataSource.BubbleSupplier.features; 
    // var indexDelete;
    // var startLine = {x:dataSource.BoxInfo.Longitude, y:dataSource.BoxInfo.Latitude}
    // var allSupplier = {"SupplierName": 0,"FunctionName":0,"LevelOne":0, "count":0}; 
    // $.each(geoJson, function(i,v){
    //     if(v.geometry.coordinates[0].toFixed(0) == dataSource.BoxInfo.Longitude.toFixed(0) && v.geometry.coordinates[1].toFixed(0) == dataSource.BoxInfo.Latitude.toFixed(0)) {         
            
    //         $.extend(allSupplier,v.properties)
            
    //         indexDelete = i
    //     }else{
    //         var color;
    //         if(v.properties.count <= 5){
    //             color = "#7F7F7F";
    //         }else if(v.properties.count <= 20){
    //             color = "#b5ce7d";
    //         }  else {
    //             color = "#60B4E4"; 
    //         }
            
    //         var newProperties = {"marker-size": "small","marker-symbol":"marker","marker-color":color}; 
    //         $.extend(true, v.properties,newProperties)
    //         var endLine = {x:v.geometry.coordinates[0], y: v.geometry.coordinates[1]};
            
    //         var generator = new arc.GreatCircle(startLine, endLine, {});
      
    //         var line = generator.Arc(100, { offset: 20 });
                
    //         var line_options = { opacity: 1, weight: 2,color:v.properties.Color };
    //         L.geoJson(line.json(),line_options).addTo(mapLeaflet);
    //         // L.geoJson(line.json().line_optionsxnxn).addTo(mapLeaflet);
     
    //     }
    // });   

    // (indexDelete === undefined)?'': geoJson.splice(indexDelete,1)
    // var boxLabel = dataSource.BoxInfo
    // var labelFte =  (boxLabel.fte=== null)? boxLabel.fte : kendo.toString(boxLabel.fte, 'N1')
    // var receivingCountry = fmi.receivingCountry().replace("'", "&#39;");

    // var templatePopUpReceivingCountry = 
    //                     [
    //                    "<a href='#supplier_"+fmi.receivingCountry()+"'><b>"+ fmi.receivingCountry()+ "</b></a><span style='color:#0644a0'> as Receiver</span>",
    //                     "# of Suppliers : <a onclick='fmi.receivingSetHoverValue(\"\",\"suppliername\")' href='#'>"+boxLabel.SupplierName+"</a>",
    //                     "# of Functions : <a onclick='fmi.receivingSetHoverValue(\"\",\"functionname\")' href='#'>"+boxLabel.FunctionName+"</a>",
    //                     "Total FTE : "+  kendo.toString(boxLabel.FTE, 'N2'),
    //                     "# of Level 1 Processes : <a onclick='fmi.receivingSetHoverValue(\"\",\"Level1Process\")' href='#'>"+boxLabel.LevelOne+" </a>",
    //                     "<a onclick='fmi.receivingDetailsModal()' href='#'>Details</a></br>",

    //                     "<a href='#supplier_"+fmi.receivingCountry()+"'><b>"+ fmi.receivingCountry()+ "</b></a><span style='color:#0644a0'> as  Supplier</span>",
    //                     "# of Suppliers : <a onclick='fmi.receivingSetHoverValue(\""+receivingCountry+"\",\"suppliername\")' href='#'>"+ allSupplier.SupplierName+"</a>",
    //                     "# of Functions : <a onclick='fmi.receivingSetHoverValue(\""+receivingCountry+"\",\"functionname\")' href='#'>"+ allSupplier.FunctionName+"</a>",
    //                     "# Total FTE :"+kendo.toString(allSupplier.count, 'N2')+"",
    //                     "# of Level 1 Processes : <a onclick='fmi.receivingSetHoverValue(\""+receivingCountry+"\",\"Level1Process\")' href='#'>"+allSupplier.LevelOne+"</a>",
    //                     "<a onclick='fmi.receivingDetailsModal(\""+receivingCountry+"\")' href='#'>Details</a></br>"
    //                     ]
    //                     .join("<br>") 
    //     var receiverMarker = L.marker([dataSource.BoxInfo.Latitude, dataSource.BoxInfo.Longitude], {
    //     icon : L.icon( {
    //         iconUrl : '/static/img/receiver-marker.png',
    //     } )
    // } ).addTo( mapLeaflet ).bindPopup(templatePopUpReceivingCountry).openPopup();

    // receiverMarker.on("mouseover", function(e) {
    //    var popup = L.popup()
    //        .setLatLng([boxLabel.Latitude, boxLabel.Longitude]) 
    //        .setContent(templatePopUpReceivingCountry)
    //        .openOn(mapLeaflet);
    // });

    // var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    // myLayer.setGeoJSON(geoJson);
   
    // myLayer.on("mouseover", function(e) {
    //     var supplierCountry = e.layer.feature.properties['SecondaryID'].replace("'", "&#39;");
    //     var templatePopUp = [
    //                 "<span style='color:#0644a0'>Supplier Country Data</span>",
    //                         "<a href='#supplier_"+e.layer.feature.properties['SecondaryID']+"'><b>"+ supplierCountry + "</b></a>",
    //                         "# of Suppliers : <a onclick='fmi.receivingSetHoverValue(\""+supplierCountry+"\",\"suppliername\")' href='#'>"+e.layer.feature.properties['SupplierName']+" </a>",
    //                         "# of Functions : <a onclick='fmi.receivingSetHoverValue(\""+supplierCountry+"\",\"functionname\")' href='#'>"+e.layer.feature.properties['FunctionName']+"  </a>",
    //                         "Total FTE : "+ kendo.toString(e.layer.feature.properties['count'], 'N2'),
    //                         "# of Level 1 Processes : <a onclick='fmi.receivingSetHoverValue(\""+supplierCountry+"\",\"Level1Process\")' href='#'> "+e.layer.feature.properties['LevelOne']+"  </a>",   
    //                         "<a onclick='fmi.receivingDetailsModal(\""+supplierCountry+"\")' href='#'>Details</a>"].join("<br>")   
    //     var popup = L.popup()
    //        .setLatLng(e.latlng) 
    //        .setContent(templatePopUp)
    //        .openOn(mapLeaflet);
    // });

    // receiverMarker.on("click", function(e) {
    //     window.location.href = '#supplier_'+fmi.receivingCountry();
    //     //     // var payloadSummary={
    //     //     //     Suppliertype :  receiver.supplierType(),
    //     //     //     ReceivingCountry :  receiver.receivingCountry(),
    //     //     //     LegalEntity : [],
    //     //     //     SupplierCountry : ''
    //     //     // }
    //     //     // ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
    //     //     //   receiver.createSummary(res)
    //     //     // })    
    // });
    // myLayer.on('click', function(e) {
    //     window.location.href = '#supplier_'+e.layer.feature.properties['SecondaryID'];
    //     //     // var country = e.layer.feature.properties['SecondaryID']
    //     //     // var payloadSummary={
    //     //     //     Suppliertype :  receiver.supplierType(),
    //     //     //     ReceivingCountry :  receiver.receivingCountry(),
    //     //     //     LegalEntity : [],
    //     //     //     SupplierCountry : country
    //     //     // }
    //     //     // ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
    //     //     //     receiver.createSummary(res)
    //     //     // })
    // });
};

fmi.supplierMapDetails = function(dataSource){
    fmi.supplierPrepareMap();    
    // fmi.supplierLegendShow(false);
    var dSource = dataSource.BubbleSupplier.features;
    var fromlatLng = [dataSource.BoxInfo.Longitude,dataSource.BoxInfo.Latitude];
    var boxLabel = dataSource.BoxInfo
    var supplierCountry = fmi.supplierCountry().replace("'", "&#39;");
    var allSupplier = {"SupplierName": 0,"FunctionName":0,"LevelOne":0, "count":0, "FMI":0}; ; 
    var greenIcon = L.icon({
                        iconUrl: '/live/static/img/marker-green.png',
                        iconSize:     [20, 45], // size of the icon 
                    });    
    var blueIcon = L.icon({
                        iconUrl: '/live/static/img/marker-blue.png',
                        iconSize:     [20, 45], // size of the icon 
                    }); 
    var greyIcon = L.icon({
                        iconUrl: '/live/static/img/marker-grey.png',
                        iconSize:     [20, 45], // size of the icon 
                    });
    var receiverIcon = L.icon({
                        iconUrl: '/live/static/img/supplier-marker2.png',
                        iconSize:     [20, 30], // size of the icon 
                    });
    // var mbAttr = 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
    //         '<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
    //         'Imagery © <a href="http://mapbox.com">Mapbox</a>',
    //     mbUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpandmbXliNDBjZWd2M2x6bDk3c2ZtOTkifQ._QA7i5Mpkd_m30IGElHziw';

    // var grayscale   = L.tileLayer(mbUrl, {id: 'mapbox.light', attribution: mbAttr,minZoom: 2});
     var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});
     
    var map = L.map('map-fmi-supplier', {
        center: [1,38],
        zoom: 2,
        layers: grayscale,
            zoomControl: false,
    }) 
      L.control.zoom({
         position:'topright'
    }).addTo(map);
    
    var path = []
    for(var i in dSource){
        data = dSource[i]
        if(fromlatLng[1] === dSource[i].geometry.coordinates[1] && fromlatLng[0] === dSource[i].geometry.coordinates[0]){
 
            allSupplier = {Vendor: data.properties.Vendor, "SupplierName": data.properties.SupplierName ,"FunctionName":data.properties.FunctionName,"LevelOne":data.properties.LevelOne, "count":data.properties.count, "FMI":data.properties.FMI};
       
        }
        if(fromlatLng[1] !== dSource[i].geometry.coordinates[1] && fromlatLng[0] !== dSource[i].geometry.coordinates[0] ){      
        if(dSource[i].properties.count <= 5){
            var icon = greyIcon;
        }else if(dSource[i].properties.count <= 20){
            var icon =greenIcon;
        }  else {
            var icon = blueIcon; 
        }
        
        var marker = L.marker([dSource[i].geometry.coordinates[1], dSource[i].geometry.coordinates[0]], {icon: icon}).addTo(map);
        var templatePopUp = [
                        "<span style='color:#0644a0'>Receiver Country Data</span>",
                        "<a href='#receiver_"+data.properties.SecondaryID+"'><b>"+ data.properties.SecondaryID + "</b></a>",
                        "# of Suppliers : <a onclick='fmi.supplierSetHoverValue(\""+data.properties.SecondaryID+"\",\"suppliername\")' href='#'> "+ data.properties.SupplierName +"  </a>",
                        "# of Functions : <a onclick='fmi.supplierSetHoverValue(\""+data.properties.SecondaryID+"\",\"functionname\")' href='#'>"+ data.properties.FunctionName +" </a>",
                        // "Total FTE : "+ kendo.toString( data.properties.count, 'N2'),
                        "# of Level 1 Processes : <a onclick='fmi.supplierSetHoverValue(\""+data.properties.SecondaryID+"\",\"Level1Process\")' href='#'> "+ data.properties.LevelOne +" </a>",
                        "# of FMI : <a onclick='fmi.supplierFMIValue(\""+data.properties.SecondaryID+"\",\"fmi\")' href='#'> "+data.properties.FMI+"  </a>",
                        "# of Vendors : <a onclick='fmi.SupplierVendorModal(\""+data.properties.SecondaryID+"\")' href='#'>"+data.properties.Vendor+"  </a>",
                        "<a onclick='fmi.SupplierDetailsModal(\""+data.properties.SecondaryID+"\")' href='#'>Details</a>"].join("<br>");   
        marker.bindPopup(templatePopUp);
        marker.on('mouseover', function (e) {
            this.openPopup();
        });
        // marker.on('mouseout', function (e) {
        //     this.closePopup();
        // });
        latSelisih = Math.abs( Math.abs(fromlatLng[1]) -  Math.abs(dSource[i].geometry.coordinates[1]))
        lngSelisih = Math.abs( Math.abs(fromlatLng[0]) -  Math.abs(dSource[i].geometry.coordinates[0]))
       var x = 0;
        if(latSelisih >= 1 && latSelisih <= 5){
            if (lngSelisih >= 1 && lngSelisih <= 5 ){
                x = 1
            }else if (lngSelisih > 5 && lngSelisih <= 16 ){
                x = 4   
            }else{
                x = 9
            }
            
            
        }else if(latSelisih > 5 && latSelisih <= 10 ){
            if (lngSelisih >= 1 && lngSelisih <= 5 ){
                x = 1
            }else if (lngSelisih > 5 && lngSelisih <= 10 ){
                x = 4   
            }else{
                x = 9
            }
            
        }else if ((latSelisih > 10 && latSelisih <= 15 ) && (lngSelisih > 10 && lngSelisih <= 15 ) ){
            x = 10
        }else{
            if (lngSelisih >= 1 && lngSelisih <= 5 ){
                x = 1
            }else if (lngSelisih > 5 && lngSelisih <= 10 ){
                x = 4   
            }else{
                x = 9
            }
        }
       
        latCenter = ((fromlatLng[1] + dSource[i].geometry.coordinates[1]) / 2) + x
       
        if(Math.abs(lngSelisih <= 15)){
            lngCenter = ((fromlatLng[0] + dSource[i].geometry.coordinates[0]) / 2 ) + x
           
        }else{
            lngCenter = ((fromlatLng[0] + dSource[i].geometry.coordinates[0]) / 2 )     
        }
 
        path.push(L.curve(['M',[fromlatLng[1],fromlatLng[0] ],
                            'Q',[latCenter,lngCenter],
                                [dSource[i].geometry.coordinates[1],dSource[i].geometry.coordinates[0]]],{color:data.properties.Color}).addTo(map));
        }
    } 
    var templatePopUpReceivingCountry = [
                    "<a href='#receiver_"+fmi.supplierCountry()+"'><b>"+ fmi.supplierCountry() + "</b></a><span style='color:#0644a0'> as Supplier</span>",
                    "# of Receivers :  <a onclick='fmi.supplierSetHoverValue(\"\",\"receivername\")' href='#'> "+boxLabel.SupplierName+"</a>",
                    "# of Functions :  <a onclick='fmi.supplierSetHoverValue(\"\",\"functionname\")' href='#'>"+boxLabel.FunctionName+"</a>",
                    // "Total FTE : "+  kendo.toString(boxLabel.FTE, 'N2'),
                    "# of Level 1 Processes : <a onclick='fmi.supplierSetHoverValue(\"\",\"Level1Process\")' href='#'>  "+boxLabel.LevelOne+"</a>",
                    "# of FMI : <a onclick='fmi.supplierFMIValue(\"\",\"fmi\")' href='#'> "+boxLabel.FMI+"</a>",   
                    "# of Vendors : <a onclick='fmi.SupplierVendorModal()' href='#'>"+boxLabel.Vendor+"  </a>",
                    "<a onclick='fmi.SupplierDetailsModal()' href='#'>Details</a></br>",
                     

                    "<a href='#receiver_"+fmi.supplierCountry()+"'><b>"+ fmi.supplierCountry() + "</b></a><span style='color:#0644a0'> as Receiver</span>",
                    "# of Suppliers :<a onclick='fmi.supplierSetHoverValue(\""+supplierCountry+"\",\"suppliername\")' href='#'>"+allSupplier.SupplierName+"</a>",
                    "# of Functions :<a onclick='fmi.supplierSetHoverValue(\""+supplierCountry+"\",\"functionname\")' href='#'>"+allSupplier.FunctionName+"</a>",
                    // "# Total FTE :"+ kendo.toString(allSupplier.count, 'N2')+"",
                    "# of Level 1 Processes : <a onclick='fmi.supplierSetHoverValue(\""+supplierCountry+"\",\"Level1Process\")' href='#'> "+allSupplier.LevelOne+"</a>",
                    "# of FMI : <a onclick='fmi.supplierFMIValue(\""+supplierCountry+"\",\"fmi\")' href='#'> "+allSupplier.FMI+"  </a>", 
                    "# of Vendors :  <a onclick='fmi.SupplierVendorModal(\""+supplierCountry+"\")' href='#'> "+allSupplier.Vendor+"  </a>",                     
                    "<a onclick='fmi.SupplierDetailsModal(\""+supplierCountry+"\")' href='#'>Details</a>"].join("<br>")

   defMarker =  L.marker([fromlatLng[1], fromlatLng[0]], {icon: receiverIcon}).addTo(map)
        .bindPopup(templatePopUpReceivingCountry).openPopup();
    defMarker.on('mouseover', function (e) {
            this.openPopup();
    });
    $('path[class="leaflet-interactive"]').attr('stroke-width',"2"); 


    // console.log(JSON.stringify(dataSource))
    // fmi.supplierPrepareMap();
    // L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxNWVubjg2MDA2NWZta2tnc2NocnF4ZyJ9.NDWpdAW4qO42qUdRBNIa5Q';
    // var mapLeaflet = L.mapbox.map('map-int-supplier', 'mapbox.light',{'worldCopyJump': true, minZoom: 2}).setView([1,38], 2)    
    // var geoJson = dataSource.BubbleSupplier.features; 
    // var indexDelete;
    // var startLine = {x:dataSource.BoxInfo.Longitude, y:dataSource.BoxInfo.Latitude}
    
    // var allSupplier = {"SupplierName": 0,"FunctionName":0,"LevelOne":0, "count":0}; ; 
   
    // // var pathOne = L.curve(['M',[50.14874640066278,14.106445312500002],
    // //                    'Q',[51.67255514839676,16.303710937500004],
    // //                        [50.14874640066278,18.676757812500004],
    // //                    'T',[49.866316729538674,25.0927734375]]).addTo(mapLeaflet);
    // $.each(geoJson, function(i,v){
    //     if(v.geometry.coordinates[0].toFixed(0) == dataSource.BoxInfo.Longitude.toFixed(0) && v.geometry.coordinates[1].toFixed(0) ==  dataSource.BoxInfo.Latitude.toFixed(0)) {         
    //         indexDelete = i 
        
    //         $.extend(allSupplier,v.properties)
    //     }else{
    //          var color;
    //         if(v.properties.count <= 5){
    //             color = "#7F7F7F";
    //         }else if(v.properties.count <= 20){
    //             color = "#b5ce7d";
    //         }  else {
    //             color = "#60B4E4"; 
    //         }
            
    //         var newProperties = {"marker-size": "small","marker-symbol":"marker","marker-color":color}; 
    //         $.extend(true, v.properties,newProperties)

    //          var endLine = {x:v.geometry.coordinates[0], y: v.geometry.coordinates[1]};
      


    //        var generator = new arc.GreatCircle(startLine,endLine,{color: "#CBA23C" });
            
    //         var line = generator.Arc(200, { offset: 0 });
    //         var line_options = { opacity: 1, weight: 2,color:v.properties.Color};
    //         L.geoJson(line.json(),line_options).addTo(mapLeaflet);
    //     }
    // });
    // (indexDelete === undefined)?'': geoJson.splice(indexDelete,1)

    // var supplierCountry = fmi.supplierCountry().replace("'", "&#39;");
    // var boxLabel = dataSource.BoxInfo
    // var labelFte =  (boxLabel.fte=== null)? boxLabel.fte : kendo.toString(boxLabel.fte, 'N1')
    // var templatePopUpReceivingCountry = [
    //             "<a href='#receiver_"+fmi.supplierCountry()+"'><b>"+ fmi.supplierCountry() + "</b></a><span style='color:#0644a0'> as Supplier</span>",
    //             "# of Receivers :  <a onclick='fmi.supplierSetHoverValue(\"\",\"receivername\")' href='#'> "+boxLabel.SupplierName+"</a>",
    //             "# of Functions :  <a onclick='fmi.supplierSetHoverValue(\"\",\"functionname\")' href='#'>"+boxLabel.FunctionName+"</a>",
    //             "Total FTE : "+  kendo.toString(boxLabel.FTE, 'N2'),
    //             "# of Level 1 Processes : <a onclick='fmi.supplierSetHoverValue(\"\",\"Level1Process\")' href='#'>  "+boxLabel.LevelOne+"</a>",
    //             "<a onclick='fmi.SupplierDetailsModal()' href='#'>Details</a></br>",

    //             "<a href='#receiver_"+fmi.supplierCountry()+"'><b>"+ fmi.supplierCountry() + "</b></a><span style='color:#0644a0'> as Receiver</span>",
    //             "# of Suppliers :<a onclick='fmi.supplierSetHoverValue(\""+supplierCountry+"\",\"suppliername\")' href='#'>"+allSupplier.SupplierName+"</a>",
    //             "# of Functions :<a onclick='fmi.supplierSetHoverValue(\""+supplierCountry+"\",\"functionname\")' href='#'>"+allSupplier.FunctionName+"</a>",
    //             "# Total FTE :"+ kendo.toString(allSupplier.count, 'N2')+"",
    //             "# of Level 1 Processes : <a onclick='fmi.supplierSetHoverValue(\""+supplierCountry+"\",\"Level1Process\")' href='#'> "+allSupplier.LevelOne+"</a>",
    //             "<a onclick='fmi.SupplierDetailsModal(\""+supplierCountry+"\")' href='#'>Details</a></br>",



    //             ].join("<br>")  
    //     var receiverMarker = L.marker([dataSource.BoxInfo.Latitude, dataSource.BoxInfo.Longitude], {
    //         icon : L.icon( {
    //             iconUrl : '/static/img/supplier-marker.png',
    //         } )
    // } ).addTo( mapLeaflet ).bindPopup(templatePopUpReceivingCountry).openPopup();
    // receiverMarker.on("mouseover", function(e) {
    //    var popup = L.popup()
    //        .setLatLng([boxLabel.Latitude, boxLabel.Longitude]) 
    //        .setContent(templatePopUpReceivingCountry)
    //        .openOn(mapLeaflet);
    // });

    // var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    // myLayer.setGeoJSON(geoJson);
    // myLayer.on("mouseover", function(e) {
    //     var receivingCountry = e.layer.feature.properties['SecondaryID'].replace("'", "&#39;");
    //     var templatePopUp = [
    //                     "<span style='color:#0644a0'>Receiver Country Data</span>",
    //                     "<a href='#receiver_"+e.layer.feature.properties['SecondaryID']+"'><b>"+ e.layer.feature.properties['SecondaryID'] + "</b></a>",
    //                     "# of Suppliers : <a onclick='fmi.supplierSetHoverValue(\""+receivingCountry+"\",\"suppliername\")' href='#'> "+e.layer.feature.properties['SupplierName']+"  </a>",
    //                     "# of Functions : <a onclick='fmi.supplierSetHoverValue(\""+receivingCountry+"\",\"functionname\")' href='#'>"+e.layer.feature.properties['FunctionName']+" </a>",
    //                     "Total FTE : "+ kendo.toString(e.layer.feature.properties['count'], 'N2'),
    //                     "# of Level 1 Processes : <a onclick='fmi.supplierSetHoverValue(\""+receivingCountry+"\",\"Level1Process\")' href='#'> "+e.layer.feature.properties['LevelOne']+" </a>",
    //                     "<a onclick='fmi.SupplierDetailsModal(\""+receivingCountry+"\")' href='#'>Details</a>"].join("<br>")
    //     var popup = L.popup()
    //        .setLatLng(e.latlng) 
    //        .setContent(templatePopUp)
    //        .openOn(mapLeaflet);
    // });

    // receiverMarker.on("click", function(e) {
    //     window.location.href = '#receiver_'+fmi.supplierCountry();
    //     // var payloadSummary={
    //     //     Suppliertype :  receiver.supplierType(),
    //     //     ReceivingCountry :  receiver.receivingCountry(),
    //     //     LegalEntity : [],
    //     //     SupplierCountry : ''
    //     // }
    //     // ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
    //     //   receiver.createSummary(res)
    //     // })
    // });
    // myLayer.on('click', function(e) {
    //     // $('#receiver_INONESIA').trigger('click')
    //     window.location.href = '#receiver_'+e.layer.feature.properties['SecondaryID'];
    //     // var country = e.layer.feature.properties['SecondaryID']
    //     // var payloadSummary={
    //     //     Suppliertype :  receiver.supplierType(),
    //     //     ReceivingCountry :  receiver.receivingCountry(),
    //     //     LegalEntity : [],
    //     //     SupplierCountry : country
    //     // }
    //     // ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
    //     //     receiver.createSummary(res)
    //     // })
    // });
};

fmi.receivingMap = function(dataSource){
    fmi.receivingPrepareMap();
    // fmi.receivingLegendShow(true);
    var greenIcon = L.icon({
                        iconUrl: '/live/static/img/marker-green.png',
                        iconSize:     [20, 45], // size of the icon 
                    });    
    var blueIcon = L.icon({
                        iconUrl: '/live/static/img/marker-blue.png',
                        iconSize:     [20, 45], // size of the icon 
                    }); 
    var greyIcon = L.icon({
                        iconUrl: '/live/static/img/marker-grey.png',
                        iconSize:     [20, 45], // size of the icon 
                    });
    // var mbAttr = 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
    //         '<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
    //         'Imagery © <a href="http://mapbox.com">Mapbox</a>',
    //     mbUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpandmbXliNDBjZWd2M2x6bDk3c2ZtOTkifQ._QA7i5Mpkd_m30IGElHziw';

    // var grayscale   = L.tileLayer(mbUrl, {id: 'mapbox.light', attribution: mbAttr,minZoom: 2});
     var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});
    var map = L.map('map-fmi-receiving', {
        center: [1,38],
        zoom: 2,
        layers: grayscale,
        zoomControl: false,
    })
    L.control.zoom({
         position:'topright'
    }).addTo(map);
   
    var geoJson = dataSource.features;
    $.each(geoJson, function(i,v){
        if(v.properties.count <= 5){
            var icon = greyIcon;
        }else if(v.properties.count <= 20){
            var icon =greenIcon;
        }  else {
            var icon = blueIcon; 
        }
        var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}).addTo(map);
        marker.Country = v.properties.SecondaryID
        marker.on('click', function(e){ 
            fmi.receivingCountry(e.target.Country);
            fmi.receivingGetData();
        });
    })
    // var geoJson =dataSource.features;
    
    // $.each(geoJson, function(i,v){
       
    //     if(v.properties.count <= 5){
    //         var color = "#7F7F7F";
    //     }else if(v.properties.count <= 20){
    //         var color = "#b5ce7d";
    //     }  else {
    //         var color = "#60B4E4"; 
    //     }
    //     var newProperties = {"marker-size": "small","marker-symbol":"marker",'marker-color': color}; 
    //     $.extend(true, v.properties,newProperties)
    // });
   
    // L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxOXR1djI3MDFseGZ0bTFhbDc0YnoxdSJ9.vo3h2zpopQD9DVMILpkPYg';
    // var mapLeaflet = L.mapbox.map('map-int-receiving', 'mapbox.light',{'worldCopyJump': true, minZoom: 2})
    //   .setView([1,38], 2)

    // var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    // myLayer.setGeoJSON(geoJson);
    
    // myLayer.on('click', function(e) {
    //     var country = e.layer.feature.properties['SecondaryID']
    //     fmi.receivingCountry(country);
    //     fmi.receivingGetData(); 
    // }); 
};

fmi.supplierMap = function(dataSource){
    fmi.supplierPrepareMap()
    // fmi.supplierLegendShow(true);
    var greenIcon = L.icon({
                        iconUrl: '/live/static/img/marker-green.png',
                        iconSize:     [20, 45], // size of the icon 
                    });    
    var blueIcon = L.icon({
                        iconUrl: '/live/static/img/marker-blue.png',
                        iconSize:     [20, 45], // size of the icon 
                    }); 
    var greyIcon = L.icon({
                        iconUrl: '/live/static/img/marker-grey.png',
                        iconSize:     [20, 45], // size of the icon 
                    });
    // var mbAttr = 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
    //         '<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
    //         'Imagery © <a href="http://mapbox.com">Mapbox</a>',
    //     mbUrl = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpandmbXliNDBjZWd2M2x6bDk3c2ZtOTkifQ._QA7i5Mpkd_m30IGElHziw';

    // var grayscale   = L.tileLayer(mbUrl, {id: 'mapbox.light', attribution: mbAttr,minZoom: 2});
     var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});
    var map = L.map('map-fmi-supplier', {
        center: [1,38],
        zoom: 2,
        layers: grayscale,
            zoomControl: false,
    })
  L.control.zoom({
         position:'topright'
    }).addTo(map);
   
    var geoJson = dataSource.features;
    $.each(geoJson, function(i,v){
        if(v.properties.count <= 5){
            var icon = greyIcon;
        }else if(v.properties.count <= 20){
            var icon =greenIcon;
        }  else {
            var icon = blueIcon; 
        }
        var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}).addTo(map);
        marker.Country = v.properties.SecondaryID
        marker.on('click', function(e){ 
            fmi.supplierCountry(e.target.Country);
            fmi.suppliergGetData();
        });
    })

    // fmi.supplierPrepareMap()
    // var geoJson =dataSource.features;
    
    // $.each(geoJson, function(i,v){
       
    //     if(v.properties.count <= 5){
    //         var color = "#7F7F7F";
    //     }else if(v.properties.count <= 20){
    //         var color = "#b5ce7d";
    //     }  else {
    //         var color = "#60B4E4"; 
    //     }
    //     var newProperties = {"marker-size": "small","marker-symbol":"marker",'marker-color': color}; 
    //     $.extend(true, v.properties,newProperties)
    // });
   
    // L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxOXR1djI3MDFseGZ0bTFhbDc0YnoxdSJ9.vo3h2zpopQD9DVMILpkPYg';
    // var mapLeaflet = L.mapbox.map('map-int-supplier', 'mapbox.light',{'worldCopyJump': true, minZoom: 2})
    //   .setView([1,38], 2)

    // var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    // myLayer.setGeoJSON(geoJson);
    
    // myLayer.on('click', function(e) {
    //     var country = e.layer.feature.properties['SecondaryID']
    //     fmi.supplierCountry(country);
    //     fmi.suppliergGetData(); 
    // }); 
};

fmi.configSeries = function(indexClass, indeexData, selectorId){
    var color = ["#00506D","#0077A3","#50D0FF"]
    var visibleData   = $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data[indeexData].visible
    $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data[indeexData].visible = !visibleData
    $("#"+selectorId+"_"+indexClass).getKendoChart().redraw();
    var datas = $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data
    color = (!visibleData)?color[indeexData]: '#9b9898';
    $("#legend-"+selectorId +"_"+indexClass).find("li").eq(indeexData).find(".square").css('background',color)
    var totalDataTrue = 0 
    $.each(datas, function(i, val){            
        if(val.visible == true){
            totalDataTrue += val.value
        } 
    })

    $.each(datas, function(i, val){            
        var percentage = 100 / (totalDataTrue / val.value) 
        if(val.visible == true){ 
            $("#legend-donut-"+selectorId+"-precentage_"+ indexClass +"_"+i).text(String(percentage.toFixed(0)) +"%")
        }else{
            $("#legend-donut-"+selectorId+"-precentage_"+ indexClass +"_"+i).text("")
        }
    }) 
};

fmi.sortData = function(dataSource){ 
    $.each(dataSource,function(index,value){
        for(var i=0; i<(dataSource.length-1); i++){
            if(dataSource[i].Country.toLowerCase() > dataSource[i+1].Country.toLowerCase()){
                var old = dataSource[i+1];
                dataSource[i+1] = dataSource[i]
                dataSource[i] = old
            }
        }
    }) 
    return dataSource
};

fmi.downloadPopUpDonut = function(){
    return function(){
        var grid = $("#grid-popup-fmi-donut").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard FMI Receiver Drilldown Donut"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

fmi.downloadPopUpDonutSupplier = function(){
    return function(){
        var grid = $("#grid-popup-fmi-donut-supplier").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard FMI Supplier Drilldown Donut"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

fmi.popUpDonut =  function(payload){
    $("#grid-popup-fmi-donut").html("");
    $("#grid-popup-fmi-donut").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost("/receiverview/getpopupdonut", payload, function(datas){
                        option.success(datas); 
                        $('#modal-fmi-donut').modal('show');
                        setTimeout(function() {
                                $("#grid-popup-fmi-donut").data("kendoGrid").resize();  
                        }, 500);
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            //pageSize: 10,
            sort: [
                {field:"receivercountry",dir:"asc"},
                {field:"suppliercountry",dir:"asc"},
                {field:"categoryname_",dir:"asc"},
                {field:"productfunction",dir:"asc"},
                {field:"parentprocessname",dir:"asc"},
                {field:"processname",dir:"asc"},
                {field:"servicedescription",dir:"asc"},
                {field:"barriertype",dir:"asc"},
            ],
        },
        height: 380,
        columns: [
           {
                field:"receivercountry",
                title:'Receiver Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= receivercountry + ' - ' + receiverlegalentity #",
            },
            {
                field:"suppliercountry",
                title:'Supplier Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
            },
            {
                field:"categoryname_",
                title:'Business',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"productfunction",
                title:'Product',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"parentprocessname",
                title:'Level 1 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"processname",
                title:'Level 2 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"servicedescription",
                title:'Service Description',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"barriertype",
                title:'Barrier Type',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }
        ],
        excel: {
            fileName: "PopUpFMIGroupDonut.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
};

fmi.popUpDonutSupplier =  function(payload){
    $("#grid-popup-fmi-donut-supplier").html("");
    $("#grid-popup-fmi-donut-supplier").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost("/receiverview/getpopupdonut", payload, function(datas){
                        option.success(datas); 
                        $('#modal-fmi-donut-supplier').modal('show');
                        setTimeout(function() {
                                $("#grid-popup-fmi-donut-supplier").data("kendoGrid").resize();  
                        }, 500);
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            //pageSize: 10,
            sort: [
                {field:"receivercountry",dir:"asc"},
                {field:"suppliercountry",dir:"asc"},
                {field:"categoryname_",dir:"asc"},
                {field:"productfunction",dir:"asc"},
                {field:"parentprocessname",dir:"asc"},
                {field:"processname",dir:"asc"},
                {field:"servicedescription",dir:"asc"},
                {field:"barriertype",dir:"asc"},
            ],
        },
        height: 380,
        columns: [
           // {
           //      field:"_id.servicerefid",
           //      title:'Service Ref Id',
           //      /*filterable: false,*/
           //      width:150,
           //      headerAttributes: {
           //              "class": "align-left"
           //      }
           //  },
            
            {
                field:"receivercountry",
                title:'Receiver Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= receivercountry + ' - ' + receiverlegalentity #",
            },
            {
                field:"suppliercountry",
                title:'Supplier Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
            },
            {
                field:"categoryname_",
                title:'Business',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"productfunction",
                title:'Product',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"parentprocessname",
                title:'Level 1 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"processname",
                title:'Level 2 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"servicedescription",
                title:'Service Description',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"barriertype",
                title:'Barrier Type',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
        ],
        excel: {
            fileName: "PopUpFMIGroupDonut.xlsx",
            allPages: true
        },
        sortable: true,
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     pageSize: 20,
        //     buttonCount: 1
        // },
        height: 380,
    });
};

fmi.receivingCreateSummary =  function(payload){
    ajaxPost("/receiverview/summaryfmi",payload, function (res){        
        var receivers = [];
        var suppliers = [];

        $.each(res.Country, function(index,v){
            var data ={
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                NumSLA:kendo.toString(v.NumSLA,"n0"),
                DetailsDonut: v.DetailsDonut,
                TotalDonut: v.TotalDonut,
                Legal: [],
            };
            for(var i in v.DetailsLegal){
                data.Legal.push({
                    keyID:index+"-"+i,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    NumSLA:kendo.toString(v.DetailsLegal[i].NumSLA,"n0"),
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal,
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                });
            }
            receivers.push(data);
        });
        fmi.receivingReceiverSummary(receivers);
        dataSupplier = fmi.sortData(res.Supplier)

        $.each(dataSupplier, function(index,v){
            var data ={
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                NumSLA:kendo.toString(v.NumSLA,"n0"),
                DetailsDonut : v.DetailsDonut,
                Legal: [],
                TotalDonut: v.TotalDonut,
            };
            for(var i in v.DetailsLegal){

                data.Legal.push({
                    keyID:index+"-"+i,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    NumSLA:kendo.toString(v.DetailsLegal[i].NumSLA,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal
                });
            }
            suppliers.push(data);
        });
        fmi.receivingSupplierSummary(suppliers);
        var color=["#00506D","#0077A3","#50D0FF"];
        

        $.each(receivers, function(i,v){
            var dataReceiver = []
            $.each(v.DetailsDonut, function(index,value){
                dataReceiver.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                $("#legend-fmi_receiver_"+i+" ul").append("<li><a onClick='fmi.configSeries("+i+","+index+",\"fmi_receiver\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-fmi_receiver-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-fmi_receiver-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
             receiverClick = function(e){

                switch(e.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                }
                var payload = {
                    Business : fmi.receivingCategory(),
                    Country : v.Country,
                    FilterCountry : fmi.receivingCountry(),
                    FilterLegal : fmi.receivingLegalEntity(),
                    Flag : "receiver",
                    LegalEntity : [],
                    Parentprocessname: fmi.receivingLevelProcess(),
                    Suppliertype: fmi.receivingSupplierType(),
                    Classification: fmi.receivingClassification(),
                    Suppliername : fmi.receivingSupplierName(),
                    Fmitype : fmi.receivingFMIType(),
                    Posisi: "receiverview",
                    Tab : "fmi",
                    Type: dataItem,
                }; 
                fmi.popUpDonut(payload)
            }
            var configDonut = ko.mapping.toJS(fmi.configDonut);
            configDonut.series[0].data = dataReceiver;
            configDonut.seriesClick = receiverClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
           
            $("#fmi_receiver_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dateLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dateLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    
                    switch(data.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0;   
                    $("#legend-fmi_receiver-entity_"+value.keyID+" ul").append("<li><a onClick='fmi.configSeries(\""+value.keyID+"\","+number+",\"fmi_receiver-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-fmi_receiver-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-fmi_receiver-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                receiverEntityClick = function(e){
                     var legalEntity  = value.CountryLegal.split("~")[0];
                    // legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    // Country = Country.trim()
                    switch(e.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    }
                    var payload = {
                        Business : fmi.receivingCategory(),
                        Country : Country,
                        FilterCountry : fmi.receivingCountry(),
                        FilterLegal : fmi.receivingLegalEntity(),
                        Flag : "receiver",
                        LegalEntity : [legalEntity],
                        Parentprocessname: fmi.receivingLevelProcess(),
                        Suppliertype: fmi.receivingSupplierType(),
                        Classification: fmi.receivingClassification(),
                        Suppliername : fmi.receivingSupplierName(),
                        Fmitype : fmi.receivingFMIType(),
                        Posisi: "receiverview",
                        Tab : "fmi",
                        Type: dataItem,
                    };
                    
                    fmi.popUpDonut(payload)
                }
                var configDetailsDonut = ko.mapping.toJS(fmi.configDonut);
                configDetailsDonut.series[0].data = dateLegal;
                configDetailsDonut.seriesClick = receiverEntityClick;
                configDetailsDonut.legend.labels.template ="#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
                $("#fmi_receiver-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        })
        $.each(suppliers, function(i,v){
            var dataSuplier = []
            $.each(v.DetailsDonut, function(index,value){
                dataSuplier.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                $("#legend-fmi_supplier_"+i+" ul").append("<li><a onClick='fmi.configSeries("+i+","+index+",\"fmi_supplier\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-fmi_supplier-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-fmi_supplier-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
            supplierClick = function(e){

                switch(e.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                }
                var payload = {
                    Business : fmi.receivingCategory(),
                    Country : v.Country,
                    FilterCountry : fmi.receivingCountry(),
                    FilterLegal : fmi.receivingLegalEntity(),
                    Flag : "supplier",
                    LegalEntity : [],
                    Parentprocessname: fmi.receivingLevelProcess(),
                    Suppliertype: fmi.receivingSupplierType(),
                    Classification: fmi.receivingClassification(),
                    Suppliername : fmi.receivingSupplierName(),
                    Fmitype : fmi.receivingFMIType(),
                    Posisi: "receiverview",
                    Tab : "fmi",
                    Type: dataItem,
                }; 
                
                fmi.popUpDonut(payload)
            }
            var configDonut = ko.mapping.toJS(fmi.configDonut);
            configDonut.series[0].data = dataSuplier;
            configDonut.seriesClick = supplierClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
            $("#fmi_supplier_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dataSupplierLegal = []
                $.each(value.DetailsDonut, function(number,data){
                   
                    dataSupplierLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                
                    switch(data.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    } 

                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0;   
                   
                    $("#legend-fmi_supplier-entity_"+value.keyID+" ul").append("<li><a onClick='fmi.configSeries(\""+value.keyID+"\","+number+",\"fmi_supplier-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-fmi_supplier-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-fmi_supplier-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                supplierEntityClick = function(e){
                    var legalEntity  = value.CountryLegal.split("~")[0];
                    legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    Country = Country.trim()
                    switch(e.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    }
                    var payload = {
                        Business : fmi.receivingCategory(),
                        Country : Country,
                        FilterCountry : fmi.receivingCountry(),
                        FilterLegal : fmi.receivingLegalEntity(),
                        Flag : "supplier",
                        LegalEntity : [legalEntity],
                        Parentprocessname: fmi.receivingLevelProcess(),
                        Suppliertype: fmi.receivingSupplierType(),
                        Classification: fmi.receivingClassification(),
                        Suppliername : fmi.receivingSupplierName(),
                        Fmitype : fmi.receivingFMIType(),
                        Posisi: "receiverview",
                        Tab : "fmi",
                        Type: dataItem,
                    };
                    fmi.popUpDonut(payload)
                } 
                var configDetailsDonut = ko.mapping.toJS(fmi.configDonut);
                configDetailsDonut.seriesClick = supplierEntityClick;
                configDetailsDonut.series[0].data = dataSupplierLegal;
                configDetailsDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
         
                $("#fmi_supplier-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        })
    });
};

fmi.supplierCreateSummary =  function(payload){
    ajaxPost("/receiverview/summaryfmi",payload, function (res){
        var receivers = [];
        var suppliers = [];
        $.each(res.Country, function(index,v){
            var data ={
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                NumSLA:kendo.toString(v.NumSLA,"n0"),
                DetailsDonut : v.DetailsDonut,
                Legal: [],
                TotalDonut: v.TotalDonut,
            };
            for(var i in v.DetailsLegal){
                data.Legal.push({
                    keyID:index+"-"+i,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    NumSLA:kendo.toString(v.DetailsLegal[i].NumSLA,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal
                });
            }
            receivers.push(data);
        });
        
        dataSupplier = fmi.sortData(res.Supplier)
        $.each(dataSupplier, function(index,v){
            var data ={
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                NumSLA:kendo.toString(v.NumSLA,"n0"),
                DetailsDonut : v.DetailsDonut,
                Legal: [],
                TotalDonut: v.TotalDonut,
            };
            for(var i in v.DetailsLegal){
                data.Legal.push({
                    keyID:index+"-"+i,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    NumSLA:kendo.toString(v.DetailsLegal[i].NumSLA,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,

                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal
                });
            }
            suppliers.push(data);
        });

        fmi.supplierReceiverSummary(receivers);
        fmi.supplierSupplierSummary(suppliers);
        
         var color=["#00506D","#0077A3","#50D0FF"];
        $.each(receivers, function(i,v){
            var dataReceiver = []
            $.each(v.DetailsDonut, function(index,value){
                dataReceiver.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                $("#legend-fmi_supreceiver_"+i+" ul").append("<li><a onClick='fmi.configSeries("+i+","+index+",\"fmi_supreceiver\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-fmi_supreceiver-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-fmi_supreceiver-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })

            receiverClick = function(e){

                switch(e.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                }
                var payload = {
                    Business : fmi.supplierCategory(),
                    Country : v.Country,
                    FilterCountry : fmi.supplierCountry(),
                    FilterLegal : fmi.supplierLegalEntity(),
                    Flag : "receiver",
                    LegalEntity : [],
                    Parentprocessname: fmi.supplierLevelProcess(),
                    Suppliertype: fmi.supplierSupplierType(),
                    Classification: fmi.supplierClassification(),
                    Suppliername : fmi.supplierSupplierName(),
                    Fmitype : fmi.supplierFMIType(),
                    Posisi: "supplierview",
                    Tab : "fmi",
                    Type: dataItem,
                }; 
                fmi.popUpDonutSupplier(payload)
            }

            var configDonut = ko.mapping.toJS(fmi.configDonut);
            configDonut.series[0].data = dataReceiver;
            configDonut.seriesClick = receiverClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
            
            $("#fmi_supreceiver_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                 var dateLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dateLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    
                    switch(data.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0; 

                    $("#legend-fmi_supreceiver-entity_"+value.keyID+" ul").append("<li><a onClick='fmi.configSeries(\""+value.keyID+"\","+number+",\"fmi_supreceiver-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-fmi_supreceiver-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-fmi_supreceiver-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                receiverEntityClick = function(e){
                    var legalEntity  = value.CountryLegal;
                    var Country  = v.Country;
                    // var legalEntity  = value.CountryLegal.split("~")[0];
                    // legalEntity = legalEntity.trim()
                    // var Country  = value.CountryLegal.split("~")[1];
                    // Country = Country.trim()

                    switch(e.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    }
                    var payload = {
                        Business : fmi.supplierCategory(),
                        Country : Country,
                        FilterCountry : fmi.supplierCountry(),
                        FilterLegal : fmi.supplierLegalEntity(),
                        Flag : "receiver",
                        LegalEntity : [legalEntity],
                        Parentprocessname: fmi.supplierLevelProcess(),
                        Suppliertype: fmi.supplierSupplierType(),
                        Classification: fmi.supplierClassification(),
                        Suppliername : fmi.supplierSupplierName(),
                        Fmitype : fmi.supplierFMIType(),
                        Posisi: "supplierview",
                        Tab : "fmi",
                        Type: dataItem,
                    };
                     fmi.popUpDonutSupplier(payload)
                }
                var configDetailsDonut = ko.mapping.toJS(fmi.configDonut);
                configDetailsDonut.series[0].data = dateLegal;
                configDetailsDonut.seriesClick = receiverEntityClick;
                configDetailsDonut.legend.labels.template ="#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
                $("#fmi_supreceiver-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        });

        $.each(suppliers, function(i,v){
            var dataSuplier = []
            $.each(v.DetailsDonut, function(index,value){
                dataSuplier.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                    
                $("#legend-fmi_supsupplier_"+i+" ul").append("<li><a onClick='fmi.configSeries("+i+","+index+",\"fmi_supsupplier\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-fmi_supsupplier-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-fmi_supsupplier-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
            supplierClick = function(e){

                switch(e.category){
                case'OCIRCompliant':
                    var dataItem = 'OCIR Compliant'
                break;
                case'NoSLA':
                    var dataItem = 'No SLA'
                break;
                default:
                    var dataItem = 'Non-Compliant SLA'
                }
                var payload = {
                    Business : fmi.supplierCategory(),
                    Country : v.Country,
                    FilterCountry : fmi.supplierCountry(),
                    FilterLegal : fmi.supplierLegalEntity(),
                    Flag : "supplier",
                    LegalEntity : [],
                    Parentprocessname: fmi.supplierLevelProcess(),
                    Suppliertype: fmi.supplierSupplierType(),
                    Classification: fmi.supplierClassification(),
                    Suppliername : fmi.supplierSupplierName(),
                    Fmitype : fmi.supplierFMIType(),
                    Posisi: "supplierview",
                    Tab : "fmi",
                    Type: dataItem,
                }; 
              fmi.popUpDonutSupplier(payload)
            }
            var configDonut = ko.mapping.toJS(fmi.configDonut);
            configDonut.series[0].data = dataSuplier;
             configDonut.seriesClick = supplierClick;
             configDonut.legend.labels.template ="#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
            $("#fmi_supsupplier_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dateLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dateLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    
                    switch(data.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0; 

                    $("#legend-fmi_supsupplier-entity_"+value.keyID+" ul").append("<li><a onClick='fmi.configSeries(\""+value.keyID+"\","+number+",\"fmi_supsupplier-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-fmi_supsupplier-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-fmi_supsupplier-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                supplierEntityClick = function(e){
            
                     var legalEntity  = value.CountryLegal.split("~")[0];
                    legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    Country = Country.trim()
                    switch(e.category){
                    case'OCIRCompliant':
                        var dataItem = 'OCIR Compliant'
                    break;
                    case'NoSLA':
                        var dataItem = 'No SLA'
                    break;
                    default:
                        var dataItem = 'Non-Compliant SLA'
                    }
                    var payload = {
                        Business : fmi.supplierCategory(),
                        Country : Country,
                        FilterCountry : fmi.supplierCountry(),
                        FilterLegal : fmi.supplierLegalEntity(),
                        Flag : "supplier",
                        LegalEntity : [legalEntity],
                        Parentprocessname: fmi.supplierLevelProcess(),
                        Suppliertype: fmi.supplierSupplierType(),
                        Classification: fmi.supplierClassification(),
                        Suppliername : fmi.supplierSupplierName(),
                        Fmitype : fmi.supplierFMIType(),
                        Posisi: "supplierview",
                        Tab : "fmi",
                        Type: dataItem,
                    };
                     fmi.popUpDonutSupplier(payload)
                    
                    
                } 
                var configDetailsDonut = ko.mapping.toJS(fmi.configDonut);
                configDetailsDonut.seriesClick = supplierEntityClick;
                configDetailsDonut.series[0].data = dateLegal;
                configDetailsDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA'  # &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; # # #}else{# #: 'Non-Compliant SLA' #&nbsp;# # #}#  #= removeSpace(kendo.toString(percentage,'P0'))#",
             
                $("#fmi_supsupplier-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        });
    }); 
    // ajaxPost("/receiverview/summarysupplierintragroup",payload, function (res){
        
       
        

    //     $.each(suppliers, function(i,v){
    //         var configDonut = ko.mapping.toJS(fmi.configDonut);
    //         configDonut.series[0].data = v.DetailsDonut;
    //         configDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA' # #}else{# #: 'Non-compliant SLA' # #}#",
            
    //         $("#fmi_supsupplier_"+i).kendoChart(configDonut)
    //         $.each(v.Legal,function(index,value){
    //             var configDetailsDonut = ko.mapping.toJS(fmi.configDonut);
    //             configDetailsDonut.series[0].data = value.DetailsDonut;
    //             configDetailsDonut.legend.labels.template = "#if(dataItem.category=='OCIRCompliant'){# #: 'OCIR Compliant' # #}else if(dataItem.category==='NoSLA'){# #: 'No SLA' # #}else{# #: 'Non-compliant SLA' # #}#",
    //             $("#fmi_supsupplier-entity_"+value.keyID).kendoChart(configDetailsDonut)
    //         })
    //     })
    // }); 
};

fmi.receivingGetData =  function(){
    if(fmi.receivingCountry() == ''){
         var payload={
            Business :  fmi.receivingCategory(),
            LegalEntity : fmi.receivingLegalEntity(),
            Parentprocessname : fmi.receivingLevelProcess(),
            Suppliertype: fmi.receivingSupplierType(),
            Classification: fmi.receivingClassification(),
            Flag: "FMI",
            Suppliername : fmi.receivingSupplierName(),
            Fmitype : fmi.receivingFMIType(),
        }
        var url = "/receiverview/getdefaultreceiver";
        ajaxPost(url, payload, function (res){
            fmi.receivingMap(res)
        });
        fmi.showLegendLineReceiver(false)
    }else{
       
        var payload={
            Business :  fmi.receivingCategory(),
            ReceivingCountry :  fmi.receivingCountry(),
            Parentprocessname : fmi.receivingLevelProcess(),
            Suppliertype: fmi.receivingSupplierType(),
            Classification: fmi.receivingClassification(),
            LegalEntity : fmi.receivingLegalEntity(),
            Suppliername : fmi.receivingSupplierName(),
            Fmitype : fmi.receivingFMIType(),
        }
       
        var url = "/receiverview/getdetailsreceiverfmi";
        ajaxPost(url, payload, function (res){
            fmi.receivingMapDetails(res)
        });
        fmi.showLegendLineReceiver(true)
    }
    var payload = {
        ReceivingCountry :  fmi.receivingCountry(),
        LegalEntity : fmi.receivingLegalEntity(),
        Business : fmi.receivingCategory(),
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        Suppliername : fmi.receivingSupplierName(),
        Fmitype : fmi.receivingFMIType(),
        Flag: "Receiver",
    }
    fmi.receivingCreateSummary(payload)
    localStorage.setItem('filter', JSON.stringify(payload));
};

fmi.suppliergGetData =  function(){
    if(fmi.supplierCountry() == ''){
        var payload={
            Business :  fmi.supplierCategory(),
            Flag: "FMI",
            Parentprocessname : fmi.supplierLevelProcess(),
            Suppliertype: fmi.supplierSupplierType(),
            Classification: fmi.supplierClassification(),
            LegalEntity : fmi.supplierLegalEntity(),
            Suppliername : fmi.supplierSupplierName(),
            Fmitype : fmi.supplierFMIType(),
        }
        var url = "/supplierview/getdefaultsupplier";
        ajaxPost(url, payload, function (res){
            fmi.supplierMap(res)
        });
        fmi.showLegendLineSupplier(false);
    }else{
        var payload={
            Business :  fmi.supplierCategory(),
            ReceivingCountry :  fmi.supplierCountry(),
            Parentprocessname : fmi.supplierLevelProcess(),
            Suppliertype: fmi.supplierSupplierType(),
            Classification: fmi.supplierClassification(),
            LegalEntity : fmi.supplierLegalEntity(),
            Suppliername : fmi.supplierSupplierName(),
            Fmitype : fmi.supplierFMIType(),
        }
       
        var url = "/supplierview/getdetailssupplierfmi";
        ajaxPost(url, payload, function (res){
            fmi.supplierMapDetails(res)
        });
        fmi.showLegendLineSupplier(true);
    }
    var payload ={
        ReceivingCountry :  fmi.supplierCountry(),
        LegalEntity : fmi.supplierLegalEntity(),
        Business : fmi.supplierCategory(),
        Parentprocessname : fmi.supplierLevelProcess(),
        Suppliertype: fmi.supplierSupplierType(),
        Classification: fmi.supplierClassification(),
        Suppliername : fmi.supplierSupplierName(),
        Fmitype : fmi.supplierFMIType(),
        Flag: "Supplier",
    } 
    fmi.supplierCreateSummary(payload)
    localStorage.setItem('filter', JSON.stringify(payload));
};

fmi.getReceivingCountry = function(){
    var payload = {
        LegalEntity : fmi.receivingLegalEntity(),
        Business :  fmi.receivingCategory(),
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        Suppliername : fmi.receivingSupplierName(),
        Fmitype : fmi.receivingFMIType(),
        Flag : 'FMI',
    };
    var url = "/receiverview/getreceivercountry";
    ajaxPost(url,payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        fmi.receivingCountryList(receivingCountries);
    });
};

fmi.getSupplierCountry = function(){
    var payload = {
        LegalEntity : fmi.supplierLegalEntity(),
        Business :  fmi.supplierCategory(),
        Parentprocessname : fmi.supplierLevelProcess(),
        Suppliertype: fmi.supplierSupplierType(),
        Classification: fmi.supplierClassification(),
        Suppliername : fmi.supplierSupplierName(),
        Fmitype : fmi.supplierFMIType(),
        Flag : 'FMI',
    };
    var url = "/supplierview/getsuppliercountry";
    ajaxPost(url,payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        fmi.supplierCountryList(receivingCountries);
    });
};

fmi.getReceivingLegalEntity = function(){
    var payload = {
        ReceivingCountry : fmi.receivingCountry(),
        Business :  fmi.receivingCategory(),
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        Suppliername : fmi.receivingSupplierName(),
        Fmitype : fmi.receivingFMIType(),
        Flag : 'FMI',

    };
    var url = "/receiverview/getlegalentityreceiverfmi";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        
        fmi.receivingLegalEntityList(legalEntities) 
    });
};

fmi.getSupplierLegalEntity = function(){
    var payload = {
        ReceivingCountry : fmi.supplierCountry(),
        Business :  fmi.supplierCategory(),
        Parentprocessname : fmi.supplierLevelProcess(),
        Suppliertype: fmi.supplierSupplierType(),
        Classification: fmi.supplierClassification(),
        Suppliername : fmi.supplierSupplierName(),
        Fmitype : fmi.supplierFMIType(),
        Flag : 'FMI'
    };
    var url = "/supplierview/getlegalentitysupplierfmi";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        fmi.supplierLegalEntityList(legalEntities) 
    });
};

fmi.getReceivingCategory = function(){
    var payload = {
        ReceivingCountry : fmi.receivingCountry(),
        LegalEntity : fmi.receivingLegalEntity(),
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        Suppliername : fmi.receivingSupplierName(),
        Fmitype : fmi.receivingFMIType(),
        Flag : 'FMI',
    };
    var url = "/receiverview/getcategoryfmi";
    ajaxPost(url,payload, function (res){
        var receivingCategory = [];
        $.each(res, function(i,v){
            receivingCategory.push({text:v._id, value:v._id})
        });
        fmi.receivingCategoryList(receivingCategory);
    });
};

fmi.getSupplierCategory = function(){
    var payload = {
        ReceivingCountry : fmi.supplierCountry(),
        LegalEntity : fmi.supplierLegalEntity(),
        Parentprocessname : fmi.supplierLevelProcess(),
        Suppliertype: fmi.supplierSupplierType(),
        Classification: fmi.supplierClassification(),
        Suppliername : fmi.supplierSupplierName(),
        Fmitype : fmi.supplierFMIType(),
        Flag : 'FMI'
    };
    var url = "/supplierview/getcategoryfmi";
    ajaxPost(url,payload, function (res){
        var supplierCategory = [];
        $.each(res, function(i,v){
            supplierCategory.push({text:v._id, value:v._id})
        });
        fmi.supplierCategoryList(supplierCategory);
    });
};

fmi.getReceivingLevelProcess = function(){
    var payload = {
        ReceivingCountry :  fmi.receivingCountry(),
        LegalEntity : fmi.receivingLegalEntity(),
        Business : fmi.receivingCategory(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        Suppliername : fmi.receivingSupplierName(),
        Fmitype : fmi.receivingFMIType()
    };

    var url = "/receiverview/getparentprocessfmi";
    ajaxPost(url,payload, function (res){
        var levelProcess = [];
        $.each(res, function(i,v){
            levelProcess.push({text:v._id, value:v._id})
        });
        fmi.receivingLevelProcessList(levelProcess);
    });
};

fmi.getSupplierLevelProcess = function(){
    var payload = {
        ReceivingCountry :  fmi.supplierCountry(),
        LegalEntity : fmi.supplierLegalEntity(),
        Business : fmi.supplierCategory(),
        Suppliertype: fmi.supplierSupplierType(),
        Classification: fmi.supplierClassification(),
        Suppliername : fmi.supplierSupplierName(),
        Fmitype : fmi.supplierFMIType()
    };

    var url = "/supplierview/getparentprocessfmi";
    ajaxPost(url,payload, function (res){
        var levelProcess = [];
        $.each(res, function(i,v){
            levelProcess.push({text:v._id, value:v._id})
        });
        fmi.supplierLevelProcessList(levelProcess);
    });
};

fmi.getReceivingSupplierName = function(){
    var payload = {
        ReceivingCountry :  fmi.receivingCountry(),
        LegalEntity : fmi.receivingLegalEntity(),
        Business : fmi.receivingCategory(),
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        Fmitype : fmi.receivingFMIType()
    };

    var url = "/receiverview/getsuppliernamefmi";
    ajaxPost(url,payload, function (res){
        var suppliername = [];
        $.each(res, function(i,v){
            suppliername.push({text:v._id, value:v._id})
        });
        fmi.receivingSupplierNameList(suppliername);
    });
};

fmi.getSupplierSupplierName = function(){
    var payload = {
        ReceivingCountry :  fmi.supplierCountry(),
        LegalEntity : fmi.supplierLegalEntity(),
        Business : fmi.supplierCategory(),
        Parentprocessname : fmi.supplierLevelProcess(),
        Suppliertype: fmi.supplierSupplierType(),
        Classification: fmi.supplierClassification(),
        Fmitype : fmi.supplierFMIType()
    };

    var url = "/supplierview/getsuppliernamefmi";
    ajaxPost(url,payload, function (res){
        var suppliername = [];
        $.each(res, function(i,v){
            suppliername.push({text:v._id, value:v._id})
        });
        fmi.supplierSupplierNameList(suppliername);
    });
};

fmi.getReceivingFMIType = function(){
    var payload = {
        ReceivingCountry :  fmi.receivingCountry(),
        LegalEntity : fmi.receivingLegalEntity(),
        Business : fmi.receivingCategory(),
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(),
        Classification: fmi.receivingClassification(),
        Suppliername : fmi.receivingSupplierName()
    };

    var url = "/receiverview/getfmitype";
    ajaxPost(url,payload, function (res){
        var fmitype = [];
        $.each(res, function(i,v){
            fmitype.push({text:v._id, value:v._id})
        });
        fmi.receivingFMITypeList(fmitype);
    });
};

fmi.getSupplierFMIType = function(){
    var payload = {
        ReceivingCountry :  fmi.supplierCountry(),
        LegalEntity : fmi.supplierLegalEntity(),
        Business : fmi.supplierCategory(),
        Parentprocessname : fmi.supplierLevelProcess(),
        Suppliertype: fmi.supplierSupplierType(),
        Classification: fmi.supplierClassification(),
        Suppliername : fmi.supplierSupplierName()
    };

    var url = "/supplierview/getfmitype";
    ajaxPost(url,payload, function (res){
        var fmitype = [];
        $.each(res, function(i,v){
            fmitype.push({text:v._id, value:v._id})
        });
        fmi.supplierFMITypeList(fmitype);
    });
}; 
fmi.getReceivingClasification = function(){
    var payload = {
        ReceivingCountry :  fmi.receivingCountry(),
        LegalEntity : fmi.receivingLegalEntity(),
        Business : fmi.receivingCategory(),
        Parentprocessname : fmi.receivingLevelProcess(),
        Suppliertype: fmi.receivingSupplierType(), 
        Suppliername : fmi.receivingSupplierName(),
        Fmitype : fmi.receivingFMIType(),
         tab: "receiver"
    };

    var url = "/receiverview/getclassification";
    ajaxPost(url,payload, function (res){
        var classification = [];
        $.each(res, function(i,v){
            var text = v._id;
            switch(v._id){
                case "Internal Indirect":
                  text =  "Indirect via Internal";  
                break;

                case "Internal Direct":
                  text =  " Direct via Internal";  
                break;

                case "External Indirect":
                  text =  "Indirect via External";  
                break;

                case "External Direct":
                  text =  "Direct via External";  
                break
            }
            classification.push({text:text, value:v._id})
        });
        fmi.receivingClassificationList(classification);
    });
};


fmi.getSupplierClasification = function(){
    var payload = {
        ReceivingCountry :  fmi.supplierCountry(),
        LegalEntity : fmi.supplierLegalEntity(),
        Business : fmi.supplierCategory(),
        Parentprocessname : fmi.supplierLevelProcess(),
        Suppliertype: fmi.supplierSupplierType(), 
        Suppliername : fmi.supplierSupplierName(),
        Fmitype : fmi.supplierFMIType(),
        tab: "supplier"
    };

    var url = "/receiverview/getclassification";
    ajaxPost(url,payload, function (res){
        var classification = [];
        $.each(res, function(i,v){
                var text = v._id;
            switch(v._id){
                case "Internal Indirect":
                  text =  "Indirect via Internal";  
                break;

                case "Internal Direct":
                  text =  " Direct via Internal";  
                break;

                case "External Indirect":
                  text =  "Indirect via External";  
                break;

                case "External Direct":
                  text =  "Direct via External";  
                break
            }
            classification.push({text:text, value:v._id})
        });
        fmi.supplierClassificationList(classification);
    });
};

fmi.receivingCountry.subscribe(function(newValue){
    fmi.onchangeReceivingCountry(false)

    if (fmi.receivingCountry() == '') {
        fmi.receivingLegalEntity([]);
        fmi.receivingCategory([]);
    };
    
    fmi.getReceivingLegalEntity();
    fmi.getReceivingCategory();
    fmi.getReceivingSupplierName();
    fmi.getReceivingFMIType();
    fmi.receivingGetData();
    fmi.getReceivingLevelProcess();
    fmi.getReceivingClasification();
    dashboard.createNewCookie({receiverCountry:fmi.receivingCountry()}); 
    CNUtimeout = setTimeout(function(){
        fmi.onchangeReceivingCountry(true) 
    },1000);
});

fmi.supplierCountry.subscribe(function(newValue){
    fmi.onchangeSupplierCountry(false)
    
    if (fmi.supplierCountry() == '') {
        fmi.supplierLegalEntity([]);
        fmi.supplierCategory([]);
    };

    fmi.getSupplierLegalEntity();
    fmi.getSupplierCategory();
    fmi.getSupplierSupplierName();
    fmi.getSupplierFMIType();
    fmi.suppliergGetData();
    fmi.getSupplierLevelProcess();
    fmi.getSupplierClasification();
    dashboard.createNewCookie({supplierCountry:fmi.supplierCountry()});
    CNUtimeout = setTimeout(function(){ 
        fmi.onchangeSupplierCountry(true)
    },1000);
});

fmi.receivingLegalEntity.subscribe(function(newValue){
    if(fmi.onchangeReceivingCountry() === true){
        dashboard.createNewCookie({receiverCountry:fmi.receivingCountry(),receiverLegalEntity:newValue.toString()}); 
        fmi.receivingGetData();
    }
    fmi.getReceivingCountry();
    fmi.getReceivingCategory();
    fmi.getReceivingLevelProcess();
    fmi.getReceivingSupplierName();
    fmi.getReceivingFMIType();

    fmi.getReceivingClasification();
});

fmi.supplierLegalEntity.subscribe(function(newValue){
    if(fmi.onchangeSupplierCountry() === true){
        dashboard.createNewCookie({supplierCountry:fmi.supplierCountry(),supplierLegalentity:newValue.toString()}); 
        fmi.suppliergGetData();
    }
    fmi.getSupplierCountry();
    fmi.getSupplierCategory();
    fmi.getSupplierSupplierName();
    fmi.getSupplierLevelProcess();
    fmi.getSupplierFMIType();

    fmi.getSupplierClasification();
});

fmi.receivingCategory.subscribe(function(newValue){
    if(fmi.onchangeReceivingCountry() === true){
        fmi.receivingGetData();
    }
    fmi.getReceivingCountry();
    fmi.getReceivingLegalEntity();
    fmi.getReceivingLevelProcess();
    fmi.getReceivingSupplierName();
    fmi.getReceivingFMIType();

    fmi.getReceivingClasification();
});

fmi.supplierCategory.subscribe(function(newValue){
    if(fmi.onchangeSupplierCountry() === true){
        fmi.suppliergGetData();
    }
    fmi.getSupplierCountry();
    fmi.getSupplierLegalEntity();
    fmi.getSupplierSupplierName();
    fmi.getSupplierLevelProcess();
    fmi.getSupplierFMIType();

    fmi.getSupplierClasification();
});



// fmi.receivingLevelProcess.subscribe(function(newValue){
//     if(fmi.onchangeReceivingCountry() === true){
//         fmi.receivingGetData();
//     }
//     fmi.getReceivingCountry();
//     fmi.getReceivingLegalEntity();
//     fmi.getReceivingCategory();
//     fmi.getReceivingSupplierName();
//     fmi.getReceivingFMIType();
// });

// fmi.supplierLevelProcess.subscribe(function(newValue){
//     if(fmi.onchangeReceivingCountry() === true){
//         fmi.suppliergGetData();
//     }
//     fmi.getSupplierCountry();
//     fmi.getSupplierLegalEntity();
//     fmi.getSupplierSupplierName();
//     fmi.getSupplierCategory();
//     fmi.getSupplierFMIType();
// });

// fmi.receivingSupplierType.subscribe(function(newValue){
//     if(fmi.onchangeReceivingCountry() === true){
//         fmi.receivingGetData();
//     }
//     fmi.getReceivingCountry();
//     fmi.getReceivingLegalEntity();
//     fmi.getReceivingCategory();
//     fmi.getReceivingSupplierName();
//     fmi.getReceivingFMIType();
// });

// fmi.supplierSupplierType.subscribe(function(newValue){
//     if(fmi.onchangeSupplierCountry() === true){
//         fmi.suppliergGetData();
//     }
//     fmi.getSupplierCountry();
//     fmi.getSupplierLegalEntity();
//     fmi.getSupplierSupplierName();
//     fmi.getSupplierCategory();
//     fmi.getSupplierFMIType();
// });

fmi.receivingClassification.subscribe(function(newValue){
    if(fmi.onchangeReceivingCountry() === true){
        fmi.receivingGetData();
    }
    fmi.getReceivingCountry();
    fmi.getReceivingLegalEntity();
    fmi.getReceivingCategory();
    fmi.getReceivingSupplierName();
    fmi.getReceivingFMIType();

});

fmi.supplierClassification.subscribe(function(newValue){
    if(fmi.onchangeSupplierCountry() === true){
        fmi.suppliergGetData();
    }
    fmi.getSupplierCountry();
    fmi.getSupplierLegalEntity();
    fmi.getSupplierSupplierName();
    fmi.getSupplierCategory();
    fmi.getSupplierFMIType();

    fmi.getSupplierClasification();
});

fmi.receivingSupplierName.subscribe(function(newValue){
    if(fmi.onchangeReceivingCountry() === true){
        fmi.receivingGetData();
    }
    fmi.getReceivingCountry();
    fmi.getReceivingLegalEntity();
    fmi.getReceivingCategory();
    fmi.getReceivingLevelProcess();
    fmi.getReceivingFMIType();

    fmi.getReceivingClasification();
});

fmi.supplierSupplierName.subscribe(function(newValue){
    if(fmi.onchangeSupplierCountry() === true){
        fmi.suppliergGetData();
    }
    fmi.getSupplierCountry();
    fmi.getSupplierLegalEntity();
    fmi.getSupplierCategory();
    fmi.getSupplierLevelProcess();
    fmi.getSupplierFMIType();

    fmi.getSupplierClasification();
});

fmi.receivingFMIType.subscribe(function(newValue){
    if(fmi.onchangeReceivingCountry() === true){
        fmi.receivingGetData();
    }
    fmi.getReceivingCountry();
    fmi.getReceivingLegalEntity();
    fmi.getReceivingCategory();
    fmi.getReceivingLevelProcess();
    fmi.getReceivingSupplierName();

    fmi.getReceivingClasification();
});

fmi.supplierFMIType.subscribe(function(newValue){
    if(fmi.onchangeSupplierCountry() === true){
        fmi.suppliergGetData();
    }
    fmi.getSupplierCountry();
    fmi.getSupplierLegalEntity();
    fmi.getSupplierCategory();
    fmi.getSupplierLevelProcess();
    fmi.getSupplierSupplierName();

    fmi.getSupplierClasification();
});

fmi.expand = function(type,index){
    return function(){
      var classUp = 'glyphicon-chevron-up'
      var classDown = 'glyphicon-chevron-down'
       $("#"+type+"-legal_"+index).slideToggle( "slow", function() {
            $("#"+type+"-expand-"+index).hasClass(classDown) ? $("#"+type+"-expand-"+index).addClass(classUp).removeClass(classDown): $("#"+type+"-expand-"+index).addClass(classDown).removeClass(classUp);
       });
    }
};

fmi.expandSupplier = function(type,index){
    return function(){
      var classUp = 'glyphicon-chevron-up'
      var classDown = 'glyphicon-chevron-down'
        $("#"+type+"-legalsup_"+index).slideToggle( "slow", function() {
            $("#"+type+"-expandsup-"+index).hasClass(classDown) ? $("#"+type+"-expandsup-"+index).addClass(classUp).removeClass(classDown): $("#"+type+"-expandsup-"+index).addClass(classDown).removeClass(classUp);
        });
    }
};

fmi.init = function(){ //initReceiving
    localStorage.setItem('tab', 'fmi');
    localStorage.setItem('subTab', 'fmi-receiver');
    fmi.getReceivingCountry();
    fmi.getReceivingLegalEntity();
    fmi.getReceivingCategory();
    fmi.getReceivingLevelProcess();
    fmi.getReceivingSupplierName();
    fmi.getReceivingFMIType();
    fmi.receivingGetData();
    fmi.getReceivingClasification();
};

fmi.initSupplier = function(){
    localStorage.setItem('tab', 'fmi');
    localStorage.setItem('subTab', 'fmi-supplier');
    if(fmi.clickSupplierIndex === 0){
        fmi.getSupplierClasification();
        fmi.getSupplierCountry();
        fmi.getSupplierLegalEntity();
        fmi.getSupplierCategory();
        fmi.getSupplierSupplierName();
        fmi.getSupplierLevelProcess();
        fmi.getSupplierFMIType();
        fmi.suppliergGetData(); 
        fmi.clickSupplierIndex += 1;
    }else{
        fmi.supplierPrepareMap();
        fmi.suppliergGetData(); 
    }
};
fmi.setSubtab = function(){
    localStorage.setItem('subTab', 'fmi-receiver');
    fmi.receivingPrepareMap();
    fmi.receivingGetData();
};