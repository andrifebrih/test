sead = {}

sead.listDataCountry = ko.observableArray([])
sead.listDataSettingAssessmentDate = ko.observableArray([])
sead.valueCountry = ko.observable('')
sead.valueCustomDate = ko.observable('')
sead.valueRecurrennce = ko.observable('')
sead.valueDateConfig = ko.observable('0')
sead.idSettingAssessmentDate = ko.observable('')
sead.StatusEditOrNot = ko.observable(false)

sead.getListCountry = function(){
  var url = "/settingassessmentdate/getlistcountry"

  sead.listDataCountry([])
  ajaxPost(url, {}, function (res){
    // console.log(res);
    res = res.sort(function(a, b){
    var IdA=a._id.countryname.toLowerCase(), IdB=b._id.countryname.toLowerCase()
    if (IdA < IdB) //sort string ascending
        return -1 
    if (IdA > IdB)
         return 1
    return 0 //default return value (no sorting)
    })

    sead.listDataCountry(res)
    sead.listDataCountry.push({_id:{countryname:'ALL'}})

  })
}

sead.getListSettingAssessmentDate = function(status, id){
  var url = "/settingassessmentdate/getsettingassessmentdate"
  
  sead.listDataSettingAssessmentDate([])
  ajaxPost(url, {}, function (res){
    // console.log(res);
    // res.Data = res.Data.sort(function(a, b){
    // var IdA=a.countryname.toLowerCase(), IdB=b.countryname.toLowerCase()
    // if (IdA < IdB) //sort string ascending
    //     return -1 
    // if (IdA > IdB)
    //      return 1
    // return 0 //default return value (no sorting)
    // })

    res.Data.forEach(function(d){
      // d.recurrencepattern = d.recurrencepattern+" Month"
      if (d.basedofrecurrence == "lastcefassmtdate"){
        d.basedofrecurrence = "Last CEF Assessment Date"
        d.nextAssmentDate = "-"
      }else {
        var convertDate = d.basedofrecurrence.split('-')
        var mydate = new Date(convertDate[2], convertDate[1]-1,  convertDate[0])
        // console.log(mydate)
        d.nextAssmentDate = new Date(new Date(mydate).setMonth(mydate.getMonth() + parseInt(d.recurrencepattern)))
        d.nextAssmentDate = kendo.toString(kendo.parseDate(d.nextAssmentDate, 'yyyy-MM-ddTHH:mm:ss'), 'dd-MM-yyyy')
        // console.log("awal :",d.basedofrecurrence, "ditambah : ", d.recurrencepattern, " hasil : ",d.nextAssmentDate)
      }
    })
    sead.listDataSettingAssessmentDate(res.Data)
  })
    
}

sead.editSettingAssessmentRule = function(id){
  var url = "/settingassessmentdate/savesettingassessmentdate"
  sead.idSettingAssessmentDate(id)

  $.each(sead.listDataSettingAssessmentDate(), function(i, v){
    if (id == v._id){
      // temp = v
      console.log("isi ",v)
      sead.valueCountry(v.countryname)
      sead.valueDateConfig(v.config)

      if (v.recurrencepattern == "3"){
        $(".recPattren:eq(0)").prop("checked", true)
        $(".recPattren:eq(0)").closest('.btnRadioAssesment').addClass('active')
      }else if (v.recurrencepattern == "6"){
        $(".recPattren:eq(1)").prop("checked", true)
        $(".recPattren:eq(1)").closest('.btnRadioAssesment').addClass('active')
      }else {
        $(".recPattren:eq(2)").prop("checked", true)
        $(".recPattren:eq(2)").closest('.btnRadioAssesment').addClass('active')
      }

      if (v.basedofrecurrence !== "Last CEF Assessment Date"){
        $("#customDate1").hide()
        $("#customDate2").show() 
        sead.valueCustomDate(v.basedofrecurrence)
      }else {
        $('.lastAssesmentDate').prop("checked", true)
        $(".lastAssesmentDate").closest('.btnRadioAssesment').addClass('active')
        // sead.valueCustomDate(v.basedofrecurrence)
      }

      if (v.config == "noenddate"){
        $('.Recurrence2:eq(0)').prop("checked", true)
        sead.valueDateConfig("noenddate")  
      }else if ((v.config).indexOf('-') == -1){
        $('.Recurrence2:eq(1)').prop("checked", true)
        sead.valueDateConfig(v.config)  
      }else {
        $('.Recurrence2:eq(2)').prop("checked", true)
        sead.valueDateConfig(v.config)
      }
    }
  })

  $("#CEF-Re-AssessmentRule").modal("show")
  // sead.StatusEditOrNot(true)
}

sead.saveSettingAssessmentRule = function(status){
  var url = "/settingassessmentdate/savesettingassessmentdate"
  
    if (typeof sead.valueCustomDate() == "object"){
      if (sead.valueCustomDate() !== 'lastcefassmtdate'){
        sead.valueCustomDate(kendo.toString(kendo.parseDate(sead.valueCustomDate(), 'yyyy-MM-ddTHH:mm:ss'), 'dd-MM-yyyy'))
      }  
    }  
    if (typeof sead.valueCustomDate() == "object"){
      sead.valueDateConfig(kendo.toString(kendo.parseDate(sead.valueDateConfig(), 'yyyy-MM-ddTHH:mm:ss'), 'dd-MM-yyyy'))  
    }
            
  if (status == 'new'){
    var payload = {
      countryname : sead.valueCountry(),
      basedofrecurrence : sead.valueCustomDate(),
      recurrencepattern : $(".recPattren:checked").val(),
      patternscale : "month",
      config :sead.valueDateConfig()
    }  
  }else {
    var payload = {
      _id : sead.idSettingAssessmentDate(),
      countryname : sead.valueCountry(),
      basedofrecurrence : sead.valueCustomDate(),
      recurrencepattern : $(".recPattren:checked").val(),
      patternscale : "month",
      config :sead.valueDateConfig()
    }
  }
  
  sead.getListSettingAssessmentDate([]);
  ajaxPost(url, payload, function (res){
    console.log("isi payload ", payload);
    // console.log("isi res ", res);
  })

  sead.getListSettingAssessmentDate();
  // sead.StatusEditOrNot(false)
}

sead.resetValue = function(){
  $("#CEF-Re-AssessmentRule").find(".active").removeClass("active");
  $("#customDate2").hide()
  $("#customDate1").show()
  sead.valueCountry('')
  sead.valueCustomDate(kendo.parseDate(new Date(), 'dd-MM-yyyy'));
  $(".Recurrence2").prop("checked",false);
  sead.valueDateConfig('0')
}

sead.changeConfig = function(value){
  return function(){
    if ( value == "noenddate"){
      sead.valueDateConfig("noenddate")  
    }
    else if (value == "endby"){
      sead.valueDateConfig(kendo.toString(kendo.parseDate(sead.valueDateConfig(), 'yyyy-MM-ddTHH:mm:ss'), 'dd-MM-yyyy'))  
    }else if(value == "endafter"){
      sead.valueDateConfig()
    }
  }
}

sead.changeRangeOfRecurrence = function(value){
  return function(){
    if (value == "custom"){
      $("#customDate1").hide()
      $("#customDate2").show() 
      // sead.valueCustomDate(sead.valueCustomDate())
      
    }else {
      $("#customDate2").hide()
      $("#customDate1").show()   
      sead.valueCustomDate('lastcefassmtdate')
    }    
  }  
}

sead.CEFnewRule = function(){
  var tempCountry = []
  $.each(sead.listDataSettingAssessmentDate(), function(i, v){
    tempCountry.push(v.countryname)
  })

  var temp = []
  $.each(sead.listDataCountry(), function(i, v){
    if (tempCountry.indexOf(v._id.countryname) === -1){
      temp.push(v)
    }  
  })
  sead.listDataCountry(temp)
}


$(function(){   
  sead.getListSettingAssessmentDate();
  sead.getListCountry();
  setTimeout(function() {
    $('[data-toggle="tooltip"]').tooltip();  
  }, 500);

})