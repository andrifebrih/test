var cgv = {};

cgv.receivingcategory = ko.observableArray([]),
cgv.receivingcategoryValue = ko.observable(),
cgv.allData = ko.observable(false),
cgv.templateSummary = {
    NoOfSupplier:"",
    TotalTrx:""
}
cgv.summary = ko.mapping.fromJS(cgv.templateSummary)

cgv.getreceivingcategory = function(e){
    var url = "/categoryview/getcategory";
    ajaxPost(url,{}, function (res){
      var category = []
      $.each(res, function(index, result){		
 			  category.push({"name" : result._id,"text": result._id});
		  });
		cgv.receivingcategory(category)
    });
}

cgv.chartReceiverCountry =  function(dataSource){
      $("#receivercountrychart").kendoChart({
        dataSource: {
            data:dataSource,
            dataType: "json"
        },
        title: {
            text: "Process Receiver Countries",
            visible:true,
             font: "14px calibri",
        },
        legend :{
            position :"top",
        },
        seriesDefaults:{
            type:"column",
        },
        series :[{
            field: "Count",
        }],
        categoryAxis :{
            field : "_id",
            labels: {
                rotation: -90,
                font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
            majorGridLines: {
                visible: false
            }
        },
        valueAxis:{
            labels: {
                visible: true,
                format: "n0",
            },
        },
        tooltip: {
            visible: true,
            format: "n0",
        },
        seriesColors: ["#317DB5"],
    });
}

cgv.chartServiceCountry =  function(dataSource){
    $("#chartservicecountry").kendoChart({
        title: {
            text: "Service Processes by Country by Sub Category",
            position: "top",
            font: "14px calibri",
            visible: true
        },
        legend :{
            position :"bottom",
            labels: {
                font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        seriesDefaults:{
            type:"column",
            stack:true, 
        },
        series:dataSource.datalist,
        categoryAxis :{
            categories: dataSource.countrylist,
            labels: {
                rotation: -90,
                font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            },
        },
        tooltip: {
            visible: true,
            font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
        },
        seriesColors: ecisColors2,
    });
}

cgv.chartServiceType  =  function(dataSource){
    var data = []
    $.each(dataSource, function(i, val){    
        data.push({"category" : val._id,"value": val.Count});
    });
    $("#servicetypechart").kendoChart({
        title: {
            position: "top",
            text: "Process Supply Type :",

            font: "14px calibri"
        },
        legend: {
            position: "bottom"  
      },
        chartArea: {
            background: ""
        },
        seriesDefaults: {
            labels: { 
                position: "outsideEnd",
                visible: true,
                background: "transparent",
                template: "#= kendo.toString(percentage,'P2') #",
                font: "11px Arial,Helvetica,sans-serif"
            }
        },
        series: [{
            type: "pie",
            startAngle: 150,
            data: data
        }],
        seriesColors:ecisColors,
        tooltip: {
            visible: true,
            template: "#= '<b>' + dataItem.category  + '</br>' + kendo.toString( dataItem.value ) + '</b>' #",
            font: "11px Arial,Helvetica,sans-serif"
        }
    });
}

cgv.ServicesByProcessesGrid = function(param) {
    var dataSource = [];
    var url = "/categoryview/processnamesuppliertype";
    $("#grid-processes").html("");
    $("#grid-processes").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) {
                    if (data.Data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Data.Records;
                    }
                },
                total: "Data.Count",
            },
            pageSize: 15,
            serverPaging: false,
            serverSorting: false,
        },
        height: 400,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        excel: {
            fileName: "Count of Services by Processes and Supply Category.xlsx",
            allPages: true
        },
        columnMenu: false,
        columns: [{
            field:"Processname",
            title:"Row Label",
            width:200,
            attributes: {
                "class": "field-ellipsis"
            }
        },{
            field:"IGS",
            title:"IGS",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Systems",
            title:"Systems",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Teams",
            title:"Teams",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"TPS",
            title:"TPS",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Total",
            title:"Total",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        }]
    });
}

cgv.ServicesBySuppliersGrid = function(param) {
    var dataSource = [];
    var url = "/categoryview/suppliernamesuppliertype";
    $("#grid-suppliers").html("");
    $("#grid-suppliers").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) {
                    if (data.Data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Data.Records;
                    }
                },
                total: "Data.Count",
            },
            pageSize: 15,
            serverPaging: false,
            serverSorting: false,
        },
        height: 400,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5
        },
        excel: {
            fileName: "Count of Services by Suppliers and Supply Category.xlsx",
            allPages: true
        },
        columnMenu: false,
         columns: [{
            field:"Processname",
            title:"Row Label",
            width:200,
            attributes: {
                "class": "field-ellipsis"
            }
        },{
            field:"IGS",
            title:"IGS",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Systems",
            title:"Systems",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Teams",
            title:"Teams",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"TPS",
            title:"TPS",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        },{
            field:"Total",
            title:"Total",
            width:50,
            filterable: false,
            attributes: {"class": "align-right"}
        }]
    });
}

cgv.getData = function(){
    var payload = {
        Categoryname: cgv.receivingcategoryValue()
    }    
    ajaxPost("/categoryview/receivercountry", payload , function (res){
        cgv.chartReceiverCountry(res);
    })
    ajaxPost("/categoryview/stackbar", payload , function (res){
        cgv.chartServiceCountry(res);
    })
    ajaxPost("/categoryview/suppliertype", payload , function (res){
        cgv.chartServiceType(res);
    })
    cgv.ServicesByProcessesGrid(payload)
    cgv.ServicesBySuppliersGrid(payload)
}

cgv.changeReceivingCount= function(e){
    var dataItem = this.dataItem(e.item);
    var summary = ko.mapping.toJS(cgv.summary);
    cgv.receivingcategoryValue(dataItem.name);
    cgv.getData();
    if (cgv.receivingcategoryValue() == undefined) {
        swal({title: "No Data", type: "error"});
        cgv.allData(false);
    }else{
        cgv.allData(true);
        ajaxPost("/categoryview/summary", {Categoryname: cgv.receivingcategoryValue()} , function (res){
            summary.NoOfSupplier = res.NoOfSupplier
            summary.TotalTrx = res.TotalTrx
            ko.mapping.fromJS(summary,cgv.summary)
        })
    }
}

$(function(){
    cgv.getreceivingcategory();
    $("#export-processes").click(function () {
        var grid = $("#grid-processes").data("kendoGrid");
        grid.saveAsExcel();
    });
    $("#export-suppliers").click(function () {
        var grid = $("#grid-suppliers").data("kendoGrid");
        grid.saveAsExcel();
    });
});