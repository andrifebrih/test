var fmiCmg = {};

fmiCmg.data = ko.observableArray([]);
fmiCmg.newCountryVal = ko.observable("");

fmiCmg.init = function() {
  $(".gridCountry").kendoGrid({
    dataSource: {
      transport: {
        read: function(option) {
          ajaxPost("/fmi/getcmgcountry", {}, function(res) {
            var data = _.map(res.Data, function(d, i) {
              return {
                no: (i + 1),
                value: d
              }
            })
            option.success({"data": data, "count": res.Total});
          })
        }
      },
      schema: {
        data: "data",
        total: "count"
      },
      pageSize: 10,
    },
    columns: [
      {
        title: "#",
        field: "no",
        width: 50,
        headerAttributes: {

        }
      },
      {
        title: "Country",
        field: "value"
      },
      {
        title: "Action",
        width: 100,
        command: [
          {
            name: "customDelete",
            text: "",
            click: fmiCmg.handleDelete,
            className: "btn btn-danger",
            iconClass: " fa fa-trash"
          }
        ]
      }
    ],
    pageable: {
      pageSize: 10,
    }
  })
}

fmiCmg.handleDelete = function(e) {
  var tr = $(e.target).closest("tr");
  var data = this.dataItem(tr)
  // ajaxPost("/fmi/deletecmgcountry", {
  //   Country: fmiCmg.newCountryVal(),
  // }, function(res) {
  //   console.log(res);
  // })
}

fmiCmg.handleAdd = function() {
  ajaxPost("/fmi/createcmgcountry", {
    Country: fmiCmg.newCountryVal(),
  }, function(res) {
    console.log(res);
  })
}

$(function() {
  fmiCmg.init();
})
