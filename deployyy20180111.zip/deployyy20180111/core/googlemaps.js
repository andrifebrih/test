var gmaps = {}; 
gmaps.supplierType = ko.observableArray([]);
gmaps.receivingCountry =  ko.observable('');
gmaps.showLegend =  ko.observable(false);

gmaps.redirectCountryView = function(country){
    var protocol = window.location.protocol;
    var host = window.location.hostname;
    var port = window.location.port;
    var url;
    if(port !== ''){
        url = protocol+"//"+host+":"+port
    }else{
        url = protocol+"//"+host
    }
    var fullURL = url+"/countryview/default?country="+country;
    window.location.replace(fullURL);
};
gmaps.detailsMapTopFive =  function(ds){
  	gmaps.showLegend(true)
  	var myLatlng = {lat: 23.178089, lng: 5.508720};
    var map = new google.maps.Map(document.getElementById('maps'), {
        zoom: 2,
        center: myLatlng
    });

    var startLineCordinate = {lat: ds.BoxInfo.Latitude, lng: ds.BoxInfo.Longitude};
    var geoJson = ds.BubbleSupplier.features;
    var markers = [];
    var coordinates = [];
    var lineCordinates = [];
    var lines = [];
    var popUp = [];

    $.each(geoJson, function(i,v){
      var newProperties = {position:{lat:v.geometry.coordinates[1], lng: v.geometry.coordinates[0]}}; 
      v.properties = $.extend(true, v.properties,newProperties);
      
      if(v.properties.parentprocessname >= 100){
        var icon  = '/static/img/red-marker.png'
      }else{
        var icon  = '/static/img/yellow-marker.png'
      }

      markers[i] = new google.maps.Marker({
        position: v.properties.position,
        map: map,
        icon: icon,
        title: v.properties.SecondaryID
      });

      google.maps.event.addListener(markers[i], 'click', function(e) { 
        var country = this.title       
        gmaps.redirectCountryView(country)        
      });

      lineCordinates[i] = [
        startLineCordinate,
        v.properties.position
      ];

      lines[i] = new google.maps.Polyline({
        path: lineCordinates[i],
        geodesic: true,
        strokeColor: '#6C8DC2',
        strokeOpacity: 1.0,
        strokeWeight: 2
      });

      lines[i].setMap(map);

      var contentTooltip  = ['<div id="content">',
          '<div id="siteNotice">',
          '</div>',
          '<div id="bodyContent">',
          "Country Name : " +  v.properties.SecondaryID ,
          "</br><b>Parent processname : "+  v.properties.parentprocessname ,
          "</b></br>Service description : "+   v.properties.servicedescription , 
          "</br>Total Fte : "+  v.properties.totalfte ,
          '</div>',
          '</div>'].join(" ");

        popUp[v.properties.SecondaryID] =new google.maps.InfoWindow({
            content: contentTooltip 
        });
        google.maps.event.addListener(markers[i], 'mouseover', function(e) {        
          for(key in popUp){
            popUp[key].close()
          }
          popUp[this.title].open(map, this);         
        }); 
    }); 

    var labelInfo = ds.BoxInfo;
    var default_ContentTooltip = ['<div id="content">',
              '<div id="siteNotice">',
              '</div>',
              '<div id="bodyContent">',
              "Legal Entity : " + labelInfo.LegalEntity,
              "</br><b>Supplier Country : "+ labelInfo.SupplierCountry,
              "</b></br>Category : "+  labelInfo.Countryname,
              "</br>Supplier Count : "+   labelInfo.Suppliercount,
              "</br>Process Names :" + labelInfo.Processname,
              '</div>',
              '</div>'].join(" ");
              
    var infowindow = new google.maps.InfoWindow({
        content: default_ContentTooltip
    });
          
    var default_markerTooltip = new google.maps.Marker({
      position:startLineCordinate,
      map: map,
      title: 'Receiving Country',
      icon: '/static/img/star-marker.png'
    });

    infowindow.open(map,default_markerTooltip);

    default_markerTooltip.addListener('mouseover', function() {
      infowindow.open(map, default_markerTooltip);
    });  
};
gmaps.mapTopFive =  function(ds){
    var myLatlng = {lat: 23.178089, lng: 5.508720};
    var map = new google.maps.Map(document.getElementById('maps'), {
      zoom: 2,
      center: myLatlng
    });
    var geoJson = ds.features;
    var markers = []
    var coordinates = []

    $.each(geoJson, function(i,v){
      var newProperties = {position:{lat:v.geometry.coordinates[1], lng: v.geometry.coordinates[0]}}; 
      v.properties = $.extend(true, v.properties,newProperties);
      console.log(v.properties)
      markers[i] = new google.maps.Marker({
        position: v.properties.position,
        map: map,
        icon: '/static/img/blue_marker.png',
        title: v.properties.SecondaryID
      });

      google.maps.event.addListener(markers[i], 'click', function(e) { 
          var country = this.title       
          gmaps.receivingCountry(country)
          gmaps.getData()        
      });
    });  
};
gmaps.getData =  function(){
    var payload={
        Suppliertype :  gmaps.supplierType(),
        Country :  gmaps.receivingCountry()
    }

    if(gmaps.receivingCountry() == ''){
    	var url = "/dashboard/gettopfive";
    	ajaxPost(url, payload, function (res){
        	gmaps.mapTopFive(res)
    	});
	  }else{
  		var url = "/dashboard/getdetailstopfive";
  		ajaxPost(url, payload, function (res){
       		gmaps.detailsMapTopFive(res)
      });
	  }
};
gmaps.getSupplierType = function(){
    ajaxPost("/ocirtranche/getsuppliertype",{} , function (res){
       var suppliers = [] 
       $.each(res,function(i,v){
            suppliers.push(v._id)
       })
       gmaps.supplierType(suppliers)
       gmaps.getData()
    })
};

$(function(){
   gmaps.getSupplierType();
})


