var receiver = {};

receiver.receivingCountry     = ko.observable('');
receiver.receivingCountryList = ko.observableArray([]);
receiver.LegalEntity      = ko.observableArray([]);
receiver.LegalEntityList  = ko.observableArray([]);
receiver.mapType       = ko.observable('light');
receiver.properties    = { SecondaryID :"", count:"", percent:""}
receiver.supplierType  = ko.observableArray([]);
receiver.showSupplierType         = ko.observable(false);
receiver.onchangeReceiverCountry  = ko.observable(true);
receiver.onchangeLegalEntity      = ko.observable(true);
receiver.showSummaryReceiver      = ko.observable(false);
receiver.templateSummaryReceiver = { SupplierCountry:"", CEF:"", LegalEntity:"", ParentProcess:"", ServiceReady :""}
receiver.summaryReceiver = ko.mapping.fromJS(receiver.templateSummaryReceiver)
receiver.summaryLagalDetails = ko.observableArray([])
receiver.chartLegal = ko.observableArray([])
receiver.chartConfig = ko.observable({
    legend: {
        visible:true,
        margin:{visible:true,left:-20},
        labels: {
            template: "#if(dataItem.category=='TPS'){# #: 'External' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup' # #}else{# #: 'In-Entity' # #}#",
        },
    },
    seriesDefaults: {
        labels: {
            visible: true,
            template: "#= kendo.toString(percentage,'P0')#",
        }
    },
    tooltip: {
        visible: true,
        template: "#if(dataItem.category=='TPS'){# #: 'External - ' + kendo.toString( dataItem.value, 'n0' )# #}else if(dataItem.category==='Systems'){# #: 'Systems - '+ kendo.toString( dataItem.value, 'n0' ) # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup - '+ kendo.toString( dataItem.value, 'n0' ) # #}else{# #: 'In-Entity - '+ kendo.toString( dataItem.value, 'n0' ) # #}#",            
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
    },
});
// receiver.redirectCountryView = function(country){
//     var protocol = window.location.protocol;
//     var host = window.location.hostname;
//     var port = window.location.port;
//     var url;
    
//     if(port !== ''){
//         url = protocol+"//"+host+":"+port
//     }else{
//         url = protocol+"//"+host
//     }
//     var fullURL = url+"/countryview/default?country="+country;
//     window.location.replace(fullURL);
// };
receiver.setReceiver =  function(){
   return function () {
        eraseCookie("supplierCountry");
        eraseCookie("supplierLegalentity");
        eraseCookie("receiverCountry");
        eraseCookie("receiverLegalEntity");
        createCookie("receiverCountry",receiver.receivingCountry()); 
        var supplier = ko.mapping.toJS(receiver.summaryReceiver.SupplierCountry)
        if(supplier.toUpperCase() !== "ALL"){
            createCookie("supplierCountry",supplier); 
        }
        receiver.redirect()
    }  
}
receiver.setlegalEntity =  function(e){
   return function () {

        eraseCookie("supplierCountry");
        eraseCookie("supplierLegalentity");
        eraseCookie("receiverCountry");
        eraseCookie("receiverLegalEntity");

        createCookie("receiverCountry",receiver.receivingCountry()); 
        createCookie("receiverLegalEntity",e); 
        var supplier = ko.mapping.toJS(receiver.summaryReceiver.SupplierCountry)
        if(supplier.toUpperCase() !== "ALL"){
            eraseCookie("receiverLegalEntity");
            createCookie("supplierCountry",supplier); 
            createCookie("supplierLegalentity",e); 
        }
        receiver.redirect()
    }  
}
receiver.redirect =  function(){
    redirectUrl("/ociranalysis/default")
}
receiver.prepareMap =  function(){
    $('#map-receiving').remove();
    $(".panelMap").append("<div id='map-receiving' class='map'> </div>");
};
receiver.detailsMapTopFive = function(dataSource){
    receiver.showSupplierType(true);
    receiver.prepareMap();
    L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxNWVubjg2MDA2NWZta2tnc2NocnF4ZyJ9.NDWpdAW4qO42qUdRBNIa5Q';
    var mapLeaflet = L.mapbox.map('map-receiving', 'mapbox.'+receiver.mapType(),{'worldCopyJump': true}).setView([0,0], 2)
    
    var geoJson = dataSource.BubbleSupplier.features; 
    var indexDelete;
    var startLine = {x:dataSource.BoxInfo.Longitude, y:dataSource.BoxInfo.Latitude}  
    $.each(geoJson, function(i,v){
        if(v.geometry.coordinates[0].toFixed(0) != dataSource.BoxInfo.Longitude.toFixed(0) || v.geometry.coordinates[1].toFixed(0) != dataSource.BoxInfo.Latitude.toFixed(0)) {         
            var color;
            if(v.properties.count <= 5){
                color = "#7F7F7F";
            }else if(v.properties.count <= 20){
                color = "#b5ce7d";
            }  else {
                color = "#60B4E4"; 
            }
            
            var newProperties = {"marker-size": "small","marker-symbol":"marker","marker-color":color}; 
            $.extend(true, v.properties,newProperties)

            var endLine = {x:v.geometry.coordinates[0], y: v.geometry.coordinates[1]};
            var generator = new arc.GreatCircle(startLine,endLine,{color: "#CBA23C" });
            
            var line = generator.Arc(200, { offset: 0 });  
            L.geoJson(line.json()).addTo(mapLeaflet);
        }else{
            indexDelete = i
        }
    });   
    (indexDelete === undefined)?'': geoJson.splice(indexDelete,1)
   
    var boxLabel = dataSource.BoxInfo
    // var labelFte =  (boxLabel.fte=== null)? boxLabel.fte : kendo.toString(boxLabel.fte, 'N1')
    // var templatePopUpReceivingCountry = [
    //                                   "<span style='color:#0644a0'>Supplier Country Data</span>",
    //                                   "<b>"+ receiver.receivingCountry() + "</b>",
    //                                   "Internal Level 1   : " +  kendo.toString(boxLabel.InternalProcessname, 'N0'),
    //                                   "Level 1 Processes  : " +  kendo.toString(boxLabel.Processname, 'N0'),
    //                                   "Supplier Countries : " +   kendo.toString(boxLabel.SupplierCountry, 'N0'),
    //                                   "Suppliers :" + kendo.toString(boxLabel.Suppliercount, 'N0'),
    //                                   "Product Functions :" + kendo.toString(boxLabel.Productfunction, 'N0'),
    //                                   "Allocated Service FTE:" + labelFte ].join("<br>")
                                      
    var receiverMarker = L.marker([dataSource.BoxInfo.Latitude, dataSource.BoxInfo.Longitude], {
            icon : L.icon( {
                iconUrl : '/static/img/receiver-marker.png',
            } )
    } ).addTo( mapLeaflet );

    var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    myLayer.setGeoJSON(geoJson);

    // receiverMarker.on("mouseover", function(e) {
    //    var popup = L.popup()
    //        .setLatLng([boxLabel.Latitude, boxLabel.Longitude]) 
    //        .setContent(templatePopUpReceivingCountry)
    //        .openOn(mapLeaflet);
    // });
    
    // receiverMarker.on("click", function(e) {
    //     var country = receiver.receivingCountry()
      
    //     supplier.redirectCountryView(country)
    // });
  
    receiverMarker.on("click", function(e) {
        var payloadSummary={
            Suppliertype :  receiver.supplierType(),
            ReceivingCountry :  receiver.receivingCountry(),
            LegalEntity : [],
            SupplierCountry : ''
        }
        ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
          receiver.createSummary(res)
        })    
    });
    myLayer.on('click', function(e) {
        var country = e.layer.feature.properties['SecondaryID']
        var payloadSummary={
            Suppliertype :  receiver.supplierType(),
            ReceivingCountry :  receiver.receivingCountry(),
            LegalEntity : [],
            SupplierCountry : country
        }
        ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
            receiver.createSummary(res)
        })  
    });
    // myLayer.on('click', function(e) {
    //     var country = e.layer.feature.properties['SecondaryID']
    //     dashboard.redirectCountryView(country)   
    // });
   
    // myLayer.on("mouseover", function(e) {
    //   var fte =  (e.layer.feature.properties['fte'] === null)? e.layer.feature.properties['fte'] : e.layer.feature.properties['fte'].toFixed(1) 
    //   var templatePopUp = ["<span style='color:#0644a0'>Supplier Country Data</span>",
    //                     "<b>Country Name : " +  e.layer.feature.properties['SecondaryID'] + "</b>",
    //                     "Level1 Processes  : "+  e.layer.feature.properties['Processname'],
    //                     "Suppliers : "+   e.layer.feature.properties['Suppliercount'],
    //                     "Product Functions : "+   e.layer.feature.properties['Productfunction'],
    //                     "Allocated Service FTE : "+ fte  ].join("<br>")           
    //     var popup = L.popup()
    //        .setLatLng(e.latlng) 
    //        .setContent(templatePopUp)
    //        .openOn(mapLeaflet);
    // });
    
    $line = $("path[stroke-linejoin='round']");
    $line.attr('stroke-width',"2");
    $line.attr('stroke-opacity',"3");
    $line.attr('stroke',"#3A91B9");
};
receiver.createSummary =function(dataSource){
    var receiverDetails = dataSource.ReceiverDetails;
    var summaryReceiver = ko.mapping.toJS(receiver.summaryReceiver);
        summaryReceiver.SupplierCountry = receiverDetails.SupplierCountry;
        summaryReceiver.CEF = kendo.toString(receiverDetails.CEF, "n0");
        summaryReceiver.LegalEntity = kendo.toString(receiverDetails.LegalEntity,"n0");
        summaryReceiver.ParentProcess = kendo.toString(receiverDetails.ParentProcess,"n0");
        summaryReceiver.ServiceReady = kendo.toString(receiverDetails.ServiceReady,"n1");  
    ko.mapping.fromJS(summaryReceiver,receiver.summaryReceiver)
    
    var legalDetails =  [];
    $.each(dataSource.LegalDetails, function(i,v){
        legalDetails.push({
                            CEF:kendo.toString(v.CEF,"n0"),
                            ParentProcess:kendo.toString(v.ParentProcess,"n0"),
                            ServiceReady:kendo.toString(v.ServiceReady,"n1"),
                            Title:v.Title})
       
    })
   
    receiver.summaryLagalDetails(legalDetails) 
    receiver.createEntDonut(dataSource.LegalDetails);
};
var CNUtimeout = setTimeout(function(){
                },1000);
receiver.getDataFromMarker =  function(){
    eraseCookie("supplierCountry");
    eraseCookie("supplierLegalentity");
    eraseCookie("receiverCountry");
    eraseCookie("receiverLegalEntity");

    receiver.showSummaryReceiver(true)
    var payloadDonut = {
        Country : receiver.receivingCountry(),
        LegalEntity: []
    }
    ajaxPost("/receiverview/getdonutreceiver", payloadDonut , function (res){
        receiver.createDonut(res);
        
    });
    clearTimeout(CNUtimeout);
    CNUtimeout = setTimeout(function(){  
        receiver.getlegalEntity();
        var payload={
            Suppliertype :  receiver.supplierType(),
            ReceivingCountry :  receiver.receivingCountry(),
            LegalEntity : []
        }
        ajaxPost("/receiverview/getdetailsreceiver", payload, function (res){
            receiver.detailsMapTopFive(res)
        });
        var payloadSummary={
            Suppliertype :  receiver.supplierType(),
            ReceivingCountry :  receiver.receivingCountry(),
            LegalEntity : [],
            SupplierCountry : ''
        }
        
        ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
            receiver.createSummary(res);
            
        })  
    },1000);
    CNUtimeout = setTimeout(function(){  
        receiver.onchangeReceiverCountry(true) 
        receiver.onchangeLegalEntity(true);
    },1000);
};
receiver.mapTopFive = function(dataSource){
    receiver.prepareMap()
    var geoJson =dataSource.features;
    
    $.each(geoJson, function(i,v){
       
        if(v.properties.count <= 5){
            var color = "#7F7F7F";
        }else if(v.properties.count <= 20){
            var color = "#b5ce7d";
        }  else {
            var color = "#60B4E4"; 
        }
        var newProperties = {"marker-size": "small","marker-symbol":"marker",'marker-color': color}; 
        $.extend(true, v.properties,newProperties)
    });
   
    L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxOXR1djI3MDFseGZ0bTFhbDc0YnoxdSJ9.vo3h2zpopQD9DVMILpkPYg';
    var mapLeaflet = L.mapbox.map('map-receiving', 'mapbox.'+receiver.mapType(),{'worldCopyJump': true})
      .setView([0,0], 2)

    var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    myLayer.setGeoJSON(geoJson);
    
    myLayer.on('click', function(e) {
        var country = e.layer.feature.properties['SecondaryID']
        receiver.onchangeReceiverCountry(false);
        receiver.onchangeLegalEntity(false);
        receiver.receivingCountry(country);
        receiver.getDataFromMarker(); 
    }); 
};
receiver.getData =  function(){
    eraseCookie("supplierCountry");
    eraseCookie("supplierLegalentity");
    eraseCookie("receiverCountry");
    eraseCookie("receiverLegalEntity");

    if(receiver.receivingCountry() == ''){
        receiver.showSummaryReceiver(false)
        var url = "/receiverview/getdefaultreceiver";
        ajaxPost(url, {}, function (res){
            receiver.mapTopFive(res)
        });
    }else{  
        receiver.showSummaryReceiver(true)
        var StringlegalEntitiesValue = receiver.LegalEntity().toString()
        createCookie("receiverCountry",receiver.receivingCountry()); 
        createCookie("receiverLegalEntity",StringlegalEntitiesValue); 
        
        var payload={
            Suppliertype :  receiver.supplierType(),
            ReceivingCountry :  receiver.receivingCountry(),
            LegalEntity : receiver.LegalEntity()
        }
       
        var url = "/receiverview/getdetailsreceiver";
        ajaxPost(url, payload, function (res){
            receiver.detailsMapTopFive(res)
        });
        var payloadSummary={
            Suppliertype :  receiver.supplierType(),
            ReceivingCountry :  receiver.receivingCountry(),
            LegalEntity : receiver.LegalEntity(),
            SupplierCountry : ''
        }
        ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
            receiver.createSummary(res);
            //receiver.createEntDonut(res.LegalDetails);
        })
        var payloadDonut={
            Country : receiver.receivingCountry(),
            LegalEntity:  receiver.LegalEntity()
        }

        ajaxPost("/receiverview/getdonutreceiver", payloadDonut , function (res){
            receiver.createDonut(res);
            
        });
    }    
};
receiver.getlegalEntity = function(){
    var payload = {
        ReceivingCountry : receiver.receivingCountry() 
    };
    var url = "/receiverview/getlegalentityreceiver";
    receiver.LegalEntity([]);
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        // legalEntities.push({text:"ALL", value:"ALL"})
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        
        receiver.LegalEntityList(legalEntities) 
    });
};
receiver.receivingCountry.subscribe(function(newValue){
    if(receiver.onchangeReceiverCountry() === true){
        receiver.onchangeLegalEntity(false) 
        clearTimeout(CNUtimeout);
        CNUtimeout = setTimeout(function(){  
            receiver.getlegalEntity();
            receiver.getData();   
        },1000) 
        CNUtimeout = setTimeout(function(){  
            receiver.onchangeLegalEntity(true) 
        },1000)  
    }
});
receiver.LegalEntity.subscribe(function(newValue){
    if(receiver.onchangeLegalEntity() === true ){
        console.log("getDATA")
        receiver.getData();
    }
})
receiver.getReceivingCountry = function(){
    var url = "/receiverview/getreceivercountry";
    ajaxPost(url,{}, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        receiver.receivingCountryList(receivingCountries);
    });
};
// receiver.changeMapType = function(e){
//     receiver.mapType(e) 
//     receiver.getData()
// };
receiver.changeSupplierType =  function(){
    if(receiver.showSupplierType() === true){
        var data;
        var $input = $("nav[id='receiver-filter']").find('input[type="checkbox"]');
        var totalInput= $input.length;
        var datas=[];
        if($("nav[id='receiver-filter']").find('input[type="checkbox"]:checked').length === 1){
           $("nav[id='receiver-filter']").find('input[type="checkbox"]:checked').attr( "disabled", "disabled" );
        }else{
            $("nav[id='receiver-filter']").find('input[type="checkbox"]:checked').removeAttr( "disabled");
        }

        for(var i=0; i < totalInput; i++){
            data = String($("nav[id='receiver-filter']").find('input[type="checkbox"]:checked').eq(i).val())
            if(data != "undefined"){
                datas.push(data)
            }
        }
        
        receiver.supplierType([])
        receiver.supplierType(datas)
        receiver.getData();   
        
    }
};
receiver.changeLegendSupplier =  function(e){ 
    var status = 0;
    var datas = receiver.supplierType();
    $.each(datas,function(i,v){
        if(v === e.text){
           datas.splice(i,1);
           $("nav[id='receiver-filter']").find('input[value="'+e.text+'"]').prop('checked',false)
           status = 1;
           return false;
        }
    });
    if(status == 0){ 
        datas.push(e.text)
        $("nav[id='receiver-filter']").find('input[value="'+e.text+'"]').prop('checked',true)
    }
    receiver.supplierType(datas)

    var legalEntitiesValue = [] 
    if(receiver.LegalEntity().length === 0 || receiver.LegalEntity().indexOf("ALL")  > -1){         
       $.each(receiver.LegalEntityList(), function(i,v){
            legalEntitiesValue.push(v.value);
        })
        receiver.LegalEntity("ALL");
    }else{
        legalEntitiesValue = receiver.LegalEntity()
    }
    var StringlegalEntitiesValue = legalEntitiesValue.toString()

    var payload={
        Suppliertype :  receiver.supplierType(),
        ReceivingCountry :  receiver.receivingCountry(),
        LegalEntity : legalEntitiesValue
    }
       
    var url = "/receiverview/getdetailsreceiver";
    ajaxPost(url, payload, function (res){
        receiver.detailsMapTopFive(res)
    });       
};
receiver.reset = function(){ 
 receiver.receivingCountry('')
 receiver.LegalEntity([])
 receiver.getData() 
};
receiver.createDonut = function(dataSource){
    var data = []
    var color =["#5eb74d","#268f00","#0042ba","#2ba6cb"]
   
    $.each(dataSource, function(i, val){    
        data.push({"category" : val._id.suppliertype,"value": val.Count, "color" : color[i]});
    });
    
    
    $("#chart").kendoChart({
        legend: {
            visible:true,
            margin:{visible:true,left:-20},
            labels: {
                template: "#if(dataItem.category=='TPS'){# #: 'External' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup' # #}else{# #: 'In-Entity' # #}#",
            },
        },
        chartArea: {
            heigh : 200,
            background: "transparent",
            width : 200,
        },
        seriesDefaults: {
              labels: {
                visible: true,
                template: "#= kendo.toString(percentage,'P0')#",
              }
        },
        series: [{
            type: "donut",
            data: data,
            color:"#5eb74d",
            overlay:{gradient:"none"},
        }],
        valueAxis:{
            visible:false,
            labels: {
              font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
              visible: false,
              format:"{0:P0}",
            },
            majorGridLines: {
                visible: false
            },
        },
        tooltip: {
            visible: true,
            template: "#if(dataItem.category=='TPS'){# #: 'External - ' + kendo.toString( dataItem.value, 'n0' )# #}else if(dataItem.category==='Systems'){# #: 'Systems - '+ kendo.toString( dataItem.value, 'n0' ) # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup - '+ kendo.toString( dataItem.value, 'n0' ) # #}else{# #: 'In-Entity - '+ kendo.toString( dataItem.value, 'n0' ) # #}#",            

            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        },

        legendItemClick: receiver.changeLegendSupplier
    });  
};
receiver.createEntDonut = function(dataSource){
    var data = []
    var color =["#5eb74d","#268f00","#0042ba","#2ba6cb"]
    // console.log(dataSource) 
    $.each(dataSource, function(i, val){    
        
        var data2 = []
        $.each(val.DonutChart, function(index, value){ 
            data2.push({"category" : value.suppliertype,"value": value.Count, "color" : color[index]});
        });

        data.push(data2)
        $("#chart_"+i).kendoChart({
            legend: {
                visible:true,
                margin:{visible:true,left:-20},
                labels: {
                    template: "#if(dataItem.category=='TPS'){# #: 'External' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup' # #}else{# #: 'In-Entity' # #}#",
                    },
            },
            chartArea: {
                height : 200,
                background: "transparent",
                width : 200,
            },
            seriesDefaults: {
                  labels: {
                    visible: true,
                    template: "#= kendo.toString(percentage,'P0')#",
                  }
            },
            series: [{
                type: "donut",
                data: data[i],
                overlay:{gradient:"none"},
            }],
            valueAxis:{
                visible:false,
                labels: {
                  font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                  visible: false,
                  format:"{0:P0}",
                },
                majorGridLines: {
                    visible: false
                },
            },
            tooltip: {
                visible: true,
                template: "#if(dataItem.category=='TPS'){# #: 'External - ' + kendo.toString( dataItem.value, 'n0' )# #}else if(dataItem.category==='Systems'){# #: 'Systems - '+ kendo.toString( dataItem.value, 'n0' ) # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup - '+ kendo.toString( dataItem.value, 'n0' ) # #}else{# #: 'In-Entity - '+ kendo.toString( dataItem.value, 'n0' ) # #}#",            

                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },

            legendItemClick: receiver.changeLegendSupplier
        });  
    });


};

$(function(){
    receiver.getReceivingCountry();
    receiver.getData();
    // receiver.getChart();
    $('.carousel-linked-nav > li > a').click(function() {
        var item = Number($(this).attr('href').substring(1));
        $('#myCarousel').carousel(item - 1);
        $('.carousel-linked-nav .active').removeClass('active');
        $(this).parent().addClass('active');
        return false;
    });
    
    // supplier.getReceivingCountry();
    // $('#myCarousel').carousel({
    //   interval: 3000
    // });

})