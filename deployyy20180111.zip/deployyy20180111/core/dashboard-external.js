function increaseIndexingAjx(index){
    return index( index() + 1 );
}
de = {}
de.receivingSupplierType = ko.observable('TPS');
// de.receivingSupplierTypeList = ko.observableArray([{value:"FMI_TPS",text:"FMI External"},
                                                   // {value:"TPS",text:"External"}]);

de.supplierSupplierType  = ko.observable('TPS');
// de.supplierSupplierTypeList  = ko.observableArray([{value:"FMI_TPS",text:"FMI External"},
                                                   // {value:"TPS",text:"External"}]);

de.receivingCountry     = ko.observable('');
de.receivingCountryList = ko.observableArray([]);

de.supplierCountry     = ko.observable('');
de.supplierCountryList = ko.observableArray([]);

de.receivingLegalEntity     = ko.observableArray([]);
de.receivingLegalEntityList = ko.observableArray([]);

de.supplierLegalEntity      = ko.observableArray([]);
de.supplierLegalEntityList  = ko.observableArray([]);

de.receivingCategory     = ko.observableArray([]);
de.receivingCategoryList = ko.observableArray([]);

de.supplierCategory     = ko.observableArray([]);
de.supplierCategoryList = ko.observableArray([]);

de.receivingProduct     = ko.observableArray([]);
de.receivingProductList = ko.observableArray([]);

de.supplierProduct     = ko.observableArray([]);
de.supplierProductList = ko.observableArray([]);

de.onchangeReceivingCountry = ko.observable(true);
de.onchangeSupplierCountry  = ko.observable(true);

de.receivingReceiverSummary = ko.observableArray([]);
de.supplierReceiverSummary = ko.observableArray([]);

de.receivingSupplierSummary = ko.observableArray([]);
de.supplierSupplierSummary = ko.observableArray([]);

de.receivingLevelProcess     = ko.observableArray([]);
de.receivingLevelProcessList = ko.observableArray([]);

de.supplierLevelProcess     = ko.observableArray([]);
de.supplierLevelProcessList = ko.observableArray([]);

de.receivingLevel2Process     = ko.observableArray([]);
de.receivingLevel2ProcessList = ko.observableArray([]);

de.supplierLevel2Process     = ko.observableArray([]);
de.supplierLevel2ProcessList = ko.observableArray([]);

de.receiverCountryMap = ko.observable();

de.headerModalReceiver = ko.observable('');
de.headerModalSupplier = ko.observable('');
de.templateConfigDonut = {
    legend: {
        visible:false,
        labels: {
            font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            template:'',
            color: "#0075B2"
        },
        margin:{
            visible:true,
            left:-15
        },
    },
    chartArea: {
        height : 100,
        background: "transparent",
        width : 120,
    },
    seriesDefaults: {
        labels: {
            visible: false,
            template: "#= removeSpace(kendo.toString(percentage,'P0'))#",
            font: "9px Helvetica Neue, Arial, sans-serif",
            background: "transparent"
        }
    },
    // seriesColors: ["#00506D","#0077A3","#50D0FF","#8ADFFF"],
    series: [{
        type: "donut",
        data: '',
        overlay:{gradient:"none"},
    }],
    valueAxis:{
        visible:false,
        labels: {
            font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
            visible: false,
            format:"{0:P0}",
        },
        majorGridLines: {
            visible: false
        },
    },
    tooltip: {
        visible: true,
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        template: "#=kendo.toString(value,'N0')#"
    },
}; 
de.configDonut = ko.mapping.fromJS(de.templateConfigDonut);

de.receivingHoverCountry = ko.observable('');
de.receivingTypeHoverCountry = ko.observable('');

de.supplierHoverCountry = ko.observable('');
de.supplierTypeHoverCountry = ko.observable('');

de.clickSupplierIndex = 0;
de.loadingMap =  {
    receiver : ko.observable(false),
    supplier : ko.observable(false),
};
de.indexingAjax = {
    receiverSummary: ko.observable(0),
    supplierSummary: ko.observable(0)
}

de.clickAnalyze = function(value,type){
    return function () { 
        var cookies;
        if(value.hasOwnProperty('receiverLegalEntity') ){
            var data = dashboard.parseLegalEntity(value)
                cookies = {receiverCountry:data['country'].trim(), receiverLegalEntity:data['legalEntity'].trim()};
            if(type == 'supplier'){
                $.extend(true,cookies,{supplierCountry:de.supplierCountry()})
                if(de.supplierLegalEntity().length > 0){
                    $.extend(true,cookies,{supplierLegalentity:de.supplierLegalEntity()})
                }
                if(de.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:de.supplierCategory()})
                }
            }else{
                if(de.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:de.receivingCategory()})
                }
            }
        }else if(value.hasOwnProperty('supplierLegalentity')){
            var data = dashboard.parseLegalEntity(value)

                cookies = {supplierCountry:data['country'].trim(), supplierLegalentity:data['legalEntity'].trim()};
            if(type == 'receiver'){
                $.extend(true,cookies,{receiverCountry:de.receivingCountry()})
                if(de.receivingLegalEntity().length > 0){
                    $.extend(true,cookies,{receiverLegalEntity:de.receivingLegalEntity()})
                }
                if(de.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:de.receivingCategory()})  
                }
            }else{
                if(de.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:de.supplierCategory()})
                }
            }
        }else if(value.hasOwnProperty('receiverCountry')){
            cookies = value;
            if(type == 'supplier' ){
                $.extend(true,cookies,{supplierCountry:de.supplierCountry()})
                if(de.supplierLegalEntity().length > 0){
                    $.extend(true,cookies,{supplierLegalentity:de.supplierLegalEntity()})
                }
                if(de.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:de.supplierCategory()})
                }
            }else{
                if(de.receivingLegalEntity().length > 0){
                    $.extend(true,cookies,{receiverLegalEntity:de.receivingLegalEntity()})
                }
                if(de.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:de.receivingCategory()})  
                }
            }
        }else if(value.hasOwnProperty('supplierCountry')){
            cookies = value;
            if(type == 'receiver' ){
                $.extend(true,cookies,{receiverCountry:de.receivingCountry()})
                if(de.receivingLegalEntity().length > 0){
                    $.extend(true,cookies,{receiverLegalEntity:de.receivingLegalEntity()})
                }
                if(de.receivingCategory().length > 0){
                    $.extend(true,cookies,{bussiness:de.receivingCategory()})  
                }
            }else{
                if(de.supplierLegalEntity().length > 0){
                    $.extend(true,cookies,{supplierLegalentity:de.supplierLegalEntity()})
                }
                if(de.supplierCategory().length > 0){
                    $.extend(true,cookies,{bussiness:de.supplierCategory()})
                }
            }
        }
        $.extend(true,cookies,{supplierType:'FMI_TPS'});
      
        dashboard.createNewCookie(cookies);
        redirectUrl("/ociranalysis/default")
    }
};

de.receivingPrepareMap = function(){
    $('#map-ex-receiving').remove();
    $(".panelMap-ex").append("<div id='map-ex-receiving' class='map'> </div>");
};

de.supplierPrepareMap = function(){
   $('#map-ex-supplier').remove();
   $(".panelMap-exSupplier").append("<div id='map-ex-supplier' class='map'> </div>");
};

de.downloadReceivingDetails = function(){
    return function(){
        var grid = $("#grid-ex-receiver-detail").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard External Receiver Drilldown Details"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

de.downloadReceiving = function(){
    return function(){
        var grid = $("#popupExReceiver").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard External Receiver Drilldown"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

de.downloadSupplierDetails = function(){
    return function(){
        var grid = $("#grid-ex-supplier-detail").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard External Supplier Drilldown Details"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

de.downloadSupplier = function(){
    return function(){
        var grid = $("#popupExSupplier").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard External Supplier Drilldown"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

de.receivingSetHoverValue =  function(country,type){
    var param = {
        ReceivingCountry : de.receivingCountry(),
        LegalEntity : de.receivingLegalEntity(),
        Business : de.receivingCategory(),
        Productfunction : de.receivingProduct(),
        SupplierCountry : country,
        Flag  : type,
        Suppliertype : "TPS",
        SuppliertypeOption: de.receivingSupplierType(),
        Parentprocessname : de.receivingLevelProcess(),
        Processname : de.receivingLevel2Process(),
        Tab : "receiver"
    }

    var titleGrid;
    if (type == "suppliername"){
        titleGrid = "Vendors"
    } else if(type == "receivername"){
        titleGrid = "Receiver Name" 
    } else if(type == "functionname"){
        titleGrid = "Suppliers" 
    } else {
        titleGrid = " Level 1 Process"
    }

    de.headerModalReceiver(titleGrid);
    
    var url = "/receiverview/getdetailstooltipexternal"
      $("#popupExReceiver").html("");
      $("#popupExReceiver").kendoGrid({
         dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, param, function(datas){
                        option.success(datas); 
                        $('#dereceivermodal').modal('show');
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            // pageSize: 10,
            /*serverFiltering: true,*/
         },
         dataBound: function(){
            $('#popupExReceiver .k-grid-content').height(315);
        }, 
         columns: [{
            field:"_id",
            title:de.headerModalReceiver(),
            width:200,
            /*filterable: false,*/
            attributes: {
                "class": "field-ellipsis"
            }
        }],
        excel: {
            fileName: de.headerModalReceiver() + " External Receiver.xlsx",
            allPages: true
        },
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });
};

de.supplierSetHoverValue =  function(country,type){
    var param = {
        ReceivingCountry :  country,
        LegalEntity : de.supplierLegalEntity(),
        Business : de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        SupplierCountry : de.supplierCountry(),
        Flag  : type,
        Suppliertype : "TPS",
        SuppliertypeOption: de.supplierSupplierType(),
        Parentprocessname : de.supplierLevelProcess(),
        Processname : de.supplierLevel2Process(),
        Tab : "supplier"        
    }

    var titleGrid;
    if (type == "suppliername"){
        titleGrid = "Vendors"
    } else if(type == "receivername"){
        titleGrid = "Receiver Name" 
    } else if(type == "functionname"){
        titleGrid = "Suppliers" 
    } else {
        titleGrid = " Level 1 Process"
    }

    de.headerModalSupplier(titleGrid);
    
    var url = "/receiverview/getdetailstooltipexternal"
      $("#popupExSupplier").html("");
      $("#popupExSupplier").kendoGrid({
         dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, param, function(datas){
                        option.success(datas);
                        $('#desuppliermodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            /*serverFiltering: true,*/
            // pageSize: 10
         },
         dataBound: function(){
            $('#popupExSupplier .k-grid-content').height(315);
        },
         columns: [{
            field:"_id",
            title:de.headerModalSupplier(),
            width:200,
            /*filterable: false,*/
            attributes: {
                "class": "field-ellipsis"
            }
        }],
        excel: {
            fileName: dig.headerModalSupplier() + " External Supplier.xlsx",
            allPages: true
        },
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });
};

de.receivingDetailsModal = function(supplierCountry){
    var payload = {
        ReceivingCountry :  de.receivingCountry(),
        LegalEntity : de.receivingLegalEntity(),
        SupplierCountry : supplierCountry,
        Flag : "exsternal",
        Business : de.receivingCategory(),
        Productfunction : de.receivingProduct(),
        Suppliertype: de.receivingSupplierType(),
        Parentprocessname : de.receivingLevelProcess(),
        Processname : de.receivingLevel2Process(),
        Tab : "receiver",
    };
    var url = "/receiverview/getdetailsrowtooltip";
     
    $("#grid-ex-receiver-detail").html("");
    $("#grid-ex-receiver-detail").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#dereceiverdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {     

                   return JSON.stringify(data);                                 
                },
            },
            // pageSize: 10,
            /*serverFiltering: true,*/
            sort: [
                {field:"_id.suppliercountry",dir:"asc"},
                {field:"_id.legalcontractsignatory",dir:"asc"},
                {field:"_id.parentprocessname",dir:"asc"},
                {field:"_id.suppliername",dir:"asc"},
            ],
        },
        dataBound: function(){
            $('#grid-ex-receiver-detail .k-grid-content').height(315);
        }, 
        excel: {
            fileName: "Details Receiving External.xlsx",
            allPages: true
        },
        columns: [
            {
                field:"_id.receivercountry",
                title:"Receiver Country",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.receiverlegalentity",
                title:"Receiver Legal Entity",
                width:200,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.parentprocessname",
                title:"L1 Process Name",
                width:150,
                /*filterable: false,*/
                 headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.suppliername",
                title:"Vendor",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"

                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
             {
                field:"_id.contractid",
                title:"Contract ID",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            }
            // {
            //     field:"fte",
            //     title:"Contract ID (Contract_ID)",
            //     format:"{0:N1}",
            //     width:100,
            //     headerAttributes: {
            //         "class": "align-left"
            //     },
            //     filterable: false
            // }
        ],
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });
};
de.receivingSupplierDetailsModal = function(receivingCountry){
    var payload = {
        ReceivingCountry :  receivingCountry,
        LegalEntity : de.receivingLegalEntity(),
        SupplierCountry : "",
        Flag : "exsternal",
        Business : de.receivingCategory(),
        Productfunction : de.receivingProduct(),
        Suppliertype: de.receivingSupplierType(),
        Parentprocessname : de.receivingLevelProcess(),
        Processname : de.receivingLevel2Process(),
        Tab : "receiver",
    };
    var url = "/receiverview/getdetailsrowtooltip";
     
    $("#grid-ex-receiver-detail").html("");
    $("#grid-ex-receiver-detail").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#dereceiverdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {     

                   return JSON.stringify(data);                                 
                },
            },
            // pageSize: 10,
            /*serverFiltering: true,*/
            sort: [
                {field:"_id.suppliercountry",dir:"asc"},
                {field:"_id.legalcontractsignatory",dir:"asc"},
                {field:"_id.parentprocessname",dir:"asc"},
                {field:"_id.suppliername",dir:"asc"},
            ],
        },
        dataBound: function(){
            $('#grid-ex-receiver-detail .k-grid-content').height(315);
        }, 
        excel: {
            fileName: "Details Receiving External.xlsx",
            allPages: true
        },
        columns: [
            {
                field:"_id.suppliercountry",
                title:"Supplier Country",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.legalcontractsignatory",
                title:"Legal Contract Signatory",
                width:200,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.parentprocessname",
                title:"L1 Process Name",
                width:150,
                /*filterable: false,*/
                 headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.suppliername",
                title:"Vendor",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"

                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
             {
                field:"_id.contractid",
                title:"Contract ID",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            }
            // {
            //     field:"fte",
            //     title:"Contract ID (Contract_ID)",
            //     format:"{0:N1}",
            //     width:100,
            //     headerAttributes: {
            //         "class": "align-left"
            //     },
            //     filterable: false
            // }
        ],
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });
};

de.SupplierDetailsModal = function(receivingCountry){
    var payload = {
        ReceivingCountry :  receivingCountry,
        LegalEntity : de.supplierLegalEntity(),
        SupplierCountry : de.supplierCountry(),
        Flag : "exsternal",
        Business : de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        Suppliertype: de.supplierSupplierType(),
        Parentprocessname : de.supplierLevelProcess(),
        Processname : de.supplierLevel2Process(),
        Tab : "supplier",
    };
    
    var url = "/receiverview/getdetailsrowtooltip";
    
    $("#grid-ex-supplier-detail").html("");
    $("#grid-ex-supplier-detail").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#desupplierdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            // pageSize: 10,
            /*serverFiltering: true,*/
            sort: [
                {field:"_id.receivercountry",dir:"asc"},
                {field:"_id.receiverlegalentity",dir:"asc"},
                {field:"_id.parentprocessname",dir:"asc"},
                {field:"_id.suppliername",dir:"asc"},
            ],
        },
        dataBound: function(){
            $('#grid-ex-supplier-detail .k-grid-content').height(315);
        }, 
        excel: {
            fileName: "Details Supplier External.xlsx",
            allPages: true
        },
          columns: [
            {
                field:"_id.suppliercountry",
                title:"Supplier Country",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.legalcontractsignatory",
                title:"Legal Contract Signatory",
                width:200,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.parentprocessname",
                title:"L1 Process Name",
                width:150,
                /*filterable: false,*/
                 headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.suppliername",
                title:"Vendor",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
             {
                field:"_id.contractid",
                title:"Contract ID",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            }
            // {
            //     field:"fte",
            //     title:"Contract ID (Contract_ID)",
            //     format:"{0:N1}",
            //     width:100,
            //     headerAttributes: {
            //         "class": "align-left"
            //     },
            //     filterable: false
            // }
        ],
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });    
};
de.SupplierReceivingDetailsModal = function(supplierCountry){
    var payload = {
        ReceivingCountry :  "",
        LegalEntity : de.supplierLegalEntity(),
        SupplierCountry : supplierCountry,
        Flag : "exsternal",
        Business : de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        Suppliertype: de.supplierSupplierType(),
        Parentprocessname : de.supplierLevelProcess(),
        Processname : de.supplierLevel2Process(),
        Tab : "supplier",
    };
    
    var url = "/receiverview/getdetailsrowtooltip";
    
    $("#grid-ex-supplier-detail").html("");
    $("#grid-ex-supplier-detail").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#desupplierdetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            // pageSize: 10,
            /*serverFiltering: true,*/
            sort: [
                {field:"_id.receivercountry",dir:"asc"},
                {field:"_id.receiverlegalentity",dir:"asc"},
                {field:"_id.parentprocessname",dir:"asc"},
                {field:"_id.suppliername",dir:"asc"},
            ],
        },
        dataBound: function(){
            $('#grid-ex-supplier-detail .k-grid-content').height(315);
        }, 
        excel: {
            fileName: "Details Supplier External.xlsx",
            allPages: true
        },
          columns: [
            {
                field:"_id.receivercountry",
                title:"Receiver Country",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.receiverlegalentity",
                title:"Receiver Legal Entity",
                width:200,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.parentprocessname",
                title:"L1 Process Name",
                width:150,
                /*filterable: false,*/
                 headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.suppliername",
                title:"Vendor",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
             {
                field:"_id.contractid",
                title:"Contract ID",
                width:150,
                /*filterable: false,*/
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            }
            // {
            //     field:"fte",
            //     title:"Contract ID (Contract_ID)",
            //     format:"{0:N1}",
            //     width:100,
            //     headerAttributes: {
            //         "class": "align-left"
            //     },
            //     filterable: false
            // }
        ],
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });    
};

de.receivingMapDetails = function(dataSource){
    de.receivingPrepareMap();
    setTimeout(function(){
        var dSource = dataSource.BubbleSupplier.features;
        var fromlatLng = [dataSource.BoxInfo.Longitude,dataSource.BoxInfo.Latitude];
        var boxLabel = dataSource.BoxInfo
        var receivingCountry = dig.receivingCountry().replace("'", "&#39;");
        
        
       
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});

         
        var map = L.map('map-ex-receiving', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
                zoomControl: false,
        }) 
          L.control.zoom({
             position:'topright'
        }).addTo(map);
  
        var path = []
        var allSupplier = {"Suppliers": 0,"Vendors":0,"LevelOne":0}; 
        for(var i in dSource){
            data = dSource[i]
            if(fromlatLng[1] === dSource[i].geometry.coordinates[1] && fromlatLng[0] === dSource[i].geometry.coordinates[0]){
                allSupplier = {"Suppliers": data.properties.Suppliers ,"Vendors":data.properties.Vendors,"LevelOne":data.properties.LevelOne};
            }
            if(fromlatLng[1] !== dSource[i].geometry.coordinates[1] && fromlatLng[0] !== dSource[i].geometry.coordinates[0] ){      
            if(dSource[i].properties.count <= 5){
                var icon = dashboard.mapGreyIcon;
            }else if(dSource[i].properties.count <= 20){
                var icon = dashboard.mapGreenIcon;
            }  else {
                var icon = dashboard.mapBlueIcon; 
            }
            
            var marker = L.marker([dSource[i].geometry.coordinates[1], dSource[i].geometry.coordinates[0]], {icon: icon}).addTo(map);

            var templatePopUp = [
                                 "<span style='color:#0644a0'>Supplier Country Data</span>",
                                "<a href='#supplier_"+data.properties.SecondaryID+"'><b>"+ data.properties.SecondaryID + "</b></a>",
                                "# of Vendors : <a onclick='de.receivingSetHoverValue(\""+data.properties.SecondaryID+"\",\"suppliername\")' href='#'>"+data.properties.SupplierNam+" </a>",
                                "# of Receivers :  <a onclick='de.receivingSetHoverValue(\""+data.properties.SecondaryID+"\",\"functionname\")' href='#'>"+data.properties.FunctionName+"  </a>",
                                // "Total FTE : "+ kendo.toString(e.layer.feature.properties['count'], 'N1'),
                                "# of Level 1 Processes :<a onclick='de.receivingSetHoverValue(\""+data.properties.SecondaryID+"\",\"Level1Process\")' href='#'> "+data.properties.LevelOne+"  </a>",   
                                "<a onclick='de.receivingDetailsModal(\""+data.properties.SecondaryID+"\")' href='#'>Details</a>"].join("<br>") 

            var templatePopUp = [
                        "<span style='color:#0644a0'>Supplier Country Data</span>",
                                "<a href='#supplier_"+data.properties.SecondaryID +"'><b>"+ data.properties.SecondaryID  + "</b></a>",
                                "# of Vendors : <a onclick='de.receivingSetHoverValue(\""+data.properties.SecondaryID +"\",\"suppliername\")' href='#'>"+ data.properties.Vendors   +" </a>",
                                "# of Receivers :  <a onclick='de.receivingSetHoverValue(\""+data.properties.SecondaryID +"\",\"functionname\")' href='#'>"+ data.properties.Suppliers +"  </a>",
                                // "Total FTE : "+ kendo.toString(e.layer.feature.properties['count'], 'N1'),
                                "# of Level 1 Processes :<a onclick='de.receivingSetHoverValue(\""+data.properties.SecondaryID +"\",\"Level1Process\")' href='#'> "+ data.properties.LevelOne +"  </a>",   
                                "<a onclick='de.receivingDetailsModal(\""+data.properties.SecondaryID +"\")' href='#'>Details</a>"].join("<br>")   
            marker.bindPopup(templatePopUp);
            marker.on('mouseover', function (e) {
                this.openPopup();
            });
            coordinatesProp = {latFrom:fromlatLng[1] ,latTo:dSource[i].geometry.coordinates[1] ,lngFrom:fromlatLng[0],lngTo:dSource[i].geometry.coordinates[0]}
            coordinate = dashboard.getLatLngCenter(coordinatesProp);
            path.push(L.curve(['M',[fromlatLng[1],fromlatLng[0] ],
                               'Q',[coordinate.latCenter,coordinate.lngCenter],
                                    [dSource[i].geometry.coordinates[1],dSource[i].geometry.coordinates[0]]],{weight: 2,color:'#3A91B9'}).addTo(map));
            }
        }  
        var templatePopUpReceivingCountry = [
                    "<a href='#supplier_"+de.receivingCountry()+"'><b>"+ de.receivingCountry()+ "</b></a><span style='color:#0644a0'> as Receiver</span>", 
                    "# of Vendors : <a onclick='de.receivingSetHoverValue(\"\",\"suppliername\")' href='#'> "+boxLabel.Vendors+"</a>",
                    "# of Supplier : <a onclick='de.receivingSetHoverValue(\"\",\"functionname\")' href='#'> "+boxLabel.Suppliers+"</a>",
                    // "Total FTE : "+  kendo.toString(boxLabel.FTE, 'N1'),
                    "# of Level 1 Processes: <a onclick='de.receivingSetHoverValue(\"\",\"Level1Process\")' href='#'> "+boxLabel.LevelOne+"</a>",
                    "<a onclick='de.receivingSupplierDetailsModal(\""+de.receivingCountry()+"\")' href='#'>Details</a></br>",

                    "<a href='#supplier_"+de.receivingCountry()+"'><b>"+ de.receivingCountry()+ "</b></a><span style='color:#0644a0'> as Supplier</span>",
                    "# of Vendors : <a onclick='de.receivingSetHoverValue(\""+de.receivingCountry()+"\",\"suppliername\")' href='#'> "+allSupplier.Vendors+" </a>",
                    "# of Receiver : <a onclick='de.receivingSetHoverValue(\""+de.receivingCountry()+"\",\"functionname\")' href='#'> "+allSupplier.Suppliers+" </a>",
                    "# of Level 1 Processes : <a onclick='de.receivingSetHoverValue(\""+de.receivingCountry()+"\",\"Level1Process\")' href='#'> "+allSupplier.LevelOne+" </a>", 
                    "<a onclick='de.receivingDetailsModal(\""+de.receivingCountry()+"\")' href='#'>Details</a></br>"
                    ].join("<br>")  
        defMarker = L.marker([fromlatLng[1], fromlatLng[0]], {icon: dashboard.receiverIcon}).addTo(map)
            .bindPopup(templatePopUpReceivingCountry).openPopup();
        defMarker.on('mouseover', function (e) {
                this.openPopup();
        });
    },100);  
};

de.supplierMapDetails = function(dataSource){
    de.supplierPrepareMap();
    setTimeout(function(){
        var dSource = dataSource.BubbleSupplier.features;
        var fromlatLng = [dataSource.BoxInfo.Longitude,dataSource.BoxInfo.Latitude];
        var boxLabel = dataSource.BoxInfo
        var supplierCountry = de.supplierCountry().replace("'", "&#39;");
        var allSupplier = {"Suppliers": 0,"Vendors":0,"LevelOne":0}; 

        var grayscale   = L.tileLayer(dashboard.mapBoxUrl , {id: 'mapbox.light', attribution: dashboard.mapBoxAttr ,minZoom: 2});
     
        var map = L.map('map-ex-supplier', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
                zoomControl: false,
        }) 
        
        L.control.zoom({
             position:'topright'
        }).addTo(map);
       
        var path = []
        for(var i in dSource){
            data = dSource[i]
            if(fromlatLng[1] === dSource[i].geometry.coordinates[1] && fromlatLng[0] === dSource[i].geometry.coordinates[0]){
                 allSupplier = {"Suppliers": data.properties.Suppliers ,"Vendors":data.properties.Vendors,"LevelOne":data.properties.LevelOne};
            }
            if(fromlatLng[1] !== dSource[i].geometry.coordinates[1] && fromlatLng[0] !== dSource[i].geometry.coordinates[0] ){      
            if(dSource[i].properties.count <= 5){
                var icon = dashboard.mapGreyIcon ;
            }else if(dSource[i].properties.count <= 20){
                var icon = dashboard.mapGreenIcon;
            }  else {
                var icon = dashboard.mapBlueIcon; 
            }
            
            var marker = L.marker([dSource[i].geometry.coordinates[1], dSource[i].geometry.coordinates[0]], {icon: icon}).addTo(map);

            var templatePopUp = [
                            "<span style='color:#0644a0'>Receiver Country Data</span>",
                            "<a href='#receiver_"+data.properties.SecondaryID+"'><b>"+ data.properties.SecondaryID+ "</b></a>",
                            "# of Vendors: <a onclick='de.supplierSetHoverValue(\""+data.properties.SecondaryID+"\",\"suppliername\")' href='#'> "+data.properties.Vendors +"  </a>",
                            "# of Suppliers : <a onclick='de.supplierSetHoverValue(\""+data.properties.SecondaryID+"\",\"functionname\")' href='#'>"+data.properties.Suppliers+" </a>",
                             "# of Level 1 Processes : <a onclick='de.supplierSetHoverValue(\""+data.properties.SecondaryID+"\",\"Level1Process\")' href='#'> "+ data.properties.LevelOne +" </a>",
                            "<a onclick='de.SupplierDetailsModal(\""+data.properties.SecondaryID+"\")' href='#'>Details</a>"].join("<br>")

     
            marker.bindPopup(templatePopUp);
            marker.on('mouseover', function (e) {
                this.openPopup();
            });
            
            coordinatesProp = {latFrom:fromlatLng[1] ,latTo:dSource[i].geometry.coordinates[1] ,lngFrom:fromlatLng[0],lngTo:dSource[i].geometry.coordinates[0]}
            coordinate = dashboard.getLatLngCenter(coordinatesProp);
     
            path.push(L.curve(['M',[fromlatLng[1],fromlatLng[0] ],
                               'Q',[coordinate.latCenter,coordinate.lngCenter],
                                    [dSource[i].geometry.coordinates[1],dSource[i].geometry.coordinates[0]]],{weight: 2,color:'#3A91B9'}).addTo(map));
            }
        } 
        var templatePopUpReceivingCountry = [
                    "<a href='#receiver_"+de.supplierCountry()+"'><b>"+ de.supplierCountry() + "</b></a><span style='color:#0644a0'> as Supplier</span>",
                  
                    
                    "# of Vendors : <a onclick='de.supplierSetHoverValue(\"\",\"suppliername\")' href='#'> "+boxLabel.Vendors+"</a>",
                    "# of Receivers :<a onclick='de.supplierSetHoverValue(\"\",\"receivername\")' href='#'> "+boxLabel.Suppliers+"</a>",
                    // "Total FTE : "+  kendo.toString(boxLabel.FTE, 'N1'),
                    "# of Level 1 Processes : <a onclick='de.supplierSetHoverValue(\"\",\"Level1Process\")' href='#'>  "+boxLabel.LevelOne+"</a>",
                    "<a onclick='de.SupplierReceivingDetailsModal(\""+de.supplierCountry()+"\")' href='#'>Details</a></br>",
                    
                    "<a href='#receiver_"+de.supplierCountry()+"'><b>"+ de.supplierCountry() + "</b></a><span style='color:#0644a0'> as Receiver</span>",
                    "# of Vendors :<a onclick='de.supplierSetHoverValue(\""+supplierCountry+"\",\"suppliername\")' href='#'>"+allSupplier.Vendors+"</a>",
                    "# of Supplier : <a onclick='de.supplierSetHoverValue(\""+supplierCountry+"\",\"functionname\")' href='#'> "+allSupplier.Suppliers+"</a>",
                    "# of Level 1 Processes : <a onclick='de.supplierSetHoverValue(\""+supplierCountry+"\",\"Level1Process\")' href='#'> "+allSupplier.LevelOne+"</a> ",
                    "<a onclick='de.SupplierDetailsModal(\""+de.supplierCountry()+"\")' href='#'>Details</a></br>"
                    ].join("<br>") 
        defMarker = L.marker([fromlatLng[1], fromlatLng[0]], {icon: dashboard.supplierIcon}).addTo(map)
            .bindPopup(templatePopUpReceivingCountry).openPopup();
        defMarker.on('mouseover', function (e) {
                this.openPopup();
        }); 
    },100);  
};

de.receivingMap = function(dataSource){
    de.receivingPrepareMap()
    setTimeout(function(){
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl, {id: 'mapbox.light', attribution: dashboard.mapBoxAttr, minZoom: 2}); 
        var map = L.map('map-ex-receiving', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
            zoomControl: false,
        })
        L.control.zoom({
             position:'topright'
        }).addTo(map);
       
        var geoJson = dataSource.features;
        $.each(geoJson, function(i,v){
            if(v.properties.count <= 5){
                var icon =  dashboard.mapGreyIcon;
            }else if(v.properties.count <= 20){
                var icon =  dashboard.mapGreenIcon;
            }  else {
                var icon =  dashboard.mapBlueIcon; 
            }
            var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}).addTo(map);
            marker.Country = v.properties.SecondaryID
            marker.on('click', function(e){ 
                de.receivingCountry(e.target.Country);
                de.receivingGetData();
            });
        })
    },100);   
};

de.supplierMap = function(dataSource){
    de.supplierPrepareMap()
    setTimeout(function(){
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl, {id: 'mapbox.light', attribution: dashboard.mapBoxAttr, minZoom: 2});
        var map = L.map('map-ex-supplier', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
            zoomControl: false,
        })
        L.control.zoom({
             position:'topright'
        }).addTo(map);
       
        var geoJson = dataSource.features;
        $.each(geoJson, function(i,v){
            if(v.properties.count <= 5){
                var icon = dashboard.mapGreyIcon;
            }else if(v.properties.count <= 20){
                var icon = dashboard.mapGreenIcon;
            }  else {
                var icon = dashboard.mapBlueIcon; 
            }
            var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}).addTo(map);
            marker.Country = v.properties.SecondaryID
            marker.on('click', function(e){ 
                de.supplierCountry(e.target.Country);
                de.suppliergGetData();
            });
        })
    },100);      
};

de.configSeries = function(indexClass, indeexData, selectorId){
    var color = ["#00506D","#0077A3","#50D0FF","#8ADFFF"]
    var visibleData   = $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data[indeexData].visible
    $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data[indeexData].visible = !visibleData
    $("#"+selectorId+"_"+indexClass).getKendoChart().redraw();
    var datas = $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data
    color = (!visibleData)?color[indeexData]: '#9b9898';
    $("#legend-"+selectorId +"_"+indexClass).find("li").eq(indeexData).find(".square").css('background',color)
    var totalDataTrue = 0 
    $.each(datas, function(i, val){            
        if(val.visible == true){
            totalDataTrue += val.value
        } 
    })

    $.each(datas, function(i, val){            
        var percentage = 100 / (totalDataTrue / val.value) 
        if(val.visible == true){ 
            $("#legend-donut-"+selectorId+"-precentage_"+ indexClass +"_"+i).text(String(percentage.toFixed(0)) +"%")
        }else{
            $("#legend-donut-"+selectorId+"-precentage_"+ indexClass +"_"+i).text("")
        }
    }) 
};

de.sortData = function(dataSource){ 
    $.each(dataSource,function(index,value){
        for(var i=0; i<(dataSource.length-1); i++){
            if(dataSource[i].Country.toLowerCase() > dataSource[i+1].Country.toLowerCase()){
                var old = dataSource[i+1];
                dataSource[i+1] = dataSource[i]
                dataSource[i] = old
            }
        }
    }) 
    return dataSource
};

de.downloadPopUpDonut = function(){
    return function(){
        var grid = $("#grid-popup-external-donut").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard External Receiver Drilldown Donut"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

de.downloadPopUpDonutSupplier = function(){
    return function(){
        var grid = $("#grid-popup-external-donut-supplier").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard External Supplier Drilldown Donut"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
};

de.popUpDonut =  function(payload){
    $("#grid-popup-external-donut").html("");
    $("#grid-popup-external-donut").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost("/receiverview/getpopupdonut", payload, function(datas){
                        option.success(datas); 
                        $('#modal-external-donut').modal('show');
                        setTimeout(function() {
                          $("#grid-popup-external-donut").data("kendoGrid").resize();  
                        }, 500);
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            // pageSize: 10,
            /*serverFiltering: true,*/
            sort: [
                {field:"receivercountry",dir:"asc"},
                {field:"suppliercountry",dir:"asc"},
                {field:"categoryname_",dir:"asc"},
                {field:"productfunction",dir:"asc"},
                {field:"parentprocessname",dir:"asc"},
                {field:"processname",dir:"asc"},
                {field:"servicedescription",dir:"asc"},
                {field:"barriertype",dir:"asc"},
            ],
        },
        columns: [
                // {
                //     field:"_id.servicerefid",
                //     title:'Service Ref Id',
                //     /*filterable: false,*/
                //     width:250,
                //     headerAttributes: {
                //       "class": "align-left"
                //     }
                // },
                {
                    field:"receivercountry",
                    title:'Receiver Country',
                    // /*filterable: false,*/
                    width:180,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    },
                    template: "#= receivercountry + ' - ' + receiverlegalentity #",
                },
                {
                    field:"suppliercountry",
                    title:'Supplier Country',
                    // /*filterable: false,*/
                    width:180,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    },
                    template: "#= suppliercountry + ' - ' + legalcontractsignatory #",    
                },
                {
                    field:"categoryname_",
                    title:'Business',
                    // /*filterable: false,*/
                    width:130,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                {
                    field:"productfunction",
                    title:'Product',
                    // /*filterable: false,*/
                    width:130,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                {
                    field:"parentprocessname",
                    title:'Level 1 Process',
                    // /*filterable: false,*/
                    width:250,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                {
                    field:"processname",
                    title:'Level 2 Process',
                    // /*filterable: false,*/
                    width:250,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                {
                    field:"servicedescription",
                    title:'Service Description',
                    // /*filterable: false,*/
                    width:250,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                {
                    field:"barriertype",
                    title:'Barrier Type',
                    // /*filterable: false,*/
                    width:130,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                
        ],
        excel: {
            fileName: "PopUpExternalDonut.xlsx",
            allPages: true
        },
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });
};

de.popUpDonutSupplier =  function(payload){
    $("#grid-popup-external-donut-supplier").html("");
    $("#grid-popup-external-donut-supplier").kendoGrid({
        dataSource: {
            transport: {
                read:function(option){
                    ajaxPost("/receiverview/getpopupdonut", payload, function(datas){
                        option.success(datas);
                        $('#modal-external-donut-supplier').modal('show');
                        setTimeout(function() {
                            $("#grid-popup-external-donut-supplier").data("kendoGrid").resize();  
                        }, 500);
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            // pageSize: 10,
            /*serverFiltering: true,*/
            sort: [
                {field:"receivercountry",dir:"asc"},
                {field:"suppliercountry",dir:"asc"},
                {field:"categoryname_",dir:"asc"},
                {field:"productfunction",dir:"asc"},
                {field:"parentprocessname",dir:"asc"},
                {field:"processname",dir:"asc"},
                {field:"servicedescription",dir:"asc"},
                {field:"barriertype",dir:"asc"},
            ],
        },
        columns: [
            {
                field:"receivercountry",
                title:'Receiver Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= receivercountry + ' - ' + receiverlegalentity #",
            },
            {
                field:"suppliercountry",
                title:'Supplier Country',
                /*filterable: false,*/
                width:180,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                },
                template: "#= suppliercountry + ' - ' + legalcontractsignatory #",    
            },
            {
                field:"categoryname_",
                title:'Business',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"productfunction",
                title:'Product',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"parentprocessname",
                title:'Level 1 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"processname",
                title:'Level 2 Process',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"servicedescription",
                title:'Service Description',
                /*filterable: false,*/
                width:250,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            },
            {
                field:"barriertype",
                title:'Barrier Type',
                /*filterable: false,*/
                width:130,
                attributes: {
                    "class": "field-ellipsis"
                },
                headerAttributes: {
                    "class": "align-left"
                }
            }
        ],
        excel: {
            fileName: "PopUpExternalDonut.xlsx",
            allPages: true
        },
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });
};

de.receivingCreateSummary =  function(payload){
    console.log("ajax");
    increaseIndexingAjx(de.indexingAjax.receiverSummary);
    payload.Index = de.indexingAjax.receiverSummary(); 
    ajaxPost("/receiverview/externalsummaryreceiver",payload, function (res){        
        if(res.Index != de.indexingAjax.receiverSummary())
            return;

        var receivers = [];
        var suppliers = [];

        $.each(res.Country, function(index,v){
            var data ={
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                SupplierName:kendo.toString(v.Vendors,"n0"),
                Contract:kendo.toString(v.Contracts,"n0"),
                DetailsDonut: v.DetailsDonut,
                TotalDonut: v.TotalDonut,
                Legal: [],
            };
            for(var i in v.DetailsLegal){
                data.Legal.push({
                    keyID:index+"-"+i,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    SupplierName:kendo.toString(v.DetailsLegal[i].Vendors,"n0"),
                    Contract:kendo.toString(v.DetailsLegal[i].Contracts,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal,
                });
            }
            receivers.push(data);
        });
        de.receivingReceiverSummary(receivers);
        dataSupplier = de.sortData(res.Supplier)
        $.each(dataSupplier, function(index,v){
            var data ={
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                SupplierName:kendo.toString(v.Vendors,"n0"),
                Contract:kendo.toString(v.Contracts,"n0"),
                DetailsDonut : v.DetailsDonut,
                Legal: [],
                TotalDonut: v.TotalDonut,
            };
            for(var i in v.DetailsLegal){

                data.Legal.push({
                    keyID:index+"-"+i,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    SupplierName:kendo.toString(v.DetailsLegal[i].Vendors,"n0"),
                    Contract:kendo.toString(v.DetailsLegal[i].Contracts,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal,
                });
            }
            suppliers.push(data);
        });
        de.receivingSupplierSummary(suppliers);
        var color = ["#00506D","#0077A3","#50D0FF","#8ADFFF"]

        $.each(receivers, function(i,v){
            var dataReceiver = []
            $.each(v.DetailsDonut, function(index,value){
                dataReceiver.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'NoContract':
                    var dataItem = 'No Contract'
                break;
                case'NoCritical':
                    var dataItem = 'Contract NC'
                break;
                case'ReadyRes':
                    var dataItem = 'Contract RR'
                break;
                default:
                    var dataItem = 'Contract NRR'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
               
                $("#legend-de_receiver_"+i+" ul").append("<li><a onClick='de.configSeries("+i+","+index+",\"de_receiver\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-de_receiver-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-de_receiver-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
             receiverClick = function(e){
                switch(e.category){
                case'NoContract':
                    var dataItem = 'No Contract'
                break;
                case'NoCritical':
                    var dataItem = 'Contract NC'
                break;
                case'ReadyRes':
                    var dataItem = 'Contract RR'
                break;
                default:
                    var dataItem = 'Contract NRR'
                } 
                var payload = {
                    Business : de.receivingCategory(),
                    Productfunction : de.receivingProduct(),
                    Country : v.Country,
                    FilterCountry : de.receivingCountry(),
                    FilterLegal : de.receivingLegalEntity(),
                    Suppliertype: de.receivingSupplierType(),
                    Parentprocessname : de.receivingLevelProcess(),
                    Processname : de.receivingLevel2Process(),
                    Flag : "receiver",
                    LegalEntity : [],
                    Posisi: "receiverview",
                    Tab : "external",
                    Type: dataItem,
                }; 
                de.popUpDonut(payload)
            }
            var configDonut = ko.mapping.toJS(de.configDonut);
            configDonut.series[0].data = dataReceiver;
            configDonut.seriesClick = receiverClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='NoContract'){# #: 'No Contract' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='NoCritical'){# #: 'Contract NC' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='ReadyRes'){# #: 'Contract RR' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#  # #}else if(dataItem.category==='NoReady'){# #: 'Contract NRR'   # &nbsp;&nbsp;# # #}#   #= removeSpace(kendo.toString(percentage,'P0'))#",
           
            $("#de_receiver_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dateLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dateLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    switch(data.category){
                    case'NoContract':
                        var dataItem = 'No Contract'
                    break;
                    case'NoCritical':
                        var dataItem = 'Contract NC'
                    break;
                    case'ReadyRes':
                        var dataItem = 'Contract RR'
                    break;
                    default:
                        var dataItem = 'Contract NRR'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0;   
                    $("#legend-de_receiver-entity_"+value.keyID+" ul").append("<li><a onClick='de.configSeries(\""+value.keyID+"\","+number+",\"de_receiver-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-de_receiver-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-de_receiver-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                receiverEntityClick = function(e){
                    var legalEntity  = value.CountryLegal.split("~")[0];
                    legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    Country = Country.trim()
                    switch(e.category){
                    case'NoContract':
                        var dataItem = 'No Contract'
                    break;
                    case'NoCritical':
                        var dataItem = 'Contract NC'
                    break;
                    case'ReadyRes':
                        var dataItem = 'Contract RR'
                    break;
                    default:
                        var dataItem = 'Contract NRR'
                    } 
                    var payload = {
                        Business : de.receivingCategory(),
                        Productfunction : de.receivingProduct(),
                        Country : Country,
                        FilterCountry : de.receivingCountry(),
                        FilterLegal : de.receivingLegalEntity(),
                        Suppliertype: de.receivingSupplierType(),
                        Parentprocessname : de.receivingLevelProcess(),
                        Processname : de.receivingLevel2Process(),
                        Flag : "receiver",
                        LegalEntity : [legalEntity],
                        Posisi: "receiverview",
                        Tab : "external",
                        Type: dataItem,
                    };
                    
                    de.popUpDonut(payload)
                }
                var configDetailsDonut = ko.mapping.toJS(de.configDonut);
                configDetailsDonut.series[0].data = dateLegal;
                configDetailsDonut.seriesClick = receiverEntityClick;
                configDonut.legend.labels.template = "#if(dataItem.category=='NoContract'){# #: 'No Contract' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='NoCritical'){# #: 'Contract NC' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='ReadyRes'){# #: 'Contract RR' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#  # #}else if(dataItem.category==='NoReady'){# #: 'Contract NRR'   # &nbsp;&nbsp;# # #}#   #= removeSpace(kendo.toString(percentage,'P0'))#",
                $("#de_receiver-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        })
        $.each(suppliers, function(i,v){
            var dataSuplier = []
            $.each(v.DetailsDonut, function(index,value){
                dataSuplier.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'NoContract':
                    var dataItem = 'No Contract'
                break;
                case'NoCritical':
                    var dataItem = 'Contract NC'
                break;
                case'ReadyRes':
                    var dataItem = 'Contract RR'
                break;
                default:
                    var dataItem = 'Contract NRR'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                $("#legend-de_supplier_"+i+" ul").append("<li><a onClick='de.configSeries("+i+","+index+",\"de_supplier\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-de_supplier-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-de_supplier-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
            supplierClick = function(e){
                switch(e.category){
                case'NoContract':
                    var dataItem = 'No Contract'
                break;
                case'NoCritical':
                    var dataItem = 'Contract NC'
                break;
                case'ReadyRes':
                    var dataItem = 'Contract RR'
                break;
                default:
                    var dataItem = 'Contract NRR'
                } 
                var payload = {
                    Business : de.receivingCategory(),
                    Productfunction : de.receivingProduct(),
                    Country : v.Country,
                    FilterCountry : de.receivingCountry(),
                    FilterLegal : de.receivingLegalEntity(),
                    Suppliertype: de.receivingSupplierType(),
                    Parentprocessname : de.receivingLevelProcess(),
                    Processname : de.receivingLevel2Process(),
                    Flag : "supplier",
                    LegalEntity : [],
                    Posisi: "receiverview",
                    Tab : "external",
                    Type: dataItem,
                }; 
                
                de.popUpDonut(payload)
            }
            var configDonut = ko.mapping.toJS(de.configDonut);
            configDonut.series[0].data = dataSuplier;
            configDonut.seriesClick = supplierClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='NoContract'){# #: 'No Contract' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='NoCritical'){# #: 'Contract NC' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='ReadyRes'){# #: 'Contract RR' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#  # #}else if(dataItem.category==='NoReady'){# #: 'Contract NRR'   # &nbsp;&nbsp;# # #}#   #= removeSpace(kendo.toString(percentage,'P0'))#",
            $("#de_supplier_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dataSupplierLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dataSupplierLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    switch(data.category){
                    case'NoContract':
                        var dataItem = 'No Contract'
                    break;
                    case'NoCritical':
                        var dataItem = 'Contract NC'
                    break;
                    case'ReadyRes':
                        var dataItem = 'Contract RR'
                    break;
                    default:
                        var dataItem = 'Contract NRR'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0;   
                   
                    $("#legend-de_supplier-entity_"+value.keyID+" ul").append("<li><a onClick='de.configSeries(\""+value.keyID+"\","+number+",\"de_supplier-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-de_supplier-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-de_supplier-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                supplierEntityClick = function(e){
            
                    var legalEntity  = value.CountryLegal.split("~")[0];
                    legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    Country = Country.trim()
                    switch(e.category){
                    case'NoContract':
                        var dataItem = 'No Contract'
                    break;
                    case'NoCritical':
                        var dataItem = 'Contract NC'
                    break;
                    case'ReadyRes':
                        var dataItem = 'Contract RR'
                    break;
                    default:
                        var dataItem = 'Contract NRR'
                    } 
                    var payload = {
                        Business : de.receivingCategory(),
                        Productfunction : de.receivingProduct(),
                        Country : Country,
                        FilterCountry : de.receivingCountry(),
                        FilterLegal : de.receivingLegalEntity(),
                        Suppliertype: de.receivingSupplierType(),
                        Parentprocessname : de.receivingLevelProcess(),
                        Processname : de.receivingLevel2Process(),
                        Flag : "supplier",
                        LegalEntity : [legalEntity],
                        Posisi: "receiverview",
                        Tab : "external",
                        Type: dataItem,
                    };
                    de.popUpDonut(payload)
                } 
                var configDetailsDonut = ko.mapping.toJS(de.configDonut);
                configDetailsDonut.seriesClick = supplierEntityClick;
                configDetailsDonut.series[0].data = dataSupplierLegal;
                configDetailsDonut.legend.labels.template ="#if(dataItem.category=='NoContract'){# #: 'No Contract' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='NoCritical'){# #: 'Contract NC' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='ReadyRes'){# #: 'Contract RR' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#  # #}else if(dataItem.category==='NoReady'){# #: 'Contract NRR'   # &nbsp;&nbsp;# # #}#   #= removeSpace(kendo.toString(percentage,'P0'))#",
                $("#de_supplier-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        })
    });
};

de.supplierCreateSummary =  function(payload){
    increaseIndexingAjx(de.indexingAjax.supplierSummary);
    payload.Index = de.indexingAjax.supplierSummary(); 
    ajaxPost("/receiverview/externalsummaryreceiver",payload, function (res){        
        if(res.Index != de.indexingAjax.supplierSummary())
            return;
        
        var receivers = [];
        var suppliers = [];

        $.each(res.Country, function(index,v){
            var data ={
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                SupplierName:kendo.toString(v.Vendors,"n0"),
                Contract:kendo.toString(v.Contracts,"n0"),
                DetailsDonut: v.DetailsDonut,
                TotalDonut: v.TotalDonut,
                Legal: [],
            };
            for(var i in v.DetailsLegal){
                data.Legal.push({
                    keyID:index+"-"+i,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    SupplierName:kendo.toString(v.DetailsLegal[i].Vendors,"n0"),
                    Contract:kendo.toString(v.DetailsLegal[i].Contracts,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal,
                });
            }
            receivers.push(data);
        });
        de.supplierReceiverSummary(receivers);
        dataSupplier = de.sortData(res.Supplier)
        $.each(dataSupplier, function(index,v){
            var data ={
                Country:v.Country,
                LegalEntity:kendo.toString(v.LegalEntity,"n0"),
                CEF:kendo.toString(v.CEF,"n0"),
                Level1Process:kendo.toString(v.Level1Process,"n0"),
                CriticalService:kendo.toString(v.CriticalService,"n0"),
                SupplierName:kendo.toString(v.Vendors,"n0"),
                Contract:kendo.toString(v.Contracts,"n0"),
                DetailsDonut : v.DetailsDonut,
                Legal: [],
                TotalDonut: v.TotalDonut,
            };
            for(var i in v.DetailsLegal){

                data.Legal.push({
                    keyID:index+"-"+i,
                    CountryLegal:v.DetailsLegal[i].CountryLegal,
                    CEF:kendo.toString(v.DetailsLegal[i].CEF,"n0"),
                    Level1Process:kendo.toString(v.DetailsLegal[i].Level1Process,"n0"),
                    CriticalService:kendo.toString(v.DetailsLegal[i].CriticalService,"n0"),
                    SupplierName:kendo.toString(v.DetailsLegal[i].Vendors,"n0"),
                    Contract:kendo.toString(v.DetailsLegal[i].Contracts,"n0"),
                    DetailsDonut : v.DetailsLegal[i].DetailsDonut,
                    TotalDonutLegal: v.DetailsLegal[i].TotalDonutLegal,
                });
            }
            suppliers.push(data);
        });
        de.supplierSupplierSummary(suppliers);
        var color = ["#00506D","#0077A3","#50D0FF","#8ADFFF"] 
        $.each(receivers, function(i,v){
            var dataReceiver = []
            $.each(v.DetailsDonut, function(index,value){
                dataReceiver.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'NoContract':
                    var dataItem = 'No Contract'
                break;
                case'NoCritical':
                    var dataItem = 'Contract NC'
                break;
                case'ReadyRes':
                    var dataItem = 'Contract RR'
                break;
                default:
                    var dataItem = 'Contract NRR'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
               
                $("#legend-de_supreceiver_"+i+" ul").append("<li><a onClick='de.configSeries("+i+","+index+",\"de_supreceiver\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-de_supreceiver-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-de_supreceiver-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
             receiverClick = function(e){
                switch(e.category){
                case'NoContract':
                    var dataItem = 'No Contract'
                break;
                case'NoCritical':
                    var dataItem = 'Contract NC'
                break;
                case'ReadyRes':
                    var dataItem = 'Contract RR'
                break;
                default:
                    var dataItem = 'Contract NRR'
                } 
                var payload = {
                    Business : de.supplierCategory(),
                    Productfunction : de.supplierProduct(),
                    Country : v.Country,
                    FilterCountry : de.supplierCountry(),
                    FilterLegal : de.supplierLegalEntity(),
                    Suppliertype: de.supplierSupplierType(),
                    Parentprocessname : de.supplierLevelProcess(),
                    Processname : de.supplierLevel2Process(),
                    Flag : "receiver",
                    LegalEntity : [],
                    Posisi: "supplierview",
                    Tab : "external",
                    Type: dataItem,
                }; 
                de.popUpDonutSupplier(payload)
            }
            var configDonut = ko.mapping.toJS(de.configDonut);
            configDonut.series[0].data = dataReceiver;
            configDonut.seriesClick = receiverClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='NoContract'){# #: 'No Contract' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='NoCritical'){# #: 'Contract NC' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='ReadyRes'){# #: 'Contract RR' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#  # #}else if(dataItem.category==='NoReady'){# #: 'Contract NRR'   # &nbsp;&nbsp;# # #}#   #= removeSpace(kendo.toString(percentage,'P0'))#",
            $("#de_supreceiver_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dateLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dateLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    switch(data.category){
                    case'NoContract':
                        var dataItem = 'No Contract'
                    break;
                    case'NoCritical':
                        var dataItem = 'Contract NC'
                    break;
                    case'ReadyRes':
                        var dataItem = 'Contract RR'
                    break;
                    default:
                        var dataItem = 'Contract NRR'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0;   
                    $("#legend-de_supreceiver-entity_"+value.keyID+" ul").append("<li><a onClick='de.configSeries(\""+value.keyID+"\","+number+",\"de_supreceiver-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-de_supreceiver-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-de_supreceiver-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                receiverEntityClick = function(e){
                    var legalEntity  = value.CountryLegal.split("~")[0];
                    legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    Country = Country.trim()
                    switch(e.category){
                    case'NoContract':
                        var dataItem = 'No Contract'
                    break;
                    case'NoCritical':
                        var dataItem = 'Contract NC'
                    break;
                    case'ReadyRes':
                        var dataItem = 'Contract RR'
                    break;
                    default:
                        var dataItem = 'Contract NRR'
                    } 
                    var payload = {
                        Business : de.supplierCategory(),
                        Productfunction : de.supplierProduct(),
                        Country : Country,
                        FilterCountry : de.supplierCountry(),
                        FilterLegal : de.supplierLegalEntity(),
                        Suppliertype: de.supplierSupplierType(),
                        Parentprocessname : de.supplierLevelProcess(),
                        Processname : de.supplierLevel2Process(),
                        Flag : "receiver",
                        LegalEntity : [legalEntity],
                        Posisi: "supplierview",
                        Tab : "external",
                        Type: dataItem,
                    };
                    
                    de.popUpDonutSupplier(payload)
                }
                var configDetailsDonut = ko.mapping.toJS(de.configDonut);
                configDetailsDonut.series[0].data = dateLegal;
                configDetailsDonut.seriesClick = receiverEntityClick;
                configDetailsDonut.legend.labels.template = "#if(dataItem.category=='NoContract'){# #: 'No Contract' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='NoCritical'){# #: 'Contract NC' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='ReadyRes'){# #: 'Contract RR' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#  # #}else if(dataItem.category==='NoReady'){# #: 'Contract NRR'   # &nbsp;&nbsp;# # #}#   #= removeSpace(kendo.toString(percentage,'P0'))#",
                $("#de_supreceiver-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        })
        $.each(suppliers, function(i,v){
            var dataSuplier = []
            $.each(v.DetailsDonut, function(index,value){
                dataSuplier.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
                switch(value.category){
                case'NoContract':
                    var dataItem = 'No Contract'
                break;
                case'NoCritical':
                    var dataItem = 'Contract NC'
                break;
                case'ReadyRes':
                    var dataItem = 'Contract RR'
                break;
                default:
                    var dataItem = 'Contract NRR'
                } 
                var percentage = (Math.abs(value.value) != 0) ? 100 / (v.TotalDonut / value.value) : 0; 
                $("#legend-de_supsupplier_"+i+" ul").append("<li><a onClick='de.configSeries("+i+","+index+",\"de_supsupplier\")'><div class='square' style='background:"+color[index]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-de_supsupplier-precentage_"+ i +"_"+index+"'></span></a></li>") 
                $("#legend-donut-de_supsupplier-precentage_"+ i +"_"+index).text(percentage.toFixed(0)+"%")
            })
            supplierClick = function(e){
                switch(e.category){
                case'NoContract':
                    var dataItem = 'No Contract'
                break;
                case'NoCritical':
                    var dataItem = 'Contract NC'
                break;
                case'ReadyRes':
                    var dataItem = 'Contract RR'
                break;
                default:
                    var dataItem = 'Contract NRR'
                } 
                var payload = {
                    Business : de.supplierCategory(),
                    Productfunction : de.supplierProduct(),
                    Country : v.Country,
                    FilterCountry : de.supplierCountry(),
                    FilterLegal : de.supplierLegalEntity(),
                    Suppliertype: de.supplierSupplierType(),
                    Parentprocessname : de.supplierLevelProcess(),
                    Processname : de.supplierLevel2Process(),
                    Flag : "supplier",
                    LegalEntity : [],
                    Posisi: "supplierview",
                    Tab : "external",
                    Type: dataItem,
                }; 
                
                de.popUpDonutSupplier(payload)
            }
            var configDonut = ko.mapping.toJS(de.configDonut);
            configDonut.series[0].data = dataSuplier;
            configDonut.seriesClick = supplierClick;
            configDonut.legend.labels.template = "#if(dataItem.category=='NoContract'){# #: 'No Contract' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='NoCritical'){# #: 'Contract NC' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='ReadyRes'){# #: 'Contract RR' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#  # #}else if(dataItem.category==='NoReady'){# #: 'Contract NRR'   # &nbsp;&nbsp;# # #}#   #= removeSpace(kendo.toString(percentage,'P0'))#",
            $("#de_supsupplier_"+i).kendoChart(configDonut)
            $.each(v.Legal,function(index,value){
                var dataSupplierLegal = []
                $.each(value.DetailsDonut, function(number,data){
                    dataSupplierLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true})
                    switch(data.category){
                    case'NoContract':
                        var dataItem = 'No Contract'
                    break;
                    case'NoCritical':
                        var dataItem = 'Contract NC'
                    break;
                    case'ReadyRes':
                        var dataItem = 'Contract RR'
                    break;
                    default:
                        var dataItem = 'Contract NRR'
                    } 
                    var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0;   
                   
                    $("#legend-de_supsupplier-entity_"+value.keyID+" ul").append("<li><a onClick='dig.configSeries(\""+value.keyID+"\","+number+",\"de_supsupplier-entity\")'><div class='square' style='background:"+color[number]+"'></div>"+ dataItem+"<span style='float:right' id='legend-donut-de_supsupplier-entity-precentage_"+ value.keyID +"_"+number+"'></span></a></li>") 
                    $("#legend-donut-de_supsupplier-entity-precentage_"+ value.keyID +"_"+number).text(percentage.toFixed(0)+"%")
                })
                supplierEntityClick = function(e){
            
                    var legalEntity  = value.CountryLegal.split("~")[0];
                    legalEntity = legalEntity.trim()
                    var Country  = value.CountryLegal.split("~")[1];
                    Country = Country.trim()
                    switch(e.category){
                    case'NoContract':
                        var dataItem = 'No Contract'
                    break;
                    case'NoCritical':
                        var dataItem = 'Contract NC'
                    break;
                    case'ReadyRes':
                        var dataItem = 'Contract RR'
                    break;
                    default:
                        var dataItem = 'Contract NRR'
                    } 
                    var payload = {
                        Business : de.supplierCategory(),
                        Productfunction : de.supplierProduct(),
                        Country : Country,
                        FilterCountry : de.supplierCountry(),
                        FilterLegal : de.supplierLegalEntity(),
                        Suppliertype: de.supplierSupplierType(),
                        Parentprocessname : de.supplierLevelProcess(),
                        Processname : de.supplierLevel2Process(),
                        Flag : "supplier",
                        LegalEntity : [legalEntity],
                        Posisi: "supplierview",
                        Tab : "external",
                        Type: dataItem,
                    };
                    de.popUpDonutSupplier(payload)
                } 
                var configDetailsDonut = ko.mapping.toJS(de.configDonut);
                configDetailsDonut.seriesClick = supplierEntityClick;
                configDetailsDonut.series[0].data = dataSupplierLegal;
                configDetailsDonut.legend.labels.template ="#if(dataItem.category=='NoContract'){# #: 'No Contract' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='NoCritical'){# #: 'Contract NC' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else if(dataItem.category==='ReadyRes'){# #: 'Contract RR' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;#  # #}else if(dataItem.category==='NoReady'){# #: 'Contract NRR'   # &nbsp;&nbsp;# # #}#   #= removeSpace(kendo.toString(percentage,'P0'))#",
                $("#de_supsupplier-entity_"+value.keyID).kendoChart(configDetailsDonut)
            })
        })
    });
};

de.receivingGetData =  function(){
    if(de.receivingCountry() == ''){
        var payload={
            Business :  de.receivingCategory(),
            Productfunction : de.receivingProduct(),
            Flag: "TPS",
            Suppliertype: de.receivingSupplierType(),
            Parentprocessname : de.receivingLevelProcess(),
            Processname : de.receivingLevel2Process(),
            LegalEntity : de.receivingLegalEntity()
        }
        var url = "/receiverview/getdefaultreceiver";
        de.loadingMap.receiver(true);
        ajaxPost(url, payload , function (res){
            de.loadingMap.receiver(false);
            de.receivingMap(res)
        });
    }else{
        var payload={
            Business :  de.receivingCategory(),
            Productfunction : de.receivingProduct(),
            ReceivingCountry :  de.receivingCountry(),
            Suppliertype: de.receivingSupplierType(),
            Parentprocessname : de.receivingLevelProcess(),
            Processname : de.receivingLevel2Process(),
            LegalEntity : de.receivingLegalEntity(),
        }
       
        var url = "/receiverview/getdetailsreceiverexternal";
        de.loadingMap.receiver(true);
        ajaxPost(url, payload, function (res){
            de.loadingMap.receiver(false);
            de.receivingMapDetails(res)
        });
    }
    var payload = {
        ReceivingCountry :  de.receivingCountry(),
        LegalEntity : de.receivingLegalEntity(),
        Business : de.receivingCategory(),
        Productfunction : de.receivingProduct(),
        Suppliertype: de.receivingSupplierType(),
        Parentprocessname : de.receivingLevelProcess(),
        Processname : de.receivingLevel2Process(),
        Flag: "Receiver",
    }
    de.receivingCreateSummary(payload)
    localStorage.setItem('filter', JSON.stringify(payload));
};

de.suppliergGetData =  function(){
    if(de.supplierCountry() == ''){
        var payload={
            Business :  de.supplierCategory(),
            Productfunction : de.supplierProduct(),
            Flag: "TPS",
            Suppliertype: de.supplierSupplierType(),
            Parentprocessname : de.supplierLevelProcess(),
            Processname : de.supplierLevel2Process(),
            LegalEntity : de.supplierLegalEntity()
        }
        de.loadingMap.supplier(true);
        var url = "/supplierview/getdefaultsupplier";
        ajaxPost(url, payload, function (res){
            de.loadingMap.supplier(false);
            de.supplierMap(res)
        });
    }else{
        var payload={
            Business :  de.supplierCategory(),
            Productfunction : de.supplierProduct(),
            ReceivingCountry :  de.supplierCountry(),
            Suppliertype: de.supplierSupplierType(),
            Parentprocessname : de.supplierLevelProcess(),
            Processname : de.supplierLevel2Process(),
            LegalEntity : de.supplierLegalEntity(),
        }
        de.loadingMap.supplier(true);
        var url = "/supplierview/getdetailssupplierexternal";
        ajaxPost(url, payload, function (res){
           de.loadingMap.supplier(false);
           de.supplierMapDetails(res)
        });
    }
    var payload ={
        ReceivingCountry :  de.supplierCountry(),
        LegalEntity : de.supplierLegalEntity(),
        Business : de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        Suppliertype: de.supplierSupplierType(),
        Parentprocessname : de.supplierLevelProcess(),
        Processname : de.supplierLevel2Process(),
        Flag: "Supplier",
    } 
    de.supplierCreateSummary(payload)
    localStorage.setItem('filter', JSON.stringify(payload));
};

de.getReceivingCountry = function(){
    var payload = {
        LegalEntity : de.receivingLegalEntity(),
        Business :  de.receivingCategory(),
        Productfunction : de.receivingProduct(),
        Suppliertype: de.receivingSupplierType(),
        Parentprocessname : de.receivingLevelProcess(),
        Processname : de.receivingLevel2Process(),
        Flag : 'external'
    };
    var url = "/receiverview/getreceivercountry";
    ajaxPost(url,payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        de.receivingCountryList(receivingCountries);
    });
};

de.getSupplierCountry = function(){
    var payload = {
        Business :  de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        LegalEntity : de.supplierLegalEntity(),
        Suppliertype: de.supplierSupplierType(),
        Parentprocessname : de.supplierLevelProcess(),
        Processname : de.supplierLevel2Process(),
        Flag : 'external'
    };
    var url = "/supplierview/getsuppliercountry";
    ajaxPost(url,payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        de.supplierCountryList(receivingCountries);
    });
};

de.getReceivingLegalEntity = function(){
    var payload = {
        ReceivingCountry : de.receivingCountry(), 
        Business :  de.receivingCategory(),
        Productfunction : de.receivingProduct(),
        Suppliertype: de.receivingSupplierType(),
        Parentprocessname : de.receivingLevelProcess(),
        Processname : de.receivingLevel2Process(),
        Flag : 'external'
    };

    var url = "/receiverview/getlegalentityreceiverexternal";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        
        de.receivingLegalEntityList(legalEntities) 
    });
};

de.getSupplierLegalEntity = function(){
    var payload = {
        ReceivingCountry : de.supplierCountry(),
        Business :  de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        Suppliertype: de.supplierSupplierType(),
        Parentprocessname : de.supplierLevelProcess(),
        Processname : de.supplierLevel2Process(),
        Flag : 'external'
    };
    var url = "/supplierview/getlegalentitysupplierexternal";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        de.supplierLegalEntityList(legalEntities) 
    });
};

de.getReceivingCategory = function(){
    var payload = {
        ReceivingCountry : de.receivingCountry(), 
        LegalEntity : de.receivingLegalEntity(),
        Business :  de.receivingCategory(),
        Productfunction : de.receivingProduct(),
        Suppliertype: de.receivingSupplierType(),
        Parentprocessname : de.receivingLevelProcess(),
        Processname : de.receivingLevel2Process(),
        Flag : 'external'
    };
    var url = "/receiverview/getcategoryexternal";
    ajaxPost(url,payload, function (res){
        var receivingCategory = [];
        $.each(res, function(i,v){
            receivingCategory.push({text:v._id, value:v._id})
        });
        de.receivingCategoryList(receivingCategory);
    });
};

de.getSupplierCategory = function(){
    var payload = {
        ReceivingCountry : de.supplierCountry(),
        LegalEntity : de.supplierLegalEntity(),
        Business :  de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        Suppliertype: de.supplierSupplierType(),
        Parentprocessname : de.supplierLevelProcess(),
        Processname : de.supplierLevel2Process(),
        Flag : 'external'
    };
    var url = "/supplierview/getcategoryexternal";
    ajaxPost(url,payload, function (res){
        var supplierCategory = [];
        $.each(res, function(i,v){
            supplierCategory.push({text:v._id, value:v._id})
        });
        de.supplierCategoryList(supplierCategory);
    });
};

de.getReceivingProduct = function(){
    var payload = {
        ReceivingCountry : de.receivingCountry(), 
        LegalEntity : de.receivingLegalEntity(),
        Business :  de.receivingCategory(),
        Suppliertype: de.receivingSupplierType(),
        Parentprocessname : de.receivingLevelProcess(),
        Processname : de.receivingLevel2Process(),
        Flag : 'external'
    };
    var url = "/receiverview/getproductfunction";
    ajaxPost(url,payload, function (res){
        var receivingProduct = [];
        $.each(res, function(i,v){
            receivingProduct.push({text:v._id, value:v._id})
        });
        de.receivingProductList(receivingProduct);
    });
};

de.getSupplierProduct = function(){
    var payload = {
        ReceivingCountry : de.supplierCountry(),
        LegalEntity : de.supplierLegalEntity(),
        Business :  de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        Suppliertype: de.supplierSupplierType(),
        Parentprocessname : de.supplierLevelProcess(),
        Processname : de.supplierLevel2Process(),
        Flag : 'external'
    };
    var url = "/supplierview/getproductfunction";
    ajaxPost(url,payload, function (res){
        var supplierProduct = [];
        $.each(res, function(i,v){
            supplierProduct.push({text:v._id, value:v._id})
        });
        de.supplierProductList(supplierProduct);
    });
};

de.getReceivingLevelProcess = function(){
   var payload = {
        ReceivingCountry : de.receivingCountry(),
        LegalEntity : de.receivingLegalEntity(),
        Suppliertype: de.receivingSupplierType(),
        Business :  de.receivingCategory(),
        Productfunction : de.receivingProduct(),
        Processname : de.receivingLevel2Process(),
        Flag : 'external'
    };
    var url = "/receiverview/getparentprocessname";
    ajaxPost(url,payload, function (res){
        var levelProcess = [];
        $.each(res, function(i,v){
            levelProcess.push({text:v._id, value:v._id})
        });
        de.receivingLevelProcessList(levelProcess);
    });
};
de.getSupplierLevelProcess = function(){
    var payload = {
        ReceivingCountry : de.supplierCountry(),
        LegalEntity : de.supplierLegalEntity(),
        Suppliertype: de.supplierSupplierType(),
        Business :  de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        Processname : de.supplierLevel2Process(),
        Flag : 'external'
    };
    var url = "/supplierview/getparentprocessname";
    ajaxPost(url,payload, function (res){
        var levelProcess = [];
        $.each(res, function(i,v){
            levelProcess.push({text:v._id, value:v._id})
        });
        de.supplierLevelProcessList(levelProcess);
    });
};

de.getReceivingLevel2Process = function(){
    var payload = {
        ReceivingCountry : de.receivingCountry(),
        LegalEntity : de.receivingLegalEntity(),
        Suppliertype: de.receivingSupplierType(),
        Business :  de.receivingCategory(),
        Productfunction : de.receivingProduct(),
        Parentprocessname : de.receivingLevelProcess(),
        Flag : 'external'
    };
    var url = "/receiverview/getprocessname";
    ajaxPost(url,payload, function (res){
        var level2Process = [];
        $.each(res, function(i,v){
            level2Process.push({text:v._id, value:v._id})
        });
        de.receivingLevel2ProcessList(level2Process);
    });
};
de.getSupplierLevel2Process = function(){
    var payload = {
        ReceivingCountry : de.supplierCountry(),
        LegalEntity : de.supplierLegalEntity(),
        Suppliertype: de.supplierSupplierType(),
        Business :  de.supplierCategory(),
        Productfunction : de.supplierProduct(),
        Parentprocessname : de.supplierLevelProcess(),
        Flag : 'external'
    };
    var url = "/supplierview/getprocessname";
    ajaxPost(url,payload, function (res){
        var level2Process = [];
        $.each(res, function(i,v){
            level2Process.push({text:v._id, value:v._id})
        });
        de.supplierLevel2ProcessList(level2Process);
    });
};

de.receivingCountry.subscribe(function(newValue){
    de.onchangeReceivingCountry(false)
    
    if (de.receivingCountry() == '') {
        de.receivingLegalEntity([]);
        de.receivingCategory([]);
    };

    de.getReceivingLegalEntity();
    de.getReceivingCategory();
    de.getReceivingProduct();
    de.getReceivingLevelProcess();
    de.getReceivingLevel2Process();
    de.receivingGetData();
    dashboard.createNewCookie({receiverCountry:de.receivingCountry()}); 
    CNUtimeout = setTimeout(function(){
        de.onchangeReceivingCountry(true) 
    },1000);
});

de.supplierCountry.subscribe(function(newValue){
    de.onchangeSupplierCountry(false)

    if (de.supplierCountry() == '') {
        de.supplierLegalEntity([]);
        de.supplierCategory([]);
    };
    
    de.getSupplierLegalEntity();
    de.getSupplierCategory();
    de.getSupplierProduct();
    de.getSupplierLevelProcess();
    de.getSupplierLevel2Process();
    de.suppliergGetData();
    dashboard.createNewCookie({supplierCountry:de.supplierCountry()});
    CNUtimeout = setTimeout(function(){ 
        de.onchangeSupplierCountry(true)
    },1000);
});

de.receivingLegalEntity.subscribe(function(newValue){
    if(de.onchangeReceivingCountry() === true){
        dashboard.createNewCookie({receiverCountry:de.receivingCountry(),receiverLegalEntity:newValue.toString()}); 
        de.receivingGetData();
    }
    de.getReceivingCountry();
    de.getReceivingCategory();
    de.getReceivingProduct();
    de.getReceivingLevelProcess();
    de.getReceivingLevel2Process();
});

de.supplierLegalEntity.subscribe(function(newValue){
    if(de.onchangeSupplierCountry() === true){
        dashboard.createNewCookie({supplierCountry:de.supplierCountry(),supplierLegalentity:newValue.toString()}); 
        de.suppliergGetData();
    }
    de.getSupplierCountry();
    de.getSupplierCategory();
    de.getSupplierProduct();
    de.getSupplierLevelProcess();
    de.getSupplierLevel2Process();

});

de.receivingCategory.subscribe(function(newValue){
    if(de.onchangeReceivingCountry() === true){
        de.receivingGetData();
    }
    de.getReceivingCountry();
    de.getReceivingLegalEntity();
    de.getReceivingProduct();
    de.getReceivingLevelProcess();
    de.getReceivingLevel2Process();
});

de.supplierCategory.subscribe(function(newValue){
    if(de.onchangeSupplierCountry() === true){
        de.suppliergGetData();
    }
    de.getSupplierCountry();
    de.getSupplierLegalEntity();
    de.getSupplierProduct();
    de.getSupplierLevelProcess();
    de.getSupplierLevel2Process();
});

de.receivingSupplierType.subscribe(function(newValue){
    if(de.onchangeReceivingCountry() === true){
        de.receivingGetData();
    }
    de.getReceivingCountry();
    de.getReceivingLegalEntity();
    de.getReceivingCategory();
    de.getReceivingProduct();
    de.getReceivingLevelProcess();
    de.getReceivingLevel2Process();
});

de.supplierSupplierType.subscribe(function(newValue){
    if(de.onchangeSupplierCountry() === true){
        de.suppliergGetData();
    }
    de.getSupplierCountry();
    de.getSupplierLegalEntity();
    de.getSupplierCategory();
    de.getSupplierProduct();
    de.getSupplierLevelProcess();
    de.getSupplierLevel2Process();
});

de.receivingProduct.subscribe(function(newValue){
    if(de.onchangeReceivingCountry() === true){
        de.receivingGetData();
    }
    de.getReceivingCountry();
    de.getReceivingLegalEntity();
    de.getReceivingCategory();
    de.getReceivingLevelProcess();
    de.getReceivingLevel2Process();
});

de.supplierProduct.subscribe(function(newValue){
    if(de.onchangeSupplierCountry() === true){
        de.suppliergGetData();
    }
    de.getSupplierCountry();
    de.getSupplierLegalEntity();
    de.getSupplierCategory();
    de.getSupplierLevelProcess();
    de.getSupplierLevel2Process();
});

de.receivingLevelProcess.subscribe(function(newValue){
    if(de.onchangeReceivingCountry() === true){
        de.receivingGetData();
    }
    de.getReceivingCountry();
    de.getReceivingLegalEntity();
    de.getReceivingCategory();
    de.getReceivingProduct();
    de.getReceivingLevel2Process();
});

de.supplierLevelProcess.subscribe(function(newValue){
    if(de.onchangeSupplierCountry() === true){
        de.suppliergGetData();
    }
    de.getSupplierCountry();
    de.getSupplierLegalEntity();
    de.getSupplierCategory();
    de.getSupplierProduct();
    de.getSupplierLevel2Process();
});

de.receivingLevel2Process.subscribe(function(newValue){
    if(de.onchangeReceivingCountry() === true){
        de.receivingGetData();
    }
    de.getReceivingCountry();
    de.getReceivingLegalEntity();
    de.getReceivingCategory();
    de.getReceivingProduct();
    de.getReceivingLevelProcess();
});

de.supplierLevel2Process.subscribe(function(newValue){
    if(de.onchangeSupplierCountry() === true){
        de.suppliergGetData();
    }
    de.getSupplierCountry();
    de.getSupplierLegalEntity();
    de.getSupplierCategory();
    de.getSupplierProduct();
    de.getSupplierLevelProcess();
});

de.expand = function(type,index){
    return function(){
      var classUp = 'glyphicon-chevron-up'
      var classDown = 'glyphicon-chevron-down'
       $("#"+type+"-legal_"+index).slideToggle( "slow", function() {
            $("#"+type+"-expand-"+index).hasClass(classDown) ? $("#"+type+"-expand-"+index).addClass(classUp).removeClass(classDown): $("#"+type+"-expand-"+index).addClass(classDown).removeClass(classUp);
       });
    }
};

de.expandSupplier = function(type,index){
    return function(){
      var classUp = 'glyphicon-chevron-up'
      var classDown = 'glyphicon-chevron-down'
        $("#"+type+"-legalsup_"+index).slideToggle( "slow", function() {
            $("#"+type+"-expandsup-"+index).hasClass(classDown) ? $("#"+type+"-expandsup-"+index).addClass(classUp).removeClass(classDown): $("#"+type+"-expandsup-"+index).addClass(classDown).removeClass(classUp);
        });
    }
};

de.init = function(){ //initReceiving
    localStorage.setItem('tab', 'external');
    localStorage.setItem('subTab', 'de-receiver');
    de.getReceivingCountry();
    de.getReceivingLegalEntity();
    de.getReceivingCategory();
    de.getReceivingProduct();
    de.getReceivingLevelProcess();
    de.getReceivingLevel2Process();
    de.receivingGetData();
};

de.initSupplier = function(){
    localStorage.setItem('tab', 'external');
    localStorage.setItem('subTab', 'de-supplier');
    if(de.clickSupplierIndex === 0){
        de.getSupplierCountry();
        de.getSupplierLegalEntity();
        de.getSupplierCategory();
        de.getSupplierProduct();
        de.getSupplierLevelProcess();
        de.getSupplierLevel2Process();
        de.suppliergGetData(); 
        de.clickSupplierIndex += 1;
    }else{
        de.supplierPrepareMap();
        de.suppliergGetData(); 
    }
};

de.setSubtab = function(){
    localStorage.setItem('subTab', 'de-receiver');
    de.receivingPrepareMap();
    de.receivingGetData();
};