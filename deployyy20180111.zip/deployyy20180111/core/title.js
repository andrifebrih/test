var mt  = {};

mt.databaseList  = ko.observableArray([]);
mt.titleList  = ko.observableArray([]);
mt.databaseValue = ko.observable();
mt.titleValue = ko.observable();


// mt.getReceivingCountry = function(e){
//     var url = "/dashboard/getddlcountry";
//     ajaxPost(url,{}, function (res){
//       var country = []
//       $.each(res, function(index, result){      
//               country.push({"name" : result._id,"text": result._id});
//           });
//         mt.receivingcountry(country)
//     }); 

// }

var CNUtimeout = setTimeout(function(){
},1000);

mt.getAll = function(){
    var url = "/title/getall";
    ajaxPost(url,{}, function (res){
        var database = []
        var title = []
        $.each(res.Data, function(index, result){       
            database.push({"name" : result.Database,"text": result.Database});
            title.push({"name" : result.Title,"text": result.Title});
        });
        mt.databaseList(database)
        mt.titleList(title)
    });
}



mt.getDataGrid = function() {
    var db = (mt.databaseValue() === '')?[]:mt.databaseValue();
    var title = (mt.titleValue() === '')?[]:mt.titleValue();

    var param =  {
        "Database" : db,
        "Title" : title
    };
    console.log(param)
    var dataSource = [];
    var url = "/title/getdata";
    $("#dataGrid").html("");
    $("#dataGrid").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) {
                    // if (data.Data.Count == 0) {
                    //     return dataSource;
                    // } else {
                        return data.Data.Records;
                    // }
                },
                //total: "Data.Count",
            },
            // pageSize: 10,
            serverPaging: false,
            serverSorting: true,
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        resizable: true,
        sortable: true,
        pageable: false,
        // pageable: {
        //     refresh: true,
        //     pageSizes: true,
        //     buttonCount: 10
        // },
        excel: {
            allPages: true,
            fileName:"title.xlsx"
        },
        columnMenu: false,
         columns: [
        {
            field:"Database",
            title:"Database"
        }, {
            field:"Title",
            title:"Title"
        }, {
            field:"Uniquerecords",
            title:"Unique/Distinct Records",
            format:"{0:N0}",
            attributes:{style:"text-align:right"},
        }, {
            field:"Totalrecords",
            title:"Total Records",
            format:"{0:N1}",
            attributes:{style:"text-align:right"},
        }
        ]     
    });
    localStorage.setItem('filter', JSON.stringify(param));
}

mt.reset = function(){
    return function(){
        mt.databaseValue('');
        mt.titleValue('');
        mt.getDataGrid();
    }
}

mt.Search = function(){
    mt.getDataGrid();
   
}


$(function(){
   mt.getAll();
   // mt.getDataGrid()
   $("#export-datagrid").click(function () {
        var grid = $("#dataGrid").data("kendoGrid");
        grid.saveAsExcel();
    });
    localStorage.setItem('link',location.href.split('?')[0]);
    console.log(localStorage)
    if(getStringQuery('back')){
        var filter =  JSON.parse(localStorage.filter);   
        CNUtimeout = setTimeout(function(){
            mt.databaseValue(filter.Database); 
            mt.titleValue(filter.Title);
            mt.getDataGrid()
        },1000);
    }else{
        mt.getDataGrid()
    }

});