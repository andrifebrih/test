var dashboard = {};
dashboard.page = ko.observable("dashboard");
dashboard.mapGreenIcon = L.icon({
                          iconUrl: '/live/static/img/marker-green.png',
                          iconSize:     [20, 45], // size of the icon 
                        });    
dashboard.mapBlueIcon = L.icon({
                          iconUrl: '/live/static/img/marker-blue.png',
                          iconSize:     [20, 45], // size of the icon 
                        }); 
dashboard.mapGreyIcon = L.icon({
                          iconUrl: '/live/static/img/marker-grey.png',
                          iconSize:     [20, 45], // size of the icon 
                        });
dashboard.receiverIcon = L.icon({
                          iconUrl: '/live/static/img/receiver-marker2.png',
                          iconSize:     [20, 30], // size of the icon 
                        });
dashboard.supplierIcon = L.icon({
                          iconUrl: '/live/static/img/supplier-marker2.png',
                          iconSize:     [20, 30], // size of the icon 
                        });
dashboard.mapBoxAttr   = 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
                         '<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
                         'Imagery © <a href="http://mapbox.com">Mapbox</a>'
dashboard.mapBoxUrl    = 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoiYW5kcmlmOTUiLCJhIjoiY2l6ZGsyYm9yMjR1NjJxcDk4OXl2OWF1eCJ9.mIOW47-NbEinOt2RdL9yJQ';
dashboard.listTab      = ko.observableArray([]);
dashboard.configDonutSeries = function(id,indexId, indexData){
  var color = ["#00506D","#0077A3","#50D0FF"]
 
  $id = $("#donut_"+id+"_"+indexId)

  var donutChart  =  $id.getKendoChart()
  var visibleData =  $id.getKendoChart().options.series[0].data[indexData].visible
       
  $id.getKendoChart().options.series[0].data[indexData].visible = !visibleData
  $id.getKendoChart().redraw();
        
  var datas = $id.getKendoChart().options.series[0].data
      
  color = (!visibleData) ? color[indexData]: '#9b9898';

  $("#legend_donut_"+id+"_"+indexId).find("li").eq(indexData).find(".square").css('background',color)
  var totalDataTrue = 0 
  $.each(datas, function(i, val){            
    if(val.visible == true){
      totalDataTrue += val.value
    } 
  })

  $.each(datas, function(i, val){            
    var percentage = 100 / (totalDataTrue / val.value)
    if(val.visible == true){ 
      $("#legend_donut_"+id+"_precentage_"+ indexId +"_"+i).text(String(percentage.toFixed(0))+"%")
    }else{
      $("#legend_donut_"+id+"_precentage_"+ indexId +"_"+i).text("");
    }
  }) 
}

var CNUtimeout = setTimeout(function(){
},1000);
dashboard.getLatLngCenter  = function(coordinateProp){
  latSelisih = Math.abs( Math.abs(coordinateProp.latFrom) -  Math.abs(coordinateProp.latTo))
  lngSelisih = Math.abs( Math.abs(coordinateProp.lngFrom) -  Math.abs(coordinateProp.lngTo))
  var x = 0;
  if(latSelisih >= 1 && latSelisih <= 5){
      if (lngSelisih >= 1 && lngSelisih <= 5 ){
          x = 1
      }else if (lngSelisih > 5 && lngSelisih <= 16 ){
          x = 4   
      }else{
          x = 9
      }
            
            
  }else if(latSelisih > 5 && latSelisih <= 10 ){
      if (lngSelisih >= 1 && lngSelisih <= 5 ){
          x = 1
      }else if (lngSelisih > 5 && lngSelisih <= 10 ){
          x = 4   
      }else{
          x = 9
      }
            
  }else if ((latSelisih > 10 && latSelisih <= 15 ) && (lngSelisih > 10 && lngSelisih <= 15 ) ){
      x = 10
  }else{
      if (lngSelisih >= 1 && lngSelisih <= 5 ){
          x = 1
       }else if (lngSelisih > 5 && lngSelisih <= 10 ){
          x = 4   
      }else{
          x = 9
      }
  }
       
   latCenter = ((coordinateProp.latFrom + coordinateProp.latTo) / 2) + x
       
  if(Math.abs(lngSelisih <= 15)){
      lngCenter = ((coordinateProp.lngFrom + coordinateProp.lngTo) / 2 ) + x
           
  }else{
      lngCenter = ((coordinateProp.lngFrom + coordinateProp.lngTo) / 2 )     
  }
  return  {latCenter:latCenter,lngCenter:lngCenter}
};
dashboard.getSupplierType = function(){ 
    ajaxPost("/ocirtranche/getsuppliertype",{} , function (res){
        var suppliers = [] 
        $.each(res,function(i,v){
             suppliers.push(v._id)
        }); 
    });
};
dashboard.formatCookies =  function(){
    eraseCookie("receiverCountry");
    eraseCookie("receiverLegalEntity");
    eraseCookie("supplierCountry");
    eraseCookie("supplierLegalentity");
    eraseCookie("supplierType");
    eraseCookie("bussiness");
};
dashboard.createNewCookie = function(cookiesValue){
   
    dashboard.formatCookies();
    $.each(cookiesValue, function(i,v){
    // console.log(i)
      
      if(i === 'supplierLegalentity' || i === 'receiverLegalEntity' || i === 'receiverCountry' || i === 'supplierCountry' ){
        if (Array.isArray(v)){
            for(var x in v){
                var value = v[x];
                v = value.replace(",", "~");
            }
        }else{
          if (v.indexOf(',') !== -1){
            v = v.replace(",", "~");
          } 
        }
      }

      createCookie(i,v); 
      createCookie(i,v); 
    });
};
dashboard.parseLegalEntity = function(value){
    var obj = value.hasOwnProperty('receiverLegalEntity') ? value.receiverLegalEntity : value.supplierLegalentity;
        arr = obj.split("~");
    var result = [];
        result['country'] = arr[arr.length - 1];
        result['legalEntity'] = arr[arr.length - 2];
    if(arr.length > 1){
        legalEntity = '';
        for(i=0; i<arr.length-1; i++){
            legalEntity += arr[i]; 
        }   
    }
    return result;
}
dashboard.getListMenu =  function(){
  ajaxPost("/receiverview/getlisttab", {}, function (res){
    dashboard.listTab(res.Data)
  });
}
dashboard.Render = function(name){
  switch(name){
    case"GLOBALDASHBOARD-FTE":
      dfr.init();
    break;
    case"GLOBALDASHBOARD-INTRA-GROUP":
       dig.init();
    break;
    case"GLOBALDASHBOARD-IN-ENTITY":
       di.init();
    break;
    case"GLOBALDASHBOARD-EXTERNAL":
       de.init();
    break;
    case"GLOBALDASHBOARD-FMI":
       fmi.init();
    break;
  }

} 
function increaseIndexingAjx(index){
  return index( index() + 1 );
}
$(function(){
    dashboard.formatCookies();
    dashboard.getListMenu();
  });