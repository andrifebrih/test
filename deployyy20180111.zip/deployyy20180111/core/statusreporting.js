rsr = {}

rsr.reportNameList  = ko.observableArray([
											{value:"Critical Contract Identification",text:"Critical Contract Identification"}
										]); 
rsr.reportName = ko.observableArray([]);

rsr.receiverCountryList = ko.observableArray([]);
rsr.receiverCountry = ko.observable('');

rsr.supplierCountryList = ko.observableArray([]);
rsr.supplierCountry = ko.observable('');

rsr.receiverLegalList = ko.observableArray([]);
rsr.receiverLegal = ko.observableArray([]);

rsr.supplierLegalList = ko.observableArray([]);
rsr.supplierLegal = ko.observableArray([]);

rsr.businessList = ko.observableArray([]);
rsr.business = ko.observable('');

rsr.serviceList = ko.observableArray([]);
rsr.service = ko.observable('');

rsr.productList = ko.observableArray([]);
rsr.product = ko.observableArray([]);

rsr.emailTo = ko.observableArray([]);
rsr.emailCc = ko.observableArray([]);


rsr.emailValue = ko.observable({mailsubject:"", mailmsg:"", mailto:[], mailcc:[] ,pdffile:"", excelfile:"", excelfolder:""});
rsr.loadingProcess = ko.observable(false);

rsr.showGridReceiver = ko.observable(true);
rsr.showGridSupplier = ko.observable(true);

rsr.listFilter = ko.observableArray([]);
rsr.valueFilter = ko.observable('');
rsr.valueCreateNewFilter = ko.observable('');

rsr.getReceiverCountry =  function(){
	var payload = {         
	 	ReceiverLegalEntity : rsr.receiverLegal(),
        SupplierCountry : rsr.supplierCountry(),
        SupplierLegalEntity : rsr.supplierLegal(),
        Suppliertype: rsr.service(), 
        Categoryname : rsr.business(),
        Productfunction : rsr.product(), 
    } 
    var url = "/statusreporting/getreceivercountry";
    ajaxPost(url,payload, function (res){
        var receiverCountries = [];
        $.each(res, function(i,v){
            receiverCountries.push({text:v._id, value:v._id})
        });
        rsr.receiverCountryList(receiverCountries);
    })
};
rsr.getReceiverLegal =  function(){
	var payload = {
        ReceiverCountry : rsr.receiverCountry(), 
        SupplierCountry : rsr.supplierCountry(),
        SupplierLegalEntity : rsr.supplierLegal(),
        Suppliertype: rsr.service(), 
        Categoryname : rsr.business(),
        Productfunction : rsr.product(), 
    }
    var url = "/statusreporting/getreceiverlegalentity";
    ajaxPost(url,payload, function (res){
        var receiverLegals = [];
        $.each(res, function(i,v){
            receiverLegals.push({text:v._id, value:v._id})
        });
        if(receiverLegals.length == 1){
           console.log("---->")
          rsr.showGridReceiver(false);
        }
        rsr.receiverLegalList(receiverLegals);
    })
};
rsr.getSupplierCountry =  function(){
	var payload = {
        ReceiverCountry : rsr.receiverCountry(),
        ReceiverLegalEntity : rsr.receiverLegal(), 
        SupplierLegalEntity : rsr.supplierLegal(),
        Suppliertype: rsr.service(), 
        Categoryname : rsr.business(),
        Productfunction : rsr.product(), 
    }  
    var url = "/statusreporting/getsuppliercountry";
    ajaxPost(url,payload, function (res){
        var supplierCountries = [];
        $.each(res, function(i,v){
            supplierCountries.push({text:v._id, value:v._id})
        });
        rsr.supplierCountryList(supplierCountries);
    })
};
rsr.getSupplierlegal =  function(){
	var payload = {
        ReceiverCountry : rsr.receiverCountry(),
        ReceiverLegalEntity : rsr.receiverLegal(),
        SupplierCountry : rsr.supplierCountry(), 
        Suppliertype: rsr.service(), 
        Categoryname : rsr.business(),
        Productfunction : rsr.product(), 
    }  
    var url = "/statusreporting/getsupplierlegalentity";
    ajaxPost(url,payload, function (res){
        var supplierLegals = [];
        $.each(res, function(i,v){
            supplierLegals.push({text:v._id, value:v._id})
        });

        if(supplierLegals.length == 1){
          rsr.showGridSupplier(false);
        }
        rsr.supplierLegalList(supplierLegals);
    })
};
rsr.getServiceType = function(){
   	var payload = {
        ReceiverCountry : rsr.receiverCountry(),
        ReceiverLegalEntity : rsr.receiverLegal(),
        SupplierCountry : rsr.supplierCountry(),
        SupplierLegalEntity : rsr.supplierLegal(), 
        Categoryname : rsr.business(),
        Productfunction : rsr.product(), 
    }  

    var url = "/statusreporting/getsuppliertype";
    ajaxPost(url,payload, function (res){
        var serviceTypes = []
        $.each(res, function(index, value){
            var results;
            switch (value._id){
            	case 'IGS':
            		results = "Intra-Group"
            	break;
            	case 'TPS':
            		results = "External"
            	break;
            	case 'Teams':
            		results = "In-Entity"
            	break;
            	default:
 		           	results = "Systems"

            }
       
            serviceTypes.push({text:results, value:value._id});
        });
        rsr.serviceList(serviceTypes);
    });
};
rsr.getBusiness = function(){
    var payload = {
        ReceiverCountry : rsr.receiverCountry(),
        ReceiverLegalEntity : rsr.receiverLegal(),
        SupplierCountry : rsr.supplierCountry(),
        SupplierLegalEntity : rsr.supplierLegal(),
        Suppliertype: rsr.service(), 
        Productfunction : rsr.product(), 
    }
    var url = "/statusreporting/getbusinessfunction";
    ajaxPost(url,payload, function (res){
        var business = []
        $.each(res, function(index, result){
            business.push({"text" : result._id,"value": result._id});
        });
        rsr.businessList(business);
    });
};
rsr.getProduct = function(){
    var payload = {
        ReceiverCountry : rsr.receiverCountry(),
        ReceiverLegalEntity : rsr.receiverLegal(),
        SupplierCountry : rsr.supplierCountry(),
        SupplierLegalEntity : rsr.supplierLegal(),
        Suppliertype: rsr.service(), 
        Categoryname : rsr.business()
    } 

    var url = "/statusreporting/getproduct";
    ajaxPost(url,payload, function (res){
        var product = []
        $.each(res, function(index, result){
            product.push({"text" : result._id,"value": result._id});
        });
        rsr.productList(product);
    });
};
rsr.createGrid = function(payload){

	var dataSource = [];
    var payload = { 
        ReceiverCountry : rsr.receiverCountry(), 
        ReceiverLegalEntity : rsr.receiverLegal(),
        SupplierCountry : rsr.supplierCountry(),
        SupplierLegalEntity : rsr.supplierLegal(),
        Suppliertype: rsr.service(), 
        Categoryname : rsr.business(),
        Productfunction : rsr.product(), 
    }; 
    var url = "/statusreporting/getdatagridstatus";
    var coloumns  =  [
            
            
            {
                field:"Servicedescription",
                title:"Service Description", 
                width:200,
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
          
            {
                field:"Productfunction",
                title:"Product",
                width:150,
                headerAttributes: {
                    "class": "align-left"
                },
              
            },
            {
                field:"Suppliertype",
                title:"Service Type", 
                width:150,
                headerAttributes: {
                    "class": "align-left"
                },
                
            },
            {
                field:"Barriertype",
                title:"Barrier Type", 
                width:150,
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            }

        ]
      if(rsr.showGridReceiver() ==  true && rsr.showGridSupplier() == true){
          coloumns.unshift(
            {
                field:"receiver",
                title:"Receiver Country", 
                width:200,
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"supplier",
                title:"Supplier Country", 
                width:200,
                headerAttributes: {
                    "class": "align-left"
                },
                attributes: {
                    "class": "field-ellipsis"
                }
            }
          )
      }else if(rsr.showGridReceiver() ==  true && rsr.showGridSupplier() == false){
          coloumns.unshift(
            {
                field:"receiver",
                title:"Receiver Country", 
                headerAttributes: {
                    "class": "align-left"
                },
                width:200,
                attributes: {
                    "class": "field-ellipsis"
                }
            }
          )
      }else if(rsr.showGridReceiver() ==  false && rsr.showGridSupplier() == true){
          coloumns.unshift( 
            {
                field:"supplier",
                title:"Supplier Country", 
                width:200,
                attributes: {
                    "class": "field-ellipsis"
                }
            }
          )
      }
      coloumns.unshift(
            {
                field:"number",
                title:"Serial No",
                width:100,
                headerAttributes: {
                    "class": "align-right"
                },
                attributes: {
                    "class": "align-right"
                } 
            }
          )
    $("#grid-report").html("");
    $("#grid-report").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: payload,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) { 
                    // if (data.length == 0) {
                    //     return dataSource;
                    // } else {
                    //     index = 1;
                    //     data.forEach(function (d) { 
                    //         d.number =  index;
                    //         d.supplier = d.suppliercountry + ' - ' + d.supplierlegalentity
                    //         index++;
                    //     })
                    //     return data 
                    // }
                    // console.log(payload);
                    if (data.Data.Count == 0) {
                        return dataSource;
                    } else {
                        skip = $("#grid-report").data("kendoGrid").dataSource._skip;
                        index = 1+skip;
                        data.Data.Records.forEach(function (d) {
                          d.number = index;
                          d.receiver = d.Receivercountry + ' - ' + d.Receiverlegalentity;
                          if(rsr.service() == 'TPS'){
                            d.supplier = d.Suppliercountry + ' - ' + d.Legalcontractsignatory;
                          }else{
                            d.supplier = d.Suppliercountry + ' - ' + d.Supplierlegalentity;
                          }
                          index++;
                        });
                        return data.Data.Records;
                    }   
                  },
                  total: "Data.Count",  
              
            },
            pageSize: 10,
            // serverPaging: false,
            // serverSorting: false,
            serverPaging: true,
            serverSorting: true,
        },
        // filterable: {
        //     extra:false, 
        //     operators: {
        //         string: {
        //             contains: "Contains",
        //             startswith: "Starts with",
        //             eq: "Is equal to",
        //             neq: "Is not equal to",
        //             doesnotcontain: "Does not contain",
        //             endswith: "Ends with"
        //         },
        //     }
        // },
        resizable: true,
        scrollable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 10,
            pageSizes: [5, 10, 20],
        },
        columnMenu: false,
        columns:coloumns
    });
};

rsr.getData = function(){
	var payload = {        
	 	ReceiverCountry : rsr.receiverCountry(),  
	 	ReceiverLegalEntity : rsr.receiverLegal(),
        SupplierCountry : rsr.supplierCountry(),
        SupplierLegalEntity : rsr.supplierLegal(),
        Suppliertype: rsr.service(), 
        Categoryname : rsr.business(),
        Productfunction : rsr.product(), 
    } 
    rsr.createGrid(payload);
};
rsr.download =  function(type){
	return function(){
    var payload = {
              ReceiverCountry : rsr.receiverCountry(),  
              ReceiverLegalEntity : rsr.receiverLegal(),
              SupplierCountry : rsr.supplierCountry(),
              SupplierLegalEntity : rsr.supplierLegal(),
              Suppliertype: rsr.service(), 
              Categoryname : rsr.business(),
              Productfunction : rsr.product()
          };

		if(type == "excel"){
        rsr.loadingProcess(true)
            ajaxPost("/statusreporting/getexcel",payload , function (res){
                redirectUrl("/static/temp/StatusReporting/"res.msg)
                // var port=document.location.port;
                // var host = document.location.hostname;
                // if(port==""){ 
                //   rsr.loadingProcess(false)
                //   window.location.href = "http://"+document.location.hostname+"/static/temp/StatusReporting/"+res.msg;
                // }else{ 
                //   rsr.loadingProcess(false)
                //   window.location.href = "http://"+document.location.hostname+":"+port+"/static/temp/StatusReporting/"+res.msg;  
                // }
            })
            var payload = {
              Type : "StatusReporting Grid Excel"
            }
            ajaxPost("/analyticuser/downloadlog", payload, function (res){
            })
        }else {
          rsr.loadingProcess(true)
          ajaxPost("/rptpdfstatus/controlrpt",payload , function (res){
                 redirectUrl("/static/temp/pdf/"res.msg)
                // console.log(res)
                // var port = document.location.port;
                // var host = document.location.hostname;
                // if(port == ""){ 
                //    // window.location.href = "http://"+document.location.hostname+"/static/temp/pdf/"+res.Data;
                //    rsr.loadingProcess(false)
                //    window.open("http://"+document.location.hostname+"/static/temp/pdf/"+res.Data)
                // }else{ 
                //    // window.location.href = "http://"+document.location.hostname+":"+port+"/static/temp/pdf/"+res.Data;
                //    rsr.loadingProcess(false)  
                //    window.open("http://"+document.location.hostname+":"+port+"/static/temp/pdf/"+res.Data)
                // }
            })
            var payload = {
              Type : "StatusReporting Grid PDF"
            }
            ajaxPost("/analyticuser/downloadlog", payload, function (res){
            })
        }
	}
};

rsr.sendEmail = function(){
  var payloadFile = {
          ReceiverCountry : rsr.receiverCountry(),  
          ReceiverLegalEntity : rsr.receiverLegal(),
          SupplierCountry : rsr.supplierCountry(),
          SupplierLegalEntity : rsr.supplierLegal(),
          Suppliertype: rsr.service(), 
          Categoryname : rsr.business(),
          Productfunction : rsr.product()
      };
  
  for (var i in rsr.emailTo()){ 
    rsr.emailValue().mailto.push(rsr.emailTo()[i].id)
  }

  for (var i in rsr.emailCc()){ 
    rsr.emailValue().mailcc.push(rsr.emailCc()[i].id)
  }  
  
  rsr.loadingProcess(true);
  ajaxPost("/statusreporting/getexcel",payloadFile , function (res1){
                console.log(res1)
               rsr.emailValue().excelfile = res1.msg
               rsr.emailValue().excelfolder = "StatusReporting"

    ajaxPost("/rptpdfstatus/controlrpt",payloadFile , function (res2){
                  console.log(res2)
                  rsr.emailValue().pdffile = res2.Data
                 
      ajaxPost("/reportpdf/sendmail",rsr.emailValue() , function (res3){
            console.log(res3);
            if (!res3.IsError){
              rsr.loadingProcess(false); 
              swal("Email Sent", "", "success");
              $("#ModalEmail").modal("hide");
              rsr.resetField();
            }else {
              rsr.loadingProcess(false);
              swal("Error!",res3.Data, "error"); 
            }
      })    
    })
  }) 
}

rsr.resetField = function(){
  rsr.emailValue().mailsubject = ""; 
  rsr.emailValue().mailmsg = "" ;
  rsr.emailValue().mailto = []; 
  rsr.emailValue().mailcc = [];
  rsr.emailValue().pdffile = "" ;
  rsr.emailValue().excelfile = "" ;
  rsr.emailValue().excelfolder = "";
  $("#emailCc").tokenInput("clear");
  $("#emailTo").tokenInput("clear");
  $("#subjectMail").val("");
  $("#msgMail").val("");
}

var CNUtimeout = setTimeout(function(){
    },1000);
rsr.receiverCountry.subscribe(function(newValue){
	rsr.getReceiverLegal();
	rsr.getSupplierCountry();
	rsr.getBusiness();
	rsr.getProduct();
	if(rsr.receiverCountry() == ''){
		rsr.getReceiverCountry();
	}
    CNUtimeout = setTimeout(function(){
                   rsr.getData();
                 },2000);
});
rsr.receiverLegal.subscribe(function(newValue){
	// rsr.getReceiverCountry();
	rsr.getSupplierCountry();
	rsr.getSupplierlegal(); 
	rsr.getBusiness();
	rsr.getProduct();
	if(rsr.receiverLegal().length == 0){
		rsr.getReceiverLegal();
	}

  if(rsr.receiverLegal().length == 1){
    rsr.showGridReceiver(false)
  }else{
    rsr.showGridReceiver(true)
  }
    CNUtimeout = setTimeout(function(){
                   rsr.getData();
                 },2000);
    
});
rsr.supplierCountry.subscribe(function(newValue){
  
  rsr.getReceiverCountry();
	rsr.getSupplierlegal(); 
	rsr.getBusiness();
	rsr.getProduct();
	if(rsr.supplierCountry == ''){
		rsr.getSupplierCountry();
	}
    CNUtimeout = setTimeout(function(){
                   rsr.getData();
                 },2000);
});
rsr.supplierLegal.subscribe(function(newValue){
 
  rsr.getReceiverCountry();
  rsr.getReceiverLegal(); 
	rsr.getBusiness();
	rsr.getProduct();
	if(rsr.supplierLegal().length == 0){
		rsr.getSupplierlegal(); 
	} 
  
  if(rsr.supplierLegal().length == 1){
    rsr.showGridSupplier(false) 
  }else{
    rsr.showGridSupplier(true) 
  }    
    CNUtimeout = setTimeout(function(){
                   rsr.getData();
                 },2000); 
});
rsr.business.subscribe(function(newValue){
 
  rsr.getReceiverCountry();
  rsr.getReceiverLegal();
  rsr.getSupplierCountry();
	rsr.getSupplierlegal(); 
	rsr.getProduct();
	if(rsr.business().length == 0){
		rsr.getBusiness();
	}  
    CNUtimeout = setTimeout(function(){
                   rsr.getData();
                 },2000);
});
rsr.service.subscribe(function(newValue){
 
  rsr.getReceiverCountry();
  rsr.getReceiverLegal();
  rsr.getSupplierCountry();
	rsr.getSupplierlegal(); 
	rsr.getBusiness();
	rsr.getProduct();
    CNUtimeout = setTimeout(function(){
                   rsr.getData();
                 },2000);
});
rsr.product.subscribe(function(newValue){
	rsr.getReceiverCountry();
  rsr.getReceiverLegal();
  rsr.getSupplierCountry();
	rsr.getSupplierlegal(); 
	rsr.getBusiness();
	if(rsr.product().length == 0){
		rsr.getProduct();
	}  
    CNUtimeout = setTimeout(function(){
                   rsr.getData();
                 },2000);
});

rsr.saveFilter = function(){
  var payload = {
    Report: rsr.reportName(),
    receiverCountry: rsr.receiverCountry(),
    ReceiverLegal: rsr.receiverLegal(),
    SupplierCountry: rsr.supplierCountry(),
    SupplierLegal: rsr.supplierLegal(),
    Service: rsr.service(),
    Business: rsr.business(),
    Product: rsr.product(),
    Submenu : "StatusReporting",
    Name : rsr.valueCreateNewFilter()
  }

  var status = 0

  var validator = $("#newFilterName").data("kendoValidator");

  if(validator ==  undefined){
     validator = $("#newFilterName").kendoValidator().data("kendoValidator");
    }

  if (validator.validate()){
      // for (var i in rsr.listFilter()){
      $.each(rsr.listFilter(), function(k, v){   
      if (v._id == "StatusReporting"+rsr.valueCreateNewFilter()){
        swal({   
          title: "Are you sure?",   
          text: "Filter name already exist",   
          type: "warning",   
          showCancelButton: true,   
          confirmButtonColor: "#3F9E35",   
          confirmButtonText: "Yes, edit it!",   
          cancelButtonText: "No, cancel",   
          closeOnConfirm: false,   
          closeOnCancel: false 
          }, 
          function(isConfirm){   
            if (isConfirm) {     
              // swal("Deleted!", "Your imaginary file has been deleted.", "success");
              save();   
            } else {     
              swal("Cancelled", "", "error");
              return;   
            } 
          });
      }else {
        status = status+1;
        if (status == rsr.listFilter().length){
          save();
        }
      }
    });
  }else {
    swal("Error!","Filter name cannot be empty", "error"); 
  }
  
  function save(){
    ajaxPost("/reportcontrolverification/savereportconfig",payload , function (res){
      console.log(res);
      if (res.Success){
        swal("Success", "Filter name saved", "success");
        rsr.valueCreateNewFilter('');   
        rsr.getListFilter();
      }else {
        swal("Error!",'failed to save', "error"); 
      }
    })
  }   

}

rsr.changeFilterValue = function(e){  
  var selected = e.sender._selectedValue; 
  // console.log(selected)
  rsr.valueFilter(selected);

  if (selected !== ''){
    $.each(rsr.listFilter(), function(k, v){      
      if (v._id == selected){
        console.log(v);
        rsr.reportName(v.Report)
        rsr.receiverCountry(v.receiverCountry)
        rsr.receiverLegal(v.ReceiverLegal)
        rsr.supplierCountry(v.SupplierCountry)
        rsr.supplierLegal(v.SupplierLegal)
        rsr.service(v.Service)
        rsr.business(v.Business)
        rsr.product(v.Product)

      }
    })  
  }else {
    rsr.showGridLegalEntity(true);
    rsr.reportName('')
    rsr.receiverCountry('')
    rsr.receiverLegal([])
    rsr.supplierCountry('')
    rsr.supplierLegal([])
    rsr.service('')
    rsr.business('')
    rsr.product([])
  } 
  
}

rsr.getListFilter = function(){
  var payload = {
    Submenu : "StatusReporting"
  };
  
  ajaxPost("/reportcontrolverification/getnameconfig",payload , function (res){
    // console.log(res);
    // rsr.changeFilterValue(res);
    rsr.listFilter(res);
    
  })
     
}

rsr.CreateTokenInputEmail = function(){
  $("#emailTo").tokenInput([], { 
    zindex: 700,
    noResultsText: "Add New Email",
    allowFreeTagging: true,
    placeholder: 'Type Email Here',
    tokenValue: 'id',
    propertyToSearch: 'key',
    theme: "facebook",
    onAdd: function (item) {
      // console.log(item)
      if (validateEmailFormat(item.key)){
        rsr.emailTo.push(item);  
        $("#alertMessage1").hide();
      }else {
        $("#alertMessage1").text(item.key+" is not valid email !");
        $("#alertMessage1").show()
        this.tokenInput("remove", {id: item.key});
        setTimeout(function() {
          $("#alertMessage1").hide();
        }, 5000);
      }
    },
    onDelete: function (item) {
      // console.log("delete",item)
      rsr.emailTo.remove(item);  
    }
  });

  $("#emailCc").tokenInput([], { 
    zindex: 700,
    noResultsText: "Add New Email",
    allowFreeTagging: true,
    placeholder: 'Type Email Here',
    tokenValue: 'id',
    propertyToSearch: 'key',
    theme: "facebook",
    onAdd: function (item) {
      // console.log(item)
      if (validateEmailFormat(item.key)){
        rsr.emailCc.push(item);  
        $("#alertMessage2").hide();
      }else {
        $("#alertMessage2").text(item.key+" is not valid email !");
        $("#alertMessage2").show()
        this.tokenInput("remove", {id: item.key});
        setTimeout(function() {
          $("#alertMessage2").hide();
        }, 5000);
      }
    },
    onDelete: function (item) {
      rsr.emailCc.remove(item);  
    }
  });
}

$(function(){ 
	rsr.getServiceType();
	rsr.getReceiverCountry();
	rsr.getSupplierCountry();
	rsr.getProduct();
	rsr.getData();

	date = 	model.getDateMinOne()
    fullDate =  model.getDaysName(date.getDay()) +", "+ date.getDate() + " "+ model.getMonthName(date.getMonth()) + " " + date.getFullYear(); 
  	$("#fullDate-text").text(fullDate)

    rsr.CreateTokenInputEmail();
    rsr.getListFilter();  
})