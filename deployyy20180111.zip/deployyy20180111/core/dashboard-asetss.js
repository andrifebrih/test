var da = {}

da.receivingSupplierType = ko.observableArray([]);
da.supplierSupplierType  = ko.observableArray([]);

da.receivingCountry     = ko.observable('');
da.receivingCountryList = ko.observableArray([]);

da.supplierCountry     = ko.observable('');
da.supplierCountryList = ko.observableArray([]);

da.receivingLegalEntity     = ko.observableArray([]);
da.receivingLegalEntityList = ko.observableArray([]);

da.supplierLegalEntity      = ko.observableArray([]);
da.supplierLegalEntityList  = ko.observableArray([]);

da.receivingBusiness =  ko.observable('');
da.receivingBusinessList = ko.observableArray([]);

da.supplierBusiness =  ko.observable('');
da.supplierBusinessList = ko.observableArray([]);

da.onchangeReceivingLegalEntity = ko.observable(true);
da.onchangeSupplierLegalEntity  = ko.observable(true);

da.receivingReceiverSummary = ko.observableArray([]);
da.supplierReceiverSummary = ko.observableArray([])

da.receivingSupplierSummary = ko.observableArray([]);
da.supplierSupplierSummary = ko.observableArray([]);

da.clickSupplierIndex = 0;

var CNUtimeout = setTimeout(function(){
},1000);
da.formatCookies = function(){
    eraseCookie("receiverCountry");
    eraseCookie("receiverLegalEntity");
    eraseCookie("supplierCountry");
    eraseCookie("supplierLegalentity");
};
da.createNewCookie = function(cookiesValue){
    da.formatCookies();
    $.each(cookiesValue, function(i,v){
        createCookie(i,v); 
        createCookie(i,v); 
    });
};
da.receivingPrepareMap = function(){
	$('#map-assets-receiving').remove();
    $(".panelMapReceiving").append("<div id='map-assets-receiving' class='map'> </div>");
}
da.supplierPrepareMap = function(){
    $('#map-assets-supplier').remove();
    $(".panelMapSupplier").append("<div id='map-assets-supplier' class='map'> </div>");
}
da.receivingMapDetails = function(dataSource){
    da.receivingPrepareMap();
    L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxNWVubjg2MDA2NWZta2tnc2NocnF4ZyJ9.NDWpdAW4qO42qUdRBNIa5Q';
    var mapLeaflet = L.mapbox.map('map-assets-receiving', 'mapbox.light',{'worldCopyJump': true}).setView([0,0], 2)
    
    var geoJson = dataSource.BubbleSupplier.features; 
    var indexDelete;
    var startLine = {x:dataSource.BoxInfo.Longitude, y:dataSource.BoxInfo.Latitude}
    $.each(geoJson, function(i,v){
        if(v.geometry.coordinates[0].toFixed(0) != dataSource.BoxInfo.Longitude.toFixed(0) || v.geometry.coordinates[1].toFixed(0) != dataSource.BoxInfo.Latitude.toFixed(0)) {         
            var color;
            if(v.properties.count <= 5){
                color = "#7F7F7F";
            }else if(v.properties.count <= 20){
                color = "#b5ce7d";
            }  else {
                color = "#60B4E4"; 
            }
            
            var newProperties = {"marker-size": "small","marker-symbol":"marker","marker-color":color}; 
            $.extend(true, v.properties,newProperties)

            var endLine = {x:v.geometry.coordinates[0], y: v.geometry.coordinates[1]};
            var generator = new arc.GreatCircle(startLine,endLine,{color: "#CBA23C" });
            
            var line = generator.Arc(200, { offset: 0 });
            L.geoJson(line.json()).addTo(mapLeaflet);
        }else{
            indexDelete = i
        }
    });
    (indexDelete === undefined)?'': geoJson.splice(indexDelete,1)
   
    var boxLabel = dataSource.BoxInfo

    var receiverMarker = L.marker([dataSource.BoxInfo.Latitude, dataSource.BoxInfo.Longitude], {
            icon : L.icon( {
                iconUrl : '/static/img/receiver-marker.png',
            } )
    } ).addTo( mapLeaflet );

    var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    myLayer.setGeoJSON(geoJson);

    receiverMarker.on("click", function(e) {
        // var payloadSummary={
        //     Suppliertype :  receiver.supplierType(),
        //     ReceivingCountry :  receiver.receivingCountry(),
        //     LegalEntity : [],
        //     SupplierCountry : ''
        // }
        // ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
        //   receiver.createSummary(res)
        // })
    });
    myLayer.on('click', function(e) {
        // var country = e.layer.feature.properties['SecondaryID']
        // var payloadSummary={
        //     Suppliertype :  receiver.supplierType(),
        //     ReceivingCountry :  receiver.receivingCountry(),
        //     LegalEntity : [],
        //     SupplierCountry : country
        // }
        // ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
        //     receiver.createSummary(res)
        // })
    });
    
    $line = $("path[stroke-linejoin='round']");
    $line.attr('stroke-width',"2");
    $line.attr('stroke-opacity',"3");
    $line.attr('stroke',"#3A91B9");
};
da.supplierMapDetails = function(dataSource){
    da.supplierPrepareMap();
    L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxNWVubjg2MDA2NWZta2tnc2NocnF4ZyJ9.NDWpdAW4qO42qUdRBNIa5Q';
    var mapLeaflet = L.mapbox.map('map-assets-supplier', 'mapbox.light',{'worldCopyJump': true}).setView([0,0], 2)
    
    var geoJson = dataSource.BubbleSupplier.features; 
    var indexDelete;
    var startLine = {x:dataSource.BoxInfo.Longitude, y:dataSource.BoxInfo.Latitude}
    $.each(geoJson, function(i,v){
        if(v.geometry.coordinates[0].toFixed(0) != dataSource.BoxInfo.Longitude.toFixed(0) || v.geometry.coordinates[1].toFixed(0) != dataSource.BoxInfo.Latitude.toFixed(0)) {         
            var color;
            if(v.properties.count <= 5){
                color = "#7F7F7F";
            }else if(v.properties.count <= 20){
                color = "#b5ce7d";
            }  else {
                color = "#60B4E4"; 
            }
            
            var newProperties = {"marker-size": "small","marker-symbol":"marker","marker-color":color}; 
            $.extend(true, v.properties,newProperties)

            var endLine = {x:v.geometry.coordinates[0], y: v.geometry.coordinates[1]};
            var generator = new arc.GreatCircle(startLine,endLine,{color: "#CBA23C" });
            
            var line = generator.Arc(200, { offset: 0 });
            L.geoJson(line.json()).addTo(mapLeaflet);
        }else{
            indexDelete = i
        }
    });   
    (indexDelete === undefined)?'': geoJson.splice(indexDelete,1)
   
    var boxLabel = dataSource.BoxInfo

    var receiverMarker = L.marker([dataSource.BoxInfo.Latitude, dataSource.BoxInfo.Longitude], {
        icon : L.icon( {
           iconUrl : '/static/img/supplier-marker.png',
        } )
    } ).addTo( mapLeaflet );

    var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    myLayer.setGeoJSON(geoJson);

    receiverMarker.on("click", function(e) {
        // var payloadSummary={
        //     Suppliertype :  receiver.supplierType(),
        //     ReceivingCountry :  receiver.receivingCountry(),
        //     LegalEntity : [],
        //     SupplierCountry : ''
        // }
        // ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
        //   receiver.createSummary(res)
        // })
    });
    myLayer.on('click', function(e) {
        // var country = e.layer.feature.properties['SecondaryID']
        // var payloadSummary={
        //     Suppliertype :  receiver.supplierType(),
        //     ReceivingCountry :  receiver.receivingCountry(),
        //     LegalEntity : [],
        //     SupplierCountry : country
        // }
        // ajaxPost("/receiverview/summaryreceiver",payloadSummary , function (res){
        //     receiver.createSummary(res)
        // })
    });
    
    $line = $("path[stroke-linejoin='round']");
    $line.attr('stroke-width',"2");
    $line.attr('stroke-opacity',"3");
    $line.attr('stroke',"#3A91B9");
};
da.receivingMap = function(dataSource){
    da.receivingPrepareMap()
    var geoJson =dataSource.features;
    
    $.each(geoJson, function(i,v){
       
        if(v.properties.count <= 5){
            var color = "#7F7F7F";
        }else if(v.properties.count <= 20){
            var color = "#b5ce7d";
        }  else {
            var color = "#60B4E4"; 
        }
        var newProperties = {"marker-size": "small","marker-symbol":"marker",'marker-color': color}; 
        $.extend(true, v.properties,newProperties)
    });
   
    L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxOXR1djI3MDFseGZ0bTFhbDc0YnoxdSJ9.vo3h2zpopQD9DVMILpkPYg';
    var mapLeaflet = L.mapbox.map('map-assets-receiving', 'mapbox.light',{'worldCopyJump': true})
      .setView([0,0], 2)

    var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    myLayer.setGeoJSON(geoJson);
    
    myLayer.on('click', function(e) {
        var country = e.layer.feature.properties['SecondaryID']
        da.receivingCountry(country);
        da.receivingGetData(); 
    }); 
};
da.supplierMap = function(dataSource){
    da.supplierPrepareMap()
    var geoJson =dataSource.features;
    
    $.each(geoJson, function(i,v){
       
        if(v.properties.count <= 5){
            var color = "#7F7F7F";
        }else if(v.properties.count <= 20){
            var color = "#b5ce7d";
        }  else {
            var color = "#60B4E4"; 
        }
        var newProperties = {"marker-size": "small","marker-symbol":"marker",'marker-color': color}; 
        $.extend(true, v.properties,newProperties)
    });
   
    L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxOXR1djI3MDFseGZ0bTFhbDc0YnoxdSJ9.vo3h2zpopQD9DVMILpkPYg';
    var mapLeaflet = L.mapbox.map('map-assets-supplier', 'mapbox.light',{'worldCopyJump': true})
      .setView([0,0], 2)

    var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    myLayer.setGeoJSON(geoJson);
    
    myLayer.on('click', function(e) {
        var country = e.layer.feature.properties['SecondaryID']
        // console.log(country);
        da.supplierCountry(country);
        da.suppliergGetData(); 
    }); 
};
da.receivingCreateSummary = function(dataSource){
    console.log(dataSource);
    var receivers = []
    $.each(dataSource.Country, function(i,v){
        receivers.push({
            CEF:kendo.toString(v.CEF,"n0"),
            Country:v.Country,
            FTE:kendo.toString(v.FTE,"n2"),
            LegalEntity:kendo.toString(v.LegalEntity,"n1")
        })
    });
    da.receivingReceiverSummary(receivers); 

    var suppliers = []
    $.each(dataSource.CountryLegal, function(i,v){
        suppliers.push({
            CEF:kendo.toString(v.CEF,"n1"),
            CountryLegal:v.CountryLegal,
            FTE:kendo.toString(v.FTE,"n2")
        })
    });
    da.receivingSupplierSummary(suppliers); 
}
da.supplierCreateSummary = function(dataSource){
    var receivers = []
    $.each(dataSource.Country, function(i,v){
        receivers.push({
            CEF:kendo.toString(v.CEF,"n0"),
            Country:v.Country,
            FTE:kendo.toString(v.FTE,"n2"),
            LegalEntity:kendo.toString(v.LegalEntity,"n1")
        })
    });
    da.supplierReceiverSummary(receivers); 
    
    var suppliers = []
    $.each(dataSource.CountryLegal, function(i,v){
        suppliers.push({
            CEF:kendo.toString(v.CEF,"n1"),
            CountryLegal:v.CountryLegal,
            FTE:kendo.toString(v.FTE,"n2")
        })
    });
    da.supplierSupplierSummary(suppliers); 
}
da.receivingGetData = function(){
  
	if(da.receivingCountry() == ''){
		var url = "/receiverview/getdefaultreceiver";
    	ajaxPost(url, {}, function (res){
        	da.receivingMap(res)
   	 	});
	}else{
		var payload={
            Suppliertype : da.receivingSupplierType(),
            ReceivingCountry : da.receivingCountry(),
            LegalEntity : da.receivingLegalEntity()
        }
        // var cookies = {receiverCountry: da.receivingCountry(), receiverLegalEntity: da.receivingLegalEntity().toString()}
        // da.createNewCookie(cookies);
        var url = "/receiverview/getdetailsreceiver";
        ajaxPost(url, payload, function (res){
            da.receivingMapDetails(res)
        });
	}

    var payload = {
        ReceivingCountry : da.receivingCountry(),
        LegalEntity : da.receivingLegalEntity(),
        Business : da.receivingBusiness()
    };
    ajaxPost("/receiverview/summaryreceivernew",payload , function (res){
        da.receivingCreateSummary(res);
    });
};
da.suppliergGetData = function(){
    if(da.supplierCountry() == ''){
        var url = "/supplierview/getdefaultsupplier";
        ajaxPost(url, {}, function (res){
            da.supplierMap(res)
        });
    }else{
        var payload={
            Suppliertype :  da.supplierSupplierType(),
            ReceivingCountry :  da.supplierCountry(),
            LegalEntity : da.supplierLegalEntity()
        }
        // var cookies = {supplierCountry: da.supplierCountry(), supplierLegalentity: da.supplierLegalEntity().toString()}
        // da.createNewCookie(cookies);
        var url = "/supplierview/getdetailssupplier";
        ajaxPost(url, payload, function (res){
            da.supplierMapDetails(res)
        });
    }

    var payload = {
        ReceivingCountry :  da.supplierCountry(),
        LegalEntity : da.supplierLegalEntity(),
        Business : da.supplierBusiness()
    };
    ajaxPost("/receiverview/summaryreceivernew",payload , function (res){
        da.supplierCreateSummary(res);
    });
};
da.getReceivingCountry = function(){
    var url = "/receiverview/getreceivercountry";
    ajaxPost(url,{}, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        da.receivingCountryList(receivingCountries);
    });
};
da.getSupplierCountry = function(){
    var url = "/supplierview/getsuppliercountry";
    ajaxPost(url,{}, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
       	da.supplierCountryList(receivingCountries);
    });
};
da.getReceivingLegalEntity = function(){
    var payload = {
        ReceivingCountry : da.receivingCountry() 
    };
    var url = "/receiverview/getlegalentityreceiver";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        
        da.receivingLegalEntityList(legalEntities) 
    });
};
da.getSupplierLegalEntity = function(){
    var payload = {
        ReceivingCountry : da.supplierCountry() 
    };
    var url = "/supplierview/getlegalentitysupplier";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        da.supplierLegalEntityList(legalEntities) 
    });
};
da.getReceivingBusiness = function(){
    ajaxPost("/receiverview/getcategory",{}, function (res){
        var bussiness = [];
        $.each(res, function(i,v){
            bussiness.push({text:v._id, value:v._id})
        });
        da.receivingBusinessList(bussiness) 
    });  
};
da.getSupplierBusiness = function(){
    ajaxPost("/receiverview/getcategory",{}, function (res){
        var bussiness = [];
        $.each(res, function(i,v){
            bussiness.push({text:v._id, value:v._id})
        });
        da.supplierBusinessList(bussiness) 
    });  
};
da.receivingCountry.subscribe(function(newValue){
    da.receivingLegalEntity([])
    da.onchangeReceivingLegalEntity(false) 

    da.getReceivingLegalEntity();
    da.receivingGetData();
    CNUtimeout = setTimeout(function(){  
        da.onchangeReceivingLegalEntity(true) 
    },1000);
});
da.supplierCountry.subscribe(function(newValue){
    da.supplierLegalEntity([])
    da.onchangeSupplierLegalEntity(false) 
    da.getSupplierLegalEntity();
    da.suppliergGetData();
    CNUtimeout = setTimeout(function(){  
        da.onchangeSupplierLegalEntity(true) 
    },1000);
});
da.receivingLegalEntity.subscribe(function(newValue){
    if(da.onchangeReceivingLegalEntity() === true){
        da.receivingGetData();
    }
});
da.supplierLegalEntity.subscribe(function(newValue){
    if(da.onchangeSupplierLegalEntity() === true){
        da.suppliergGetData();
    }
});
da.receivingBusiness.subscribe(function(newValue){
    da.receivingGetData();
});
da.supplierBusiness.subscribe(function(newValue){
    da.suppliergGetData();
});
da.init =  function(){ // initReceiving
	da.getReceivingCountry();
    da.getReceivingBusiness();
	da.receivingGetData();
	// console.log("dashboard.asetss");
}
da.initSupplier = function(){
    if(da.clickSupplierIndex === 0){
        da.getSupplierCountry();
        da.getSupplierBusiness();
        da.suppliergGetData(); 
        da.clickSupplierIndex += 1;
    }
}