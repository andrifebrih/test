var up = {};
up.typeFileList = ko.observableArray([{_id:'Data Visualization'},{_id:'FTE Resource'},{_id:'CEF Report'}]);
up.typeFile = ko.observable('Data Visualization');
up.tmpFile 	= ko.observableArray([]);
up.delimiterList  = ko.observableArray([{_id:'∟'},{_id:'¥'},{_id:'âˆŸ'}]);
up.delimiter 	= ko.observable('∟');
up.statusUploadFiles = ko.observableArray([]);
up.statusUpload = ko.observable(true);
up.totalErrorFile = ko.observable(0);
up.enabledBaseGrid = ko.observable(false);
up.gridDone =ko.observable(false);
up.getActiveDone = ko.observable(false);
up.activeGenerateProperties = {total:0,totalprocess:0,processed:0};
up.precentageGenerate = ko.observable(0)
up.onProcessStatus  =  ko.observable(false);
up.generateProcessTotal = ko.observable(1);
up.callCheckActiveGenerated = ko.observable(true);
up.loadingGrid = ko.observable(false)
up.blankLayer = ko.observable(false);
function handleFiles(input) {
  var dataFile = [];
  $('#listIcon').html("");
  if ($("#uploadFile")[0].files.length > 0) {
    var files = $("#uploadFile")[0].files;
    var typeExtension = ["jpg", "png", "doc", "pdf", "xls", "zip", "txt", "csv", "unknown"];
    var typeFile = "default";

    for (var i in files) {
      if (files[i].size != undefined) {
        var Filename = files[i].name;
        var extension = Filename.substring(Filename.lastIndexOf('.') + 1);
        var indexExtension = typeExtension.indexOf(extension);
        if (indexExtension > 0) {
          typeFile = extension;
        }

        dataFile.push({
          id: "keyFile" + i,
          name: files[i].name,
          size: files[i].size,
          type: extension,
          classCSS: typeFile
        });
      }
    }

    up.tmpFile(dataFile);
    $('#listIcon').html("");
    $divListIcon = $('#listIcon');
    up.statusUploadFiles();
    var statusUpload = []
    var errorFile = 0;
    for (var dw in dataFile) {
      if (dataFile[dw].name.match('^DV_+[0-9]{6}') !== null || dataFile[dw].name.match('^FTE_+[0-9]{6}') !== null  || dataFile[dw].name.match('^CEF_+[0-9]{6}') !== null || dataFile[dw].name.match('^PFP_+[0-9]{6}') !== null || dataFile[dw].name.match('^MPP_+[0-9]{6}') !== null|| dataFile[dw].name.match('^STA_+[0-9]{6}') !== null || dataFile[dw].name.match('^SYS_+[0-9]{6}') !== null){
        startYearIndex = dataFile[dw].name.indexOf('_')
        endYearIndex =startYearIndex + 5;
        var  year = []; 
        for(i=startYearIndex + 1; i<endYearIndex; i++){
          year.push(dataFile[dw].name[i])
        }
        if(parseInt(year.join('')) > 1950){
          $Icon = $("<div class='file-wrapper' id='"+dataFile[dw].id+"'>" +
              "<span class='file-icon " + dataFile[dw].classCSS + "-file glyphicon glyphicon-ok-circle'></span>" +
              "<h4 class='file-heading file-name-heading'> Name: " + dataFile[dw].name + "</h4>" +
              "<h4 class='file-heading file-size-heading'> Size: " + dataFile[dw].size + "</h4>" +
              "<span id='btnRemoveFile' class='remove-File fa fa-times' onclick = up.removeFile(\"" + dataFile[dw].id + "\")></span>" +
              "</div>");
          $Icon.appendTo($divListIcon);
          statusUpload.push(true)
        }else{
          $Icon = $("<div class='file-wrapper-disable' id='"+dataFile[dw].id+"'>" +
              "<span class='file-icon " + dataFile[dw].classCSS + "-file glyphicon glyphicon-exclamation-sign'></span>" +
              "<h4 class='file-heading file-name-heading'> Name: " + dataFile[dw].name + "</h4>" +
              "<h4 class='file-heading file-size-heading'> Size: " + dataFile[dw].size + "</h4>" +
              "<span id='btnRemoveFile' class='remove-File fa fa-times' onclick = up.removeFile(\"" + dataFile[dw].id + "\")></span>" +
              "</div>");
          $Icon.appendTo($divListIcon);
          errorFile += 1;
          up.statusUpload(false)
          statusUpload.push(false)
        }
      }else{
        $Icon = $("<div class='file-wrapper-disable' id='"+dataFile[dw].id+"'>" +
               "<span class='file-icon " + dataFile[dw].classCSS + "-file glyphicon glyphicon-exclamation-sign'></span>" +
              "<h4 class='file-heading file-name-heading'> Name: " + dataFile[dw].name + "</h4>" +
              "<h4 class='file-heading file-size-heading'> Size: " + dataFile[dw].size + "</h4>" +
              "<span id='btnRemoveFile' class='remove-File fa fa-times' onclick = up.removeFile(\"" + dataFile[dw].id + "\")></span>" +
              "</div>");
        $Icon.appendTo($divListIcon); 
        errorFile += 1;
        up.statusUpload(false)
        statusUpload.push(false)
      }
    }
    up.statusUploadFiles(statusUpload);
    up.totalErrorFile(errorFile)
  }
}
up.reset = function(){
  up.tmpFile([])
  up.typeFile('Data Visualization');
  up.delimiter('∟');
  $( "input[value='pipes']" ).prop("checked", true)
  $("#listIcon").html('')
  $("input[id='uploadFile']").val('')
}
up.removeFile =  function(id){
	newData = [];
  statues = [];
	var totalError = up.totalErrorFile();    
  $.each(up.tmpFile(),function(i,v){
		status = up.statusUploadFiles()[i]
    if(v.id !== id){
			newData.push(v)
      statues.push(status)
		}else{
      if(status == 'false'){
        totalError -=1;
         up.totalErrorFile(totalError);    
      }
     
    }
	})
  if(up.totalErrorFile() == 0){
    up.statusUpload(true)
  }
  up.statusUploadFiles(statues)
	up.tmpFile(newData);
	$("#"+id).remove('')
}
up.uploadFile = function(){
  if(up.statusUpload()){
  	if ($("#uploadFile")[0].files.length > 0) { 	
      var listFile = up.tmpFile();
      if (listFile.length == 0) {
        return swal("Confirmation!", "Please choose file to be uploaded.", "error");
      }
           $("#GridLogProcess").html("");
      up.loadingGrid(true)
      var formData = new FormData();
      // formData.append("typeFile", up.startDate());
      formData.append("delimiter", up.delimiter() );
      var j = 0;
      for (i = 0; i < $("#uploadFile")[0].files.length; i++) {
        for (var cek in listFile) {
          if (listFile[cek].name == $("#uploadFile")[0].files[i].name) {
            formData.append("UploadFile", $("#uploadFile")[0].files[j]);
            j++;
          }
        }
      }
      up.blankLayer(false)
    	$.ajax({
        url: "/live/upload/doupload",
        data: formData,
        type: "POST",
        contentType: false,
        cache: false,
        processData:false,
        xhr: function(){
          var xhr = $.ajaxSettings.xhr();
          if (xhr.upload) {
              xhr.upload.addEventListener('progress', function(event) {
                var percent = 0;
                var position = event.loaded || event.position;
                var total = event.total;
                if (event.lengthComputable) {
                  percent = Math.ceil(position / total * 100);
                }
               
                up.blankLayer(true)
                // console.log(percent)
                $(".progress-bar").css("width", + percent +"%");
                $(".status").text(percent +"%");
              }, true);
              
          }
          return xhr;

        },
        mimeType:"multipart/form-data"
        }).done(function(res){ //
          up.blankLayer(false)
          up.gridLogProcess()
          up.cekActiveGenerate()
        });
      //   contentType: false,
      //   dataType: "json",
      //   mimeType: 'multipart/form-data',
      //   processData: false,
      //   type: 'POST',
      //   beforeSend: function (jqXHR, settings) {
          
      //   },
      //   success: function (data) {
     
            
      //     	up.gridLogProcess()
      //       up.cekActiveGenerate()
      //   },
      //   error: function (jqXHR, textStatus, errorThrown) {
          
      //   }
      // });  
    }
    $("input[id='uploadFile']").val('')
    $('#listIcon').html("");
    up.statusUploadFiles([]);
    up.statusUpload(true);
    up.totalErrorFile(0);
  }else{
    return swal("Confirmation!", "Please .", "error");
  }
}
up.expand = function(flag){
  var classUp = 'glyphicon-chevron-up'
  var classDown = 'glyphicon-chevron-down'
  $(".icon"+flag).slideToggle("fast", function(){
    $(".icon"+flag).hasClass(classDown) ? $(".icon"+flag).addClass(classUp).removeClass(classDown) : $(".icon"+flag).addClass(classDown).removeClass(classUp)
    $(".icon"+flag).show()
  })
}
up.gridLogProcess = function (IdProcess) {

  $("#GridLogProcess").html("");
  $("#GridLogProcess").kendoGrid({
    dataSource: {
      transport: {
       read:function(option){
            up.gridDone(false)
            ajaxPost("/upload/getuploadlog", {}, function(datas){
              option.success(datas);  
            })
          },
        parameterMap: function (data) {
          return JSON.stringify(data);
        },
      },
      schema: {
        data: function (data) {
          up.gridDone(false);
          if (data.Data.length == 0) {
            return Data;
          } else {
            var Data = data.Data; 
            up.onProcessStatus(false)
            Data.forEach(function (d) {
              persen =  ( d.insertedrows / d.rows ) * 100
              d.Percentage = (d.rows == 0)? 0 :persen;
              switch(d.status){
                case 0:
                    d.statusName = 'Ready'
                break;
                case 1:
                    d.statusName = 'On Process'
                    up.onProcessStatus(true)
                break;
                case 2:
                    d.statusName = 'Failed'
                break;
                case 3:
                    d.statusName = 'Success'
                    if(d.isgenerated == 0){
                      up.enabledBaseGrid(true)
                    }
                break;
                default:
                    d.statusName = 'Failed'
              }  
              year_processdate = d.processdate.split('T')[0].split('-')[0]
              // console.log(year_processdate)
              if(parseInt(year_processdate) < 1950){
                d.processdate = ''
              }
              // if()
            })
            up.gridDone(true)
            up.loadingGrid(false);
            return Data
          }
        },
        total: "Data.length",
      },
      pageSize: 10,
    },
    resizable: true,
    sortable: true,
    pageable: {
      refresh: true,
      pageSizes: true,
      buttonCount: 5
    },
    excel: {
      allPages: true,
      fileName: "log.xlsx"
    },
    columnMenu: false,
    dataBound: function (e) {
      var grid = this;
      $(".progress-detail").each(function () {
        var x = $(this);
        $(this).kendoProgressBar({
          value: x.attr("data-percentage"),
          type: "percent",
          animation: true,
          min: 0,
          max: 100,
        });

      });
    },
    columns: [
      {
        field: "uploaddate",
        title: "Upload Date",
         template: "#if(uploaddate != ''){# #:  kendo.toString(new Date(getUTCDate(getUTCDateFull(uploaddate))), 'dd-MM-yyyy') # #} #",
        width: 150,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "align-left"
        },
      },
      {
        field: "filename",
        title: "File Name",
        width: 150,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "align-left"
        },
      },
      {
        field: "filesize",
        title: "File Size (MB)",
        headerAttributes: {
            "class": "align-right"
        },
        attributes: {
            "class": "align-right"
        },
        width: 150,
        template: "#:kendo.toString(filesize,'N2')#",
      },
      {
        field: "rows",
        title: "Rows",
        width: 150,
        headerAttributes: {
            "class": "align-right"
        },
        attributes: {
            "class": "align-right"
        }
      },
      
      // },
      {
        field: "Percentage",
        title: "Percentage",
        width: 130,
        attributes: {"class": "align-right"},
        headerAttributes: {
            "class": "align-right"
        },
        template: "<div style='width: 100%' data-history='#: #' data-percentage='#: Percentage #' class=\"progress-detail p#: #\"></div>",
      },
      {
        field: "insertedrows",
        title: "inserted Rows",
        width: 130,
        headerAttributes: {
            "class": "align-right"
        },
        attributes: {
            "class": "align-right"
        }
      },
      {
        field: "statusName",
        title: "Status",
        width: 100,
        headerAttributes: {
            "class": "align-left"
        },
        template: " "+
                  "#if(statusName == 'Ready'){# <button  class=\"btn btn-sm pull-left btn-primary\" id=\"raady-button\" onClick='up.doProcess(\"#:_id #\" )' >#:statusName#</button> #}"+
                  "else if(statusName == 'On Process'){# <button  class=\"btn btn-sm pull-left btn-info\" disabled=\"disabled\"  >#:statusName#</button>#}"+
                  "else if(statusName == 'Failed'){# <button class=\"btn btn-sm pull-left btn-danger\" disabled=\"disabled\" >#:statusName#</button> <button class=\"btn btn-sm pull-left btn-danger\" id=\"failed-button\"  onClick='up.doProcess(\"#:_id#\")'>Process</button> #}"+
                  "else if(statusName == 'Success'){#  <button  class=\"btn btn-sm pull-left btn-success\" disabled=\"disabled\">#:statusName#</button>  #}"+
                  "#",
      },
      {
        field: "processdate",
        title: "Processed Date",
        width: 130,
        template: "#if(processdate != ''){# #:  kendo.toString(new Date(getUTCDate(getUTCDateFull(processdate))), 'dd-MM-yyyy') # #} #",
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "align-left"
        },
      
      },
      {
        field: "processdate ",
        title: "Processed Time",
        width: 130,
        template: "#if(processdate != ''){# #: kendo.toString(new Date(getUTCDateFull(processdate)), 'HH:mm:ss')   # #} #",
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "align-left"
        },
         
      }, 
      {
        field: "isgenerated",
        title: "Generated?",
        width: 100,
        headerAttributes: {
          "class": "align-center"
        },
        attributes: {
          "class": "align-center"
        },
        template: "<span class=\"glyphicon #if(isgenerated == 1){# #: 'glyphicon-ok green-icon' # #}else{# #: 'glyphicon-time red-icon' # #}# glyph-custom\"></span>",
      }         
    ]
  });
  up.checkButtonGrid();
  // $('#GridLogProcess').data('kendoGrid').dataSource.read({"Id": IdProcess});
  // var refreshIntervalId = setInterval(function () {
  //   $('#GridLogProcess').data('kendoGrid').dataSource.read({"Id": IdProcess});

  //   var paramInterval = {
  //     "Id": IdProcess,
  //   }
  //   ajaxPost("/uploadfilev2/isprocesstradefinish", paramInterval, function (res) {
  //     if (res.Data == true) {
  //       clearInterval(refreshIntervalId); 
  //     }
  //   });
  // }, 3000);
}
up.checkButtonGrid = function(){
  if(parseInt(up.activeGenerateProperties.total) == 1){
    $('#raady-button').attr('disabled','disabled');
    $('#failed-button').attr('disabled','disabled');
  }else{
    $('#raady-button').removeAttr('disabled');
    $('#failed-button').removeAttr('disabled');
  }
}
up.doProcess = function(id,type){  
  ajaxPost("/upload/doprocess",{_id:id} , function (res){
     if(res.IsError){
        return swal("Confirmation!", res.Message, "error");
     }else{
        $('#GridLogProcess').data('kendoGrid').dataSource.read({});
        up.cekActiveGenerate();
        return swal("Confirmation!", res.Message, "success");  
     }
  })
 
}
up.refreshGrid =  function(){
  up.gridDone(false);
  $('#GridLogProcess').data('kendoGrid').dataSource.read({});
  up.cekActiveGenerate(); 
}
up.cekActiveGenerate =  function(){
  up.getActiveDone(false)
  ajaxPost("/upload/getactivegenerate",{} , function (res){
    up.activeGenerateProperties.total = res.Total
    if(up.activeGenerateProperties.total){
       up.activeGenerateProperties.totalprocess = res.Data.totalprocess;
       up.activeGenerateProperties.processed = res.Data.processed
    }
    up.getActiveDone(true)
    up.checkButtonGrid();
  })
  up.disabledButton();
}
up.disabledButton =  function(){
  check =  setInterval(function(){
    if(up.getActiveDone() && up.gridDone()){
      if(parseInt(up.activeGenerateProperties.total)  === 0){
        if(up.onProcessStatus()){
          $("#generate-button").attr("disabled","disabled");
          var checkGrid = setInterval(function(){
            if(up.gridDone() === true){
              $('#GridLogProcess').data('kendoGrid').dataSource.read({});
              console.log(!up.onProcessStatus()) 
              if(up.onProcessStatus() ===  false){
              console.log('stop',checkGrid) 
                 clearInterval(checkGrid) 
              }
            }
          },2000)
        }else{
          if(up.enabledBaseGrid()){
            $("#generate-button").removeAttr( "disabled" );
          }else{
            $("#generate-button").attr("disabled","disabled");
          }
        }
        up.precentageGenerate(0)
      }else{
        $("#generate-button").attr("disabled","disabled")
        
        if(up.callCheckActiveGenerated()){  
          checkActiveGenerated = setInterval(function(){
            up.callCheckActiveGenerated(false)
            if(up.getActiveDone()){
              if(up.getActiveDone()){
                up.cekActiveGenerate()
                if(parseInt(up.activeGenerateProperties.total) === 1){
                  percentage =  (parseInt(up.activeGenerateProperties.totalprocess) == 0)? 0 : (parseInt(up.activeGenerateProperties.processed) /  parseInt(up.activeGenerateProperties.totalprocess) ) * 100
                  up.precentageGenerate(percentage.toFixed(0)) 
                }else{
                  clearInterval(checkActiveGenerated)
                }
              }
            }
          },2000)
        }else{
          percentage =  (parseInt(up.activeGenerateProperties.totalprocess) == 0)? 0 : (parseInt(up.activeGenerateProperties.processed) /  parseInt(up.activeGenerateProperties.totalprocess) ) * 100
          up.precentageGenerate(percentage.toFixed(0))
        }
      }
      clearInterval(check)
    }
  },3000)
}
up.generate =  function(){
  ajaxPost("/upload/dogenerate",{} , function (res){
     if(res.IsError){
        return swal("Confirmation!", res.Message, "error");
     }else{
        $('#GridLogProcess').data('kendoGrid').dataSource.read({});
        up.cekActiveGenerate();
        return swal("Confirmation!", res.Message, "success"); 
     }
  });
}
$(function(){ 
  up.gridLogProcess()
  up.cekActiveGenerate()
  // up.disabledButton()
})