var Satria  = {
	servicedescription: ko.observable(""),
	DatePict : ko.observable(""),
	receivercountry: ko.observableArray([]),


	productfunction: ko.observable(""),
	productfunctionList: ko.observableArray([]),
};

Satria.Search = function(){
	Satria.ShowDataGridKendo();
}

Satria.ShowDataGridPaost = function() {
	var param =  {
		
    };
    var url = "/satria/getdata";
    ajaxPost(url, param, function(res){
    	Satria.ShowPostChart(res.Data.Records);
    });
}

Satria.ShowPostChart = function(dataSource){
	var EmptyData = [];
	$("#gridsatriacallpost").kendoGrid({
            dataSource: {
                   	data : dataSource,
                   	schema: {
                        data: function(data) {
                        	// console.log(data);
                            if (data == 0) {
                                return EmptyData;
                            } else {
                                return data;
                            }
                        },
                        total: function(total){
                        	console.log(total.length);
                        	return total.length;
                        },
                    },
                    pageSize: 15,
                    // serverPaging: true,
                    // serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                columnMenu: false,
            columns: [
                {
                    field:"Receivercountry",
                    title:"Country",
                    width:200
                }, {
                    field:"Processownername",
                    title:"Name",
                    width:200
                }]
    });
}

Satria.ShowDataGridKendo = function() {
	var param =  {
		"Product" : Satria.productfunction(),
		"Country" : Satria.receivercountry(),
		"Period" : Satria.DatePict(),
		"Status" : $('#cok').bootstrapSwitch('state')
    };
    var dataSource = [];
    var url = "/satria/getdata";
    $("#gridsatriadirect").html("");
    $("#gridsatriadirect").kendoGrid({
            dataSource: {
                    transport: {
                        read: {
                            url: url,
                            data: param,
                            dataType: "json",
                            type: "POST",
                            contentType: "application/json",
                        },
                        parameterMap: function(data) {                                 
                           return JSON.stringify(data);                                 
                        },
                    },
                    schema: {
                        data: function(data) {
                            if (data.Data.Count == 0) {
                                return dataSource;
                            } else {
                                return data.Data.Records;
                            }
                        },
                        total: "Data.Count",
                    },
                    pageSize: 15,
                    serverPaging: true,
                    serverSorting: true,
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                columnMenu: false,
                columns: [
                {
                    field:"Receivercountry",
                    title:"receivercountry",
                    width:200
                }, {
                    field:"receiverlegalentity",
                    title:"receiverlegalentity",
                    width:200
                }, {
                    field:"Processownername",
                    title:"Owner",
                    width:200
                }]
    });
}

Satria.GetDropdownlist = function(){

    var url = "/satria/getfunct";
    ajaxPost(url, {}, function(res){
    	// console.log(res);
    	for (var i in res){
    		Satria.productfunctionList.push({
    			"text" :res[i]._id.productfunction,
    			"value" : res[i]._id.productfunctionid
    		});
    	}
    });
}

Satria.GetData = function(){
    var url = "/dashboard/getgeomap";
    ajaxPost(url,{}, function (res){
        Satria.GeoMapBasic(res);
        // console.log(res);
    });
}      


Satria.GeoMapBasic = function(dataSource){
    var sourcesAttr = []
    for (var i in dataSource) {
        var trxContent = "<div class='MapsMarker'>" +
        "<h6>" + dataSource[i]._id.Country + "</h6>"+
        "<div>"+kendo.toString(dataSource[i].ColTotalAmountUSD,"N2")+"</div>";

        var attr = {
            Location:[parseFloat(dataSource[i]._id.Latitude),parseFloat(dataSource[i]._id.Longitude)],
            Content:trxContent,
            Value:dataSource[i].ColTotalAmountUSD
        }

        sourcesAttr.push(attr);
    }

    console.log(sourcesAttr);

    $("#basicgeomap").kendoMap({
            center: [5.508720,23.178089],
            zoom: 3,
            layers: [{
                type: "tile",
                urlTemplate: "http://#= subdomain #.tile.openstreetmap.org/#= zoom #/#= x #/#= y #.png",
                subdomains: ["a", "b", "c"],
                attribution: "&copy; <a href='http://osm.org/copyright'>OpenStreetMap contributors</a>"
            },{
                type: "bubble",
                maxSize: 25,
                style: {
                    fill: {
                        color: "#317DB5",
                        opacity: 0.5
                    },
                    stroke: {
                        width: 0
                    },
                },
                dataSource: {
                    data: sourcesAttr
                },
                locationField:"Location",
                valueField:"Value",
            }],
            // markers: [{
            //     location: [30.268107, -97.744821],
            //     shape: "pinTarget",
            //     tooltip: {
            //         content: "Austin, TX"
            //     }
            // }]
    });
}

$(document).ready(function () {
	$('#cok').bootstrapSwitch('state', true);
	Satria.GetDropdownlist();
	// Satria.ShowDataGridPaost();
    Satria.GetData();
	// Satria.ShowDataGridKendo();
});