var ts = {}
// ts.config = {
// 				dropDown:"bottom",
// 				multiSelect: ["0","3","1"]
// 			  }
// ts.tamplatePositions = [{name:"MALAYSIA"},{name:"INDIA"}];
// ts.tamplateDS = [{ name: "Jane Doe", age: 30, id: 1 },{ name: "John Doe", age: 33, id: 2 }]		
ts.chart = {
	categoryAxis: [{
    	crosshair: {tooltip: { template: "Year: #: value #",visible: true},
      	visible: true
    },
  	}],
  	series:  [],
  	dataSource: {
		data: []
	}
}

ts.pieChart = {
	title: {
        text: "Pie Chart"
    },
    legend: {
        position: "bottom"
    },
    seriesDefaults: {
        labels: {
            visible: true,
            format: "{0}%"
        }
    },
    series: [{
    	type:"pie",
    	data: []
    }],
  
}

ts.templateMultiSelect = [{name:"MALAYSIA"},{name:"INDIA"},{name:"Standard Chartered Bank Malaysia Berhad"},
{name:"Technology"},{name:"Scope International (M) Sdn Bhd"},{name:"IGS"},{name:"Teams"},{name:"Malware Processes (Protection)"},
{name:"Report SLA Compliance"},{name:"Application Support"},{name:"TECH-RTB-GIS KL"}]

ts.templatePayload   = {
				skip : 1, 
				take : 10, 
				Receivercountry    :[],
				Receiverlegalentity:[],
				Categoryname       :[],
				Suppliercountry    :[],
				Supplierlegalentity:[],
				Suppliertype       :[],
				Suppliername       :[],
				Processname        :[],
				Servicedescription :""
			}
ts.templatePrice = {
    payPrecentage :"",
    colPrecentage :"",
    payVolume:"",
    colVolume:"",
    sliderTotal:""
}
ts.templateSlider = {
    start:"",
    end:""
}
ts.multiSelect = ko.observableArray(ts.templateMultiSelect);
ts.payload   = ko.mapping.fromJS(ts.templatePayload)
ts.price     = ko.mapping.fromJS(ts.templatePrice)
ts.slider    = ko.mapping.fromJS(ts.templateSlider)

ts.gridData = function(data){
    var EmptyData = [];
    $("#grid").kendoGrid({
            dataSource: {
                    data: data.Data.Records,
                    schema: {
                        data: function(data) {
                            // console.log(data);
                            if (data == 0) {
                                return EmptyData;
                            } else {
                                return data;
                            }
                        },
                        total: function(total){
                           
                            return total.length;
                        },
                    }, 
                    pageSize: 15,
                    // serverPaging: true,
                    // serverSorting: true
                },
                resizable: true,
                sortable: true,
                pageable: {
                    refresh: true,
                    pageSizes: true,
                    buttonCount: 5
                },
                columnMenu: false,
                columns: [{
                    field:"Receivercountry",
                    title:"Receivercountry",
                    width:150
                }, 
                {
                    field:"Receiverlegalentity",
                    title:"Receiverlegalentity",
                    width:300
                },
                {
                    field:"Categoryname",
                    title:"Categoryname",
                    width:150
                },
                {
                    field:"Productfunctionid",
                    title:"Productfunctionid",
                    width:150
                },
                {
                    field:"Productfunction",
                    title:"Productfunction",
                    width:150
                },
                {
                    field:"Suppliercountry",
                    title:"Suppliercountry",
                    width:170
                },
                {
                    field:"Supplierlegalentity",
                    title:"Supplierlegalentity",
                    width:300
                },
                {
                    field:"Suppliertype",
                    title:"Suppliertype",
                    width:150
                },
                {
                    field:"IdRaw",
                    title:"IdRaw",
                    width:200
                },
                {
                    field:"Suppliername",
                    title:"Suppliername",
                    width:300
                },
                {
                    field:"Processid",
                    title:"Processid",
                    width:200
                },
                {
                    field:"Processname",
                    title:"Processname",
                    width:900
                },
                {
                    field:"Processownerpsid",
                    title:"Processownerpsid",
                    width:200
                },
                {
                    field:"Processownername",
                    title:"Processownername",
                    width:200
                },
                {
                    field:"Unitheadcriticalpersonname",
                    title:"Unitheadcriticalpersonname",
                    width:200
                },
                {
                    field:"Servicedescription",
                    title:"Servicedescription",
                    width:700
                },
                {
                    field:"Teamcostcentre",
                    title:"Teamcostcentre",
                    width:100
                },
                {
                    field:"Itproduct",
                    title:"Itproduct",
                    width:100
                },
                {
                    field:"Itameuc",
                    title:"Itameuc",
                    width:100
                },
                {
                    field:"Globalteamname",
                    title:"Globalteamname",
                    width:150
                },
                {
                    field:"Doi",
                    title:"Doi",
                    width:100
                },
                {
                    field:"Contractid",
                    title:"Contractid",
                    width:100
                },
                {
                    field:"Slaid",
                    title:"Slaid",
                    width:100
                },
                {
                    field:"Servicefte",
                    title:"Servicefte",
                    width:130
                }]
                
    });
 	// 	ajaxPost('/ocirtranche/getdata',param, function(res){
	//     ts.dataGrid(res)
	// });
}

ts.chartLineData =  function(data){
	var chart = ko.mapping.toJS(ts.chart)
    var series = []
    var DSdata = []
    $.each(data.Data.Records, function(i,val){
        series.push({"field": val.Suppliercountry,"name": val.Suppliercountry, type:"line"})
        var obj = {}
        obj[val.Suppliercountry] = val.Teamcostcentre
        DSdata.push(obj)
    })
    chart.series = series
    chart.dataSource.data = DSdata
    $("#chart-line").kendoChart(chart);

}

ts.chartBarData =  function(data){
	var chart = ko.mapping.toJS(ts.chart)
	var series = []
	var DSdata = []
	$.each(data.Data.Records, function(i,val){
		series.push({"field": val.Suppliercountry,"name": val.Suppliercountry, type:"bar"})
		var obj = {}
		obj[val.Suppliercountry] = val.Teamcostcentre
		DSdata.push(obj)
	})
	chart.series = series
	chart.dataSource.data = DSdata
	$("#chart-bar").kendoChart(chart);
	console.log(chart)
}
ts.chartPieData =  function(data){
	var pieChart = ko.mapping.toJS(ts.pieChart)
	var series = []
	$.each(data.Data.Records, function(i,val){
		series.push({"category": val.Suppliercountry,"value": val.Teamcostcentre})
	})
 
	pieChart.series.data = series
	$.each(pieChart.series, function(i,val){
		val.data = series
	})
	$("#chart-pie").kendoChart(pieChart);
}
ts.setSlider =  function(data){
    slider = ko.mapping.toJS(ts.slider)
    slider.start = data[0]
    slider.end = data[1] 
    ko.mapping.fromJS(slider,ts.slider)
}
ts.radialGaguge = function(){
    price = ko.mapping.toJS(ts.price)
    

    price.payPrecentage = 52.71867612293144;
    price.colPrecentage = 28.293063133281372;
    price.payVolume = 100;
    price.colVolume = 200;
    price.sliderTotal = 1000;

    $("#PricePrecentageChart").kendoRadialGauge({
        pointer: [{
          value: price.payPrecentage, //Payment Blue
          color: "#317DB5",
        }, {
          value: price.colPrecentage, //Collection Green
          color: "#73B576"
        }],
        gaugeArea:{
            height:150
        },
        scale: {
            minorUnit:5,
            startAngle: 0,
            endAngle: 180,
            max: 100,
            min:0
        }
    }); 
   
    $("#PriceRange").html("<input /><input />");
    $("#PriceRange").kendoRangeSlider({
        min: 0,
        max: price.sliderTotal,
        change:function(e){
             ts.setSlider(e.values);
        },
        tooltip: {
            template: "#= selectionStart # - #= selectionEnd #"
        }
    });

   
    ko.mapping.fromJS(price,ts.price)
}
ts.getData = function(){
	param = ko.mapping.toJS(ts.payload)
	ajaxPost("/ocirtranche/getdata",param, function (res){
	 	ts.gridData(res)
	 	ts.chartLineData(res)
	 	ts.chartBarData(res)
	 	ts.chartPieData(res)
        ts.radialGaguge()
	});
} 
ts.cek = function(){
    console.log("---------->");
}
$(function(){
	ts.getData()	
});
// ko.applyBindings(ts)
