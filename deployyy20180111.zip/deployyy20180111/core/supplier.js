var supplier = {};

supplier.receivingCountry     = ko.observable('');
supplier.receivingCountryList = ko.observableArray([]);
supplier.LegalEntity      = ko.observableArray([]);
supplier.LegalEntityList  = ko.observableArray([]);
supplier.mapType       = ko.observable('light');
supplier.properties    = { SecondaryID :"", count:"", percent:""}
supplier.supplierType  = ko.observableArray([])
supplier.showSupplierType         = ko.observable(false);
supplier.onchangeReceiverCountry  = ko.observable(true);
supplier.onchangeLegalEntity      = ko.observable(true);
supplier.showSummaryReceiver      = ko.observable(false);
supplier.templateSummaryReceiver = { SupplierCountry:"", CEF:"", LegalEntity:"", ParentProcess:"", ServiceReady :""};
supplier.summaryReceiver = ko.mapping.fromJS(receiver.templateSummaryReceiver);
supplier.summaryLagalDetails = ko.observableArray([]);
supplier.chartLegal = ko.observableArray([])
supplier.chartConfig = ko.observable({
    legend: {
        visible:true,
        margin:{visible:true,left:-20},
        labels: {
            template: "#if(dataItem.category=='TPS'){# #: 'External' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup' # #}else{# #: 'In-Entity' # #}#",
        },
    },
    seriesDefaults: {
        labels: {
            visible: true,
            template: "#= kendo.toString(percentage,'P0')#",
        }
    },
    tooltip: {
        visible: true,
        template: "#if(dataItem.category=='TPS'){# #: 'External - ' + kendo.toString( dataItem.value, 'n0' )# #}else if(dataItem.category==='Systems'){# #: 'Systems - '+ kendo.toString( dataItem.value, 'n0' ) # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup - '+ kendo.toString( dataItem.value, 'n0' ) # #}else{# #: 'In-Entity - '+ kendo.toString( dataItem.value, 'n0' ) # #}#",            
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
    },
});
supplier.clickIndex = 0;
// supplier.showLegend    = ko.observable(false)
// supplier.showMap        = ko.observable(false)

// supplier.redirectCountryView = function(country){
//     var protocol = window.location.protocol;
//     var host = window.location.hostname;
//     var port = window.location.port;
//     var url;
    
//     if(port !== ''){
//         url = protocol+"//"+host+":"+port
//     }else{
//         url = protocol+"//"+host
//     }
//     var fullURL = url+"/countryview/default?country="+country;
//     window.location.replace(fullURL);
// };
supplier.setReceiver =  function(){
   return function () {
        eraseCookie("supplierCountry");
        eraseCookie("supplierLegalentity");
        eraseCookie("receiverCountry");
        eraseCookie("receiverLegalEntity");
        createCookie("supplierCountry",supplier.receivingCountry()); 
        var receiver = ko.mapping.toJS(supplier.summaryReceiver.SupplierCountry)
        if(receiver.toUpperCase() !== "ALL"){
            createCookie("receiverCountry",receiver); 
        }
        supplier.redirect();
    }  
}
supplier.setlegalEntity =  function(e){
   return function () {

        eraseCookie("supplierCountry");
        eraseCookie("supplierLegalentity");
        eraseCookie("receiverCountry");
        eraseCookie("receiverLegalEntity");

        createCookie("supplierCountry",supplier.receivingCountry()); 
        createCookie("supplierLegalentity",e); 
        var receiver = ko.mapping.toJS(supplier.summaryReceiver.SupplierCountry)
        if(receiver.toUpperCase() !== "ALL"){
            eraseCookie("supplierLegalentity");
            createCookie("receiverCountry",receiver); 
            createCookie("receiverLegalEntity",e); 
        }
        supplier.redirect()
    }  
}
supplier.redirect =  function(){
    window.location.replace("/ociranalysis/default");
     redirectUrl("/ociranalysis/default")
}
supplier.prepareMap =  function(){
    $('#map-supplier').remove();
    $(".panelMapSupplier").append("<div id='map-supplier' class='map'> </div>");
};
supplier.detailsMapTopFive = function(dataSource){
    supplier.showSupplierType(true);
    supplier.prepareMap();
    L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxNWVubjg2MDA2NWZta2tnc2NocnF4ZyJ9.NDWpdAW4qO42qUdRBNIa5Q';
    var mapLeaflet = L.mapbox.map('map-supplier', 'mapbox.'+supplier.mapType(),{'worldCopyJump': true})
      .setView([5.508720,23.178089], 2)
     
    var geoJson = dataSource.BubbleSupplier.features;
    var indexDelete;
    var startLine = {x:dataSource.BoxInfo.Longitude, y:dataSource.BoxInfo.Latitude}  
    $.each(geoJson, function(i,v){
        if(v.properties.parentprocessname <= 5){
            var color = "#7F7F7F";
        }else if(v.properties.parentprocessname <= 20){
            var color = "#b5ce7d";
        }  else {
            var color = "#60B4E4"; 
        }
        var newProperties = {"marker-size": "small","marker-symbol":"marker",'marker-color': color};
        $.extend(true, v.properties,newProperties)
        
        if(v.geometry.coordinates[0].toFixed(0) != dataSource.BoxInfo.Longitude.toFixed(0) || v.geometry.coordinates[1].toFixed(0) != dataSource.BoxInfo.Latitude.toFixed(0)) {         
            
            var endLine = {x:v.geometry.coordinates[0], y: v.geometry.coordinates[1]};
            var generator = new arc.GreatCircle(startLine,endLine,{color: "#CBA23C" });
       
            var line = generator.Arc(200, { offset: 0 });  
            L.geoJson(line.json()).addTo(mapLeaflet);
        }else{
            indexDelete = i
        }
    }); 
    
    (indexDelete === undefined)?'': geoJson.splice(indexDelete,1)
    var boxLabel = dataSource.BoxInfo
    // var labelFte =  (boxLabel.fte=== null)? boxLabel.fte : kendo.toString(boxLabel.fte, 'N1')
    // var templatePopUpReceivingCountry = [
    //                                   "<span style='color:#0644a0'>Supplier Country Data</span>",
    //                                   "<b>"+ supplier.receivingCountry() + "</b>",
    //                                   "Internal Level 1   : "+  kendo.toString(boxLabel.InternalProcessname, 'N0'),
    //                                   "Level 1 Processes  : "+  kendo.toString(boxLabel.Processname, 'N0'),
    //                                   "Supplier Countries : "+   kendo.toString(boxLabel.SupplierCountry, 'N0'),
    //                                   "Suppliers :" + kendo.toString(boxLabel.Suppliercount, 'N0'),
    //                                   "Product Functions :" + kendo.toString(boxLabel.Productfunction, 'N0'),
    //                                   "Allocated Service FTE:" + labelFte ].join("<br>")
 
   var supplierMarker =  L.marker([boxLabel.Latitude, boxLabel.Longitude], {
            icon : L.icon( {
                iconUrl : '/static/img/supplier-marker.png',
            } )
    }).addTo( mapLeaflet );
   

    var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    myLayer.setGeoJSON(geoJson);

    // supplierMarker.on("mouseover", function(e) {
    //    var popup = L.popup()
    //        .setLatLng([boxLabel.Latitude, boxLabel.Longitude]) 
    //        .setContent(templatePopUpReceivingCountry)
    //        .openOn(mapLeaflet);
    // });
    // supplierMarker.on("click", function(e) {
    
    //     var country = supplier.receivingCountry()
    //     supplier.redirectCountryView(country)
    // });
    
    supplierMarker.on("click", function(e) {
        var payloadSummary={
            Suppliertype :  supplier.supplierType(),
            ReceivingCountry :  supplier.receivingCountry(),
            LegalEntity : supplier.LegalEntity(),
            SupplierCountry : ''
        };
        ajaxPost("/supplierview/summarysupplier",payloadSummary , function (res){
            supplier.createSummary(res)
        });
    });
    myLayer.on('click', function(e) {
          var country = e.layer.feature.properties['SecondaryID']
        var payloadSummary={
            Suppliertype :  supplier.supplierType(),
            ReceivingCountry :  supplier.receivingCountry(),
            LegalEntity : supplier.LegalEntity(),
            SupplierCountry : country
        };
        ajaxPost("/supplierview/summarysupplier",payloadSummary , function (res){
            supplier.createSummary(res)
        });
    });
    // myLayer.on('click', function(e) {
    //     var country = e.layer.feature.properties['SecondaryID']
    //     supplier.redirectCountryView(country)   
    // });
   
    // myLayer.on("mouseover", function(e) {
    //     var fte =  (e.layer.feature.properties['fte'] === null)? e.layer.feature.properties['fte'] : kendo.toString(e.layer.feature.properties['fte'] , 'N1')
    //     var templatePopUp = ["<span style='color:#0644a0'>Receiver Country Data</span>",
    //                         "<b>Country Name : " +  e.layer.feature.properties['SecondaryID'] + "</b>",
    //                         "Level1 Processes  : "+  kendo.toString(e.layer.feature.properties['Processname'], 'N0'),
    //                         "Suppliers : "+   kendo.toString(e.layer.feature.properties['Suppliercount'], 'N0'),
    //                         "Product Functions : "+   kendo.toString(e.layer.feature.properties['Productfunction'], 'N0'),
    //                         "Allocated Service FTE : "+  fte ].join("<br>")        
    //     var popup = L.popup()
    //        .setLatLng(e.latlng) 
    //        .setContent(templatePopUp)
    //        .openOn(mapLeaflet);
    // });
    
    $line = $("path[stroke-linejoin='round']");
    $line.attr('stroke-width',"2");
    $line.attr('stroke-opacity',"3");
    $line.attr('stroke',"#3A91B9");
};
supplier.createSummary =function(dataSource){
    var receiverDetails = dataSource.ReceiverDetails;
    var summaryReceiver = ko.mapping.toJS(receiver.summaryReceiver);
        summaryReceiver.SupplierCountry = receiverDetails.SupplierCountry;
        summaryReceiver.CEF = kendo.toString(receiverDetails.CEF, "n0");
        summaryReceiver.LegalEntity = kendo.toString(receiverDetails.LegalEntity,"n0");
        summaryReceiver.ParentProcess = kendo.toString(receiverDetails.ParentProcess,"n0");
        summaryReceiver.ServiceReady = kendo.toString(receiverDetails.ServiceReady,"n1");  
    ko.mapping.fromJS(summaryReceiver,supplier.summaryReceiver)
    
    var legalDetails =  [];
    $.each(dataSource.LegalDetails, function(i,v){
        legalDetails.push({
                            CEF:kendo.toString(v.CEF,"n0"),
                            ParentProcess:kendo.toString(v.ParentProcess,"n0"),
                            ServiceReady:kendo.toString(v.ServiceReady,"n1"),
                            Title:v.Title})
    })
    supplier.summaryLagalDetails(legalDetails)
    supplier.createSupplierEntityDonut(dataSource.LegalDetails); 
};
supplier.getDataFromMarker =  function(){
    eraseCookie("supplierCountry");
    eraseCookie("supplierLegalentity");
    eraseCookie("receiverCountry");
    eraseCookie("receiverLegalEntity");
   
    supplier.showSummaryReceiver(true)
    var payloadDonut = {
        Country : supplier.receivingCountry(),
        LegalEntity: []
    }
    ajaxPost("/supplierview/getdonutreceiver", payloadDonut , function (res){
        supplier.createDonut(res);
        
    });
    clearTimeout(CNUtimeout);
    CNUtimeout = setTimeout(function(){  
        supplier.getlegalEntity();
        var payload={
            Suppliertype :  supplier.supplierType(),
            ReceivingCountry :  supplier.receivingCountry(),
            LegalEntity : []
        }
        ajaxPost("/supplierview/getdetailssupplier", payload, function (res){
            supplier.detailsMapTopFive(res)
        }); 
        var payloadSummary ={
            Suppliertype :  supplier.supplierType(),
            ReceivingCountry :  supplier.receivingCountry(),
            LegalEntity : [],
            SupplierCountry : ''
        } 
        ajaxPost("/supplierview/summarysupplier", payloadSummary , function (res){
            supplier.createSummary(res);
        }) 
    },1000);
    CNUtimeout = setTimeout(function(){  
        supplier.onchangeReceiverCountry(true) 
        supplier.onchangeLegalEntity(true);
    },1000);
};
supplier.mapTopFive = function(dataSource){
    supplier.prepareMap()
    var geoJson =dataSource.features;
    
    $.each(geoJson, function(i,v){
        if(v.properties.count <= 5){
            var color = "#7F7F7F";
        }else if(v.properties.count <= 20){
            var color = "#b5ce7d";
        }  else {
            var color = "#60B4E4"; 
        }
        var newProperties = {"marker-size": "small","marker-symbol":"marker",'marker-color': color}; 
        $.extend(true, v.properties,newProperties)
    });
   
    L.mapbox.accessToken = 'pk.eyJ1IjoiYW5kcmlmZWJyaWgiLCJhIjoiY2lxOXR1djI3MDFseGZ0bTFhbDc0YnoxdSJ9.vo3h2zpopQD9DVMILpkPYg';
    var mapLeaflet = L.mapbox.map('map-supplier', 'mapbox.'+supplier.mapType(),{'worldCopyJump': true})
      .setView([5.508720,23.178089], 2)

    var myLayer = L.mapbox.featureLayer().addTo(mapLeaflet);
    myLayer.setGeoJSON(geoJson);
    
    myLayer.on('click', function(e) {
        var country = e.layer.feature.properties['SecondaryID']
        supplier.onchangeReceiverCountry(false);
        supplier.onchangeLegalEntity(false);
        supplier.receivingCountry(country);
        supplier.getDataFromMarker(); 
    }); 
};
supplier.getData =  function(){  
    eraseCookie("supplierCountry");
    eraseCookie("supplierLegalentity");
    eraseCookie("receiverCountry");
    eraseCookie("receiverLegalEntity");
    if(supplier.receivingCountry() == ''){
        supplier.showSummaryReceiver(false)
        var url = "/supplierview/getdefaultsupplier";
        ajaxPost(url, {}, function (res){
            supplier.mapTopFive(res)
        });
    }else{
        supplier.showSummaryReceiver(true)
        var StringlegalEntitiesValue = supplier.LegalEntity().toString()
        createCookie("supplierCountry",supplier.receivingCountry()); 
        createCookie("supplierLegalentity",StringlegalEntitiesValue); 
        
        var payload={
            Suppliertype :  supplier.supplierType(),
            ReceivingCountry  :  supplier.receivingCountry(),
            LegalEntity : supplier.LegalEntity()
        }
        var url = "/supplierview/getdetailssupplier";
        ajaxPost(url, payload, function (res){
            supplier.detailsMapTopFive(res)
        });
        var payloadSummary={
            Suppliertype :  supplier.supplierType(),
            ReceivingCountry :  supplier.receivingCountry(),
            LegalEntity : supplier.LegalEntity(),
            SupplierCountry : ''
        };
        ajaxPost("/supplierview/summarysupplier",payloadSummary , function (res){
            supplier.createSummary(res);
        });
        var payloadDonut={
            Country : supplier.receivingCountry(),
            LegalEntity:  supplier.LegalEntity()
        }

        ajaxPost("/supplierview/getdonutreceiver", payloadDonut , function (res){
            supplier.createDonut(res);
        });
    }
};
supplier.getlegalEntity = function(){
    var payload = {
        ReceivingCountry : supplier.receivingCountry() 
    };
    var url = "/supplierview/getlegalentitysupplier";
    supplier.LegalEntity([]);

    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        
        legalEntities.push({text:"ALL", value:"ALL"})
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        supplier.LegalEntityList(legalEntities) 
    });
};
var CNUtimeout = setTimeout(function(){
                },1000);
supplier.receivingCountry.subscribe(function(newValue){
    if(supplier.onchangeReceiverCountry() === true){
        supplier.onchangeLegalEntity(false) 
        clearTimeout(CNUtimeout);
        CNUtimeout = setTimeout(function(){  
            supplier.getlegalEntity();
             
            supplier.getData();   
        },1000) 
        CNUtimeout = setTimeout(function(){  
            supplier.onchangeLegalEntity(true) 
        },1000) 
    }
});
supplier.LegalEntity.subscribe(function(newValue){
    if(supplier.onchangeLegalEntity() === true ){
        supplier.getData();
    }
});
supplier.changeMapType = function(e){
    supplier.mapType(e) 
    supplier.getData()
};
supplier.changeSupplierType =  function(){
    var data;
    var $input = $("nav[id='supplier-filter']").find('input[type="checkbox"]');
    var totalInput= $input.length;
    var datas=[];
    if($("nav[id='supplier-filter']").find('input[type="checkbox"]:checked').length === 1){
        $("nav[id='supplier-filter']").find('input[type="checkbox"]:checked').attr( "disabled", "disabled" );
    }else{
        $("nav[id='supplier-filter']").find('input[type="checkbox"]:checked').removeAttr( "disabled");
    }  
    for(var i=0; i < totalInput; i++){
        data = String($("nav[id='supplier-filter']").find('input[type="checkbox"]:checked').eq(i).val())
        if(data != "undefined"){
            datas.push(data)
        }
    }
    
    supplier.supplierType([])
    supplier.supplierType(datas)
    supplier.getData(); 
};
supplier.changeLegendSupplier =  function(e){ 
    var status = 0;
    var datas = supplier.supplierType();
    $.each(datas,function(i,v){
        if(v === e.text){
           datas.splice(i,1);
           $("nav[id='supplier-filter']").find('input[value="'+e.text+'"]').prop('checked',false)
           status = 1;
           return false;
        }
    });
    if(status == 0){ 
        datas.push(e.text)
        $("nav[id='supplier-filter']").find('input[value="'+e.text+'"]').prop('checked',true)
    }
    supplier.supplierType(datas)

    var legalEntitiesValue = [] 
    if(supplier.LegalEntity().length === 0 || supplier.LegalEntity().indexOf("ALL")  > -1 ){ 
         $.each(supplier.LegalEntityList(), function(i,v){
            legalEntitiesValue.push(v.value);
        })
        supplier.LegalEntity("ALL");
    }else{
        legalEntitiesValue = supplier.LegalEntity()
    }
    var StringlegalEntitiesValue = legalEntitiesValue.toString()
    var payload={
        Suppliertype :  supplier.supplierType(),
        ReceivingCountry  :  supplier.receivingCountry(),
        LegalEntity : legalEntitiesValue
    }
    var url = "/supplierview/getdetailssupplier";
    ajaxPost(url, payload, function (res){
        supplier.detailsMapTopFive(res)
    });
};
supplier.getReceivingCountry = function(){

    var url = "/supplierview/getsuppliercountry";
    ajaxPost(url,{}, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        supplier.receivingCountryList(receivingCountries);
    });
};
supplier.initMap = function(e){ 
    if(supplier.receivingCountry() === '' && supplier.clickIndex === 0){

        supplier.getData();
        supplier.clickIndex += 1;
    } 
};
supplier.createDonut = function(dataSource){
    var data = []
    var color =["#5eb74d","#268f00","#0042ba","#2ba6cb"]
   
    $.each(dataSource, function(i, val){    
        data.push({"category" : val._id.suppliertype,"value": val.Count, "color" : color[i]});
    });

    $("#chartsupplier").kendoChart({
        legend: {
            visible:true,
            margin:{visible:true,left:-20},
            labels: {
                template: "#if(dataItem.category=='TPS'){# #: 'External' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup' # #}else{# #: 'In-Entity' # #}#",
            },
        },
        chartArea: {
            height : 200,
            background: "transparent",
            width : 200,
        },
        seriesDefaults: {
              labels: {
                visible: true,
                // template: "#= dataItem.category  + '-' + kendo.toString(percentage,'P0')#",
                template:"#:kendo.toString(percentage,'P0')#"
              }
        },
        series: [{
            type: "donut",
            data: data,
            overlay:{gradient:"none"},
        }],
        valueAxis:{
            visible:false,
            labels: {
              font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
              visible: false,
              format:"{0:P0}",
            },
            majorGridLines: {
                visible: false
            },
        },
        seriesColors:ecisColors,
        tooltip: {
            visible: true,
            template: "#if(dataItem.category=='TPS'){# #: 'External - ' + kendo.toString( dataItem.value, 'n0' )# #}else if(dataItem.category==='Systems'){# #: 'Systems - '+ kendo.toString( dataItem.value, 'n0' ) # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup - '+ kendo.toString( dataItem.value, 'n0' ) # #}else{# #: 'In-Entity - '+ kendo.toString( dataItem.value, 'n0' ) # #}#",            
            font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        },
        legendItemClick: supplier.changeLegendSupplier
    });
};
supplier.createSupplierEntityDonut = function(dataSource){
    var data = []
    var color =["#5eb74d","#268f00","#0042ba","#2ba6cb"]
     
    $.each(dataSource, function(i, val){    
        
        var data2 = []
        $.each(val.DonutChart, function(index, value){ 
            data2.push({"category" : value.suppliertype,"value": value.Count, "color" : color[index]});
        });
        data.push(data2)
        $("#chartsupplier_"+i).kendoChart({
            legend: {
                visible:true,
                margin:{visible:true,left:-20},
                labels: {
                    template: "#if(dataItem.category=='TPS'){# #: 'External' # #}else if(dataItem.category==='Systems'){# #: 'Systems' # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup' # #}else{# #: 'In-Entity' # #}#",
                    },
            },
            chartArea: {
                height : 200,
                background: "transparent",
                width : 200,
            },
            seriesDefaults: {
                  labels: {
                    visible: true,
                    template: "#= kendo.toString(percentage,'P0')#",
                  }
            },
            series: [{
                type: "donut",
                data: data[i],
                overlay:{gradient:"none"},
            }],
            valueAxis:{
                visible:false,
                labels: {
                  font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                  visible: false,
                  format:"{0:P0}",
                },
                majorGridLines: {
                    visible: false
                },
            },
            tooltip: {
                visible: true,
                template: "#if(dataItem.category=='TPS'){# #: 'External - ' + kendo.toString( dataItem.value, 'n0' )# #}else if(dataItem.category==='Systems'){# #: 'Systems - '+ kendo.toString( dataItem.value, 'n0' ) # #}else if(dataItem.category==='IGS'){# #: 'IntraGroup - '+ kendo.toString( dataItem.value, 'n0' ) # #}else{# #: 'In-Entity - '+ kendo.toString( dataItem.value, 'n0' ) # #}#",            

                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
            },

            legendItemClick: receiver.changeLegendSupplier
        });  
    });
     
};
supplier.reset = function(){ 
 supplier.receivingCountry('')
 supplier.LegalEntity([])
 supplier.getData()
};

$(function(){
    supplier.getReceivingCountry();
    $('.carousel-linked-nav > li > a').click(function() {
        var item = Number($(this).attr('href').substring(1));
        $('#myCarousel').carousel(item - 1);
        $('.carousel-linked-nav .active').removeClass('active');
        $(this).parent().addClass('active');
        return false;
    });
    // supplier.getReceivingCountry();
    // $('#myCarousel2').carousel({
    //   interval: 3000
    // });
})