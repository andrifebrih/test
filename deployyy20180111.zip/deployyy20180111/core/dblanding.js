var dbl = {};

dbl.fieldList = ko.observableArray([]);
dbl.fieldValue = ko.observableArray([])
dbl.fieldGrid = ko.observableArray([])

var CNUtimeout = setTimeout(function(){
},1000);

dbl.getDataGrid = function() {
    var fields = ko.mapping.toJS(dbl.fieldGrid())
    var param = {};
    var dataSource = [];
    var url = "/dblanding/getdata";
    $("#dataGrid").html("");
    // for(var i in fields){
    //     fields[i].attributes = {class: "field-ellipsis"}
    // }
    $("#dataGrid").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            schema: {
                data: function(data) {
                    if (data.Data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Data.Records;
                    }
                },
                total: "Data.Count",
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        resizable: true,
        sortable: true,
        scrollable:true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 10,
            pageSizes: [5, 10, 20],
        },
        columnMenu: false,
        columns: fields
    });
}

dbl.reset = function(){
    // return function(){
        dbl.fieldValue([]);
        dbl.prepareData() 
    // }
}

dbl.getData = function(){
    var fieldValue = dbl.fieldValue();
    var fieldList = ko.mapping.toJS(dbl.fieldList);
    var fields = [];
    var defaultWidth = 120;
    var width = 0;
    
    if(fieldValue.length === 0){
        $.each(fieldList,function(i,v){
            width = defaultWidth
            if(v.field === "Legalentity" || v.field === "Teamfunctionname"){
                width = 300;
            }
            var header = {"class": "align-left"};
            var attr = {class: "field-ellipsis"};
            if(v.field == 'Fte'){
                var header = {"class": "align-right"};
                var attr = {class: "align-right"};
            }
            
            fields.push({field:v.field, title:v.desc, width:width, headerAttributes: header,  attributes: attr})
            // fields.push({field:v.field, title:v.desc,width:width})
        });
    }else{
        $.each(fieldValue, function(index,value){
            $.each(fieldList,function(i,v){
                if (v.field == fieldValue[index]){
                    width = defaultWidth
                    if(v.field === "Legalentity" || v.field === "Teamfunctionname"){
                        width = 300;
                    }
                    var header = {"class": "align-left"};
                    var attr = {class: "field-ellipsis"};
                    if(v.field == 'Fte'){
                        var header = {"class": "align-right"};
                        var attr = {class: "align-right"};
                    }
                    fields.push({field:v.field, title:v.desc,width:width,headerAttributes: header,  attributes: attr})
                    // fields.push({field:v.field, title:v.desc,width:width})
                }
            });
        });
    }
    dbl.fieldGrid(fields)
    dbl.getDataGrid();
    localStorage.setItem('filter', JSON.stringify(dbl.fieldValue()));
}

dbl.prepareData = function(){
    var url = "/dblanding/getallcolumn";
    ajaxPost(url,{}, function (res){
        var fields = []
        $.each(res, function(index, result){
            fields.push({"desc" : result.Desc,"field": result.Field});
        });
        dbl.fieldList(fields)
        dbl.getData()
    });
}

dbl.export = function(){
    var param = {};
    ajaxPost("/dblanding/getexcel", param, function(res){
        redirectUrl("/static/temp/LandingPage/"+res.msg)
        // var port=document.location.port;
        // var host = document.location.hostname;
        // if(port==""){ 
        //    window.location.href = "http://"+document.location.hostname+"/static/temp/LandingPage/"+res.msg;
        // }else{ 
        //    window.location.href = "http://"+document.location.hostname+":"+port+"/static/temp/LandingPage/"+res.msg;
        // }
    });
}

$(function(){
   dbl.prepareData();
   // dbl.getData()
   localStorage.setItem('link',location.href.split('?')[0]);
    if(getStringQuery('back')){
         var filter = JSON.parse(localStorage.filter);
        CNUtimeout = setTimeout(function(){
           dbl.fieldValue(filter);
           dbl.getData();
        },1000);
    }
});