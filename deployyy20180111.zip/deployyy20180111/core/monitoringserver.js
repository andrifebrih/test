var monitoringServer = {};

monitoringServer.getData = function(){
	$("#servergrid").kendoGrid({
       	dataSource: {
			transport: {
				read:function(option){
					ajaxPost("/monitoringserver/getdata", {}, function (datas){
						option.success(datas);
					})
				},
				parameterMap: function(data) {
					return JSON.stringify(data);
				},
			},
			schema: {
				data: function(data) {
					if (data.Data.length == 0) {
						return [];
					} else { 
						return data.Data;
					}
				},
				total: "Data.length",
			}, 
		}, 
        columns: [
          {
            field:"db",
            title:'DB Name',
            width:75, 
             headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
          {
            field:"collections",
            title:'Collection (B)',
            width:70, 
            template: "#= kendo.toString(collections,'N2') #",
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis align-right" 
            }
          },
          {
            field: "avgObjSize",
            title:'Size (KB)',
            width: 70,
            template: "#= kendo.toString(avgObjSize,'N2') #",
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis align-right" 
            }
          },             {
            field:"dataSize",
            title:'Data Size (GB)',
            width:70, 
            template: "#= kendo.toString(dataSize,'N2') #",
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis align-right" 
            }
          },
          {
            field:"indexSize",
            title:'Index Size (GB)',
            width:70, 
             headerAttributes: {
             "class": "align-left"
            },
            template: "#= kendo.toString(indexSize,'N2') #",
            attributes: {
              "class": "field-ellipsis align-right" 
            }
          },
          {
            field:"indexes",
            title:'Index (B)',
            width:70, 
            template: "#= kendo.toString(indexes,'N2') #",
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis align-right"
            }
          },
          {
            field:"numExtents",
            title:'No. of Extent',
            width:70,
            template: "#= kendo.toString(numExtents,'N2') #",
            headerAttributes: {
		        	"class": "align-left"
		        },
		        attributes: {
		          "class": "align-right"
		        }
          },
          {
            field:"objects",
            title:'Object (MB)',
            width:70,
            headerAttributes: {
              "class": "align-left"
            },
            attributes: {
              "class": "align-right"
            }
          },
          {
            field:"storageSize",
            title:'Storage Size (GB)',
            width:70,
            template: "#= kendo.toString(storageSize,'N2') #",
            headerAttributes: {
              "class": "align-left"
            },
            attributes: {
              "class": "align-right"
            }
          },
          {
            field:"ok",
            title:'OK',
            width:70,
            headerAttributes: {
              "class": "align-left"
            },
            attributes: {
              "class": "align-left gridred"
            }
          },
        ],
  			resizable: true,
        sortable: true,
        scrollable:{
          virtual: true
        }, 
        pageable: {
          refresh: true,
          pageSizes: true,
          buttonCount: 1, 
          pageSize: 10,
        },
        dataBound: function (e) {
          $("#servergrid").find('.gridred').each(function(index){
            number =  ($(this).text());
            if(number == 1){ 
              $(this).removeClass('gridred').addClass('gridgreen');
            }else{
              $(this).removeClass('gridgreen').addClass('gridred');
            }
        	})
        },
    });
}

$(function(){
	monitoringServer.getData();
});