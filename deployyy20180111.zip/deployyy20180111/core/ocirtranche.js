var OCIRTranche  = {
    receivercountry: ko.observableArray([]),
    receivercountrylist: ko.observableArray([]),
    receiverlegality: ko.observableArray([]),
    receiverlegalitylist: ko.observableArray([]),
    categoryname: ko.observableArray([]),
    categorynamelist: ko.observableArray([]),
    suppliercountry: ko.observableArray([]),
    suppliercountrylist: ko.observableArray([]),
    supplierlegality: ko.observableArray([]),
    supplierlegalitylist: ko.observableArray([]),
    suppliertype: ko.observableArray([]),
    suppliertypelist: ko.observableArray([]),
    suppliername: ko.observableArray([]),
    suppliernamelist: ko.observableArray([]),
    processname: ko.observableArray([]),
    processnamelist: ko.observableArray([]),
    servicedescription: ko.observable(""),
    servicedescriptionlist: ko.observableArray([]),
    // *Servicerefid servicerefid: ko.observableArray([]),
    // *Servicerefid servicerefidList: ko.observableArray([]),
    processing:ko.observable(false)
};

var CNUtimeout = setTimeout(function(){
},1000);

OCIRTranche.Search = function(){
	OCIRTranche.ShowDataGridKendo();
}

OCIRTranche.ShowDataGridKendo = function() {
    var param =  {
        "Receivercountry" : OCIRTranche.receivercountry(),
        "Receiverlegalentity" : OCIRTranche.receiverlegality(),
        "Categoryname" : OCIRTranche.categoryname(),
        "Suppliercountry" : OCIRTranche.suppliercountry(),
        "Supplierlegalentity" : OCIRTranche.supplierlegality(),
        "Suppliername" : OCIRTranche.suppliername(),
        "Suppliertype" : OCIRTranche.suppliertype(),
        "Processname" : OCIRTranche.processname(),
        "Servicedescription" : OCIRTranche.servicedescription(),
        //*Servicerefid  "Servicerefid": OCIRTranche.servicerefid()
    };
    var dataSource = [];
   
    var url = "/ocirtranche/getdata";    
    $("#grid-ocirtranche").html("");
    var newColumn = [];
    $("#grid-ocirtranche").kendoGrid({
        dataSource: {
            transport: {
                read:function(options){
                    var par = param;
                    par.filter = options.data.filter
                    par.page = options.data.page
                    par.pageSize = options.data.pageSize
                    par.skip = options.data.skip
                    par.sort = options.data.sort
                    par.take = options.data.take
                    ajaxPost(url,par,function(res){ //here
                        $("#receivercountrys").html("Receiver Country "+res.Data.CountInfo.receivercountry)
                        $("#receiverlegalentity").html("Receiver Legal Entity "+res.Data.CountInfo.receiverlegalentity)
                        $("#categoryname_").html("Category Name "+res.Data.CountInfo.categoryname_)
                        $("#subgroupid").html("Product Function ID "+res.Data.CountInfo.subgroupid)
                        $("#productfunction").html("Product Function "+res.Data.CountInfo.productfunction)
                        $("#suppliercountrys").html("Supplier Country "+res.Data.CountInfo.suppliercountry)
                        $("#supplierlegalentity").html("Supplier Legal Entity "+res.Data.CountInfo.supplierlegalentity)
                        $("#suppliertypes").html("Supplier Type "+res.Data.CountInfo.suppliertype)
                        $("#servicerefid").html("Service Ref ID "+res.Data.CountInfo.servicerefid)
                        $("#supplierid").html("Supplier ID "+res.Data.CountInfo.supplierid)
                        $("#suppliernames").html("Supplier Name "+res.Data.CountInfo.suppliername)
                        $("#psgid").html("Process ID "+res.Data.CountInfo.psgid)
                        $("#processnames").html("Process Name "+res.Data.CountInfo.processname)
                        $("#processownerid").html("Process Owner PSID "+res.Data.CountInfo.processownerid)
                        $("#pfpprocessowner").html("Process Owner Name "+res.Data.CountInfo.pfpprocessowner)
                        $("#checker").html("Unit Head / ITO SME / Critical Person Name "+res.Data.CountInfo.checker)
                        $("#servicedescriptions").html("Service Description "+res.Data.CountInfo.servicedescription)
                        $("#teamcostcentre").html("Team Cost Center "+res.Data.CountInfo.teamcostcentre)
                        $("#itbusiness").html("IT Product/Business Service "+res.Data.CountInfo.itbusiness)
                        $("#itameuc").html("ITAM/EUC "+res.Data.CountInfo.itameuc)
                        $("#globalteamname").html("Global Team Name "+res.Data.CountInfo.globalteamname)
                        $("#doi").html("DOI "+res.Data.CountInfo.doi)
                        $("#contractid").html("Contract ID "+res.Data.CountInfo.contractid)
                        $("#slaid").html("SLA ID "+res.Data.CountInfo.slaid)
                        $("#servicefte").html("Service FTE "+res.Data.CountInfo.servicefte)
                        $("#active").html("Active "+res.Data.CountInfo.active)
                        options.success(res);
                    });
                }
                // read: {
                //     url: url,
                //     data: param,
                //     dataType: "json",
                //     type: "POST",
                //     contentType: "application/json",
                // },
                // parameterMap: function(data) {                                 
                //    return JSON.stringify(data);                                 
                // },
            },
            schema: {
                data: function(data) {      
                    if (data.Data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Data.Records;
                    }   
                },
                total: "Data.Count",
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,

        },
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        resizable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 5,
            pageSizes: [5, 10, 20],
        },
        columnMenu: false,
        columns:[
            {
                field:"Receivercountry",
                headerTemplate:"<span id='receivercountrys'>Receiver Country</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150
            }, {
                field:"Receiverlegalentity",
                title:"Receiver Legal Entity",
                headerTemplate:"<span id='receiverlegalentity'>Receiver Legal Entity</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200,
                    attributes: {
                        "class": "field-ellipsis"
                    }
            }, {
                field:"categoryname_",
                title:"Category Name",
                headerTemplate:"<span id='categoryname_'>Category Name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150
            }, {
                field:"Subgroupid",
                title:"Product Function ID",
                headerTemplate:"<span id='subgroupid'>Product Function ID</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            }, {
                field:"Productfunction",
                title:"Product Function",
                headerTemplate:"<span id='productfunction'>Product Function</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150
            }, {
                field:"Suppliercountry",
                title:"Supplier Country",
                headerTemplate:"<span id='suppliercountrys'>Supplier Country</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            }, {
                field:"Supplierlegalentity",
                title:"Supplier Legal Entity",
                headerTemplate:"<span id='supplierlegalentity'>Supplier Legal Entity</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100,
                    attributes: {
                        "class": "field-ellipsis"
                    }
            }, {
                field:"Suppliertype",
                title:"Supplier Type",
                headerTemplate:"<span id='suppliertypes'>Supplier Type</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:120
            }, {
                field:"Servicerefid",
                title:"Service Ref ID",
                headerTemplate:"<span id='servicerefid'>Service Ref ID</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:120
            }, {
                field:"Supplierid",
                title:"Supplier ID",
                headerTemplate:"<span id='supplierid'>Supplier ID</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:120
            }, {
                field:"Suppliername",
                title:"Supplier Name",
                headerTemplate:"<span id='suppliernames'>Supplier Name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200,
                    attributes: {
                        "class": "field-ellipsis"
                    }
            }, {
                field:"Psgid",
                title:"Process ID",
                headerTemplate:"<span id='psgid'>Process ID</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:120
            }, {
                field:"Processname",
                title:"Process Name",
                headerTemplate:"<span id='processnames'>Process Name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200,
                    attributes: {
                        "class": "field-ellipsis"
                    }
            }, {
                field:"Processownerid",
                headerTemplate:"<span id='processownerid'>Process Owner PSID</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            }, {
                field:"Pfpprocessowner",
                headerTemplate:"<span id='pfpprocessowner'>Process Owner Name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            }, {
                field:"Checker",
                headerTemplate:"<span id='checker'>Unit Head / ITO SME / Critical Person Name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200,                
                    attributes: {
                        "class": "field-ellipsis"
                    }
            }, {
                field:"Servicedescription",
                headerTemplate:"<span id='servicedescriptions'>Service Description</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100,
                    attributes: {
                        "class": "field-ellipsis"
                    }
            }, {
                field:"Teamcostcentre",
                headerTemplate:"<span id='teamcostcentre'>Team Cost Center</span>",
                headerAttributes: {
                    "class": "align-right"
                },
                width:100,
                attributes: {"class": "align-right"}
            }, {
                field:"Itbusiness",
                headerTemplate:"<span id='itbusiness'>IT Product/Business Service</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150
            }, {
                field:"Itameuc",
                title:"ITAM/EUC",
                headerTemplate:"<span id='itameuc'>ITAM/EUC</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            }, {
                field:"Globalteamname",
                headerTemplate:"<span id='globalteamname'>Global Team Name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            }, {
                field:"Doi",
                headerTemplate:"<span id='doi'>DOI</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            }, {
                field:"Contractid",
                headerTemplate:"<span id='contractid'>Contract ID</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            }, {
                field:"Slaid",
                headerTemplate:"<span id='slaid'>SLA ID</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            }, {
                field:"Servicefte",
                headerTemplate:"<span id='servicefte'>Service FTE</span>",
                headerAttributes: {
                    "class": "align-right"
                },
                width:100,
                attributes: {"class": "align-right"}
            }, {
                field:"Active",
                headerTemplate:"<span id='active'>Activess</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100,
                template: "#if(Active=='Y'){# #: 'Active' # #}else{# #: 'Inactive' # #}#"
            },{
                field:"Parentprocessname",
                headerTemplate:"<span id='active'>Parent Process Name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200
            },{
                field:"Status",
                headerTemplate:"<span id='active'>Status</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Contractresolution",
                headerTemplate:"<span id='active'>Contract Resolution Critical>/span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Perpetualcontractresolution",
                headerTemplate:"<span id='active'>Perpetual Contract</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Contractavailable",
                headerTemplate:"<span id='active'>Contract Available</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Teamtotal",
                headerTemplate:"<span id='active'>Team total</span>",
                headerAttributes: {
                    "class": "align-right"
                },
                width:100,
                attributes: {"class": "align-right"}
            },{
                field:"ftepercentage",
                headerTemplate:"<span id='active'>Fte Percentage</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Slainplace",
                headerTemplate:"<span id='active'>Fte Percentage</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Slasection",
                headerTemplate:"<span id='active'>SLA Section</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Lastupdated",
                headerTemplate:"<span id='active'>Last Updated</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Pfpcritical",
                headerTemplate:"<span id='active'>PFP Critical</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Cefcritical",
                headerTemplate:"<span id='active'>CEF Critical</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Buildingid",
                headerTemplate:"<span id='active'>Building ID</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Contractresolutionlangproofed",
                headerTemplate:"<span id='active'>Contract Resolution lang Proofed</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150
            },{
                field:"Contractmeetspra",
                headerTemplate:"<span id='active'>Contract meets PRA</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Sladescription",
                headerTemplate:"<span id='active'>SLA description</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200
            },{
                field:"Contractdescription",
                headerTemplate:"<span id='active'>Contract Description</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Legalcontractsignatory",
                headerTemplate:"<span id='active'>Legal Contract Signatory</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Iscontractglobal",
                headerTemplate:"<span id='active'>IsContract global</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Contractmanagername",
                headerTemplate:"<span id='active'>Contract Manager name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Armslengthchargingstructure",
                headerTemplate:"<span id='active'>Arms Length Charging Structure</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Slamanagername",
                headerTemplate:"<span id='active'>Sla Manager Name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200
            },{
                field:"Backtobackslareference",
                headerTemplate:"<span id='active'>Back To Back Sla Reference</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Slabasisforrecharge",
                headerTemplate:"<span id='active'>SLA Basis For Recharge</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Iscrefid",
                headerTemplate:"<span id='active'>ISC Ref Id</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Iscdescription",
                headerTemplate:"<span id='active'>ISC Description</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Iscreceivercountries",
                headerTemplate:"<span id='active'>ISC Receiver Countries</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Systemshublocation",
                headerTemplate:"<span id='active'>Systems Hub Location</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Hublocationcountry",
                headerTemplate:"<span id='active'>hub location Country</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Slaocircompliant",
                headerTemplate:"<span id='active'>SlA OCIR Compliant</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Slaparentreference",
                headerTemplate:"<span id='active'>SLA Parent Reference</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:100
            },{
                field:"Functionname",
                headerTemplate:"<span id='active'>Function Name</span>",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200
            }
        ]
    });
    localStorage.setItem('filter', JSON.stringify(param));
}

OCIRTranche.GetReceiverCountry = function(){
    ajaxPost("/ocirtranche/getreceivecountry", {}, function(res){
        for (var i in res){
            OCIRTranche.receivercountrylist.push({
                "text" : res[i]._id,
                "value" : res[i]._id
            });
        }
    });
}

OCIRTranche.GetReceiverLegality = function(){    
    ajaxPost("/ocirtranche/getreceiverlegalentity", {}, function(res){
        for (var i in res){
            OCIRTranche.receiverlegalitylist.push({
                "text" : res[i]._id,
                "value" : res[i]._id
            });
        }
    });
}

OCIRTranche.GetCategory = function(){   
    ajaxPost("/ocirtranche/getcategoryname", {}, function(res){
        for (var i in res){
            OCIRTranche.categorynamelist.push({
                "text" : res[i]._id,
                "value" : res[i]._id
            });
        }
    });
}

OCIRTranche.GetSupplierCountry = function(){
    ajaxPost("/ocirtranche/getsuppliercountry", {}, function(res){
        for (var i in res){
            OCIRTranche.suppliercountrylist.push({
                "text" : res[i]._id,
                "value" : res[i]._id
            });
        }
    });
}

OCIRTranche.GetSupplierLegality = function(){
   ajaxPost("/ocirtranche/getsupplierlegalentity", {}, function(res){
        for (var i in res){
            OCIRTranche.supplierlegalitylist.push({
                "text" : res[i]._id,
                "value" : res[i]._id
            });
        }
    });
}

OCIRTranche.GetSupplierType = function(){
    ajaxPost("/ocirtranche/getsuppliertype", {}, function(res){
        for (var i in res){
         var results;
           if(res[i]._id == 'IGS'){
            results = "Intra-Group"
          } else if(res[i]._id == 'TPS'){
            results = "External"
          } else if(res[i]._id == 'Teams'){
            results = "In-Entity"
          } else {
            results = "Systems"
          } 
            OCIRTranche.suppliertypelist.push({
                "text" : results,
                "value" : res[i]._id
            });
        }
    });
}

OCIRTranche.GetSupplierName = function(){
    ajaxPost("/ocirtranche/getsuppliername", {}, function(res){
        for (var i in res){
            OCIRTranche.suppliernamelist.push({
                "text" : res[i]._id,
                "value" : res[i]._id
            });
        }
    });
}

OCIRTranche.GetProcessName = function(){
    ajaxPost("/ocirtranche/getprocessname", {}, function(res){
        for (var i in res){
            OCIRTranche.processnamelist.push({
                "text" : res[i]._id,
                "value" : res[i]._id
            });
        }
    });
}

OCIRTranche.GetServiceDescription = function(){
    ajaxPost("/ocirtranche/getservicedescription",{} , function (res){
        for (var i in res){
            OCIRTranche.servicedescriptionlist.push({
                "text" : res[i]._id,
                "value" : res[i]._id
            });
        }
    })
}

OCIRTranche.export = function(){
    var param =  {
        "Receivercountry" : OCIRTranche.receivercountry(),
        "Receiverlegalentity" : OCIRTranche.receiverlegality(),
        "Categoryname" : OCIRTranche.categoryname(),
        "Suppliercountry" : OCIRTranche.suppliercountry(),
        "Supplierlegalentity" : OCIRTranche.supplierlegality(),
        "Suppliername" : OCIRTranche.suppliername(),
        "Suppliertype" : OCIRTranche.suppliertype(),
        "Processname" : OCIRTranche.processname(),
        "Servicedescription" : OCIRTranche.servicedescription(),
    };
    ajaxPost("/ocirtranche/getexcel", param, function(res){
         redirectUrl("/static/temp/OcirTranche/"+res.msg)
        // var port=document.location.port;
        // var host = document.location.hostname;
        // if(port==""){ 
        //    window.location.href = "http://"+document.location.hostname+"/static/temp/OcirTranche/"+res.msg;
        // }else{ 
        //    window.location.href = "http://"+document.location.hostname+":"+port+"/static/temp/OcirTranche/"+res.msg;  
        // }
    });

} 

OCIRTranche.reset = function(){
    return function(){
        OCIRTranche.receivercountry([]); 
        OCIRTranche.receiverlegality([]); 
        OCIRTranche.categoryname([]); 
        OCIRTranche.suppliercountry([]); 
        OCIRTranche.supplierlegality([]); 
        OCIRTranche.suppliertype([]); 
        OCIRTranche.suppliername([]); 
        OCIRTranche.processname([]); 
        // *Servicerefid OCIRTranche.servicerefid([]);
        OCIRTranche.servicedescription('');
        OCIRTranche.ShowDataGridKendo();
    }
}

$(document).ready(function () {
    OCIRTranche.GetReceiverCountry();
    OCIRTranche.GetReceiverLegality();
    OCIRTranche.GetCategory();
    OCIRTranche.GetSupplierCountry();
    OCIRTranche.GetSupplierLegality();
    OCIRTranche.GetSupplierType();
    OCIRTranche.GetSupplierName();
    OCIRTranche.GetProcessName();
    OCIRTranche.GetServiceDescription();
   // *Servicerefid OCIRTranche.GetServicerefid();

    localStorage.setItem('link',location.href.split('?')[0]);
    if(getStringQuery('back')){
        var filter =  JSON.parse(localStorage.filter);   
        CNUtimeout = setTimeout(function(){
            OCIRTranche.receivercountry(filter.Receivercountry); 
            OCIRTranche.receiverlegality(filter.Receiverlegalentity); 
            OCIRTranche.categoryname(filter.Categoryname); 
            OCIRTranche.suppliercountry(filter.Suppliercountry); 
            OCIRTranche.supplierlegality(filter.Supplierlegalentity); 
            OCIRTranche.suppliertype(filter.Suppliername); 
            OCIRTranche.suppliername(filter.Suppliertype); 
            OCIRTranche.processname(filter.Processname); 
            OCIRTranche.servicedescription(filter.Servicedescription);
        },5000);
    }
    OCIRTranche.ShowDataGridKendo();
});