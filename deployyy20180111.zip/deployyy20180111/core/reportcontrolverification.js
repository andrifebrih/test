rcv = {}
rcv.reportNameList  = ko.observableArray([
											{value:"CEF Sign-Off Status",text:"CEF Sign-Off Status"}
										]); 
rcv.reportName = ko.observableArray([]);

rcv.countryList = ko.observableArray([]);
rcv.country = ko.observable('');

rcv.legalEntitiyList = ko.observableArray([]);
rcv.legalEntity = ko.observableArray([]);

rcv.businessList = ko.observableArray([]);
rcv.business = ko.observable('');

rcv.productList = ko.observableArray([]);
rcv.product = ko.observableArray([]);
rcv.lastcefassmtdateList = ko.observableArray([]);
rcv.lastcefassmtdate = ko.observable('');

rcv.nextcefassmtdateList = ko.observableArray([]);
rcv.nextcefassmtdate = ko.observable('');

rcv.emailTo = ko.observableArray([]);
rcv.emailCc = ko.observableArray([]);
rcv.emailValue = ko.observable({mailsubject:"", mailmsg:"", mailto:[], mailcc:[] ,pdffile:"", excelfile:"", excelfolder:""}); 
rcv.loadingProcess = ko.observable(false);
rcv.showGridLegalEntity = ko.observable(true);

rcv.listFilter = ko.observableArray([]);
rcv.valueFilter = ko.observable('');
rcv.valueCreateNewFilter = ko.observable('');

var CNUtimeout = setTimeout(function(){
    },1000);

rcv.getCountry = function(){
    var payload = {
        LegalEntity : rcv.legalEntity(),
        Business : rcv.business(),
        Product : rcv.product()
    };
    var url = "/reportcontrolverification/getcountry";
    ajaxPost(url,payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({text:v._id, value:v._id})
        });
        rcv.countryList(receivingCountries);
    })
};
rcv.getLegalEntity = function(){
    var payload = {
    	Country  : rcv.country(), 
        Business  : rcv.business(),
        Product  : rcv.product()
    };
    var url = "/reportcontrolverification/getlegalentity";
    ajaxPost(url,payload, function (res){
        var legalEntities = [];
        $.each(res, function(i,v){
            legalEntities.push({text:v._id, value:v._id})
        });
        rcv.legalEntitiyList(legalEntities);
        if(legalEntities.length  == 1){
            rcv.showGridLegalEntity(false);
        }else{
            rcv.showGridLegalEntity(true);
        }
    })
};
rcv.getBusiness = function(){
    var payload = {
    	Country  : rcv.country(),
        LegalEntity : rcv.legalEntity(),
        Product  : rcv.product()
    };
    var url = "/reportcontrolverification/getbusinessfunction";
    ajaxPost(url,payload, function (res){
        var business = []
        $.each(res, function(index, result){
            business.push({"text" : result._id,"value": result._id});
        });
        rcv.businessList(business);
    });
};
rcv.getProduct = function(){
	var payload = {
    	Country  : rcv.country(),
        LegalEntity : rcv.legalEntity(),
        Business : rcv.business()
    }; 
    var url = "/reportcontrolverification/getproduct";
    ajaxPost(url,payload, function (res){
        var products = []
        $.each(res, function(index, result){
           products.push({text:result._id, value:result._id})
        });
        rcv.productList(products);
    });
};
rcv.createGrid = function(payload){
	var dataSource = [];
    var url = "/reportcontrolverification/getdatacontrolverification";
    var coloumn = [{
        field:"categoryname",
        title:"Business Function", 
        width:200,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "field-ellipsis"
        }
    },{
        field:"subgroupname",
        title:"Product", 
        width:200,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "field-ellipsis"
        }
    },{
        field:"status",
        title:"Status",
        width:80,
        template: "<span class=\"glyphicon #if(status== 'true'){# #: 'glyphicon-ok green-icon' # #}else{# #: 'glyphicon-remove red-icon' # #}# glyph-custom\"></span>",
        headerAttributes: {
            "class": "align-center"
        },
        attributes: {
            "class": "align-center"
        }
    },{
        field:"ceo",
        title:"CEO", 
        width:200,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "field-ellipsis"
        }
    },{
        field:"function_head",
        title:"Function Head", 
        width:200,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "field-ellipsis"
        }
    },{
        field:"delegate",
        title:"Delegate", 
        width:200,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "field-ellipsis"
        }
    },{
        field:"lastcefassmtdate",
        title:"Last Assesment Date", 
       
        width:150,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "align-left"
        }
    },{
        field:"nextcefassmtdate",
        title:"Next Assesment Date", 
        width:150,
        headerAttributes: {
            "class": "align-left"
        },
        attributes: {
            "class": "align-left"
        }
    }]
    if(rcv.showGridLegalEntity()){
        coloumn.unshift({
            field:"country",
            title:"Country",
            width:225,
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "field-ellipsis"
            }
        })
    }
    $("#grid-report").html("");
    $("#grid-report").kendoGrid({
        dataSource: {
            transport: {
                read: {
                    url: url,
                    data: payload,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {                                 
                   return JSON.stringify(data);                                 
                },
            },
            schema: {
                data: function(data) {
                    
                    if (data.length == 0) {
                        return dataSource;
                    } else {
                         data.forEach(function (d) {
                            d.country = d.countryname + ' - ' + d.receiverlegalentity
                        })
                        return data
                    }
                },
            },
            pageSize: 10,
            serverPaging: false,
            serverSorting: false,
        },
        resizable: true,
        scrollable: true,
        sortable: true,
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 10
        },
        columnMenu: false,
        columns:coloumn
    });
};
rcv.getData =  function(){
	var payload = {
		report:rcv.reportName(),
        country : rcv.country(),
        legalEntity : rcv.legalEntity(),
        business : rcv.business(),
        product : rcv.product(),
        Lastdate : rcv.lastcefassmtdate(),
        Nextdate : rcv.nextcefassmtdate()
    };
    rcv.createGrid(payload);
};
rcv.download =  function(type){
	return function(){
        var payload = {
            Country     : rcv.country(),
            LegalEntity : rcv.legalEntity(),
            Business    : rcv.business(),
            Product     : rcv.product()
        };
		if(type == "excel"){
          rcv.loadingProcess(true)  
            ajaxPost("/reportcontrolverification/getexcel",payload , function (res){
                console.log(res)
                var port=document.location.port;
                var host = document.location.hostname;
                if(port==""){ 
                  rcv.loadingProcess(false)
                    redirectUrl("/static/temp/ControlVerification/"res.msg)
                  // window.location.href = "http://"+document.location.hostname+"/static/temp/ControlVerification/"+res.msg;
                }else{
                  rcv.loadingProcess(false)
                    redirectUrl("/static/temp/ControlVerification/"res.msg)
                  // window.location.href = "http://"+document.location.hostname+":"+port+"/static/temp/ControlVerification/"+res.msg;  
                }
            })
            var payload = {
              Type : "ReportControlVerification Grid Excel"
            }
            ajaxPost("/analyticuser/downloadlog", payload, function (res){
            })
        }else{  
            rcv.loadingProcess(true)
            ajaxPost("/reportpdf/controlrpt",payload , function (res){
                console.log(res)
                var port=document.location.port;
                var host = document.location.hostname;
                if(port==""){ 
                   // window.location.href = "http://"+document.location.hostname+"/static/temp/pdf/"+res.Data;
                   rcv.loadingProcess(false)

                   rediretUrl("/static/temp/pdf/"res.msg)
                   // window.open("http://"+document.location.hostname+"/static/temp/pdf/"+res.Data)
                }else{ 
                   // window.location.href = "http://"+document.location.hostname+":"+port+"/static/temp/pdf/"+res.Data;  
                   rcv.loadingProcess(false)
                  rediretUrl("/static/temp/pdf/"res.msg)
                   // window.open("http://"+document.location.hostname+":"+port+"/static/temp/pdf/"+res.Data)
                }
            })
            var payload = {
              Type : "ReportControlVerification Grid PDF"
            }
            ajaxPost("/analyticuser/downloadlog", payload, function (res){
            })
        }
	}
};

rcv.sendEmail = function(){
    var payloadFile = {
        Country     : rcv.country(),
        LegalEntity : rcv.legalEntity(),
        Business    : rcv.business(),
        Product     : rcv.product()
    };
    for (var i in rcv.emailTo()){ 
        rcv.emailValue().mailto.push(rcv.emailTo()[i].id)
    }
    for (var i in rcv.emailCc()){ 
        rcv.emailValue().mailcc.push(rcv.emailCc()[i].id)
    }  
    rcv.loadingProcess(true);
    ajaxPost("/reportcontrolverification/getexcel",payloadFile , function (res1){
        rcv.emailValue().excelfile = res1.msg
        rcv.emailValue().excelfolder = "ControlVerification"
        ajaxPost("/reportpdf/controlrpt",payloadFile , function (res2){
            rcv.emailValue().pdffile = res2.Data
            ajaxPost("/reportpdf/sendmail",rcv.emailValue() , function (res3){
                if (!res3.IsError){
                    rcv.loadingProcess(false); 
                    swal("Email Sent", "", "success");
                    $("#ModalEmail").modal("hide");
                    rcv.resetField();
                }else {
                    rcv.loadingProcess(false);
                    swal("Error!",res3.Data, "error"); 
                }
            })    
        })
    }) 
};
rcv.getLastDAte = function(){ 
    ajaxPost("/reportcontrolverification/getlistlastcef",{} , function (res){
        var dates = [] 
        $.each(res, function(i,v){
           month = (model.getMonthName((kendo.toString(new Date(v._id),'MM'))-1));
           year = kendo.toString(new Date(v._id),'yyyy')
           date = month + "-" + year
           dateValue = kendo.toString(new Date(v._id),'dd-MM-yyyy')
           dates.push({text:date,value:dateValue})
        })
        rcv.lastcefassmtdateList(dates)
    })
};
rcv.getNextDate = function(){
    ajaxPost("/reportcontrolverification/getlistnextcef",{} , function (res){
        var dates = [] 
        $.each(res, function(i,v){
           month = (model.getMonthName((kendo.toString(new Date(v._id),'MM'))-1));
           year = kendo.toString(new Date(v._id),'yyyy')
           date = month + "-" + year
           dateValue = kendo.toString(new Date(v._id),'dd-MM-yyyy')
           dates.push({text:date,value:dateValue})
        })
        rcv.nextcefassmtdateList(dates)
    })
};
rcv.reportName.subscribe(function(newValue){
	rcv.getCountry();
    rcv.getLegalEntity();
    rcv.getBusiness();
    rcv.getProduct();   
});
rcv.country.subscribe(function(newValue){
    rcv.getLegalEntity();
    rcv.getBusiness();
    rcv.getProduct(); 

    if(rcv.country() == ''){
    	rcv.getCountry();
    }
    CNUtimeout = setTimeout(function(){
                    rcv.getData();
                 },2000);
});
rcv.legalEntity.subscribe(function(newValue){
	rcv.getCountry();
    rcv.getBusiness();
    rcv.getProduct()
    
    if(rcv.legalEntity().length == 0){
    	rcv.getLegalEntity();
    }
    if(rcv.legalEntity().length == 1){
        rcv.showGridLegalEntity(false)
    }
    CNUtimeout = setTimeout(function(){
                    rcv.getData();
                 },2000);
});
rcv.business.subscribe(function(newValue){
	rcv.getCountry();
    rcv.getLegalEntity(); 
    rcv.getProduct();

    if(rcv.business().length == 0){
    	rcv.getBusiness();
    }
    CNUtimeout = setTimeout(function(){
                    rcv.getData();
                 },2000);
});
rcv.product.subscribe(function(newValue){
	rcv.getCountry();
    rcv.getLegalEntity(); 
    rcv.getBusiness();
 
    if(rcv.product().length == 0){
    	rcv.getProduct();
    }
    CNUtimeout = setTimeout(function(){
                    rcv.getData();
                 },2000);
});
rcv.lastcefassmtdate.subscribe(function(newValue){

    CNUtimeout = setTimeout(function(){
                    rcv.getData();
                 },2000);
});
rcv.nextcefassmtdate.subscribe(function(newValue){

    CNUtimeout = setTimeout(function(){
                    rcv.getData();
                 },2000);
});
rcv.resetField = function(){
    rcv.emailValue().mailsubject = ""; 
    rcv.emailValue().mailmsg = "" ;
    rcv.emailValue().mailto = []; 
    rcv.emailValue().mailcc = [];
    rcv.emailValue().pdffile = "" ;
    rcv.emailValue().excelfile = "" ;
    rcv.emailValue().excelfolder = "";
    $("#emailCc").tokenInput("clear");
    $("#emailTo").tokenInput("clear");
    $("#subjectMail").val("");
    $("#msgMail").val("");
};
rcv.saveFilter = function(){
    var payload = {
        Report      :rcv.reportName(),
        Country     : rcv.country(),
        LegalEntity : rcv.legalEntity(),
        Business    : rcv.business(),
        Product     : rcv.product(),
        Lastdate    : rcv.lastcefassmtdate(),
        Nextdate    : rcv.nextcefassmtdate(),
        Submenu     : "ReportControlVerification",
        Name        : rcv.valueCreateNewFilter()
    }
    var status = 0
    var validator = $("#newFilterName").data("kendoValidator");

    if(validator ==  undefined){
        validator = $("#newFilterName").kendoValidator().data("kendoValidator");
    }

    if (validator.validate()){
        for (var i in rcv.listFilter()){
            if (rcv.listFilter()[i]._id == "ReportControlVerification"+rcv.valueCreateNewFilter()){
                swal({   
                    title: "Are you sure?",   
                    text: "Filter name already exist",   
                    type: "warning",   
                    showCancelButton: true,   
                    confirmButtonColor: "#3F9E35",   
                    confirmButtonText: "Yes, edit it!",   
                    cancelButtonText: "No, cancel",   
                    closeOnConfirm: false,   
                    closeOnCancel: false 
                }, 
                function(isConfirm){   
                    if (isConfirm) {     
                        save();   
                    } else {     
                        swal("Cancelled", "", "error");
                        return;   
                    } 
                });
            }else {
                status = status+1;
                if (status == rcv.listFilter().length){
                    save();
                }
            }
        }
    }else {
        swal("Error!","Filter name cannot be empty", "error"); 
    }

    function save(){
        ajaxPost("/reportcontrolverification/savereportconfig",payload , function (res){
            if (res.Success){
                swal("Success", "Filter name saved", "success");
                rcv.valueCreateNewFilter('');   
                rcv.getListFilter();
            }else {
                swal("Error!",'failed to save', "error"); 
            }
        })
    }
}
rcv.changeFilterValue = function(e){  
    var selected = e.sender._selectedValue; 
    rcv.valueFilter(selected);  
    if (selected !== ''){
        $.each(rcv.listFilter(), function(k, v){      
            if (v._id == selected){
                rcv.reportName(v.Report)
                rcv.country(v.Country)
                rcv.legalEntity(v.LegalEntity)
                rcv.business(v.Business)
                rcv.product(v.Product)
                rcv.lastcefassmtdate(v.Lastdate)
                rcv.nextcefassmtdate(v.Nextdate)     
            }
        })  
    }else {
        rcv.showGridLegalEntity(true);
        rcv.reportName('')
        rcv.country('')
        rcv.business('')
        rcv.legalEntity([])
        rcv.product([])
        rcv.lastcefassmtdate('')
        rcv.nextcefassmtdate('')     
    } 
}
rcv.getListFilter = function(){
    var payload = {
        Submenu : "ReportControlVerification"
    };
    ajaxPost("/reportcontrolverification/getnameconfig",payload , function (res){
        rcv.listFilter(res);
    })
}

rcv.CreateTokenInputEmail = function(){
    $("#emailTo").tokenInput([], {
        zindex: 700,
        noResultsText: "Add New Email",
        allowFreeTagging: true,
        placeholder: 'Type Email Here',
        tokenValue: 'id',
        propertyToSearch: 'key',
        theme: "facebook",
        onAdd: function (item) {
            if (validateEmailFormat(item.key)){
                rcv.emailTo.push(item);  
                $("#alertMessage1").hide();
            }else {
                $("#alertMessage1").text(item.key+" is not valid email !");
                $("#alertMessage1").show()
                this.tokenInput("remove", {id: item.key});
                setTimeout(function() {
                    $("#alertMessage1").hide();
                }, 5000);
            }
        },
        onDelete: function (item) {
            rcv.emailTo.remove(item);  
        }
    });

    $("#emailCc").tokenInput([], { 
        zindex: 700,
        noResultsText: "Add New Email",
        allowFreeTagging: true,
        placeholder: 'Type Email Here',
        tokenValue: 'id',
        propertyToSearch: 'key',
        theme: "facebook",
        onAdd: function (item) {
            if (validateEmailFormat(item.key)){
                rcv.emailCc.push(item);  
                $("#alertMessage2").hide();
            }else {
                $("#alertMessage2").text(item.key+" is not valid email !");
                $("#alertMessage2").show()
                this.tokenInput("remove", {id: item.key});
                setTimeout(function() {
                    $("#alertMessage2").hide();
                }, 5000);
            }
        },
        onDelete: function (item) {
            rcv.emailCc.remove(item);  
        }
    });
};
$(function(){
    rcv.getCountry();
    rcv.getLegalEntity();
    rcv.getBusiness();
    rcv.getProduct();
    rcv.getLastDAte();
    rcv.getNextDate();
    rcv.getData();
    date = 	model.getDateMinOne()
    fullDate =  model.getDaysName(date.getDay()) +", "+ date.getDate() + " "+ model.getMonthName(date.getMonth()) + " " + date.getFullYear(); 
    $("#fullDate-text").text(fullDate)
    rcv.CreateTokenInputEmail();
    rcv.getListFilter(); 
 
})