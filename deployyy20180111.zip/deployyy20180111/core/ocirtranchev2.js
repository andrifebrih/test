        var ot2  = {};
ot2.onchangefieldValue = ko.observable(true);
ot2.fieldList  = ko.observableArray([]);
ot2.fieldValue = ko.observableArray([]);
ot2.fieldGrid  = ko.observableArray([]);
ot2.dbname  = ko.observable('');
ot2.dbnameList  = ko.observableArray([
    {value:"",text:"Service Catalgoue"},
    {value:"dblanding",text:"Teams Data"},
    {value:"Staff",text:"Staff Details Report"},
    {value:"Systems",text:"Systems Details Report"},
    {value:"MPP",text:"Mapping Process Report"},
    {value:"CEF",text:"CEF Assessment Report"},
]);
ot2.secondGrid = ko.observable(false);
ot2.valueUnique = ko.observableArray([]);
ot2.loaderExportExcel = ko.observable(false);
var CNUtimeout = setTimeout(function(){
},1000);

ot2.dbname.subscribe(function(){
    ot2.onchangefieldValue(false)
    ot2.fieldValue([]);
    var urlcolumn = "";
    if (ot2.dbname() == "dblanding") {
        urlcolumn = "/dblanding/getallcolumn";
        ot2.prepareData(urlcolumn);
    }else{
        urlcolumn = "/ocirtranchev2/getallcolumn";
        ot2.prepareData(urlcolumn);
    };
        ot2.onchangefieldValue(true) 
});

ot2.fieldValue.subscribe(function(){
    if(ot2.onchangefieldValue() === true){
        ot2.getData();
    }
})

ot2.valueUnique.subscribe(function(){
    if (ot2.valueUnique()[0] == 'Yes') {
        ot2.secondGrid(true); 
        if (ot2.fieldValue() == '' && ot2.dbname() == '') {
            ot2.secondGrid(false);
            ot2.getDataGrid();
        }else{
            ot2.secondGrid(true); 
            ot2.uniqueData();
        };
    }else {
        ot2.secondGrid(false);
        ot2.getDataGrid();         
    }
})

ot2.getDataGrid = function() {
    var fields  = ko.mapping.toJS(ot2.fieldGrid())
    var param =  {
        DBType : ot2.dbname(),
        Unique : ot2.fieldValue(),
    };
    var dataSource = [];
        url = "/live/ocirtranchev2/getdata";

    $("#dataGrid").html("");
    $("#dataGrid").kendoGrid({
        dataSource: {
            transport: {
                // read:function(option){
                //     ajaxPost(url, param, function(datas){
                        
                //         option.success(datas);
                //     })
                // },
                // parameterMap: function(data) {
                //     return JSON.stringify(data);
                // },

                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {

                   return JSON.stringify(data);
                },
            },
            schema: {
                data: function(data) {
                      console.log(fields);
                     console.log(data.Records);
                    if (data.Count == 0) {
                        return dataSource;
                    } else {
                        return data.Records;
                    }
                },
                total: function (data) {
                    return data.Count;
                }
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
        },
        resizable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        sortable: true,
        scrollable:{
            virtual: true
        },
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1,
            pageSize: 20,
            pageSizes: [5, 10, 20],
        },
        columnMenu: false,
        columns: fields
    });
}

ot2.reset = function(){
    // return function(){
        ot2.fieldValue([]);
        ot2.dbname([]);
        ot2.prepareData(); 
        ot2.valueUnique([]);
    // }
}

ot2.getData = function(type){
    var fieldValue = ot2.fieldValue();
    var fieldList = ko.mapping.toJS(ot2.fieldList) ;
    var fields = [];
    var defaultWidth = 150;
    var width = 0;
    
    if(fieldValue.length === 0){
        $.each(fieldList,function(i,v){
            width = defaultWidth
            if(v.field === "processname" || v.field === "legalentity" || v.field === "teamfunctionname"){
                width = 300;
            }
            var header = {"class": "align-left"};
            var attr = {class: "field-ellipsis"};
            if(v.field == 'teamcostcentre' || v.field == 'servicefte' || v.field == 'teamtotal' || v.field == 'fte'){
                var header = {"class": "align-right"};
                var attr = {class: "align-right"};
            }
            fields.push({field:v.field, title:v.title, width:width, headerAttributes:header,  attributes:attr})    
        });
    }else{
        $.each(fieldValue, function(index,value){
            $.each(fieldList,function(i,v){
                if (v.field == fieldValue[index]){
                    width = defaultWidth
                    if(v.field === "processname" || v.field === "legalentity" || v.field === "teamfunctionname"){
                        width = 300;
                    }
                    var header = {"class": "align-left"};
                    var attr = {class: "field-ellipsis"};
                    if(v.field == 'teamcostcentre' || v.field == 'servicefte' || v.field == 'teamtotal' || v.field == 'fte'){
                        var header = {"class": "align-right"};
                        var attr = {class: "align-right"};
                    }
                    fields.push({field:v.field, title:v.title, width:width, headerAttributes:header,  attributes:attr})
                    // fields.push({field:v.field.toLowerCase(), title:v.title, width:width, headerAttributes:header,  attributes:attr})
                }
            });
        });
    }
    ot2.fieldGrid(fields);
    if (ot2.valueUnique()[0] == 'Yes') {
        if (ot2.fieldValue() == '' && ot2.dbname() == '') {
            ot2.getDataGrid();
            ot2.secondGrid(false);     
        }else{
            ot2.uniqueData();
            ot2.secondGrid(true);
        }; 
    }else {
        ot2.getDataGrid();       
        ot2.secondGrid(false);
    }
    localStorage.setItem('filter', JSON.stringify(ot2.fieldValue()));      
}

ot2.prepareData = function(urlcolumn){
    if (urlcolumn == undefined || urlcolumn == "") {
        urlcolumn = "/ocirtranchev2/getallcolumn";
    };
    var payload = { 
        DBType : ot2.dbname(),
    }
    ajaxPost(urlcolumn,payload, function (res){
        var fields = []
        $.each(res, function(index, result){       
            fields.push({"title" : result.title,"field": result.field});
        });
        ot2.fieldList(fields)
        ot2.getData()
    });
}

ot2.uniqueData = function(){
    var fields  = ko.mapping.toJS(ot2.fieldGrid())
    var param = {
        DBType : ot2.dbname(),
        Unique : ot2.fieldValue(),
    };
    console.log("unique")
    var url = "/live/ocirtranchev2/getdataunique";

    $("#dataGrid2").html("");
    $("#dataGrid2").kendoGrid({
        dataSource: {
            transport: {
                // read:function(option){
                //     ajaxPost(url, param, function(datas){
                        
                //         option.success(datas);
                //     })
                // },
                // parameterMap: function(data) {
                //     return JSON.stringify(data);
                // },

                read: {
                    url: url,
                    data: param,
                    dataType: "json",
                    type: "POST",
                    contentType: "application/json",
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            schema: {
                data: function(data) {
                    var v = [];
                    if (data.Count == 0) {
                        return dataSource;
                    } else {
                        for(var i in data.Records){
                            v.push(data.Records[i]._id);
                        }
                        return v;
                    }
                },
                total: function (data) {
                    return data.Count;
                }
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
        },
        resizable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        sortable: true,
        scrollable:{
            virtual: true
        },
        pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1,
            pageSize: 20,
            pageSizes: [5, 10, 20],
        },
        columnMenu: false,
        columns: fields
    });
}

ot2.export = function(){ 
    if (ot2.valueUnique()[0] == 'Yes'){
        var param = {
            DBType : ot2.dbname(),
            Unique : ot2.fieldValue(),
            filter : $("#dataGrid2").data("kendoGrid").dataSource._filter
        };

        var url = "/ocirtranchev2/getexcelunique";

        ot2.loaderExportExcel(true)
        ajaxPost(url, param, function(res){
          
            var port=document.location.port;
            var host = document.location.hostname;
            
            ot2.loaderExportExcel(false)
            redirectUrl("/static/temp/databrowser/"+res.msg);
        });
    }else {
        var field = []
        if(ot2.fieldValue() == ''){
            $.each(ot2.fieldList(), function(index, result){       
                field.push(result.field);
            });
        }else{
            field = ot2.fieldValue()
        }
        var param = {
            DBType : ot2.dbname(),
            Field : field,
            filter : $("#dataGrid").data("kendoGrid").dataSource._filter
        };
        var url = "/ocirtranchev2/getexceldefault";

        ot2.loaderExportExcel(true)
        ajaxPost(url, param, function(res){
            var interval =setInterval(function(){

                var id =  res.msg;
                ajaxPost("/ocirtranchev2/getjobstatus",{Jobid:res.msg}, function(result){
                    if(result.status == "Done"){
                        ot2.loaderExportExcel(false)
                        clearInterval(interval);
                         redirectUrl("/static/temp/databrowser/"+id)
                    }
                })
            },2000)
            
            interval;

            // var port=document.location.port;
            // var host = document.location.hostname;
            // if(port==""){ 
            //    window.location.href = "http://"+document.location.hostname+"/static/temp/databrowser/"+res.msg;
            // }else{ 
            //    window.location.href = "http://"+document.location.hostname+":"+port+"/static/temp/databrowser/"+res.msg;  
            // }
        });
    }
 
    var payload = {
      Type : "Selfservice Drilldown Grid"
    }
    ajaxPost("/analyticuser/downloadlog", payload, function (res){
    })
}

$(function(){
   ot2.prepareData();  
   localStorage.setItem('link',location.href.split('?')[0]);
    if(getStringQuery('back')){
         var filter =  JSON.parse(localStorage.filter);
        CNUtimeout = setTimeout(function(){
           ot2.fieldValue(filter);
           ot2.getData();  
        },1000);
    }
});