var au = {}
au.dataMostUser = ko.mapping.fromJS([])
au.dataMostVisited = ko.mapping.fromJS([])
au.viewAllMostVisited = ko.observable(false)
au.loadUserDetailChart = ko.observable(false)
au.loadUserDetailGrid  = ko.observable(false)
au.loadMenuDetailChart = ko.observable(false)
au.loadMenuDetailGrid = ko.observable(false)

au.multicharBar = function(){  
  ajaxPost("/analyticuser/actionperdate","", function (res){
    locale = "en-us",
 
  $.each(res.Get, function(i,v){
    var d = new Date(v.SortString);
    v.SortString =  d.getDate()+ " "+ d.toLocaleString(locale, { month: "short" }) + " " +d.getFullYear() ;
   })

  $.each(res.Save, function(i,v){

    var d = new Date(v.SortString);
    v.SortString =  d.getDate()+ " "+ d.toLocaleString(locale, { month: "short" }) + " " +d.getFullYear() ;
  
  })

  $.each(res.Download, function(i,v){

    var d = new Date(v.SortString);
    v.SortString =  d.getDate()+ " "+ d.toLocaleString(locale, { month: "short" }) + " "  +d.getFullYear() ;
    
     
  })

  $.each(res.Search, function(i,v){
    var d = new Date(v.SortString);
    v.SortString =  d.getDate()+ " " + d.toLocaleString(locale, { month: "short" }) + " " +d.getFullYear() ;
    
    
  })
    $("#analytic-chart-bar").kendoChart({
      title: {
        text: "Acces Monitor",
        align: "left", 
        font: "bold 18px Helvetica Neue",
        padding:{
          left:-5
        }
      },
      chartArea: { 
        background: "",
        height:385
      },
      legend: {
        position: "bottom"
      },
      seriesDefaults: {
        overlay: {
          gradient: "none"
        },
      },
      // categoryField: "SortString",
      series:[{ 
        type : "line",
        field: 'Count',
        categoryField: "SortString",
        data: res.Get,
        color: "#026BA2",
        name : 'Get Data',
        border: {
          color: "#026BA2"
        },
      },{
        type : "line",
        field: 'Count',
        categoryField: "SortString",
        data: res.Save,
        color: "#69BE28", 
        name : 'Save Data'
      },{
        type : "line",
        field: 'Count',
        categoryField: "SortString",
        data: res.Download,
        color: "#FFB533", 
        name : 'Download'
      },{
        type : "line",
        field: 'Count',
        categoryField: "SortString",
        data: res.Search,
        color: "#939598", 
        name : 'Search'
      }],
      categoryAxis:[{
        majorGridLines: {
          visible: false
        }
      }],
      valueAxis: [{
        majorGridLines: {
          visible: false
        }
      }],
      tooltip: {
        visible: true
      } 
    }); 
  })
}
au.mostUser =  function(){
  ajaxPost("/analyticuser/mostuser","", function (res){
    ko.mapping.fromJS(res,au.dataMostUser)     
  });
}
au.mostVisited =  function(){ 
  ajaxPost("/analyticuser/mostvisited","", function (res){

    ko.mapping.fromJS(res,au.dataMostVisited)     
  });
}
au.chartBAr =  function(id,dataSource){
  if(dataSource.length > 0 ){
    // var max = Enumerable.From(dataSource).Max("$.Count") * 1.4;
    if ( dataSource.length == 1){
      $("#"+id).replaceWith('<div id="'+id+'">/div>')
      $("#"+id).css('height', (dataSource.length * 60) + 'px') 
    }
    else if (dataSource.length <= 7){
      $("#"+id).replaceWith('<div id="'+id+'"></div>')
      $("#"+id).css('height', (dataSource.length * 52) + 'px') 
    }else {
      $("#"+id).css('height','400px')
    }
  }
  $("#"+id).kendoChart({
    dataSource: {
      data:dataSource,
   
      dataType: "json"
    },
    legend :{
      position :"top",
      margin:{
        visible:true,
        top:40
      },
      font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
    },
    transitions: false,
    seriesDefaults: {
      type: "bar",
      overlay: {
        gradient: "none"
      },
      tooltip: {
        visible: false,
        template: "#:kendo.toString(Count,'N0')#"
      }, 
      labels: {
        font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
        color: "#002951",
        visible: true,
        position:"outsideEnd",  
        background: "transparent"
      },
      gap: 0.3,
      color: "#005C84",
    },
    series: [{
      field: "Count",
      border: {
        width: 1,
        color: "transparent"
      },
      color: "#005C84"}],
    categoryAxis :{
      field : "_id",
      labels: {
        template: labelTemplate,
        font: "12px Helvetica Neue, Helvetica, Arial, sans-serif",
      },
      majorGridLines: {
        visible: false
      },
      line:{
        visible:false
      }
    },
    valueAxis:{
      // max: max,
      majorGridLines: {
        visible: false,
      },
      line: {
        visible: false
      },
      labels:{
        visible:false,
      },
    },
    tooltip: {
      visible: true,
      format: "n0",
    },
    seriesColors: ["#66DBFF"],
    
    seriesHover: function(e) {
      setTimeout(function(){
        $("#"+id +" g path").each(function (idx){
          var op = $(this).attr('stroke-opacity');
          if (op == 0.2){
              $(this)
              .attr('fill','#002951')
              .attr('fill-opacity', 1)
          };
        }); 
      },10);
    }
  });
  var isFound = false
  jQuery('#'+id+' g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
    if (isFound) return
    if ($(e).html() == '') isFound = true
    $(e).find('text').attr('x', 0)
  })
  function labelTemplate(e) {
    var finalStm = "";
    var maxlen = 16;
    var Spl = e.value.split(" ");
    var lenStm = 0;
    $.each(Spl, function(i, o){
      lenStm = lenStm + o.length + 1;
      var tb = "";
      if (lenStm <= maxlen) {
        tb = " ";
      } else {
        lenStm = 0;
        tb = "\n";
      }
      if (i == 0) {
        tb = "";
      }
      finalStm = finalStm + tb + o;
    });
    return finalStm
  }
  var chart = $('#'+id).data("kendoChart"),
  firstSeries = chart.options.series;
  firstSeries[0].gap = parseFloat(0.3, 10);
  chart.redraw();
  alignLegendLeft(id);
}
function alignLegendLeft(id) {
  var isFound = false
  jQuery('#'+id+' g > g:eq( 0 ) > g:gt( 3 )').each(function (i, e) {
    if (isFound) return
    if ($(e).html() == '') isFound = true
     $(e).find('text').attr('x', 0)
  })
}
function clickshowDetailVisited(title,refer){
  return function(){
    au.showDetailVisited(title,refer)
  }
}
function clickshowDetailUser(id){
  return function(){
    au.showDetailUser(id)
  }
}
function orderDSchartBar(ds){
  $.each(ds,function(index,value){
      for(var i=0; i<(ds.length-1); i++){
        if(ds[i].Count < ds[i+1].Count){
          var old = ds[i+1];
          ds[i+1] = ds[i]
          ds[i] = old
        }
      }
  }) 
  return ds;
}
au.showDetailUser = function(id){
  // return function(){
    $('#modal-all-user').modal('hide');
    au.loadUserDetailChart(true);
    au.loadUserDetailGrid(true);
    detailUser_click = false;
    $('#user-name-modal').text(id)
 
    $("#chart-detail-user").html("");
    $("#modal-detail-user").modal("show");
    $("#tab-modal-detail-user ul").find('li').removeClass('active')
    $("#tab-modal-detail-user ul li:eq(0)").addClass('active')
    $("#tab-modal-detail-user" ).tabs( {active:0});

    ajaxPost("/analyticuser/chartuser", {User:id}, function (res){
      dsChart = orderDSchartBar(res.chart) 
      au.chartBAr('chart-detail-user', dsChart);
      au.loadUserDetailChart(false)
    });
    
    $('#detail-user').click(function(){ 
      if(!detailUser_click){
        detailUser_click =  true
        $("#grid-detail-user").html("");
        $("#grid-detail-user").kendoGrid({
          dataSource: {
            transport: {
              read: {
                url: "/live/analyticuser/detailuser",
                data: {User:id},
                dataType: "json",
                type: "POST",
                contentType: "application/json",
              },
              parameterMap: function(data) {
                return JSON.stringify(data);
              },
            },
            schema: {
              data: function(data) {
                au.loadUserDetailGrid(false);
                if ( data.Count == 0) {
                  return [];
                } else {
                  return data.Records;
                }
              },
                // total: "Data.Count",
              total: function (data) {
                return data.Count;
              }
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
          },
          resizable: true,
          filterable: {
            extra:false, 
            operators: {
              string: {
                contains: "Contains",
                startswith: "Starts with",
                eq: "Is equal to",
                neq: "Is not equal to",
                doesnotcontain: "Does not contain",
                endswith: "Ends with"
              },
            }
          },
          sortable: true,
          scrollable:{
            virtual: true
          }, 
          pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1, 
            pageSize: 10,
            pageSizes: [5, 10, 20]
          },
          columnMenu: false,
          columns: [
            {
              field:"action",
              title:'Action',
              width:100,
              // filterable: false,
              attributes: {
                "class": "field-ellipsis"
              }
            },
            {
              field:"loadingtimes",
              title:'Loading Times',
              width:100,
              // filterable: false,
              attributes: {
                "class": "field-ellipsis"
              }
            },
            {
              field:"requestaddr",
              title:'Request Addr',
              width:100
            },
            {
              field:"time",
              title:'Time',
              width:100,
              template: "#if(time != ''){# #:  kendo.toString(new Date(getUTCDate(getUTCDateFull(time))), 'dd-MM-yyyy hh:mm:ss') # #} #",
              // filterable: false,
              attributes: {
                "class": "field-ellipsis"
              }
            }
          ],
        });
      }
    })
}
au.showDetailVisited =  function(title,refer){
  // return function(){
    $('#modal-all-visited').modal('hide');
    au.loadMenuDetailChart(true)
    au.loadMenuDetailGrid(true)
    detailMenu_click = false;
    $('#menu-name-modal').text(title)
    $("#grid-detail-menu").html("");
    $("#chart-detail-menu").html("");
    $("#modal-detail-menu").modal("show");
    $("#tab-modal-detail-menu ul").find('li').removeClass('active')
    $("#tab-modal-detail-menu ul li:eq(0)").addClass('active')
    $("#tab-modal-detail-menu" ).tabs( {active:0});
    
    var payload = {
      Title : title,
      Refer : refer
    }
    ajaxPost("/analyticuser/chartmenu", payload, function (res){
      dsChart = orderDSchartBar(res.chart) 
      console.log(dsChart)
      au.chartBAr('chart-detail-menu', dsChart);
      au.loadMenuDetailChart(false)
    });
    $('#detail-menu').click(function(){
      if(!detailMenu_click){
        detailMenu_click =  true;
        $("#grid-detail-menu").html("");
        $("#grid-detail-menu").kendoGrid({
          dataSource: {
            transport: {
              read: {
                url: "/live/analyticuser/detailmenu",
                data: payload,
                dataType: "json",
                type: "POST",
                contentType: "application/json",
              },
              parameterMap: function(data) {
                return JSON.stringify(data);
              },
            },
            schema: {
              data: function(data) {
                au.loadMenuDetailGrid(false);
                if ( data.Count == 0) {
                  return [];
                } else {
                  return data.Records;
                }
              },
                // total: "Data.Count",
              total: function (data) {
                return data.Count;
              }
            },
            pageSize: 10,
            serverPaging: true,
            serverSorting: true,
            serverFiltering: true,
          },
          columns: [
            {
              field:"action",
              title:'Action',
              width:100,
              // filterable: false,
              attributes: {
                "class": "field-ellipsis"
              }
            },
            // {
            //   field:"description",
            //   title:'Description',
            //   width:150,
            //   // filterable: false,
            //   attributes: {
            //     "class": "field-ellipsis"
            //   }
            // },
            {
              field:"loadingtimes",
              title:'Loading Times',
              width:100,
              // filterable: false,
              attributes: {
                "class": "field-ellipsis"
              }
            },
            {
              field:"loginid",
              title:'Login Id',
              width:100,
            },
            //   {
            //   field:"reference",
            //   title:'Reference',
            //   width:150,
            //   attributes: {
            //     "class": "field-ellipsis"
            //   }
            // },
            {
              field:"requestaddr",
              title:'Request Addr',
              width:100
            },
            // {
            //   field:"sessionid",
            //   title:'Session Id',
            //   width:150
            // },
            {
              field:"time",
              title:'Time',
              width:100,
              template: "#if(time != ''){# #:  kendo.toString(new Date(getUTCDate(getUTCDateFull(time))), 'dd-MM-yyyy hh:mm:ss') # #} #",
              // filterable: false,
              attributes: {
                "class": "field-ellipsis"
              }
            }
          ],
          resizable: true,
          filterable: {
            extra:false, 
            operators: {
              string: {
                contains: "Contains",
                startswith: "Starts with",
                eq: "Is equal to",
                neq: "Is not equal to",
                doesnotcontain: "Does not contain",
                endswith: "Ends with"
              },
            }
          },
          sortable: true,
          scrollable:{
            virtual: true
          },
          pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1, 
            pageSize: 10,
            pageSizes: [5, 10, 20],
          },
          columnMenu: false,
        });
      }
    })
}
au.showAllVisited =  function(){
  return function(){
    data = ko.mapping.toJS(au.dataMostVisited)
    console.log(data)
    $("#modal-all-visited").modal("show");
    $("#grid-all-visited").html("");
    $("#grid-all-visited").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              option.success(data);
            },
            parameterMap: function(data) {
              return JSON.stringify(data);
            },
          },
        },
        columns: [
        {
          field:"_id",
          title:'File',
          width:150,
          attributes: {
            "class": "field-ellipsis"
          }
        },
        {
          field:"Count",
          title:'Viewed',
          width:100,
          // filterable: false,
         
          attributes: {"class": "align-right"},
          headerAttributes: {
            "class": "align-right"
          },
          template: "#if(Count !== 0){# <a href=\"\\#\" onclick= 'au.showDetailVisited(\"#:_id#\",\"#:Title#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
            
        }
        ],
        sortable: true,
        filterable: {
          extra:false,
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        pageable: {
          numeric: false,
          previousNext: false,
          messages: {
            display: "Showing {2} data items"
          }
        },
        height: 380,
    });
    setTimeout(function() {
      $('#grid-all-visited .k-grid-content').height(300);
    },300)

    // positonBottom = $('.bottom-table-most-visited').position()
    // var classUp = 'glyphicon-chevron-up'
    // var classDown = 'glyphicon-chevron-down'
    // $( ".table-most-visited .disable" ).slideToggle( "slow");
    // positonBottom = $('.bottom-table-most-visited').position()
    // if( $("#expand-most-visited").hasClass(classDown)){
    //   $("#expand-most-visited").addClass('glyphicon-chevron-up').removeClass('glyphicon-chevron-down')
    // }else{
    //   $("#expand-most-visited").addClass(classDown).removeClass(classUp);
    // } 
    // $("html, body").animate({ scrollTop: $(document).height() }, positonBottom);
  }
}
au.showAllUser =  function(){
  return function(){
    data = ko.mapping.toJS(au.dataMostUser)
    $("#modal-all-user").modal("show");
    $("#grid-all-user").html("");
    $("#grid-all-user").kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              option.success(data);
            },
            parameterMap: function(data) {
              return JSON.stringify(data);
            },
          },
        },
        columns: [
        {
          field:"_id",
          title:'File',
          width:150,
          attributes: {
            "class": "field-ellipsis"
          }
        },
        {
          field:"Count",
          title:'Viewed',
          width:100,
          // filterable: false,
         
          attributes: {"class": "align-right"},
          headerAttributes: {
            "class": "align-right"
          },
          template: "#if(Count !== 0){# <a href=\"\\#\" onclick= 'au.showDetailUser(\"#:_id#\")'>#:kendo.toString(Count,'N0')#</a> #}else { ##:kendo.toString(Count,'N0')## }#",
          
        }
        ],
        sortable: true,
        filterable: {
          extra:false,
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        pageable: {
          numeric: false,
          previousNext: false,
          messages: {
            display: "Showing {2} data items"
          }
        },
        height: 380,
    });
    setTimeout(function() {
      $('#grid-all-user .k-grid-content').height(300);
    },300)
    // positonBottom = $('.bottom-table-most-user').position()
    // var classUp = 'glyphicon-chevron-up'
    // var classDown = 'glyphicon-chevron-down'
  
    // $( ".table-most-user .disable" ).slideToggle( "slow");
    // positonBottom = $('.bottom-table-most-visited').position()
    // if( $("#expand-most-user").hasClass(classDown)){
    //   $("#expand-most-user").addClass('glyphicon-chevron-up').removeClass('glyphicon-chevron-down')
    // }else{
    //   $("#expand-most-user").addClass(classDown).removeClass(classUp);
    // } 
    // $("html, body").animate({ scrollTop: $(document).height() }, positonBottom);
  }
}
$(function(){
  au.multicharBar();
  au.mostUser();
  au.mostVisited(); 
})