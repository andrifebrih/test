var di = {}

di.supplierType = ko.observableArray([]);

di.country     = ko.observable('');
di.countryList = ko.observableArray([]);

di.legalEntity     = ko.observableArray([]);
di.legalEntityList = ko.observableArray([]);

di.business     =  ko.observableArray([]);
di.businessList = ko.observableArray([]);

di.product     =  ko.observableArray([]);
di.productList = ko.observableArray([]);

di.levelProcess     = ko.observableArray([]);
di.levelProcessList = ko.observableArray([]);

di.level2Process     = ko.observableArray([]);
di.level2ProcessList = ko.observableArray([]);

di.onchangeCountry = ko.observable(true);

di.summaryCountryDetails  = ko.observableArray([]);
di.summaryEntitiesDetails = ko.observableArray([]);
di.abcde = ko.observable('');
di.entityHoverCountry = ko.observable('');
di.entityTypeHoverCountry = ko.observable('');
di.headerModal = ko.observable('');
di.loadingMap  = ko.observable(false);
di.indexingAjax = {
    receiverSummary: ko.observable(0),
}
var CNUtimeout = setTimeout(function(){
},1000);

// di.headerModal = ko.observable('')

di.clickAnalyze = function(value){
    return function () { 
        var cookies = value 
    
        if(value.hasOwnProperty('receiverLegalEntity')){
            // var data = dashboard.parseLegalEntity(value)
           cookies = {receiverCountry:di.country(),receiverLegalEntity:value.receiverLegalEntity};
        }
        $.extend(true,cookies,{supplierType:'Teams'});
        if(di.business().length > 0){
            $.extend(true,cookies,{bussiness:di.business()});
        }
        dashboard.createNewCookie(cookies); 
        redirectUrl("/ociranalysis/default")
    }
}

di.prepareMap = function(){
    $('#map-in-entity').remove();
    $(".panelMapInEntity").append("<div id='map-in-entity' class='map'> </div>");
}

di.downloadDetails = function(){
    return function(){
        var grid = $("#grid-popup-detail").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard Drilldown In-Entity Detail"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}

di.download = function(){
    return function(){
        var grid = $("#popupInEntity").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard In-Entity Drilldown"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}

di.detailsModal = function(suppliercountry){
    var payload = {
        ReceivingCountry : di.country(),
        LegalEntity : di.legalEntity(),
        SupplierCountry : suppliercountry,
        Flag : "inentity",
        Business : di.business(),
        Productfunction : di.product(),
        Parentprocessname : di.levelProcess(),
        Processname : di.level2Process(),
    };

    var url = '/receiverview/getdetailsrowtooltip';

    $("#grid-popup-detail").html("");
    $("#grid-popup-detail").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, payload, function(datas){
                        option.success(datas);
                        $('#entitydetailsmodal').modal('show');
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            //pageSize: 10,
            sort: [
                {field:"_id.functionname",dir:"asc"},
                {field:"_id.parentprocessname",dir:"asc"},
                {field:"_id.suppliercountry",dir:"asc"},
                {field:"_id.suppliername",dir:"asc"},
            ],
        },
        dataBound: function(){
            $('#grid-popup-detail .k-grid-content').height(315);
        },       
        excel: {
            fileName : "Details In-Entity.xlsx",
            allPages: true
        },
        columns: [
            {
                field:"_id.functionname",
                title:"Function Name",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.parentprocessname",
                title:"Level 1 Process",
                headerAttributes: {
                    "class": "align-left"
                },
                width:200,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.suppliercountry",
                title:"Supplier Country",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"_id.suppliername",
                title:"Supplier Name",
                headerAttributes: {
                    "class": "align-left"
                },
                width:150,
                /*filterable: false,*/
                attributes: {
                    "class": "field-ellipsis"
                }
            },
            {
                field:"fte",
                title:"FTE",
                format:"{0:N2}",
                headerAttributes: {
                    "class": "align-right"
                },
                width:100,
                /*filterable: false,*/
                attributes: {"class": "align-right"}
            }
        ],
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });    
}

di.entitySetHoverValue = function(country,type){
    var param = {
        ReceivingCountry : di.country(),
        LegalEntity : di.legalEntity(),
        Business : di.business(),
        Productfunction : di.product(),
        SupplierCountry : country,
        Flag : type,
        Parentprocessname : di.levelProcess(),
        Processname : di.level2Process(),
        Suppliertype : "Teams"
    }

    var titleGrid;
    if (type == "suppliername"){
        titleGrid = "Supplier Name"
    } else if(type == "functionname"){
        titleGrid = "Function Name" 
    } else {
        titleGrid = " Level 1 Process"
    }
    // var header = titleGrid;
    di.headerModal(titleGrid)
    var url = "/receiverview/getdetailstooltip"
    $("#popupInEntity").html("");
    $("#popupInEntity").kendoGrid({
        dataSource: {
            transport: {
               read:function(option){
                    ajaxPost(url, param, function(datas){
                        option.success(datas);
                        $('#entitymodal').modal('show');
                    })
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
            },
            // pageSize: 10
        },
        dataBound: function(){
            $('#popupInEntity .k-grid-content').height(315);
        }, 
        columns: [{
            field:"_id",
            title:di.headerModal(),
            width:200,
            /*filterable: false,*/
            attributes: {
                "class": "field-ellipsis"
            }
        }],
        excel: {
            fileName: di.headerModal() + " In-Entity.xlsx",
            allPages: true
        },
        sortable: true,
        filterable: {
            extra:false, 
            operators: {
                string: {
                    contains: "Contains",
                    startswith: "Starts with",
                    eq: "Is equal to",
                    neq: "Is not equal to",
                    doesnotcontain: "Does not contain",
                    endswith: "Ends with"
                },
            }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                display: "Showing {2} data items"
            }
        },
        height: 380,
    });
}

di.mapDetails = function(dataSource){
    di.prepareMap();
    setTimeout(function(){ 
        var geoJson = dataSource.BubbleSupplier.features; 
        var boxLabel = dataSource.BoxInfo
        var labelFte =  (boxLabel.fte=== null)? boxLabel.fte : kendo.toString(boxLabel.fte, 'N2')
        var countryFormat = di.country().replace("'", "&#39;");

     
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl, {id: 'mapbox.light', attribution: dashboard.mapBoxAttr, minZoom: 2});

         
        var map = L.map('map-in-entity', {
            center:[dataSource.BoxInfo.Latitude,dataSource.BoxInfo.Longitude],
            zoom: 5,
            layers: grayscale,
                zoomControl: false,
        }) 
          L.control.zoom({
             position:'topright'
        }).addTo(map);
        var templatePopUpReceivingCountry = [
            "<span style='color:#0644a0'>Receiver Country Data</span>",
            "<b>"+ di.country() + "</b>",
            "# of Suppliers : <a onclick='di.entitySetHoverValue(\""+countryFormat+"\",\"suppliername\")' href='#'> "+boxLabel.SupplierName+" </a>",
            "# of Functions: <a onclick='di.entitySetHoverValue(\""+countryFormat+"\",\"functionname\")' href='#'> "+boxLabel.FunctionName+" </a>",
            "Total FTE : " + kendo.toString(boxLabel.FTE,'N2'),
            "# of Level 1 Processes :<a onclick='di.entitySetHoverValue(\""+countryFormat+"\",\"Level1Process\")' href='#'> "+boxLabel.LevelOne+" </a>",
            "<a onclick='di.detailsModal(\""+countryFormat+"\")' href='#'>Details</a>"].join("<br>")  
        defMarker = L.marker([dataSource.BoxInfo.Latitude,dataSource.BoxInfo.Longitude], {icon: dashboard.receiverIcon }).addTo(map)
            .bindPopup(templatePopUpReceivingCountry).openPopup();
        defMarker.on('mouseover', function (e) {
                this.openPopup();
        });
        $line = $("path[stroke-linejoin='round']");
        $line.attr('stroke-width',"2");
        $line.attr('stroke-opacity',"3");
        $line.attr('stroke',"#3A91B9");
    },100)
};

di.map = function(dataSource){
    di.prepareMap();
    setTimeout(function(){
        var geoJson =dataSource.features;  
        var grayscale   = L.tileLayer(dashboard.mapBoxUrl, {id: 'mapbox.light', attribution: dashboard.mapBoxAttr, minZoom: 2});

        var map = L.map('map-in-entity', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
            zoomControl: false,
        })
        L.control.zoom({
             position:'topright'
        }).addTo(map);
       
        var geoJson = dataSource.features;
        $.each(geoJson, function(i,v){
            if(v.properties.count <= 5){
                var icon = dashboard.mapGreyIcon;
            }else if(v.properties.count <= 20){
                var icon = dashboard.mapGreenIcon;
            }  else {
                var icon = dashboard.mapBlueIcon; 
            }
            var marker = L.marker([v.geometry.coordinates[1], v.geometry.coordinates[0]], {icon: icon}).addTo(map);
            marker.Country = v.properties.SecondaryID
     
            marker.on('mouseover', function (e) {
                this.openPopup();
            });
            marker.on('click', function(e){ 
                di.country(e.target.Country);
                di.getData();
            });
        })  
    },100)
};

di.createSummary = function(dataSource){
    var countryDetails = [];
    var countries = [];
    var datas = [];
    var a = [];
    $.each(dataSource.Country,function(index,value){
        for(var i=0; i<(dataSource.Country.length-1); i++){
            if(dataSource.Country[i].Country.toLowerCase() > dataSource.Country[i+1].Country.toLowerCase()){
                var old = dataSource.Country[i+1];
                dataSource.Country[i+1] = dataSource.Country[i]
                dataSource.Country[i] = old
            }
        }
    }) 
    $.each(dataSource.Country, function(i,v){
        countryDetails.push({
            CEF:kendo.toString(v.CEF,"n0"),
            Country: v.Country,
            Leveloneprocess:kendo.toString(v.Leveloneprocess,"n0"),
            CriticalFTE:kendo.toString(v.CriticalFTE,"n0"), 
            CriticalService:kendo.toString(v.CriticalService,"n0"), 
            FTE:kendo.toString(v.FTE,"n2"),
            LegalEntity:kendo.toString(v.LegalEntity,"n0")
        })
        countries.push(v.Country);
        datas[i] = [];
        // a[JSON.stringify(v.Country)] = [];
    });
    di.summaryCountryDetails(countryDetails) 
     $.each(dataSource.CountryLegal,function(index,value){
        for(var i=0; i<(dataSource.CountryLegal.length-1); i++){
            if(dataSource.CountryLegal[i].Country.toLowerCase() > dataSource.CountryLegal[i+1].Country.toLowerCase()){
                var old = dataSource.CountryLegal[i+1];
                dataSource.CountryLegal[i+1] = dataSource.CountryLegal[i]
                dataSource.CountryLegal[i] = old
            }
        }
    }) 
    $.each(dataSource.CountryLegal, function(i,v){
        $.each(countries, function(index,value){
            if(value == v.Country){
                var key = {key:i+"-" + index} 
                $.extend(true, v,key)
                datas[index].push(v)
                // a[JSON.stringify(value)].push(v)
            }
        })
    });

    di.summaryEntitiesDetails(datas) 
  
    di.createDonut(dataSource.Country,datas)
}
// di.configSeries = function(indexClass, indeexData, selectorId){
//             var color = ["#00506D","#0077A3","#50D0FF"]
//             var visibleData   = $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data[indeexData].visible
//             $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data[indeexData].visible = !visibleData
//             $("#"+selectorId+"_"+indexClass).getKendoChart().redraw();
//             var datas = $("#"+selectorId+"_"+indexClass).getKendoChart().options.series[0].data
//             color = (!visibleData)?color[indeexData]: '#9b9898';
//             $("#legend-"+selectorId +"_"+indexClass).find("li").eq(indeexData).find(".square").css('background',color)
//             var totalDataTrue = 0 
//             $.each(datas, function(i, val){            
//                 if(val.visible == true){
//                     totalDataTrue += val.value
//                 } 
//             })

//             $.each(datas, function(i, val){            
//                 var percentage = 100 / (totalDataTrue / val.value) 
//                 if(val.visible == true){ 
//                     $("#legend-"+selectorId+"-precentage_"+ indexClass +"_"+i).text(String(percentage.toFixed(0)) +"%")
//                 }else{    
//                     $("#legend-"+selectorId+"-precentage_"+ indexClass +"_"+i).text('')
//                 }
//             }) 
// }
di.downloadPopUpDonut = function(){
    return function(){
        var grid = $("#grid-popup-in-entity").data("kendoGrid");
        grid.saveAsExcel();
        var payload = {
            Type : "Dashboard In-Entity Drilldown Donut"
        }
        ajaxPost("/analyticuser/downloadlog", payload, function (res){
        })
    }
}
di.popUpDonut = function(payload){
 
     $("#grid-popup-in-entity").html("");
        $("#grid-popup-in-entity").kendoGrid({
            dataSource: {
                transport: {
                   read:function(option){
                        ajaxPost("/receiverview/getpopupentity", payload, function(datas){
                            option.success(datas); 
                            $('#modal-in-entity').modal('show');
                            setTimeout(function() {
                                    $("#grid-popup-in-entity").data("kendoGrid").resize();  
                            }, 500);
                        })
                    },
                    parameterMap: function(data) {
                       return JSON.stringify(data);
                    },
                },
                //pageSize: 10,
                sort: [
                    {field:"receivercountry",dir:"asc"},
                    {field:"suppliercountry",dir:"asc"},
                    {field:"categoryname_",dir:"asc"},
                    {field:"productfunction",dir:"asc"},
                    {field:"parentprocessname",dir:"asc"},
                    {field:"processname",dir:"asc"},
                    {field:"servicedescription",dir:"asc"},
                ],
            },
            columns: [
                // {
                //     field:"_id.servicerefid",
                //     title:'Service Ref Id',
                //     /*filterable: false,*/
                //     width:200,
                //     headerAttributes: {
                //         "class": "align-left"
                //   }
                // },
                {
                    field:"receivercountry",
                    title:'Receiver Country',
                    /*filterable: false,*/
                    width:180,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    },
                    template: "#= receivercountry + ' - ' + receiverlegalentity #",
                },
                {
                    field:"suppliercountry",
                    title:'Supplier Country',
                    /*filterable: false,*/
                    width:180,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    },
                    template: "#= suppliercountry + ' - ' + supplierlegalentity #",    
                },
                {
                    field:"categoryname_",
                    title:'Business',
                    /*filterable: false,*/
                    width:130,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                {
                    field:"productfunction",
                    title:'Product',
                    /*filterable: false,*/
                    width:130,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                {
                    field:"parentprocessname",
                    title:'Level 1 Process',
                    /*filterable: false,*/
                    width:250,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                {
                    field:"processname",
                    title:'Level 2 Process',
                    /*filterable: false,*/
                    width:250,
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
                {
                    field:"servicedescription",
                    title:'Service Description',
                    width:250,
                    /*filterable: false,*/
                    attributes: {
                        "class": "field-ellipsis"
                    },
                    headerAttributes: {
                        "class": "align-left"
                    }
                },
            ],
            excel: {
                fileName: "PopUpInEntityDonut.xlsx",
                allPages: true
            },
            sortable: true,
            filterable: {
                extra:false, 
                operators: {
                    string: {
                        contains: "Contains",
                        startswith: "Starts with",
                        eq: "Is equal to",
                        neq: "Is not equal to",
                        doesnotcontain: "Does not contain",
                        endswith: "Ends with"
                    },
                }
            },
            pageable: {
                numeric: false,
                previousNext: false,
                messages: {
                    display: "Showing {2} data items"
                }
            },
            height: 380,
        });
      

}
di.createDonut = function(country,legal){    
    var color =  ["#00506D","#0077A3"]
    var data = []
    $.each(country, function(i, val){
      var dataCountry = []
      $.each(val.DetailsDonut, function(index,value){
      dataCountry.push({"category" : value.category,"value": value.value, "color" : color[index], visible:true})
      switch(value.category){
      case'TeamWithDOI':
          var dataItem = 'Teams with DOI'
      break;
                
      default:
          var dataItem = 'Teams without DOI'
      } 
      var percentage = (Math.abs(value.value) != 0) ? 100 / (val.TotalDonut / value.value) : 0; 
 
      $("#legend_donut_entity-country_"+i+" ul").append("<li>"+
                                                      "<a onClick='dashboard.configDonutSeries(\"entity-country\","+i+","+index+")'>"+
                                                      "<div class='square' style='background:"+color[index]+"'></div>"+ 
                                                         dataItem+
                                                      "<span style='float:right' id='legend_donut_entity-country_precentage_"+ i +"_"+index+"'>"+
                                                         percentage.toFixed(0)+"<b>%</b>"+
                                                      "</span>"+
                                                      "</a>"+
                                                      "</li>")  
      })  
      $("#donut_entity-country_"+i).kendoChart({
          legend: {
              visible:false,
              margin:{visible:true,left:-10},
              labels: {
                  font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                  template: "#if(dataItem.category=='TeamWithDOI'){# #: 'Teams with DOI' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else{# #: 'Teams without DOI' #&nbsp;&nbsp;&nbsp;# # #}# #=removeSpace(kendo.toString(percentage,'P0'))#",
                  color: "#0075B2"
              },
          },
          chartArea: {
              height : 100,
              background: "transparent",
              width : 120,
          },
          // seriesColors:["#00506D","#0077A3"],
          seriesDefaults: {
              labels: {
                  visible: false,
                  template: "#= removeSpace(kendo.toString(percentage,'P0'))#",
                  font: "9px Helvetica Neue, Arial, sans-serif",
                  background: "transparent"
              }
          },
          series: [{
              type: "donut",
              data:dataCountry,
              overlay:{gradient:"none"},
          }],                 
          valueAxis:{
              visible:false,
              labels: {
                  font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                  visible: false,
                  format:"{0:P0}",
              },
              majorGridLines: {
                  visible: false
              },
          },
          tooltip: {
              visible: true,
              font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
              template: "#=kendo.toString(value,'N0')#"
          },
          seriesClick: countryClick,
      });
        function countryClick(e) {
            if(e.category == "TeamWithDOI"){
                var Doi = "Y"
            }else{
                var Doi = "N"
            }
            var payload = {
                Business : di.business ,
                Doi: Doi,
                LegalEntity : di.legalEntity(),
                Productfunction : di.product(),
                Parentprocessname : di.levelProcess(),
                Processname : di.level2Process(),
                ReceivingCountry : val.Country
            }
            di.popUpDonut(payload)
            // legal = []
            // dfr.onFTEClick(country);
        }
    });

    $.each(legal, function(i,v){
        $.each(v, function(index,value){ 
          var dataLegal = []
            $.each(value.DetailsDonut, function(number,data){
                dataLegal.push({"category" : data.category,"value": data.value, "color" : color[number], visible:true, legalEntity: value.CountryLegal})
                switch(data.category){
                case'TeamWithDOI':
                    var dataItem = 'Teams with DOI'
                break;
                
                default:
                    var dataItem = 'Teams without DOI'
                } 
                var percentage = (Math.abs(data.value) != 0) ? 100 / (value.TotalDonutLegal / data.value) : 0;
                $("#legend_donut_entity-entites_"+value.key+" ul").append("<li>"+
                                                      "<a onClick='dashboard.configDonutSeries(\"entity-entites\",\""+ value.key +"\","+number+")'>"+
                                                      "<div class='square' style='background:"+color[number]+"'></div>"+ 
                                                         dataItem+
                                                      "<span style='float:right' id='legend_donut_entity-entites_precentage_"+ value.key+"_"+number+"'>"+
                                                         percentage.toFixed(0)+"<b>%</b>"+
                                                      "</span>"+
                                                      "</a>"+
                                                      "</li>")  
 
            })  
            $("#donut_entity-entites_" + value.key).kendoChart({
                legend: {
                    visible:false,
                    margin:{visible:true,left:-10},
                    labels: {
                        font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                        template: "#if(dataItem.category=='TeamWithDOI'){# #: 'Teams with DOI' #&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;# # #}else{# #: 'Teams without DOI' # #}# &nbsp;&nbsp; #= removeSpace(kendo.toString(percentage,'P0'))#",
                        color: "#0075B2"
                    },
                },
                chartArea: {
                    height : 100,
                    background: "transparent",
                    width : 120,
                },
                // seriesColors: ["#00506D","#0077A3"],
                seriesDefaults: {
                    labels: {
                        visible: false,
                        template: "#= removeSpace(kendo.toString(percentage,'P0'))#",
                        font: "9px Helvetica Neue, Arial, sans-serif",
                        background: "transparent"
                    }
                },
                series: [{
                    type: "donut",
                    data: dataLegal,
                    overlay:{gradient:"none"},
                }],
                valueAxis:{
                    visible:false,
                    labels: {
                        font: "10px Helvetica Neue, Helvetica, Arial, sans-serif",
                        visible: false,
                        format:"{0:P0}",
                    },
                    majorGridLines: {
                        visible: false
                    },
                },
                tooltip: {
                    visible: true,
                    font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
                    template: "#=kendo.toString(value,'N0')#"
                },
                 seriesClick: entityClick,
            });
            function entityClick(e) {
                // var legalEntity  = v[0].CountryLegal.split("~")[0];
                var legalEntity  = e.dataItem.legalEntity.split("~")[0];
                legalEntity = legalEntity.trim()
                if(e.category == "TeamWithDOI"){
                    var Doi = "Y"
                }else{
                    var Doi = "N"
                }
                var payload = {
                    Business : di.business() ,
                    Doi: Doi,
                    LegalEntity : [legalEntity],
                    Parentprocessname : di.levelProcess(),
                    Processname : di.level2Process(),
                    ReceivingCountry : v[0].Country
                }
                di.popUpDonut(payload)
     
            // if(e.category == "TeamWithDOI"){
            //     var Doi = "Y"
            // }else{
            //     var Doi = "N"
            // }
            // var payload = {
            //     Business : di.business ,
            //     Doi: Doi,
            //     LegalEntity : [],
            //     ReceivingCountry : val.Country
            // }
            // di.popUpDonut(payload)
            // legal = []
            // dfr.onFTEClick(country);
        }
         });  
    })
    // })       
   
}

di.getData = function(){

    increaseIndexingAjx(di.indexingAjax.receiverSummary); 

    var param = {
        ReceivingCountry: di.country(),
        LegalEntity: di.legalEntity(),
        Parentprocessname: di.levelProcess(),
        Processname: di.level2Process(),
        Business: di.business(),
        Productfunction: di.product(),
        Index: di.indexingAjax.receiverSummary()
    }
    ajaxPost("/receiverview/summaryreceivernew",param , function (res){
        if(res.Index != di.indexingAjax.receiverSummary())
            return;
        
        di.createSummary(res);
    });
    if(di.country() == ''){
        var payload={
            LegalEntity : di.legalEntity(),
            Business : di.business(),
            Productfunction : di.product(),
            Parentprocessname : di.levelProcess(),
            Processname : di.level2Process(),
            Flag: "Teams"
        }
        var url = "/receiverview/getdefaultreceiver";
        di.loadingMap(true);
        ajaxPost(url, payload, function (res){
            di.loadingMap(false);
            di.map(res)
        });
    }else{
        var payload={
            ReceivingCountry : di.country(),
            LegalEntity : di.legalEntity(),
            Parentprocessname : di.levelProcess(),
            Processname : di.level2Process(),
            Business : di.business(),
            Productfunction : di.product(),
        }
        var url = "/receiverview/getdetailsreceiverinentity";
        di.loadingMap(true);
        ajaxPost(url, payload, function (res){
            di.loadingMap(false);
            di.mapDetails(res)
        });
    }
    localStorage.setItem('filter', JSON.stringify(param));
};

di.getCountry = function(){
    var payload = {
        LegalEntity : di.legalEntity(),
        Business : di.business(),
        Productfunction : di.product(),
        Parentprocessname : di.levelProcess(),
        Processname : di.level2Process(),
        Flag : 'inentity'
    };
    ajaxPost("/receiverview/getreceivercountry",payload, function (res){
        var receivingCountries = [];
        $.each(res, function(i,v){
            receivingCountries.push({name:v._id,text:v._id})
        });
        di.countryList(receivingCountries);
    });
};

di.getLegalEntity = function(){
    var payload = {
        ReceivingCountry : di.country(),
        Business : di.business(),
        Productfunction : di.product(),
        Parentprocessname : di.levelProcess(),
        Processname : di.level2Process(),
        Flag : 'inentity'
    };
    var url = "/receiverview/getlegalentityreceiverinentity";
    ajaxPost(url,payload, function (res){
        di.legalEntityList(res) 
    });
};

di.getBusiness = function(){
    var payload = {
        ReceivingCountry : di.country(), 
        LegalEntity : di.legalEntity(),
        Productfunction : di.product(),
        Parentprocessname : di.levelProcess(),
        Processname : di.level2Process(),
        Flag : 'inentity'
    };
    ajaxPost("/receiverview/getcategoryinentity",payload, function (res){
        var category = [];
        $.each(res, function(i,v){
            category.push({text:v._id, value:v._id})
        });
        di.businessList(category);
    });
};

di.getProduct = function(){
    var payload = {
        ReceivingCountry : di.country(), 
        LegalEntity : di.legalEntity(),
        Business : di.business(),
        Productfunction : di.product(),
        Parentprocessname : di.levelProcess(),
        Processname : di.level2Process(),
        Flag : 'inentity'
    };
    ajaxPost("/receiverview/getproductfunction",payload, function (res){
        var product = [];
        $.each(res, function(i,v){
            product.push({text:v._id, value:v._id})
        });
        di.productList(product);
    });
};

di.getLevelProcess = function(){
    var payload = {
        ReceivingCountry : di.country(), 
        LegalEntity : di.legalEntity(),
        Business : di.business(),
        Productfunction : di.product(),
        Processname : di.level2Process(),
        Flag : 'inentity'
    };
    var url = "/receiverview/getparentprocessname";
    ajaxPost(url,payload, function (res){
        var levelProcess = [];
        $.each(res, function(i,v){
            levelProcess.push({text:v._id, value:v._id})
        });
        di.levelProcessList(levelProcess);
    });
};

di.getLevel2Process = function(){
    var payload = {
        ReceivingCountry : di.country(), 
        LegalEntity : di.legalEntity(),
        Business : di.business(),
        Productfunction : di.product(),
        Parentprocessname : di.levelProcess(),
        Flag : 'inentity'
    };
    var url = "/receiverview/getprocessname";
    ajaxPost(url,payload, function (res){
        var level2Process = [];
        $.each(res, function(i,v){
            level2Process.push({text:v._id, value:v._id})
        });
        di.level2ProcessList(level2Process);
    });
};

di.country.subscribe(function(newValue){
   

    di.onchangeCountry(false)

    if (di.country() == '') {
        di.legalEntity([]);
        di.business([]);
    };
    
    di.getLegalEntity();
    di.getBusiness();
    di.getProduct();
    di.getLevelProcess();
    di.getLevel2Process();
    di.getData();

    dashboard.createNewCookie({receiverCountry:di.country()}); 
    CNUtimeout = setTimeout(function(){
        di.onchangeCountry(true) 
    },1000);
});

di.legalEntity.subscribe(function(newValue){
    if(di.onchangeCountry() === true){
       dashboard.createNewCookie({receiverCountry:di.country(),receiverLegalEntity:newValue.toString()}); 
        di.getData();
    }
    di.getCountry();
    di.getBusiness();
    di.getProduct();
    di.getLevelProcess();
    di.getLevel2Process();
});

di.business.subscribe(function(newValue){
    if(di.onchangeCountry() === true){
        di.getData();
    }
    di.getCountry();
    di.getLegalEntity();
    di.getProduct();
    di.getLevelProcess();
    di.getLevel2Process();
});

di.product.subscribe(function(newValue){
    if(di.onchangeCountry() === true){
        di.getData();
    }
    di.getCountry();
     di.getBusiness();
    di.getLegalEntity();
    di.getLevelProcess();
    di.getLevel2Process();
});

di.levelProcess.subscribe(function(newValue){
    if(di.onchangeCountry() === true){
        di.getData();
    }
    di.getCountry();
    di.getLegalEntity();
    di.getBusiness();
    di.getProduct();
    di.getLevel2Process();
});

di.level2Process.subscribe(function(newValue){
    if(di.onchangeCountry() === true){
        di.getData();
    }
    di.getCountry();
    di.getLegalEntity();
    di.getBusiness();
    di.getProduct();
    di.getLevelProcess();
});

di.init = function(){
    localStorage.setItem('tab', 'in-entity');
    di.getCountry();
    di.getLegalEntity();
    di.getBusiness();
    di.getProduct();
    di.getLevelProcess();
    di.getLevel2Process();
    di.getData();
}