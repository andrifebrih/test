dl = {}
 
dl.inputData = {template:ko.observableArray([]) ,DLName:ko.observable(''),type:ko.observable('Public'),status:ko.observable('Active'),owned:ko.observable(''),remarks:ko.observable(''),members:[]}
dl.memberFilterList = [];
dl.inputsearch 			= ko.observable('')
dl.type 						= ko.observableArray([{ text:"Public"},{ text:"Private"}]);
dl.confDeleteMembers = ko.mapping.fromJS([])
dl.dataMembers 			= [];
dl.dataMembersAll 	= [];
dl.dataMembersSearch 	= [];
dl.searchStatus 		= ko.observable(false)

dl.template     = ko.observable('');
dl.templateList = ko.observableArray([])

dl.getDataGrid = function(){
	  $("#gridDAta").kendoGrid({
       	dataSource: {
					transport: {
						read:function(option){
							ajaxPost('/distributionlist/getdistributionlist', {}, function(datas){
								option.success(datas);
							})
						},
						parameterMap: function(data) {
							return JSON.stringify(data);
						},
					},
					schema: {
						data: function(data) {
							if (data.Data.length == 0) {
								return [];
							} else { 
								return data.Data;
							}
						},
						total: "Data.length",
					}, 
				}, 
        columns: [
         {
            title: "No",
            template: "#= ++record #",
            width: 20,
            headerAttributes: {
             "class": "align-center header-grid"
            }, attributes: {
              "class": "align-center number"
            }
          }, 
          {
            field:"DLName",
            title:'DL Name',
            width:100, 
            headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
            {
            field:"type",
            title:'Type',
            width:30, 
            headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "align-left" 
            }
          },
          {
            field:"owned",
            title:'Owned By',
            width:75, 
             headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
          {
            field:"lastmodifiedby",
            title:'Last Modified By',
            width:100, 
             headerAttributes: {
             "class": "align-left"
            },attributes: {
              "class": "field-ellipsis align-left" 
            }
          },
          {
            field:"lastmodifiedon",
            title:'Last Modified On',
            width:100, 
            template: "#if(lastmodifiedon != ''){# #:  kendo.toString(new Date(getUTCDate(getUTCDateFull(lastmodifiedon))), 'dd/MM/yy') # #} #",
            attributes: {
              "class": "field-ellipsis align-center"
            }
          },
          {
            field:"noofmembers",
            title:'No. of Members',
            width:60,
            headerAttributes: {
		            "class": "align-right"
		        },
		        attributes: {
		            "class": "align-right"
		        }
          },
          {
            field:"remarks",
            title:'Remarks',
            width:60,
            headerAttributes: {
                "class": "align-left"
            },
            attributes: {
                "class": "align-left"
            }
          },
          { 
            width:25,
            // filterable: false,
            headerAttributes: {
          		"class": "align-center"
        		},
		        attributes: {
		          "class": "align-center"
		        },
 
            template: "## <button  class=\"btn btn-sm pull-left btn-primary\" id=\"raady-button\"  onClick='dl.edit(\"#:DLName #\" )'><span class=\"icon-custome glyphicon glyphicon-pencil\" aria-hidden=\"true\"></span></button> ##",
          
          }
        ],
  			resizable: true,
      
          sortable: true,
          scrollable:{
            virtual: true
          }, 
          pageable: {
            refresh: true,
            pageSizes: true,
            buttonCount: 1, 
            pageSize: 10,
          }, 
          dataBinding: function() {
            record = (this.dataSource.page() -1) * this.dataSource.pageSize();
          }
    });
}
dl.gridDetails =  function(dataSource){
	$("#grid-member").html('')
	$("#grid-member").kendoGrid({
        dataSource: {
          transport: {
                read:function(option){
                  option.success(dataSource); 
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
          },  
          schema: {
            data: function(data) {
             	if (data.length == 0) {
                 	return [];
             	} else {
                 	return data; 
             	} 
            },
                // total: "Data.Count",
          },
        },  
        columns: [
          {
            field:"fullname",
            title:'Member Name',
            width:100, 
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"loginid",
            title:'PSID',
            width:70, 
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"email",
            title:'email',
            width:100, 
            attributes: {
              "class": "field-ellipsis"
            }
          },
      
          // {
          //   title:'',
          //   width:25,
          //   // filterable: false,
          //   headerAttributes: {
          // 		"class": "align-center"
        		// },
		        // attributes: {
		        //   "class": "align-center"
		        // },
 
            // template: "## <button  class=\"btn btn-sm pull-left btn-primary\" id=\"raady-button\"  onClick='dl.edit(\"#:DLName #\" )'>Edit</button> ##",
            // template: "## <button  class=\"btn btn-sm pull-left btn-cancel \" id=\"raady-button\"  onClick='deleteRowDetails(\"#:_id #\",\"#:fullname #\",\"#:email #\" )'><span class=\"small-icon-custome glyphicon glyphicon-remove\" aria-hidden=\"true\"></button> ##",
           
          
          // }
        ],
        sortable: true,
         resizable: true,
        filterable: {
          extra:false, 
          operators: {
            string: {
              contains: "Contains",
              startswith: "Starts with",
              eq: "Is equal to",
              neq: "Is not equal to",
              doesnotcontain: "Does not contain",
              endswith: "Ends with"
            },
          }
        },
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                      display: "Showing {2} data items"
                  }
              }, 
  });
}
dl.gridDataMembers = function(dataSource){
 
	$("#grid-data-members").html('')
	$("#grid-data-members").kendoGrid({
        dataSource: {
          transport: {
                read:function(option){
                  option.success(dataSource); 
                },
                parameterMap: function(data) {
                   return JSON.stringify(data);
                },
          },  
          schema: {
            data: function(data) {
             	if (data.length == 0) {
                 	return [];
             	} else {
                 	return data; 
             	} 
            },
                // total: "Data.Count",
          },
        },  
        columns: [

          {
            title:'',
            width:17,
            headerAttributes: {
          		"class": "align-center"
        		},
		        attributes: {
		          "class": "align-center add"
		        },
 
            
            template: "## <button  class=\"btn btn-sm pull-left btn-add-member   \" id=\"raady-button\"   onClick='dl.addMember(\"#:_id #\",\"#:fullname #\",\"#:email #\",\"#:loginid #\")' >Add</button> ##",
           
 
          },
          {
            field:"fullname",
            title:'Member Name',
            width:100, 
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"loginid",
            title:'PSID',
            width:70, 
            headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
          {
            field:"email",
            title:'Email',
            width:100, 
             headerAttributes: {
             "class": "align-left"
            },
            attributes: {
              "class": "field-ellipsis"
            }
          },
       
        
        ],
        resizable: true,
        sortable: true,
 
        pageable: {
            numeric: false,
            previousNext: false,
            messages: {
                      display: "Showing {2} data items"
                  }
              }, 
    });
}
dl.getMember =  function(){
	ajaxPost("/distributionlist/getmembername", "", function (res){
 			dl.dataMembersAll = res.Data
  })
}
dl.edit =  function(dlName){
  ajaxPost("/distributionlist/getmembernameedit", {id:dlName}, function (res){
  	dl.dataMembersAll = res.Data;
   
  })
	ajaxPost("/distributionlist/editdistributionlist",{id:dlName}, function (res){
    template = []
    for(i in res.Data.templates){
     
      template.push(res.Data.templates[i].templateName)
    }
 
    dl.inputData.template(template) 
		dl.inputData.DLName( res.Data.DLName) 
		dl.inputData.remarks(res.Data.remarks)  
		dl.inputData.type(res.Data.type)  
    dl.inputData.status(res.Data.status)  
    dl.dataMembers = res.Data.members 

    ko.mapping.fromJS(dl.dataMembers, dl.confDeleteMembers)
		dl.gridDetails(dl.dataMembers)
		dl.inputsearch('')


		$('#addDL').modal('show');
		$("#grid-data-members").html('')
    
	});
}
dl.addMember =  function(id,fullname,email,loginid){
	dl.dataMembers.push({_id:id,fullname:fullname,email:email,loginid:loginid})
	for(var i in dl.dataMembersAll){
		if( dl.dataMembersAll[i]._id == id){
	 		dl.dataMembersAll.splice(i,1)
		}
	}
	for(var i in dl.dataMembersSearch){
		if( dl.dataMembersSearch[i]._id == id){
	 		dl.dataMembersSearch.splice(i,1)
		}
	}
	if(dl.searchStatus()){
		dl.gridDataMembers(dl.dataMembersSearch)
	}

  ko.mapping.fromJS(dl.dataMembers, dl.confDeleteMembers)
	dl.gridDetails(dl.dataMembers)
}
function deleteRowDetails(id,fullname,email,loginid){
	return function(){
 
    for(i in dl.dataMembers){
  		if(id == dl.dataMembers[i]._id){
  			dl.dataMembers.splice(i,1); 
  		}
  	} 
  	dl.dataMembersAll.push({"_id" :id,"email":email,"fullname": fullname,loginid:loginid});
  	if(fullname.toLowerCase().indexOf(dl.inputsearch().toLowerCase()) > -1){
        dl.dataMembersSearch.push({"_id" :id,"email":email,"fullname": fullname,loginid:loginid});
    }
    if(dl.searchStatus()){
  		dl.gridDataMembers(dl.dataMembersSearch)
  	}

    ko.mapping.fromJS(dl.dataMembers, dl.confDeleteMembers)
  	dl.gridDetails(dl.dataMembers)
  }
}
dl.search =  function(){
	data = []
  dl.inputsearch($('#searchMember').val())
	$.each(dl.dataMembersAll, function(i,v){
		if(v.fullname.toLowerCase().indexOf(dl.inputsearch().toLowerCase()) > -1){
      data.push({"_id" : v._id,"email": v.email,"fullname": v.fullname,loginid:v.loginid});
    }
	}) 
	dl.searchStatus(true);
	dl.dataMembersSearch = data;
	dl.gridDataMembers(dl.dataMembersSearch);
}

dl.save = function(){
  payload = {}
  var templates = []
  for(i in dl.inputData.template()){
    templates.push({templateName:dl.inputData.template()[i]})
  } 
  payload.templates = templates
  payload.DLName    = dl.inputData.DLName()
  payload.type      = dl.inputData.type()
  payload.remarks   = dl.inputData.remarks()
  payload.status    = dl.inputData.status()
  payload.members   = dl.dataMembers  

	ajaxPost("/distributionlist/savedistributionlist", payload, function (res){
		 if(res.IsError){
        return swal("Confirmation!", res.Message, "error");
     }else{ 
      	$('#gridDAta').data('kendoGrid').dataSource.read({});
        return swal("Confirmation!", res.Message, "success");  
     }	
  })
}
dl.getTemplate = function(){
  ajaxPost("/distributionlist/gettemplatename",{}, function (res){
      var datas = []
      $.each(res.Data, function(i,v){
          datas.push({text:v._id,value:v._id})
      })
     dl.templateList(datas)
  })
};
dl.getMemberList =  function(){
	memberName = [];
	for(i in dl.memberNameList ){
		memberName.push(dl.memberNameList[i].fullname)
	}
	dl.memberFilterList = memberName;
}
dl.getOwned =  function(){
	ajaxPost("/distributionlist/getowned", "", function (res){
 		dl.inputData.owned(res.Data[0].fullname)
  })
}
dl.addData = function(){
  dl.inputData.DLName('')
  dl.inputData.type('Public')
  dl.inputData.remarks('')
  dl.inputData.status('Active')   
  dl.dataMembers = [] 
  dl.gridDetails([]) 
  dl.inputsearch('')
  dl.getMember()
  dl.getOwned()
  ko.mapping.fromJS([], dl.confDeleteMembers)
  $("#grid-member").html('')
  $("#grid-data-members").html('')
  
  $("#inputsearch").kendoAutoComplete({
    dataSource:   dl.memberFilterList,
    filter: "contains",
    placeholder: "Search",
  });
  $('#addDL').modal('show');
} 
$(function(){
	dl.getDataGrid()
  dl.getTemplate()
   $('#searchMember').on("keypress", function(e) {
      if(e.keyCode == 13){
        dl.search()
      }
  });
})




























