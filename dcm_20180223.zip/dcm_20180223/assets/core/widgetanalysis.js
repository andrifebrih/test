function getFilter(url, payload, observerData) {
  ajaxPost(url, payload, function(res) {
    var resData = []

   
    if(payload.Flag == "special_caracters"){
      _.each(res, function(d) {
        if(d._id != null){
          if(d._id == "")
            resData.push( { text: "General", value: d._id } );
          else
            resData.push( { text: d._id, value: d._id } );
        }
      });
    }else{
      _.each(res, function(d) {
        if(d._id != null)
          resData.push( { text: d._id, value: d._id } );
      });
    }
    
    observerData(resData);

  })
}

var wa = {};
var defaultCaption = 'Charts add your own summary charts by selecting the bellow "+" sign and selecting the chart type.';
// ['preview', 'export']
wa.mode           = ko.observable("preview");

wa.template       = ko.observableArray([]);
wa.page           = {
                      active: ko.observable(0),
                      total: ko.observable(0),
                      data: ko.observableArray([])
                    };
wa.hoverNavTabWidget = ko.observable(true);
wa.loaderSetupTemplate   = ko.observable(0);
wa.activeProp = {
  idxTemplate: function(){
    return wa.page.active() - 1;
  },
  template: function(){
     return wa.template()[wa.activeProp.idxTemplate()];
  },
  filter: function(){
    return wa.activeProp.template().filter;
  }, 
  payload: function(){
    return wa.activeProp.template().payload;
  },
  mainPage: function(){
    return wa.activeProp.template().mainPage;
  },
  mainPageFilter: function(){
    return wa.activeProp.mainPage().filter;
  },
  selectorPage: function(){
    return  $("#page-" + wa.activeProp.template().id);
  },
  title: function(){
    return wa.activeProp.mainPage().title();
  }

};

function createUid(){
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
         s4() + '-' + s4() + s4() + s4();
}
wa.prop = {
  idxActivePage: function(){
    return wa.page.active() - 1;
  },
  templateActive: function(){
    return wa.template()[wa.prop.idxActivePage()];
  },
  filterActive: function(){
    return wa.prop.templateActive().filter;
  },
  payloadActive: function(){
    return wa.prop.templateActive().payload;
  },
  selectorActive: function(){
    // return $("")
  },
};

wa.showDetails = function() {
  var $modal =  $("#modal_detail"),
      $grid = $modal.find('.grid');
  var payload = wa.activeProp.payload();
  _.each(wa.activeProp.mainPage().filter, function(f,i) {
    payload[i] = f
  })
  payload['Menu'] = window[wa.activeProp.mainPage().type()].menuTitle;
      $grid.html("");
      $grid.kendoGrid({
        dataSource: {
          transport: {
            read:function(option){
              payload.skip = option.data.skip
              payload.sort = typeof option.data.sort != 'undefined' ? option.data.sort : [];
              payload.take = option.data.take
              ajaxPost("/widgetanalysis/detailsgridinvestor", payload, function(res){
                option.success({ Records: res.Data, Count: res.Total });
              })
            },
        },
        schema: {
          data: function(data) {
                    return data.Records;
          },
          total: "Count",
        },
        pageSize: 10,
        serverPaging: true,
        serverSorting: true,
        serverFiltering: true,
        },
        sortable: true,
        pageable: {
          numeric: true,
          previousNext: true,
          messages: {
            display: "Showing {2} data items"
          }
        },
        columns: [
          {
            title: "Security",
            field: "security",
          },
          {
            title: "Issuer",
            field: "issuer",
          },
          {
            title: "Issuer Date",
            field: "issue_date",
          },
          {
            title: "Currency",
            field: "currency",
          },
          {
            title: "Industry",
            field: "industry"
          },
          {
            title: "Rating",
            headerAttributes: {
              "class": "align-center"
            },
            columns: [
              {
                title: "Moody's",
                field: "moodys_issuer_rating",
                attributes: {
                  "class": "align-center"
                },
                headerAttributes: {
                  "class": "align-center"
                },
                // template: "#= kendo.toString(Moodysissuerrating,'N0') #"
              },
              {
                title: "S&P",
                field: "sp_issuer_rating",
                attributes: {
                  "class": "align-center"
                },
                headerAttributes: {
                  "class": "align-center"
                },
                // template: "#= kendo.toString(Spissuerrating,'N0') #"
              },
              {
                title: "Fitch",
                field: "fitch_issuer_rating",
                attributes: {
                  "class": "align-center"
                },
                headerAttributes: {
                  "class": "align-center"
                },
                // template: "#= kendo.toString(Bidgspread,'N0') #"
              },
            ]
          }
        ]
      });
      $modal.modal('show');
}
wa.page.active.subscribe(function(n){
  console.log(n);
})

wa.closeWidget =  function(page){ 
  var lenTemplate = wa.template().length;
  if(page == wa.page.active() ){
    if(page < lenTemplate){
      wa.page.active(page);
    }else{
      wa.page.active(wa.page.active() - 1)
    }
  }else if(page <  wa.page.active() ){
    wa.page.active( wa.page.active() - 1 );
  }
  wa.page.total(wa.page.total() - 1);
  wa.template().splice((page - 1), 1);
  wa.template.valueHasMutated();
}
wa.filterProperties = function(){
  return {
    "Issuer": { 
      data  : ko.observableArray([{_id: 'Issuer'}]),
      value : ko.observableArray([])
    },
    "Parentcompanyname": { 
      data    : ko.observableArray(['Parent Company Name']),
      value : ko.observableArray([])
    },
    "Continent": { 
      data    : ko.observableArray(['Continent']),
      value : ko.observableArray([])
    },
    "Region": { 
      data    : ko.observableArray(['Region']),
         value : ko.observableArray([])
    },
    "Country": { 
      data    : ko.observableArray(['Country']),
         value : ko.observableArray([])
    },
    "Superindustry": { 
      data    : ko.observableArray(['Super Industry']),
      value : ko.observableArray([])
    },
    "Industry": { 
      data    : ko.observableArray(['Industry']),
      value : ko.observableArray([]) 
    },
    "Ownership": { 
      data    : ko.observableArray(['Ownership']),
      value : ko.observableArray([])
    },
    "Currency": { 
      data    : ko.observableArray(['Currency' ]), 
      value : ko.observableArray([])
    },
    "Ranking": { 
      data    : ko.observableArray(['Ranking' ]),
      value : ko.observableArray([])
    },
    "Product": { 
      data    : ko.observableArray(['Product' ]),
      value : ko.observableArray([])
    },
    "Specialcharacter": { 
      data    : ko.observableArray([]),
      value : ko.observableArray([])
    },
    
    //Distribution
    "IssuerDistribution": { 
      data  : ko.observableArray([{_id: 'Issuer'}]),
      value : ko.observableArray([])
    },
    "ParentcompanynameDistribution": { 
      data    : ko.observableArray(['Parent Company Name']),
      value : ko.observableArray([])
    },
    "ContinentDistribution": { 
      data    : ko.observableArray(['Continent']),
      value : ko.observableArray([])
    },
    "RegionDistribution": { 
      data    : ko.observableArray(['Region']),
         value : ko.observableArray([])
    },
    "CountryDistribution": { 
      data    : ko.observableArray(['Country']),
         value : ko.observableArray([])
    },
    "SuperindustryDistribution": { 
      data    : ko.observableArray(['Super Industry']),
      value : ko.observableArray([])
    },
    "IndustryDistribution": { 
      data    : ko.observableArray(['Industry']),
      value : ko.observableArray([]) 
    },
    "OwnershipDistribution": { 
      data    : ko.observableArray(['Ownership']),
      value : ko.observableArray([])
    },
    "CurrencyDistribution": { 
      data    : ko.observableArray(['Currency' ]), 
      value : ko.observableArray([])
    },
    "RankingDistribution": { 
      data    : ko.observableArray(['Ranking' ]),
      value : ko.observableArray([])
    },
    "ProductDistribution": { 
      data    : ko.observableArray(['Product' ]),
      value : ko.observableArray([])
    },
    "OnefourfourDistribution":{
      data: ko.observableArray([]),
      value: ko.observableArray([]),
    },
    "RegsDistribution":{
      data: ko.observableArray([]),
      value: ko.observableArray([]),
    },
    "SpecialcharacterDistribution": { 
      data    : ko.observableArray([]),
      value : ko.observableArray([])
    },
    "DistributionformatDistribution": { 
      data    : ko.observableArray([]),
      value : ko.observableArray([])
    },
    //Distribution
    "IssuerDistributionStatic": { 
      data  : ko.observableArray([{_id: 'Issuer'}]),
      value : ko.observableArray([])
    },
    "ParentcompanynameDistributionStatic": { 
      data    : ko.observableArray(['Parent Company Name']),
      value : ko.observableArray([])
    },
    "ContinentDistributionStatic": { 
      data    : ko.observableArray(['Continent']),
      value : ko.observableArray([])
    },
    "RegionDistributionStatic": { 
      data    : ko.observableArray(['Region']),
         value : ko.observableArray([])
    },
    "CountryDistributionStatic": { 
      data    : ko.observableArray(['Country']),
         value : ko.observableArray([])
    },
    "SuperindustryDistributionStatic": { 
      data    : ko.observableArray(['Super Industry']),
      value : ko.observableArray([])
    },
    "IndustryDistributionStatic": { 
      data    : ko.observableArray(['Industry']),
      value : ko.observableArray([]) 
    },
    "OwnershipDistributionStatic": { 
      data    : ko.observableArray(['Ownership']),
      value : ko.observableArray([])
    },
    "CurrencyDistributionStatic": { 
      data    : ko.observableArray(['Currency' ]), 
      value : ko.observableArray([])
    },
    "RankingDistributionStatic": { 
      data    : ko.observableArray(['Ranking' ]),
      value : ko.observableArray([])
    },
    "ProductDistributionStatic": { 
      data    : ko.observableArray(['Product' ]),
      value : ko.observableArray([])
    },
    "OnefourfourDistributionStatic":{
      data: ko.observableArray([]),
      value: ko.observableArray([]),
    },
    "RegsDistributionStatic":{
      data: ko.observableArray([]),
      value: ko.observableArray([]),
    },
    "SpecialcharacterDistributionStatic": { 
      data    : ko.observableArray([]),
      value : ko.observableArray([])
    },
    "DistributionformatDistributionStatic": { 
      data    : ko.observableArray([]),
      value : ko.observableArray([])
    },

    // reverse query  
    "RatingtypeReverse": {  
      data: ko.observableArray([{text:"Fitch",value:"point_fitch"},{text:"Moody",value:"point_moody"},{text:"SP",value:"point_sp"}]),
      value: ko.observable("")
    }, 
    "RatingactionReverse": { 
      data: ko.observableArray([
                                  {text:"equal to",value:"$eq"},
                                  {text:"worse than",value:"$gt"},
                                  {text:"worse than or equal to",value:"$gte"},
                                  {text:"better than",value:"$lt"},
                                  {text:"better than or equal to",value:"$lte"}
                              ]),
      value: ko.observable('$eq'),
    },
    "RatingValueReverse": { 
      data: ko.observableArray([]),
      value: ko.observable("")
    },
    "RankingReverse": { 
      data: ko.observableArray(['Ranking' ]),
      value: ko.observableArray("")
    },
    "OwnershipReverse": { 
      data: ko.observableArray(['Ownership']),
      value: ko.observableArray()
    }, 
    "ProductReverse": { 
      data: ko.observableArray(['Product' ]),
      value: ko.observableArray()
    },

    "EmtnProgramReverse": { 
      data: ko.observableArray(['Ownership']),
      value: ko.observableArray()
    }, 
    "ScbDealerProgramReverse": { 
      data: ko.observableArray(['Product' ]),
      value: ko.observableArray()
    },
    "IsdaReverse": { 
      data: ko.observableArray(['Ownership']),
      value: ko.observableArray()
    }, 
    "CsaReverse": { 
      data: ko.observableArray(['Product' ]),
      value: ko.observableArray()
    },
  }
};
wa.defFilter = function(){
  return [
    {
      payload : "Issuer",
      id: 'Issuer', 
      title: 'Issuer Name',
      flag: 'issuer',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Parentcompanyname",
      id: 'Parentcompanyname', 
      title: 'Parent Company Name',
      flag: 'parent_company_name',
      type: 'multiselect',
      ajax: 'true',
    },
    {

      payload : "Continent",
      id: 'Continent', 
      title: 'Continent',
      flag: 'continent',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Region",
      id: 'Region', 
      title: 'Region',
      flag: 'region',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Country",
      id: 'Country', 
      title: 'Country',
      flag: 'country',
      type: 'multiselect',
      ajax: 'true',
    },
    // {
    //   payload : "Superindustry",
    //   id: 'Superindustry', 
    //   title: 'Super Industry',
    //   flag: 'super_industry',
    //   type: 'multiselect',
    //   ajax: 'true',
    // },
    // 
       {
      payload : "Industry",
      id: 'Industry', 
      title: 'Industry',
      flag: 'industry',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Ownership",

      id: 'Ownership', 
      title: 'Ownership',
      flag: 'ownership',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Currency",

      id: 'Currency', 
      title: 'Currency',
      flag: 'currency',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Ranking", 
      id: 'Ranking', 
      title: 'Ranking',
      flag: 'ranking',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Product", 
      id: 'Product', 
      title: 'Product',
      flag: 'product',
      type: 'multiselect',
      ajax: 'true',
    },
    {
      payload : "Specialcharacter",
      id: 'Specialcharacter', 
      title: 'Special Character',
      flag: 'special_caracters',
      type: 'multiselect',
      ajax: 'true',
    }
  ];
};
wa.getWidthNav =  function(){
  if(wa.template().length <= 5)
    return "20%";
  return  ( 100 / wa.template().length )  + "%";
}
wa.getMarginNav = function(){
  if(wa.template().length <= 7)
    return "-5px;";
  else
    return "-2px;";
  // return  ( 100 / wa.template().length )  + "%"; 
}
wa.createPayload = function(allFilters, selectedFilters){
  var payload = {};
  _.each(selectedFilters, function(o){  
      payload[ o.payload ] =  typeof allFilters[ o.id ].value == "function" ? allFilters[ o.id ].value() : allFilters[ o.id ].value
  });

  return payload;
};
wa.GetDataDefaultFilters =  function(filter, exceptFilter, payload){
  payload = payload || payload
  _.each(wa.defFilter(), function(o){
    if(!o.ajax )
      return;
    payload["Flag"] = o.flag;
    var  p = _.clone(payload);
           
    // if( exceptFilter != "" && exceptFilter == o.id ){
    p[o.payload] = [];
    // }
    getFilter("/widgetanalysis/getfilterwidget", p, filter[o.id].data);
  });
};
wa.ChangeFilter = function( e, idFilter, idPayload ) {
  var template = wa.activeProp.template();
  var filter = template.filter;
      filter[idFilter].value(e._old);
  
  var payload = template.payload ;
      payload[idPayload] = e._old;
  if(template.mainPage.type() != ""){ 
    payload = window[template.mainPage.type()].extendPayload(_.clone( payload ) );  
  }
  
  wa.GetDataDefaultFilters(filter, idFilter, payload);
  wa.reloadPage2();
};
wa.createPage = function() {
  var page = wa.page.total() + 1;

  var filter  = _.clone( wa.filterProperties());
  var payload = wa.createPayload(filter, wa.defFilter());
  wa.GetDataDefaultFilters(filter, "", payload);
 
  wa.template.push({
    id: createUid(),
    filter : filter,
    payload : payload,
    pullRequest : ko.observable(0),
    mainPage : {
      // available ["default","investor"]   
      type : ko.observable(""), 
      title : ko.observable("Analytics"),
      // available 2 options: chooseData and preview
      mode: ko.observable('chooseData'),
      // filter mainpage
      filter: {},
      dataSource: [],
    }
  });
  wa.template.valueHasMutated();

  wa.page.data().push(page);
  wa.page.data.valueHasMutated();
  wa.page.total(page);
  wa.page.active(page);
};
wa.closeChart = function(){
  var template =  wa.prop.templateActive();
  window[template.mainPage.type()].Close();
  template.mainPage.title("Analytics")
  console.log(template.mainPage.title());
};
wa.reloadPage2 = function() {
  var type = wa.activeProp.mainPage().type();
  if(type != ""){
    wa.activeProp.mainPage().title( window[type].title )
    window[type].Reload();
  }
};
wa.reloadPage = function(filter, page) {
  var _page = page ? wa.getPage(page) : wa.getActivePage();
  var payload = wa.GeneratePayload(filter);
  var mainPageType = _page.mainPage.type();
  window[mainPageType].generateDataViz();
};
wa.ResetmainPageFilter =  function(){
    return wa.activeProp.mainPage().filter = {};
}
wa.GenerateChart =  function(type){
  $("#popupOptionBar").modal("hide");
  
    wa.activeProp.mainPage().title( window[type].title )
  wa.ResetmainPageFilter();
  window[type].init();
}

wa.saveTemplate2 = function() {
  var input = wa.config.template.inputVal();
  if(input == "") {
    return swal("", "Please insert a template name", "warning");
  }
  var newTemplate = [];
  var template = wa.template();
  _.each(template, function(o){
    newTemplate.push(
        {
          payload : o.payload,
          mainPage : {
            type: o.mainPage.type(),
            mode: o.mainPage.mode(),
            filter : o.mainPage.filter
          }
        }
    )
  });
  var payload = {TemplateName: input, details: newTemplate};
  ajaxPost("/widgetanalysis/savewidgetanalysis", payload, function(res) {
    var currentData = wa.config.template.data();
    currentData.push(input)
    wa.config.template.data(currentData);
    swal("Saved!", "", "success");
    wa.config.template.inputVal("");
  })



  // _.each(template, function(o) {
  //   var filter = _.map(o.filter, function(filter, i) {
  //     return {
  //       id: i,
  //       value: filter.value()
  //     }
  //   });
  //   var ownFilter = window[o.mainPage.type()].f;
  //   if(typeof ownFilter != 'undefined') {
  //     _.each(ownFilter.val, function(o, x) {
  //       filter.push({
  //         id: x,
  //         value: typeof o == "function" ? o() : o,
  //       })
  //     })
  //   }
  //   console.log(filter);
  //   newTemplate.push({
  //     filter: filter,
  //     mainPage: {
  //       type: o.mainPage.type(),
  //       mode: o.mainPage.mode(),
  //     }
  //   })
  // })

  // var payload = {TemplateName: input, details: newTemplate};
  // ajaxPost("/widgetanalysis/savewidgetanalysis", payload, function(res) {
  //   console.log(res);
  //   var currentData = wa.config.template.data();
  //   currentData.push(input)
  //   wa.config.template.data(currentData);
  //   swal("Saved!", "", "success");
  //   wa.config.template.inputVal("");
  // })
}
wa.insertFilter = function(url, filter, selectedFilter,  payload){
 
  _.each(selectedFilter, function(f){
   
    if(!_.has(f, 'ajax')){
      if( _.has( payload, f.payload ) && _.has( filter, f.id ))
         filter[f.id].value(payload[f.payload]);
      return;
    }
    var p = _.clone(payload)
        p['Flag'] = f.flag;
        p[f.payload] = [];

    ajaxPost(url, p, function(res) {
      // var resData = _.map(res, function(d) {
      //   return d._id
      // });
      var  resData = [];
      if(p.Flag == "special_caracters"){
        _.each(res, function(d) {
          if(d._id != null){
            if(d._id == "")
              resData.push( { text: "General", value: d._id } );
            else
              resData.push( { text: d._id, value: d._id } );
          }
        });
      }else{
        _.each(res, function(d) {
          if(d._id != null)
            resData.push( { text: d._id, value: d._id } );
        });
      }

      filter[f.id].data(resData);

      if( _.has( payload, f.payload ) && _.has( filter, f.id ))
        filter[f.id].value(payload[f.payload]);
    
    });
  });
  return filter
}
wa.SetupTemplate2 = function(data) {
  var template = data.details;
  var newTemplate = [];
  var newPageData = [];
  
  _.each(template,function(d,i){
    var filter = {};
    if(d.mainPage.type == "wa_reviseQryChart"){

      filter = wa.insertFilter( 
                                "/widgetanalysis/getfilterrating", 
                                _.clone( wa.filterProperties() ), 
                                wa_reviseQryChart.leftFilter, 
                                _.clone( d.payload ) 
                              );
    }else{

      var keyFilter =  wa.defFilter();
      if(d.mainPage.type == "wa_DisChart"){
        keyFilter = wa_DisChart.leftFilter();
      }else if(d.mainPage.type == "wa_DSChart"){
        keyFilter = wa_DSChart.leftFilter();
      }

      filter = wa.insertFilter( 
                                "/widgetanalysis/getfilterwidget", 
                                _.clone( wa.filterProperties() ), 
                               keyFilter, 
                                _.clone( d.payload ) 
                              )
    }
    // if(d.mainPage.type())
    newTemplate.push(
      {
        id: createUid(),
        filter: filter,
        payload: d.payload,
        pullRequest: ko.observable(0),
        mainPage: {
          title: ko.observable("Analytics"),
          type: ko.observable(d.mainPage.type),  
          mode: ko.observable(d.mainPage.mode), 
          filter: d.mainPage.filter,
          dataSource:[],
        }
      }
    );
    newPageData.push(i+1);
  });

  wa.template(newTemplate);

  wa.page.active(0);
  wa.page.total(template.length);
  wa.page.data(newPageData);
  wa.loaderSetupTemplate(template.length);

  var _template = wa.template();
  _.each(_template, function(d, i) { 
    d.pullRequest.subscribe(function(n){
      if(n == 0)
        return wa.loaderSetupTemplate(wa.loaderSetupTemplate() - 1);
    });
    wa.page.active(i+1);
    wa.reloadPage2(d);
  });
  // var filter  = _.clone( wa.filterProperties() );
  // var payload = wa.createPayload(filter, wa.defFilter());
  
  // wa.GetDataDefaultFilters(filter, "", payload);
 
  // wa.template.push({
  //   filter : filter,
  //   payload : payload,
  //   mainPage : {
  //     // available ["default","investor"]   
  //     type : ko.observable(""), 
  //     // available 2 options: chooseData and preview
  //     mode: ko.observable('chooseData'),
  //     // filter mainpage
  //     filter: {}
  //   }
  // }); 

  // _.each(template, function(d, i) {
  //   newPageData.push(i+1); 
  //   var newFilter = wa.getFilterTemplate();
  //   var filterKeys = Object.keys(newFilter);
  //   _.each(d.filter, function(obj) {
  //     if(newFilter[obj.id]) {
  //       console.log(obj);
  //       newFilter[obj.id].value(obj.value);
  //     } else {
  //       newFilter[obj.id] = {
  //         value: obj.value
  //       }
  //     }

  //   })
  //   // _.each(filterKeys, function(key,idx) {
  //   //   if(d.filter[idx].value.length > 0) {
  //   //     newFilter[key].value(d.filter[idx].value);
  //   //     newFilter[key].data(d.filter[idx].value);
  //   //   }
  //   // })
  //   var mainPage = {
  //     type: ko.observable(d.mainPage.type),
  //     mode: ko.observable(d.mainPage.mode),
  //   }
  //   newTemplate.push({
  //     filter: newFilter,
  //     mainPage: mainPage
  //   });
  // });
  // wa.template(newTemplate);
  // wa.page.active(1);
  // wa.page.total(template.length);
  // wa.page.data(newPageData);
  // var _template = wa.template();
  // _.each(_template, function(d, i) {
  //   wa.page.active(i+1);
  //   wa.reloadPage(d.filter, i);
  // })
}
wa.loadTemplate2  = function(val) {
  ajaxPost('/widgetanalysis/getdetailswidgetanalysis',{ id: val }, function(res) {
    wa.SetupTemplate2(res.Data);
  })
}
wa.page.active.subscribe(function(n){
  setTimeout(function(){
    $(window).resize(); 
  },300)
})
$(function() {
  wa.init();
})



wa.config         = {
                      dataViz: ["wa_IChart"],
                      caption: ko.observable(defaultCaption),
                      modal: {
                        state: ko.observable(""),
                        investor: {
                          defaultTypes: ['Contains', 'Equals'],
                          type: ko.observable("Contains"),
                          searchText: ko.observable(""),
                          searchMulti: ko.observableArray([]),
                          data: ko.observableArray([]),
                        },
                        distributions: {
                          defaultTypes: ['Contains', 'Equals'],
                          investorsList: ko.observableArray([]),
                          investorsVal: ko.observableArray([]),
                          investedType: ko.observable("Equals"),
                          investedList: ko.observableArray([]),
                          investedMulti: ko.observableArray([]),
                          investedText: ko.observable(""),
                        },
                        commonuninvestor: {
                          commonInvestorsList: ko.observableArray([]),
                          commonInvestorsVal: ko.observableArray([]),
                          commonInvestedList: ko.observableArray([]),
                          commonInvestedVal: ko.observableArray([]),
                        },
                        commonInvestor: {
                          investorsList: ko.observableArray([]),
                          investorsVal: ko.observable(""),
                        }
                      },
                      template: {
                        data: ko.observableArray([]),
                        value: ko.observable(""),
                        inputVal: ko.observable(""),
                      },
                      realoadProcess : ko.observable(true)
                    };
wa.filterDefault  = [
                      {id: 'Issuer', title: 'Issuer Name'},
                      {id: 'Parentcompanyname', title: 'Parent Company Name'},
                      {id: 'Continent', title: 'Continent'},
                      {id: 'Region', title: 'Region'},
                      {id: 'Country', title: 'Country'},
                      {id: 'Industry', title: 'Industry'},
                      {id: 'Ownership', title: 'Ownership'},
                      {id: 'Currency', title: 'Currency'},
                      {id: 'Ranking', title: 'Ranking'},
                      {id: 'Product', title: 'Product'}
                    ];
wa.config.template.value.subscribe(function(newValue) {
  if(newValue == '') {
    wa.formatTemplate();
  } else {
    wa.loadTemplate2(newValue);
  }
})
wa.closeBtnHandler = function() {
  var template = wa.getActivePage();
  template.mainPage.mode("chooseData");
  wa.config.caption(defaultCaption);
  if(template.mainPage.type() ==  "wa_reviseQryChart")
    template.payload = wa.createPayload( template.filter,  wa.defFilter() );
  template.mainPage.type("");
};
wa.GetDataFilter = function(filter, exceptFilter) {
  var payload = wa.GeneratePayload(filter);
  _.each(wa.defFilter(), function(o){
    if((exceptFilter && exceptFilter == o.id) || !o.ajax)
      return;
    payload["Flag"] = o.flag;
    getFilter("/widgetanalysis/getfilterwidget", payload, filter[o.id].data);
  });
}





wa.getFilterTemplate = function() {
  return {
    "Issuer": {
      payload : "Issuer",
      id    : 'issuer',
      data  : ko.observableArray([{_id: 'Issuer'}]),
      value : ko.observableArray([]),
      loading : false,
      visible : true
    },
    "Parentcompanyname": {
      payload : "Parentcompanyname",
      id      : 'parent_company_name',
      data    : ko.observableArray(['Parent Company Name']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Continent": {
      payload : "Continent",
      id      : 'continent',
      data    : ko.observableArray(['Continent']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true
    },
    "Region": {
      payload : "Region",
      id      : 'region',
      data    : ko.observableArray(['Region']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Country": {
      payload : "Country",
      id      : 'country',
      data    : ko.observableArray(['Country']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Superindustry": {
      payload : "Superindustry",
      id      : 'super_industry',
      data    : ko.observableArray(['Super Industry']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Industry": {
      payload : "Industry",
      id      : 'industry',
      data    : ko.observableArray(['Industry']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
  

    "Ownership": {
      payload : "Ownership",
      id      : 'ownership',
      data    : ko.observableArray(['Ownership']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "OwnershipReverse": {
      payload : "OwnershipReverse",
      id      : 'ownership',
      data    : ko.observableArray(['Ownership']),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
  
    "Currency": {
      payload : "Currency",
      id      : 'currency',
      data    : ko.observableArray(['Currency' ]),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
  
    "RankingReverse": {
      payload : "RankingReverse",
      id      : 'ranking',
      data    : ko.observableArray(['Ranking' ]),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Ranking": {
      payload : "Ranking",
      id      : 'ranking',
      data    : ko.observableArray(['Ranking' ]),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
  
    "productReverse": {
      payload : "ProductReverse",
      id      : 'product',
      data    : ko.observableArray(['Product' ]),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Product": {
      payload : "Product",
      id      : 'product',
      data    : ko.observableArray(['Product' ]),
      value   : ko.observableArray([]),
      loading : false,
      visible : true,
    },
    "Ratingtype": {
      payload : "Ratingtype",
      id      : 'Ratingtype',
      data    : ko.observableArray([{text:"Fitch",value:"point_fitch"},{text:"Moody",value:"point_moody"},{text:"SP",value:"point_sp"}]),
      value   : ko.observable(""),
      loading : false,
      visible : true,
    },
    "Ratingaction": {
      payload : "Ratingaction",
      id      : 'Ratingaction',

      data    : ko.observableArray([
                                    {text:"equal to",value:"$eq"},
                                    {text:"worse than",value:"$gt"},
                                    {text:"worse than or equal to",value:"$gte"},
                                    {text:"better than",value:"$lt"},
                                    {text:"better than or equal to",value:"$lte"}
                                  ]),
      value   : ko.observable('$eq'),
      loading : false,
      visible : true,
    },
    "Ratingvalue": {
      payload : "Ratingaction",
      id      : 'Ratingvalue',
      data    : ko.observableArray([]),
      value   : ko.observable(''),
      loading : false,
      visible : true,
    },
  }
}




wa.getSelectorPage = function(page) {
  if(page) {
    return "#page-"+(page+1)
  } else {
    return "#page-"+wa.page.active()
  }
};

wa.$getSelectorPage = function(page) {
  if(page) {
    return $("#page-"+(page+1));
  } else {
    return $("#page-"+wa.page.active());
  }
}

wa.getActivePage = function() {
  return wa.template()[wa.page.active() - 1];
}

wa.getPage = function(page) {
  return wa.template()[page];
}

 
wa.getPayload =  function(){
  var template = wa.getActivePage();
  var filter = template.filter;
  return  wa.GeneratePayload(filter);
}

wa.GetTemplate = function() {
  ajaxPost("/widgetanalysis/getwidgetanalysis", {}, function(res) {
    var data = _.map(res.Data, function(o) {
      return o._id;
    });
    wa.config.template.data(data);
  });
}

wa.SetupTemplate = function(data) {
  var template = data.details;
  var newTemplate = [];
  var newPageData = [];
  _.each(template, function(d, i) {
    newPageData.push(i+1); 
    var newFilter = wa.getFilterTemplate();
    var filterKeys = Object.keys(newFilter);
    _.each(d.filter, function(obj) {
      if(newFilter[obj.id]) { 
        newFilter[obj.id].value(obj.value);
      } else {
        newFilter[obj.id] = {
          value: obj.value
        }
      }

    })
    // _.each(filterKeys, function(key,idx) {
    //   if(d.filter[idx].value.length > 0) {
    //     newFilter[key].value(d.filter[idx].value);
    //     newFilter[key].data(d.filter[idx].value);
    //   }
    // })
    var mainPage = {
      type: ko.observable(d.mainPage.type),
      mode: ko.observable(d.mainPage.mode),
    }
    newTemplate.push({
      filter: newFilter,
      mainPage: mainPage
    });
  });
  wa.template(newTemplate);
  wa.page.active(1);
  wa.page.total(template.length);
  wa.page.data(newPageData);
  var _template = wa.template();
  _.each(_template, function(d, i) {
    wa.page.active(i+1);
    wa.reloadPage(d.filter, i);
  })
}

wa.loadTemplate = function(val) {
  ajaxPost('/widgetanalysis/getdetailswidgetanalysis',{
    id: val,
  }, function(res) {
    wa.SetupTemplate(res.Data);
  })
}

wa.formatTemplate = function() {
  wa.page.active(0);
  wa.page.total(0);
  wa.page.data([]);
  wa.template([]);
  wa.createPage();
}

// wa.saveTemplate = function() {
//   var input = wa.config.template.inputVal();
//   if(input == "") {
//     return swal("", "Please insert a template name", "warning");
//   }
//   var newTemplate = [];
//   var template = wa.template();

//   _.each(template, function(o) {
//     var filter = _.map(o.filter, function(filter, i) {
//       return {
//         id: i,
//         value: filter.value()
//       }
//     });
//     var ownFilter = window[o.mainPage.type()].f;
//     if(typeof ownFilter != 'undefined') {
//       _.each(ownFilter.val, function(o, x) {
//         filter.push({
//           id: x,
//           value: typeof o == "function" ? o() : o,
//         })
//       })
//     }
//     console.log(filter);
//     newTemplate.push({
//       filter: filter,
//       mainPage: {
//         type: o.mainPage.type(),
//         mode: o.mainPage.mode(),
//       }
//     })
//   })

//   var payload = {TemplateName: input, details: newTemplate};
//   ajaxPost("/widgetanalysis/savewidgetanalysis", payload, function(res) {
//     console.log(res);
//     var currentData = wa.config.template.data();
//     currentData.push(input)
//     wa.config.template.data(currentData);
//     swal("Saved!", "", "success");
//     wa.config.template.inputVal("");
//   })
// }

wa.GeneratePayload = function(filter) {
  var payload = {}
  _.each(filter, function(d,i) {
    payload[d.payload] = typeof d.value == "function" ? d.value() : d.value
  })

  return payload;
}



wa.GetDataInvestor = function(filter) {
  var payload = wa.GeneratePayload(filter);
  getFilter("/widgetanalysis/getinvestorname", payload, wa.config.modal.investor.data)
}

wa.GetDataDistributions = function(filter) {
  var payload = wa.GeneratePayload(filter);
  payload["Flag"] = "country";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.distributions.investorsList);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.distributions.investedList);
}

wa.GetDatacommonUnInv = function(filter) {
  var payload = wa.GeneratePayload(filter);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.commonuninvestor.commonInvestorsList);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.commonuninvestor.commonInvestedList);
}

wa.GetDataCommonInvestor = function(filter) {
  var payload = wa.GeneratePayload(filter);
  payload["Flag"] = "issuer";
  getFilter("/widgetanalysis/getcountrydetail", payload, wa.config.modal.commonInvestor.investorsList);
}



wa.reloadPage = function(filter, page) {
  var _page = page ? wa.getPage(page) : wa.getActivePage();
  var payload = wa.GeneratePayload(filter);
  var mainPageType = _page.mainPage.type();
  window[mainPageType].generateDataViz();
}



wa.goToPage = function(page) {
  wa.page.active(page);
}

wa.showInvestorModal = function() {
  wa.GetDataInvestor(wa.getActivePage().filter);
  $("#investorModal").modal("show");
}

wa.handleClickAddWidget = function() {
  $("#popupOptionBar").modal("show");
};


wa.GenerateInvestorViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Investors");
  payload["Action"] = wa.config.modal.investor.type();
  payload["Text"] = wa.config.modal.investor.searchText();
  payload["Textmulti"] = wa.config.modal.investor.searchMulti();
  wa_IChart.init(payload, wa.getSelectorPage());
  template.mainPage.mode('preview');
  template.mainPage.type('wa_IChart');
  $("#investorModal").modal("hide");
};

wa.GenerateDistributionsViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Distributions");
  payload['Countrydetail'] = wa.config.modal.distributions.investorsVal();
  payload['Actions'] = wa.config.modal.distributions.investedType();
  payload['Text'] = wa.config.modal.distributions.investedText();
  payload['Textmulti'] = wa.config.modal.distributions.investedMulti();
  wa_DisChart.init(payload, $(wa.getSelectorPage()).find('.distributions'));
  template.mainPage.mode('preview');
  template.mainPage.type('distributions');
  $("#distributionsModal").modal('hide');
}

wa.GenerateDefaultViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Default");
  wa_DefChart.init("/widgetanalysis/getgridtransaction", payload,$(wa.getSelectorPage()).find('.default'));
  template.mainPage.mode('preview');
  template.mainPage.type('default');
  $("#popupOptionBar").modal("hide");
}

wa.GenerateSalesPersons = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Sales Persons");
  payload['Flag'] = 'sales_person';
  wa_DefChart.init("/widgetanalysis/getgridtransaction", payload, $(wa.getSelectorPage()).find('.salesPersons'));
  template.mainPage.mode('preview');
  template.mainPage.type('salesPersons');
  $("#popupOptionBar").modal("hide");
}

wa.GenerateCommonInvViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Common Investors");
  payload['Flag'] = 'investor_name';
  payload['Issuerdetail'] = wa.config.modal.commonInvestor.investorsVal();
  wa_DefChart.init("/widgetanalysis/getgridcommon", payload, $(wa.getSelectorPage()).find('.commonInvestor'));
  template.mainPage.mode('preview');
  template.mainPage.type('commonInvestor');
  $("#commonInvestorModal").modal("hide");
}

wa.GenerateCommonUnInvViz = function() {
  var template = wa.getActivePage();
  var filter = template.filter;
  var payload = wa.GeneratePayload(filter);
  wa.config.caption("Page of Common Un Investors");
  payload['Flag'] = 'Uninvestor';
  payload['Issuerdetail'] = wa.config.modal.commonuninvestor.commonInvestorsVal();
  payload['Issuerdetail2'] = wa.config.modal.commonuninvestor.commonInvestedVal();
  wa_DefChart.init("/widgetanalysis/getgridcommon", payload,$(wa.getSelectorPage()).find('.commonUnInvestor'));
  template.mainPage.mode('preview');
  template.mainPage.type('commonUnInvestor');
  $("#commonUnInvestorModal").modal("hide");
}

wa.init = function() {
  wa.createPage();
  wa.GetTemplate();
};


wa.showAllocationModal = function() {
  // wa.GenerateAllocated();
  $("#allocationModal").modal("show");
}

wa.showDistributionsModal = function() {
  $("#popupOptionBar").modal("hide");
  wa.GetDataDistributions(wa.getActivePage().filter);
  $("#distributionsModal").modal("show");
}

wa.showCommonUnInvModal = function() {
  // wa.GenerateAllocated();
  wa.GetDatacommonUnInv(wa.getActivePage().filter);
  $("#commonUnInvestorModal").modal("show");
}

wa.showCommonInvestorModal = function() {
  $("#popupOptionBar").modal("hide");
  wa.GetDataCommonInvestor(wa.getActivePage().filter);
  $("#commonInvestorModal").modal("show");
}


wa.exportPDF = function() {
  wa.mode('export');

  kendo.drawing.drawDOM($(".wa-content"),{
    forcePageBreak  : ".page-break",
    paperSize   : "a3",
    landscape   : true,
    margin    : {top:"5mm",left:"-2cm",right:"-2cm",bottom:"0cm"},
  })
  .then(function (group) {
    return kendo.drawing.exportPDF(group);
  })
  .done(function (data) {

    kendo.saveAs({
      dataURI   : data,
      fileName  : "DCM_Focus_Report.pdf",
        callback: (function() { wa.mode("preview")})()
    });
  });
}


// wa.GenerateAllocation = function() {
//   $("#popupOptionBar").modal("hide");
//   var template = wa.getActivePage();
//   var payload = wa.GeneratePayload(template.filter);
//   wa_AlcChart.init(payload, wa.getSelectorPage());
//   wa.config.caption("Page of Allocation");
//   template.mainPage.mode('preview');
//   template.mainPage.type('allocation');
//   $("#allocationModal").modal("hide");
// };


