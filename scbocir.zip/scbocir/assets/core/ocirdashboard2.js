ocirD.map = {
	attr: 'Map data &copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors, ' +
         '<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, ' +
         'Imagery © <a href="http://mapbox.com">Mapbox</a>',
    url: 'https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=pk.eyJ1IjoiYW5kcmlmOTUiLCJhIjoiY2l6ZGsyYm9yMjR1NjJxcDk4OXl2OWF1eCJ9.mIOW47-NbEinOt2RdL9yJQ',
    icon: {
    	grey: L.icon({
			iconUrl: '/live/static/img/marker-grey.png',
			iconSize:     [20, 45], // size of the icon 
		}),
    	receiver: L.icon({
			iconUrl: '/live/static/img/receiver-marker2.png',
			iconSize:     [20, 30], // size of the icon 
        }),
    	supplier: L.icon({
			iconUrl: '/live/static/img/supplier-marker2.png',
			iconSize:     [20, 30], // size of the icon 
		})
    }
}
ocirD.getCenterLine =  function(toLat,lat,toLng,lng){
	latSelisih = Math.abs( Math.abs(toLat) -  Math.abs(lat))
	lngSelisih = Math.abs( Math.abs(toLng) -  Math.abs(lng))
	var x = 0;
	if(latSelisih >= 1 && latSelisih <= 5){
		if (lngSelisih >= 1 && lngSelisih <= 5 ){
				x = 1
		}else if (lngSelisih > 5 && lngSelisih <= 16 ){
				x = 4
		}else{
				x = 9
		}
	}else if(latSelisih > 5 && latSelisih <= 10 ){
		if (lngSelisih >= 1 && lngSelisih <= 5 ){
				x = 1
		}else if (lngSelisih > 5 && lngSelisih <= 10 ){
				x = 4
		}else{
				x = 9
		}
	}else if ((latSelisih > 10 && latSelisih <= 15 ) && (lngSelisih > 10 && lngSelisih <= 15 ) ){
		x = 10
	}else{
		if (lngSelisih >= 1 && lngSelisih <= 5 ){
				x = 1
		}else if (lngSelisih > 5 && lngSelisih <= 10 ){
				x = 4
		}else{
				x = 9
		}
	}

	var latCenter = ((toLat + lat) / 2) + x

	if(Math.abs(lngSelisih <= 15)){
			var lngCenter = ((toLng + lng) / 2 ) + x

	}else{
			var lngCenter = ((toLng + lng) / 2 )
	}
	return {lat:latCenter, lng:lngCenter};
}
ocirD.mapReceiver = function(){
	var payload =ocirD.payload();
	$("#mapReceiver").remove();
	$(".box-map_receiver").append('<div class="map" id="mapReceiver"></div>');
	ajaxIsStart(ocirD.pullRequest);

	ajaxPost("/countrydashboard/getmapreceiver", payload, function (res){
		var dSource = res.BubbleSupplier.features;
		var dCountry = res.BoxInfo; 
        var grayscale = L.tileLayer(ocirD.map.url , {id: 'mapbox.light', attribution: ocirD.map.attr ,minZoom: 2});
        var map = L.map('mapReceiver', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
            zoomControl: false,
        });
        L.control.zoom({position:'topright'}).addTo(map);
     	_.each(dSource, function(d){
     		if(d.geometry.coordinates[0] == dCountry.Longitude && d.geometry.coordinates[1] == dCountry.Latitude) return;
     		var marker = L.marker(
     								[d.geometry.coordinates[1],d.geometry.coordinates[0]], 
     								{icon: ocirD.map.icon.grey}
     							).addTo(map);
            var centerLine = ocirD.getCenterLine(
            									dCountry.Latitude, 
            									d.geometry.coordinates[1], 
            									dCountry.Longitude, 
            									d.geometry.coordinates[0]
            								)
            
            L.curve(
            		[	
						'M',[dCountry.Latitude, dCountry.Longitude],
	                    'Q',[centerLine.lat,centerLine.lng],
	                        [d.geometry.coordinates[1], d.geometry.coordinates[0]]
	                ],
	                {weight: 2,color:d.properties.Color }
	                ).addTo(map);  
     	});
     	defMarker = L.marker([dCountry.Latitude, dCountry.Longitude], {icon: ocirD.map.icon.receiver}).addTo(map)
 		// ajaxIsDone(ocirD.pullRequest);
	 	setTimeout(function(){
	     	$(".box-map_receiver_pdf").find("#mapReceiver_pdf").remove();
	     	$("#mapReceiver").clone().appendTo(".box-map_receiver_pdf");
	     	$(".box-map_receiver_pdf").find("#mapReceiver").attr("id","mapReceiver_pdf");
	     	ajaxIsDone(ocirD.pullRequest);
		},1000)
	});
}
ocirD.mapSupplier = function(){ 
	var payload = ocirD.payload ();
	$("#mapSupplier").remove();
	$(".box-map_supplier").append('<div class="map" id="mapSupplier"></div>');
	ajaxIsStart(ocirD.pullRequest);

	ajaxPost("/countrydashboard/getmapsupplier", payload, function (res){
		var dSource = res.BubbleSupplier.features;
		var dCountry = res.BoxInfo; 
        var grayscale = L.tileLayer(ocirD.map.url , {id: 'mapbox.light', attribution: ocirD.map.attr ,minZoom: 2});
        var map = L.map('mapSupplier', {
            center: [1,38],
            zoom: 2,
            layers: grayscale,
            zoomControl: false,
        });
        L.control.zoom({position:'topright'}).addTo(map); 
		_.each(dSource, function(d){
     		if(d.geometry.coordinates[0] == dCountry.Longitude && d.geometry.coordinates[1] == dCountry.Latitude) return;
     		var marker = L.marker(
     								[d.geometry.coordinates[1],d.geometry.coordinates[0]], 
     								{icon: ocirD.map.icon.grey}
     							).addTo(map);
            var centerLine = ocirD.getCenterLine(
            									dCountry.Latitude, 
            									d.geometry.coordinates[1], 
            									dCountry.Longitude, 
            									d.geometry.coordinates[0]
            								)
            
            L.curve(
            		[	
						'M',[dCountry.Latitude, dCountry.Longitude],
	                    'Q',[centerLine.lat,centerLine.lng],
	                        [d.geometry.coordinates[1], d.geometry.coordinates[0]]
	                ],
	                {weight: 2,color:d.properties.Color }
	                ).addTo(map); 

     	});
     	defMarker = L.marker([dCountry.Latitude, dCountry.Longitude], {icon: ocirD.map.icon.supplier}).addTo(map)
     	setTimeout(function(){
     		$(".box-map_supplier_pdf").find("#mapSupplier_pdf").remove();	
	     	$("#mapSupplier").clone().appendTo(".box-map_supplier_pdf");
	     	$(".box-map_supplier_pdf").find("#mapSupplier").attr("id","mapSupplier_pdf");
	     	ajaxIsDone(ocirD.pullRequest);
		},1000)
     	// ajaxIsDone(ocirD.pullRequest);
	});	
}
ocirD.createGridSummaryReceiver =  function(){
	var payload = ocirD.payload ();
	$grid = $("#gridSummaryReceiver").find("tbody");
	$grid.html("");
	ajaxIsStart(ocirD.pullRequest);

	ajaxPost("/countrydashboard/operatingsummaryreceiver", payload, function(res){
		var str = "";
		_.each(res.Data, function(d){
			str += "<tr>";
			str += "<td style='background: #78ADD2; color: #fff;'rowspan='"+d.details.length+"'>"+d.categoryname+"</td>";
			str += "<td style='background: #78ADD2; color: #fff;'rowspan='"+d.details.length+"'>"+d.product+"</td>";
			var idx = 0;	
			_.each(d.details, function(e){
				if(idx > 0) str += "<tr>" 					
				str += "<td>"+e.country+"</td>";
				str += "<td>"+e.legal+"</td>";
				str += "<td>"+e.parent+"</td>";
			 	str += "</tr>" 			
				idx++;
			})
		})

		$("#gridSummaryReceiver").find("tbody").append(str);
		if($("#gridSummaryReceiver").height() > 400)
			$("#headGridSummaryReceiver").parent().css("margin-right","17px");
		// var $sel_pdf = $("#gridSummaryReceiverPdf");		
		// _.each(res.GridData, function(d){
		// 	var strPdf = "";
		// 	_.each(d, function(e){
		// 		strPdf += "<tr>";
		// 		strPdf += "<td style='background: #78ADD2; color: #fff;'rowspan='"+e.details.length+"'>"+e.categoryname+"</td>";
		// 		strPdf += "<td style='background: #78ADD2; color: #fff;'rowspan='"+e.details.length+"'>"+e.product+"</td>";
		// 		var idx = 0;	
		// 		_.each(e.details, function(f){
		// 			if(idx > 0) strPdf += "<tr>" 					
		// 			strPdf += "<td>"+f.country+"</td>";
		// 			strPdf += "<td>"+f.legal+"</td>";
		// 			strPdf += "<td>"+f.parent+"</td>";
		// 		 	strPdf += "</tr>" 			
		// 			idx++;
		// 		})
		// 	})
		 
		// 	$sel_pdf.append(	
		// 						"<table  class='tbl-custom' width='98%' style='margin-bottom: 30px;'>"+
		// 						"<thead><tr>"+
		// 						  "<th>Category Name</th><th>Product Function</th><th>Supplier Country</th><th>Supplier Legal Entity</th><th>Parent Process Name</th>"+
		// 						"</tr>"+
		// 						"</thead>"+strPdf+"</table>"+

		// 						"<div class='pdf-break'></div>"
		// 					);
		// })
     	ajaxIsDone(ocirD.pullRequest);		
	});
}
ocirD.createGridSummarySupplier =  function(){
	var payload = ocirD.payload ();
	$grid = $("#gridSummarySupplier").find("tbody");
	$grid.html("");
	ajaxIsStart(ocirD.pullRequest);

	ajaxPost("/countrydashboard/operatingsummarysupplier", payload, function(res){
		var str = "";
		_.each(res, function(d){
			str += "<tr>";
			str += "<td style='background: #78ADD2; color: #fff;'rowspan='"+d.details.length+"'>"+d.categoryname+"</td>";
			str += "<td style='background: #78ADD2; color: #fff;'rowspan='"+d.details.length+"'>"+d.product+"</td>";
			var idx = 0;	
			_.each(d.details, function(e){
				if(idx > 0) str += "<tr>" 					
				str += "<td>"+e.country+"</td>";
				str += "<td>"+e.legal+"</td>";
				str += "<td>"+e.parent+"</td>";
			 	str += "</tr>" 			
				idx++;
			})
		})
		$("#gridSummarySupplier").find("tbody").append(str)
		if($("#gridSummarySupplier").height() > 400)
			$("#headGridSummarySupplier").parent().css("margin-right","17px")	
	
	   	ajaxIsDone(ocirD.pullRequest);		
	});
}
ocirD.createGridCriticalEconomy =  function(){
	
	var payload = ocirD.payload ();
	$grid = $("#gridCriticalEconomy").find("tbody");
	$grid.html("");
	ajaxIsStart(ocirD.pullRequest);

	ajaxPost("/countrydashboard/criticaleconomy", payload, function(res){
		var str = "";
		_.each(res, function(d){
			var rowspan = 0
			var idx = 0;	
			var strDetail = "";
			_.each(d.details, function(e){
				if(_.size(e) == 0) return;
				if(idx > 0) strDetail += "<tr>" 	
				rowspan += e.detailsproduct.length;			
				strDetail += "<td rowspan='"+e.detailsproduct.length+"'>"+e.categoryname+"</td>";
				idx2 = 0;
				_.each(e.detailsproduct, function(f){
					if(idx2 > 0) strDetail += "<tr>" 
					strDetail += "<td>"+f.productfunction+"</td>";
					strDetail += "</tr>" 		
					idx2++
					
				}); 
				idx++;

			})

			str += "<tr>";
			str += "<td style='background: #78ADD2; color: #fff;' rowspan='"+rowspan+"'>"+d.legal+"</td>"; 	
			str += strDetail; 
		})
		$("#gridCriticalEconomy").find("tbody").append(str)
		if($("#gridCriticalEconomy").height() > 400)
			$("#headGridCriticalEconomy").parent().css("margin-right","17px")	
	
	   	ajaxIsDone(ocirD.pullRequest);		
	});
}
ocirD.createGridMapping =  function(){
	var payload = ocirD.payload ();
	$grid = $("#gridMapping").find("tbody");
	$grid.html("");
	ajaxIsStart(ocirD.pullRequest);

	ajaxPost("/countrydashboard/mappingstatusdetails", payload, function (res){ 
		var str = "";
		_.each(res, function(d){
			str +="<tr><td colspan='10'><b>"+d._id+"</b></td></tr>"
			_.each(d.details, function(e){
				str += "<tr>";
				str +="<td>"+e.product+"</td> ";

				str +="<td align='right'> "+kendo.toString(e.mappedteams,'n0')+"</td>";
				str +="<td align='right'> "+kendo.toString(e.pendingteams,'n0')+"</td>";
				str +="<td align='right' class='percentage'>"+kendo.toString(e.percentteams,'n1')+"</td>";
				
				str +="<td align='right'> "+kendo.toString(e.mappedtps,'n0')+"</td>";
				str +="<td align='right'> "+kendo.toString(e.pendingtps,'n0')+"</td>";
				str +="<td align='right' class='percentage'>"+kendo.toString(e.percenttps,'n1')+"</td>";

				str +="<td align='right'> "+kendo.toString(e.mappedsystems,'n0')+"</td>";
				str +="<td align='right'> "+kendo.toString(e.pendingsystems,'n0')+"</td>";
				str +="<td align='right' class='percentage'>"+kendo.toString(e.percentsystems,'n1')+"</td>";
				str += "</tr>";
			});
		})   
		$("#gridMapping").find("tbody").append(str);
		if($("#gridMapping").height() > 400)
			$("#headGridMapping").parent().css("margin-right","17px");
		ajaxIsDone(ocirD.pullRequest);		
	})
}

ocirD.exportPdf = function(){

	ajaxIsStart(ocirD.pullRequest);	
	$(".item").addClass("show-all");	
	if(ocirD.selectedCountry() == ""){
		kendo.drawing
	    	.drawDOM($(".app-content"),{forcePageBreak:".slide:not(:first-child)", paperSize: [$(".app-content").width(), 980.89] })
	    	.then(function(group){
	      	kendo.drawing.pdf.saveAs(group, "ocirdashboard.pdf",(function(){
										$(".item").removeClass("show-all");  
										ajaxIsDone(ocirD.pullRequest);
									})(),"");
	    	});
		return;
	}

 
	$("#img-mapReceiver").html("")
	
	var w = parseInt( $("#mapReceiver_pdf .leaflet-pane.leaflet-overlay-pane > .leaflet-zoom-animated").attr("width") );
	var h = parseInt( $("#mapReceiver_pdf .leaflet-pane.leaflet-overlay-pane > .leaflet-zoom-animated").attr("height") );
	// var style = $("#mapReceiver_pdf .leaflet-pane.leaflet-overlay-pane > .leaflet-zoom-animated").attr("style");
	// var pos = style.substring( style.indexOf("(") + 1 ,style.indexOf(")"));
	// var top =  pos.split(",")[1] ;
	// var left =   pos.split(",")[0] ;
	
	$(".box-map_receiver_pdf").css("display","block");
	$(".box-map_supplier_pdf").css("display","block");

	$("#mapReceiver_pdf .leaflet-overlay-pane svg").removeAttr("style");
	$("#mapReceiver_pdf .leaflet-overlay-pane svg").clone().appendTo( ".line-mapReceiver" );
	
	$("#img-mapSupplier").html("")
	$("#mapSupplier_pdf .leaflet-overlay-pane svg").removeAttr("style");
	$("#mapSupplier_pdf .leaflet-overlay-pane svg").clone().appendTo( ".line-mapSupplier" );
	
	$("#img-mapReceiver").css({"top": "10px", "left": "-120px"});
	$("#img-mapSupplier").css({"top": "10px", "left": "-120px"});

	html2canvas($(".line-mapReceiver"), {
	    onrendered: function(canvas) {
	        $("#img-mapReceiver").append(canvas);
	        $(".line-mapReceiver").html("");
	    },
	    width: w,
	    height: h,
	    backgroundColor: false,
	}); 
	
	html2canvas($(".line-mapSupplier"), {
	    onrendered: function(canvas) {
	        $("#img-mapSupplier").append(canvas);
	        $(".line-mapSupplier").html("");
	    },
	    width: w,
	    height: h,
	    backgroundColor: false,
	}); 


	setTimeout(function(){		
		
		kendo.drawing
	    	.drawDOM($(".app-content"),{forcePageBreak:".slide:not(:first-child)", paperSize: [$(".app-content").width(), 980.89] })
	    	.then(function(group){
	      	kendo.drawing.pdf.saveAs(group, "ocirdashboard.pdf",(function(){
										$(".box-map_receiver_pdf").css("display","none");
										$(".box-map_supplier_pdf").css("display","none");
										$(".item").removeClass("show-all");  
										ajaxIsDone(ocirD.pullRequest);
										$("#img-mapReceiver").html("")
										$("#img-mapSupplier").html("")
									})(),"");
	    	});
    },3000)
}