function ajaxIsStart(f){
 	f( f() + 1);
}
function ajaxIsDone(f){
	if(f() <= 0) return;
  	f( f() - 1);
}
function coloringDropdown($id, value){
	$sel = $id.find(".k-dropdown-wrap.k-state-default > span[unselectable='on']");
	(value == "Y")? $sel.removeClass("font-red").addClass("font-green") : $sel.removeClass("font-green").addClass("font-red")
}
function coloringInput($sel, value){
	console.log(value);
	var color = "#EC644B";
	if(value >= 75)
		color = "#87D37C";
	else if(value >= 50)
		color = "#F4D03F";
	$sel.css("background", color)
}
function checkSlider(){ 
	if($('.carousel-inner .item:first').hasClass('active')) {
        $('.left.carousel-control').hide();
        $('.right.carousel-control').show();
    } else if($('.carousel-inner .item:last').hasClass('active')) {
        $('.left.carousel-control').show();
        $('.right.carousel-control').hide();
    } else {
        $('.carousel-control').show();
    } 
} 
var ocirD = {
	dataCountry: ko.observableArray([]),
	dataCef: ko.observableArray([]),
	dataNecessery: ko.observableArray([]),
	selectedCef: ko.observableArray([]),
	selectednecessary: ko.observableArray([]),
	selectedCountry: ko.observable(""),
	selectedRegion: ko.observable(""),
	selectedDateCertification: ko.observable(""),
	selectedReg: ko.observable(""),
	inputOcirLiquidity: ko.observable(0),
	selectedInPlace: ko.observable(""),
	selectedCFOApproval: ko.observable(""), 
	selectedDateScenario: ko.observable(),
	selectedCountryApproval: ko.observable(),
	dataGridFmi: ko.observableArray([]),
	pullRequest: ko.observable(0),
	totalReceiver: ko.observable(0),
	totalSupplier: ko.observable(0), 
	disableSubscribe: ko.observable(false),
	dataReceiverEntities: ko.observableArray([]),
	dataSupplierEntities: ko.observableArray([]),
	dataLogCriticalEconomy: ko.observableArray([]),
	dataLogFinancialResilience: ko.observableArray([]),
	dataLogPlaybook: ko.observableArray([]),
	dataServiceRecipient: ko.observableArray([]),
	inputDevReceiver: ko.observable(0),
	inputDevSupplier: ko.observable(0),
	dataLogDevReceiver: ko.observableArray([]),
	dataLogDevSupplier: ko.observableArray([]),
	loadingModal: ko.observable(false),
	dataOffering: ko.observableArray([]), 
	dataL1Receiver: ko.observable({L1:0, Countries:0,"Total-L1":0}), 
	dataL1Supplier: ko.observable({L1:0, Countries:0,"Total-L1":0}),
	enableDateCertification: ko.observable(true),
	enableReg: ko.observable(true),
	enableOcirLiquidity: ko.observable(true),
	dataServiceRecipientSuplier: ko.observableArray([]),
	slideActive: ko.observable(1),
};
ocirD.pullRequest.subscribe(function(v){
	if(v == 0) $(".item").removeClass("show-all");	
})
ocirD.templateBoxDonuts = ko.observableArray([
	{index:0, title: "STAFF", number:ko.observable(0), urlNumber: "/countrydashboard/staffnumber", urlDonut:"/countrydashboard/donutunderstaff", legendDonut: ko.observableArray([]) },
	{index:1, title: "VENDOR", number:ko.observable(0), urlNumber: "/countrydashboard/vendornumber", urlDonut:"/countrydashboard/donutundervendor", legendDonut: ko.observableArray([]) },
	{index:2, title: "SYSTEMS", number:ko.observable(0), urlNumber: "/countrydashboard/systemsnumber", urlDonut:"/countrydashboard/donutundersystems", legendDonut: ko.observableArray([]) },
	{index:3, title: "INTRA GROUP CONTRACTS", number:ko.observable(0), urlNumber: "/countrydashboard/slasnumber", urlDonut:"/countrydashboard/donutundersla", legendDonut: ko.observableArray([]) },
	{index:4, title: "EXTERNAL CONTRACTS", number:ko.observable(0), urlNumber: "/countrydashboard/contractsnumber", urlDonut:"/countrydashboard/donutundercontract", legendDonut: ko.observableArray([]) },
	{index:5, title: "PROPERTIES", number:ko.observable(0), urlNumber: "/countrydashboard/propertiesnumber ", urlDonut:"/countrydashboard/donutunderproperties", legendDonut: ko.observableArray([]) },
]);

ocirD.selectedDateCertification.subscribe(function(n){
	if(!ocirD.enableDateCertification()) return ocirD.enableDateCertification(true);
	ocirD.saveCriticalEconomy()
})
ocirD.selectedReg.subscribe(function(n){

	if(!ocirD.enableReg()) return ocirD.enableReg(true);
	coloringDropdown($(".reg-dropdown"),n);
	ocirD.saveCriticalEconomy();
});

// ocirD.selectedInPlace.subscribe(function(n){
// 	coloringDropdown($(".inPlace-dropdown"),n);
// 	ocirD.saveFinancialResilience();
// });
ocirD.inputOcirLiquidity.subscribe(function(n){
	if(!ocirD.enableOcirLiquidity()) return ocirD.enableOcirLiquidity(true);
	ocirD.saveFinancialResilience();
});
// ocirD.selectedCFOApproval.subscribe(function(n){
// 	coloringDropdown($(".cfoApp-dropdown"),n);
// 	ocirD.saveFinancialResilience();
// });
// ocirD.selectedDateScenario.subscribe(function(n){
// 	ocirD.savePlaybook()
// })
// ocirD.selectedCountryApproval.subscribe(function(n){
// 	coloringDropdown($(".countryApp-dropdown"),n);
// 	ocirD.savePlaybook()
// });
ocirD.inputDevReceiver.subscribe(function(n){ 
	ocirD.saveInvolvementReceiver();
	var percentage =  parseInt(n) / parseInt(ocirD.totalReceiver()) * 100;
	coloringInput($(".r-approved-bg"), parseInt(percentage))
	coloringInput($(".r-approved-input"), parseInt(percentage))
})
ocirD.inputDevSupplier.subscribe(function(n){
	ocirD.saveInvolvementSupplier();

	var percentage = parseInt(n) / parseInt(ocirD.totalSupplier()) * 100;
	coloringInput($(".s-approved-bg"), parseInt(percentage));
	coloringInput($(".s-approved-input"), parseInt(percentage));
})
ocirD.totalReceiver.subscribe(function(n){
	var percentage = parseInt(ocirD.inputDevReceiver()) / parseInt(n) * 100;
	coloringInput($(".r-approved-bg"), parseInt(percentage))
	coloringInput($(".r-approved-input"), parseInt(percentage))
});
ocirD.totalSupplier.subscribe(function(n){
	var percentage = parseInt(ocirD.inputDevSupplier()) / parseInt(n) * 100; 
	coloringInput($(".s-approved-bg"), parseInt(percentage))
	coloringInput($(".s-approved-input"), parseInt(percentage))
});
ocirD.payload = function(){
	return {Country : ocirD.selectedCountry(), Cefcritical: ocirD.selectedCef(),  Pfpcritical: ocirD.selectednecessary()};
};
ocirD.selectedCountry.subscribe(function(n){
	if(n == "") return;
	var d =_.where(ocirD.dataCountry(), {_id: n});
	if(d.length == 0) return;
	ocirD.selectedRegion(d[0].region);
	ocirD.getFilter("country")
	ocirD.loadAll();
});
ocirD.selectedCef.subscribe(function(n){
	ocirD.getFilter("cef");
	ocirD.loadAll();
})
ocirD.selectednecessary.subscribe(function(n){
	ocirD.getFilter("necessery");
	ocirD.loadAll();
})
ocirD.saveCriticalEconomy = function(){

	if(ocirD.selectedCountry() == "" || ocirD.disableSubscribe()) return;
	var payload = {
		Country: ocirD.selectedCountry(),
		details: {DateCertification: ocirD.selectedDateCertification(), regEndorsment: ocirD.selectedReg() }
	}
	ajaxPost("/countrydashboard/savecriticaleconomy",payload, function(res){
	 
	});
}
ocirD.saveFinancialResilience = function(){

	if(ocirD.selectedCountry() == "" || ocirD.disableSubscribe()) return;
	var payload = {
		Country: ocirD.selectedCountry(),
		details: {inputOcirLiquidity: parseInt(ocirD.inputOcirLiquidity()), InPlace: ocirD.selectedInPlace(), CFOApproval: ocirD.selectedCFOApproval() }
	}
	ajaxPost("/countrydashboard/savefinancialresilience",payload, function(res){
	});
}
ocirD.savePlaybook = function(){
	if(ocirD.selectedCountry() == ""|| ocirD.disableSubscribe()) return;
	var payload = {
		Country: ocirD.selectedCountry(),
		details: {DateScenario: ocirD.selectedDateScenario(), CountryApproval: ocirD.selectedCountryApproval() }
	}
	ajaxPost("/countrydashboard/saveplaybook",payload, function(res){
	 
	});
}
ocirD.saveInvolvementReceiver = function(){
	if(ocirD.selectedCountry() == ""|| ocirD.disableSubscribe()) return;
	var payload = {
		Country: ocirD.selectedCountry(),
		Input:  parseInt(ocirD.inputDevReceiver())
	}
	ajaxPost("/countrydashboard/saveinvolvementreceiver", payload, function (res){
 	
 	});
}
ocirD.saveInvolvementSupplier = function(){
	if(ocirD.selectedCountry() == ""|| ocirD.disableSubscribe()) return;
	var payload = {
		Country: ocirD.selectedCountry(),
		Input:  parseInt(ocirD.inputDevSupplier())
	}
	ajaxPost("/countrydashboard/saveinvolvementsupplier", payload, function (res){
 	
 	});	
}
ocirD.openModalLog = function(type){
	$modal = $("#modal-log-detail");
	$sel_title = $modal.find(".titleheader .title");
	switch(type){
		case"CE":
			$sel_title.text("Log Critical Economy:")
			
			var columns = [
			
							{field:"loginid", title: "Login Id"},
							{field:"fullname", title: "Name"},
							{field:"lastModified", title: "Modified Date", template: function(d){ return moment(d.lastModified).format("DD-MMM-YYYY HH:mm:SS") }, attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
							{field:"details.DateCertification", title: "Last Certification", template: function(d){ return moment(d.details.DateCertification).format("DD-MMM-YYYY") }, attributes: { "class": "text-center" }, headerAttributes:  { "class": "text-center" } },
							{field:"details.regEndorsment", title: "Reg Endorsment", attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } }, 
					
						];
			ocirD.createGridLog("/countrydashboard/getcriticaleconomy", $modal.find(".grid"), columns, ocirD.dataLogCriticalEconomy())
			break;
		case"FR": 
			$sel_title.text("Log Financial Resilience:") 
			var columns = [

							{field:"loginid", title: "Login Id"},
							{field:"fullname", title: "Name"},
							{field:"lastModified", title: "Modified Date", template: function(d){ return moment(d.lastModified).format("DD-MMM-YYYY HH:mm:SS") }, attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
							{field:"details.inputOcirLiquidity", title: "OCIR Liquidity", attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" }},
						
							// {field:"details.InPlace", title: "InPlace", attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
							// {field:"details.CFOApproval", title: "CFO Approval", attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } }
						];
			ocirD.createGridLog("/countrydashboard/getfinancialresilience", $modal.find(".grid"),columns, ocirD.dataLogFinancialResilience())
			break;
		case"PB":  
			$sel_title.text("Log Playbook:") 
			var columns = [
							
							{field:"loginid", title: "Login Id"}, 
							{field:"fullname", title: "Name"},
							{field:"lastModified", title: "Modified Date", template: function(d){ return moment(d.lastModified).format("DD-MMM-YYYY") }, attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
							{field:"details.DateScenario", title: "Date Scenario",  template: function(d){ return moment(d.details.DateScenario).format("DD-MMM-YYYY") },  attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
							{field:"details.CountryApproval", title: "Reg Country Approval",  attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
					
						];
			ocirD.createGridLog("/countrydashboard/getplaybook", $modal.find(".grid"),columns, ocirD.dataLogPlaybook())
			break;
		case"receiver":  
			$sel_title.text("Log Critical Economic Functions Receiver:") 
			var columns = [
							
							{field:"loginid", title: "Login Id"}, 
							{field:"fullname", title: "Name"},
							{field:"lastModified", title: "Modified Date", template: function(d){ return moment(d.lastModified).format("DD-MMM-YYYY HH:mm:SS") }, attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
							{field:"Input", title: "Approved",  attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
							 
						];
			ocirD.createGridLog("/countrydashboard/getinvolvementreceiver", $modal.find(".grid"),columns, ocirD.dataLogDevReceiver())
			break;
		case"supplier":  
			$sel_title.text("Log Critical Economic Functions Supplier:") 
			var columns = [
							
							{field:"loginid", title: "Login Id"}, 
							{field:"fullname", title: "Name"},
							{field:"lastModified", title: "Modified Date", template: function(d){ return moment(d.lastModified).format("DD-MMM-YYYY HH:mm:SS") }, attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
							{field:"Input", title: "Approved",  attributes: { "class": "text-center" }, headerAttributes: { "class": "text-center" } },
							 
						];
			ocirD.createGridLog("/countrydashboard/getinvolvementsupplier", $modal.find(".grid"),columns, ocirD.dataLogDevSupplier())
			break;	
	}
	$modal.modal("show");
} 
ocirD.createGridLog = function(url,$grid,col,data){ 
  	var payload = ocirD.payload(); 	
  	ocirD.loadingModal(true);
  	$grid.html("");
	$grid.kendoGrid({
		dataSource: { 
			transport: {
			read:function(option){
				ajaxPost(url,payload, function(res){
					ocirD.loadingModal(false);
					option.success({ Records: res.Data, Count: res.Data.length});
				});
			},
		},
		schema: {
			data: function(data) {
			    return data.Records;
			},
			total: "Count",
		},
		pageSize: 10,
		serverPaging: true,
		serverSorting: true,
		serverFiltering: true,
		},
		sortable: true,
		pageable: {
		numeric: true,
		previousNext: true,
		messages: {
		display: "Showing {2} data items"
		}
		},
		columns: col
	});
}
ocirD.getCriticalEconomy = function(){
	ocirD.enableDateCertification(false)
	ocirD.enableReg(false) 
	var payload = ocirD.payload(); 	
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/getcriticaleconomy",payload, function(res){
		ajaxIsDone(ocirD.pullRequest);
		if(res.Data.length == 0){
			ocirD.selectedDateCertification("");
			ocirD.selectedReg("Y");
		}else{ 
			ocirD.selectedDateCertification(res.Data[0].details.DateCertification);
			ocirD.selectedReg(res.Data[0].details.regEndorsment);
		}
		ocirD.dataLogCriticalEconomy(res.Data)
	});
}
ocirD.getFinancialResilience = function(){
 
	ocirD.enableOcirLiquidity(false)
	var payload = ocirD.payload(); 	
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/getfinancialresilience",payload, function(res){
		ajaxIsDone(ocirD.pullRequest); 
		if(res.Data.length == 0){
			ocirD.inputOcirLiquidity(0)
			// ocirD.selectedInPlace("Y");
			// ocirD.selectedCFOApproval("Y");
		}else{ 
			ocirD.inputOcirLiquidity(res.Data[0].details.inputOcirLiquidity);
			// ocirD.selectedInPlace(res.Data[0].details.InPlace);
			// ocirD.selectedCFOApproval(res.Data[0].details.CFOApproval);
		}	 

	});
}
ocirD.getPlaybook = function(){
	 
	var payload = ocirD.payload(); 	
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/getplaybook",payload, function(res){
		ajaxIsDone(ocirD.pullRequest);
		if(res.Data.length == 0){
			ocirD.selectedDateScenario("")
			ocirD.selectedCountryApproval("Y"); 
		}else{ 
			ocirD.selectedDateScenario(res.Data[0].details.DateScenario);
			ocirD.selectedCountryApproval(res.Data[0].details.CountryApproval); 
		}	 
	});
}
ocirD.getInvolvementReceiver = function(){
	 
	var payload = ocirD.payload(); 	
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/getinvolvementreceiver", payload, function (res){
 		ajaxIsDone(ocirD.pullRequest); 
		if(res.Data.length == 0) ocirD.inputDevReceiver(0);
		else ocirD.inputDevReceiver(res.Data[0].Input);
		ocirD.dataLogDevReceiver(res.Data)

 	});
}
ocirD.getInvolvementSupplier = function(){
	 
	var payload = ocirD.payload(); 	
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/getinvolvementsupplier", payload, function (res){
 		ajaxIsDone(ocirD.pullRequest);
		if(res.Data.length == 0) ocirD.inputDevSupplier(0);
		else ocirD.inputDevSupplier(res.Data[0].Input);
		ocirD.dataLogDevSupplier(res.Data)

 	});	
}

ocirD.getDataGridFmi =  function(){ 
 	var payload = ocirD.payload(); 
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/fmis", payload, function (res){
		ajaxIsDone(ocirD.pullRequest);
		ocirD.dataGridFmi(res);
	})
}
ocirD.getTotalReceiver = function(){
	var payload = ocirD.payload();
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/l1receiver", payload, function (res){
		ajaxIsDone(ocirD.pullRequest);
		ocirD.totalReceiver(_.size(res) > 0 ? res["Total-Receiver"] : "-");
	})
}
ocirD.getTotalSupplier = function(){
	var payload = ocirD.payload();
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/l1supplier", payload, function (res){
		ajaxIsDone(ocirD.pullRequest);
		ocirD.totalSupplier(_.size(res) > 0 ? res["Total-Supplier"] : "-");
	})		
}
ocirD.getEntities = function(){
	var payload = ocirD.payload();
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/incountryentities", payload, function (res){
		ajaxIsDone(ocirD.pullRequest);
  		ocirD.dataReceiverEntities(_.map(res.receiver,"_id"))
		ocirD.dataSupplierEntities(_.map(res.supplier,"_id"))
		var str = ocirD.dataReceiverEntities().join(",") + ocirD.dataSupplierEntities().join(",");
		if(str.length >= 290){
			$("#entities-tbl").css("font-size","7px")
		}
		if(str.length <= 290 && str.length > 150){ 
			console.log("2")
			$("#entities-tbl").css("font-size","9px")
		}
		if(str.length <= 150 && str.length > 50){
			console.log("3")
			$("#entities-tbl").css("font-size","10px")
		}
		if(str.length <= 50 && str.length < 50){
			console.log("4")
			$("#entities-tbl").css("font-size","11px")
		}
    })
}
ocirD.getServiceRecipient =  function(){
	var payload = ocirD.payload();
	payload.Flag = "receiver";
	payload["Region"] = ocirD.selectedRegion();
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/serviceresipient", payload, function (res){
 		ajaxIsDone(ocirD.pullRequest);
 		var series = [];
		var data = []
		var c = {"GBS": {name:"GBS", color : "#0075B0"}, "HUB": {name:"HUB", color : "#3F9C35"},"In Country": {name:"In Country", color : "#009FDA"},"Others": {name:"Others", color : "#D9534F"}};
 		var cSeries = {
			categoryField: "name",
			field: "barValue",
			border: {
				width: 0,
			},  
			tooltip: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
		};
		var cLabels = {
			font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
			color: "#fff",
			rotation: -90,
			template: function(e){ 
				return e.category;
			},
			visible: true,
			position:"insideBase",
			background: "transparent"
		};
 		_.each(res, function(d,i){
  			if(d.classification == "") return;
 			d["color"] = c[d.classification].color;
 			d["name"] = "default";
 			data.push(d);
 		});
 	
 		for(var i = data.length - 1; i >= 0; i--){
 			var d = data[i]; 
 			var s = _.clone(cSeries);
 			d.barValue  = d.country;
 			if(d.country == 0){
 				d.barValue = 1;
 				s.tooltip.template = "0";
 				}
 			s = ( Object.assign({data: [d] }, s ) )  
			series.push( Object.assign(s, _.clone(c[d.classification])) );  
 		} 
 		console.log(data, series);
 		ocirD.dataServiceRecipient(data);
 		// setTimeout(function(){
	 	 
 		$bar = $(".chart-bar"); 
 		$bar.html("");
 		$bar.kendoChart({
			legend :{
				position :"bottom",
				font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
				 visible: false,
			}, 

			transitions: false,
	 		chartArea:{
	 			height: 170,
	 			margin:{}
	 		},
			seriesDefaults: { 
				stack:true,
					overlay: {
						gradient: "none"
				},
				gap: 1,
				color: "transparent",
			},
			series: series,
			categoryAxis :{ 
				labels: { 
	                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	               	visible: false
		              // rotation: 45
	            },
	            majorGridLines: {
					visible: false
	            },
	            line:{
	                visible:false
	            },
			},
			valueAxis:{
				max: 100,
	            min:0, 
	            majorGridLines: {
					visible: false,
					dashType: "dashDot"
	            },
	        
	            line: {
	              visible: false
	            },
	           
	            labels:{
	              visible:false,
	            },
			}, 
			seriesColors: ["#66DBFF"], 
		});   
 		// },300)
 	})
}

ocirD.showHideSeriesDonut = function(idDonut, idLegend, idx){
	$id = $(idDonut);

	var donutChart  =  $id.getKendoChart();
	var visibleData =  $id.getKendoChart().options.series[0].data[idx].visible;
	var colors = $id.getKendoChart().options.seriesColors;
	visibleData = visibleData == undefined? true:visibleData;
	   
	$id.getKendoChart().options.series[0].data[idx].visible = !visibleData
	$id.getKendoChart().redraw(); 
	$(idLegend+" li").eq(idx).hasClass("disable") ? $(idLegend+" li").eq(idx).removeClass("disable") : $(idLegend+" li").eq(idx).addClass("disable");
} 
ocirD.drawDonut = function(id, data){
	var height = 130;
	$(id).kendoChart({
		theme: "flat",
       	legend: {
          	position: 'right',
          	visible : false
       	},
       	chartArea:{
        	height : height,  
        	 
        },
       	dataSource : { 
       			data : data
       	},
       	seriesDefaults: {
            type:"donut",
            stack: true,
            holeSize: height/3.7,
            padding: 8
        },
   	  	series: [
	   		{
	        	field : "value",
	        	categoryField: "category",
	        	name: "Buy",
	        	color: "color",
	        	  labels : { 
	            	template : "#= category.replace('|',' ')#",
	            },
	            tooltip: {
					visible: true,
					template: "#= kendo.toString(value,'N0') #"
				},
	    	},
    	], 
		labels:{
			font:"12px Arial,Helvetica,sans-serif",
			align: "center",
			template : "#= value #",
			rotation: "auto",
			color: "#0e678d",
		},
 
	});
}
ocirD.renderBoxDonuts = function(){
	var payload = ocirD.payload();
	var ajaxNumberDonut = function(e){
		ajaxIsStart(ocirD.pullRequest);
		ajaxPost(e.urlNumber, payload, function(res){
			ajaxIsDone(ocirD.pullRequest);
			if(res.length == 0) return;
			e.number(kendo.toString(parseInt(res[0].count),"n0"));
		});
	}
	var ajaxDonut = function(e){
		ajaxIsStart(ocirD.pullRequest);
		ajaxPost(e.urlDonut, payload, function(res){
			ajaxIsDone(ocirD.pullRequest);

			if(res.length == 0) return;
			if(e.title == "STAFF"){
				var total = res[0]["pending-validation"] + res[0]["validated"] + res[0]["unmapped"];
				var data = [
					{id: e.index, category: "Pending Validation", value: res[0]["pending-validation"], color:"#F6B75F", percentage: res[0]["pending-validation"]  == 0  ? 0 : res[0]["pending-validation"]  / total * 100 },
					{id: e.index, category: "Validated", value: res[0]["validated"], color:"#3F9C35", percentage: res[0]["validated"] == 0 ? 0 : res[0]["validated"] / total * 100},
					{id: e.index, category: "Un Mapped", value: res[0]["unmapped"], color:"#75d170", percentage: res[0]["unmapped"] == 0 ? 0 : res[0]["unmapped"] / total * 100},
				];
			}else if(_.has(res[0], "todraft")){ 
				var total = res[0]["todraft"] + res[0]["not-remediated"] + res[0]["remediated"];	
			  
					var data = [
						{id: e.index, category: "Not Remediated", value: res[0]["not-remediated"], color:"#0E678D",  percentage: res[0]["not-remediated"] == 0 ? 0 : res[0]["not-remediated"] / total * 100  },
						{id: e.index, category: "Remediated", value: res[0]["remediated"], color:"#78ADD2",  percentage: res[0]["remediated"] == 0 ? 0 : res[0]["remediated"] / total * 100 },
						{id: e.index, category: "To Draft", value: res[0]["todraft"], color:"#F6B75F",  percentage: res[0]["todraft"] == 0 ? 0 : res[0]["todraft"] / total * 100 },
					]; 
			 
			}else{

				if(_.has(res[0],"validated") || _.has(res[0],"pending-validation")){
					
					var total = res[0]["pending-validation"] + res[0]["validated"];	
					var data = [
						{id: e.index, category: "Pending Validation", value: res[0]["pending-validation"], color:"#F6B75F" ,  percentage: res[0]["pending-validation"] == 0 ? 0 : res[0]["pending-validation"] / total * 100 },
						{id: e.index, category: "Validated", value: res[0]["validated"], color:"#3F9C35",  percentage: res[0]["validated"] == 0 ? 0 : res[0]["validated"] / total * 100 },
					];
				
				}else{
					var total = res[0]["not-remediated"] + res[0]["remediated"]; 
					var data = [
						{id: e.index, category: "Not Remediated", value: res[0]["not-remediated"], color:"#0E678D",  percentage: res[0]["not-remediated"] == 0 ? 0 : res[0]["not-remediated"] / total * 100  },
						{id: e.index, category: "Remediated", value: res[0]["remediated"], color:"#78ADD2",  percentage: res[0]["remediated"] == 0 ? 0 : res[0]["remediated"] / total * 100 },
					];
				}
			}
			ocirD.drawDonut("#donut-"+e.index, data);
			e.legendDonut(data);
		});
	}
	_.each(ocirD.templateBoxDonuts(), function(d){
		if(d.urlNumber != "") ajaxNumberDonut(d);
		if(d.urlDonut != "") ajaxDonut(d);
	}) 
}
ocirD.renderGridCef = function(){
	var payload = ocirD.payload()
	var $grid = $("#gridCef" );
	$grid.find("tr").eq(0).html("");
	$grid.find("tr").eq(1).html("");
	ajaxIsStart(ocirD.pullRequest);		
	ajaxPost("/countrydashboard/getcef", payload, function(res){
		ajaxIsDone(ocirD.pullRequest);
		 
		var titles = [{"categoryname":"","title":"No of CEFs"}, 
					 	{"categoryname":"Corporate Finance","title":"Corporate Finance"},
					 	{"categoryname":"Financial Markets","title":"Financial Markets"},
					 	{"categoryname":"Lending","title":"Lending"},
					 	{"categoryname":"Principal Finance","title":"Principal Finance"},
					 	{"categoryname":"Retail Products","title":"Retail Products"},
					 	{"categoryname":"Transaction Banking","title":"Transaction Banking"},
					 	{"categoryname":"Wealth Management","title":"Wealth Management"}]
 
		_.each(titles, function(d,i){
			var attr = "   align='center' style='background: #0E678D; color: #fff;' ";
			var attr2 = " align='center' ";
			if(i == 0){ 
				$grid.find("tr").eq(0).append("<td  align='center'  rowspan='2'  class='bg-blue-light font-white' style='width:89px'>"+
												d.title +
											"</td>");
				return;
			} 
			$grid.find("tr").eq(0).append("<td" + attr + ">"+
												d.title +
											"</td>");
			var foundBody = _.where(res, {_id: d.categoryname });
			var count = "-";
			if(_.has(foundBody[0],"count")) count = foundBody[0].count;		
			$grid.find("tr").eq(1).append("<td"+ attr2 +">"+
												 count+
										"</td>")
		});
	});
};
ocirD.reset =  function(){
	ocirD.disableSubscribe(true);
	ocirD.selectedDateScenario(0);
	ocirD.selectedCountryApproval("Y"); 
	ocirD.inputOcirLiquidity(0);
	ocirD.selectedInPlace("Y");
	ocirD.selectedCFOApproval("Y");
	ocirD.selectedDateCertification("");
	ocirD.selectedReg("Y");
	ocirD.inputDevSupplier(0); 
	ocirD.inputDevReceiver(0); 
	ocirD.disableSubscribe(false);
}
ocirD.renderGridOffering = function(){
 
	var payload = ocirD.payload();
	ajaxPost("/countrydashboard/activeofferings", payload, function (res){
		var data = res; 
		var $tHead =  $(".gridOffering.header" ).find("thead ").html("");
		var $tBody =  $(".gridOffering.body" ).find("tbody").html("");
	 
		var columns = [];
		_.each(data, function(d){ 
			_.each(d.details, function(e,i){
				if(columns.indexOf(i) == -1){
					columns.push(i);
				}
			});
		}) 
		$tHead.append("<tr>"+
						"<th style='width: 22px;' class='bg-white font-black'>&nbsp;</th>"+
						"<th style='width: 70px;' class='bg-white font-black'>&nbsp;</th>"+
						'<th colspan="'+columns.length+'" align="center">Products</th>'+
					+"</tr>");
		var header = "<tr>"+ 
						"<th style='width: 22px;' class='bg-white font-black'>&nbsp;</th>"+
						"<th style='width: 70px;' class='bg-white font-black'>&nbsp;</th>";
		_.each(columns, function(d){
			header +=  "<th align='center' style='width: 70px'>"+d+"</th>";
		})
		$tHead.append(header);	
 
		_.each(data, function(d, i){  
			var  b = "<tr>";
			if(i == 0) b = "<tr>"+
								"<td  style='width: 22px;'align='center' rowspan='"+data.length+"'  class='bg-blue-light font-white'>"+
									"<div class='verticalText'><p>Segments</p></div>"+
								"</td>";
			b += "<td style='width: 70px;' style='' align='center' class='bg-blue-light font-white'>"+d._id+"</th>";
			_.each(columns, function(e){
				var count = _.has(d.details, e) ? d.details[e] : "-"; 
				b += "<td style='' align='center' width='25%'>"+count+"</th>";
			});
			$tBody.append(b);
		});  
	
	});
} 
ocirD.getServiceRecipientSupplier =  function(){
	var payload = ocirD.payload();
	payload.Flag = "supplier";
	payload["Region"] = ocirD.selectedRegion();
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/serviceresipient", payload, function (res){
 		ajaxIsDone(ocirD.pullRequest);
 		var series = [];
		var data = []
		var c = {"GBS": {name:"GBS", color : "#0075B0"}, "HUB": {name:"HUB", color : "#3F9C35"},"In Country": {name:"In Country", color : "#009FDA"},"Others": {name:"Others", color : "#D9534F"}};
 		var cSeries = {
			categoryField: "name",
			field: "barValue",
			border: {
				width: 0,
			},  
			tooltip: {
				visible: true,
				template: "#= kendo.toString(value,'N0') #"
			},
		};
		var cLabels = {
			font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
			color: "#fff",
			rotation: -90,
			template: function(e){ 
				return e.category;
			},
			visible: true,
			position:"insideBase",
			background: "transparent"
		};
 		_.each(res, function(d,i){
  			if(d.classification == "") return;
 			d["color"] = c[d.classification].color;
 			d["name"] = "default";
 			data.push(d);
 		});
 	
 		for(var i = data.length - 1; i >= 0; i--){
 			var d = data[i]; 
 			var s = _.clone(cSeries);
 			d.barValue  = d.country;
 			if(d.country == 0){
 				d.barValue = 1;
 				s.tooltip.template = "0";
 				}
 			s = ( Object.assign({data: [d] }, s ) )  
			series.push( Object.assign(s, _.clone(c[d.classification])) );  
 		} 
 		console.log(data, series);
 		ocirD.dataServiceRecipientSuplier(data);
 		// setTimeout(function(){
	 	 
 		$bar = $(".chart-bar-supplier"); 
 		$bar.html("");
 		$bar.kendoChart({
			legend :{
				position :"bottom",
				font: "bold 10px Helvetica Neue, Helvetica Neue, Helvetica, Arial, sans-serif",
				 visible: false,
			}, 

			transitions: false,
	 		chartArea:{
	 			height: 170,
	 			margin:{}
	 		},
			seriesDefaults: { 
				stack:true,
					overlay: {
						gradient: "none"
				},
				gap: 1,
				color: "transparent",
			},
			series: series,
			categoryAxis :{ 
				labels: { 
	                font: "11px Helvetica Neue, Helvetica, Arial, sans-serif",
	               	visible: false
		              // rotation: 45
	            },
	            majorGridLines: {
					visible: false
	            },
	            line:{
	                visible:false
	            },
			},
			valueAxis:{
				max: 100,
	            min:0, 
	            majorGridLines: {
					visible: false,
					dashType: "dashDot"
	            },
	        
	            line: {
	              visible: false
	            },
	           
	            labels:{
	              visible:false,
	            },
			}, 
			seriesColors: ["#66DBFF"], 
		});   
 		// },300)
 	})
}
ocirD.getSegment = function(){
	var payload = ocirD.payload();
	ajaxIsStart(ocirD.pullRequest);		
		var $grid = $("#gridSegment").find("tbody");
		$grid.html("");	
	ajaxPost("/countrydashboard/getsegment", payload, function (res){
 		ajaxIsDone(ocirD.pullRequest);			
 	
 		var body = "<tr><td align='center' style='width: 89px;' class='bg-blue-light font-white'>Segments Covered</td>"
 		_.each(res, function(d){
 			body +=  "<td align='center'>"+d._id+"</td>"
 		});
 		$grid.append(body);

    })
}
ocirD.getL1Receiver =  function(){ 
	var payload = ocirD.payload();
	ajaxIsStart(ocirD.pullRequest);			
	ajaxPost("/countrydashboard/l1receiver", payload, function (res){
		ajaxIsDone(ocirD.pullRequest);	
		ocirD.dataL1Receiver(res);			
    });
}
ocirD.getL1Supplier =  function(){
	var payload = ocirD.payload();
	ajaxIsStart(ocirD.pullRequest);	
	ajaxPost("/countrydashboard/l1supplier", payload, function (res){
		ajaxIsDone(ocirD.pullRequest);	
		ocirD.dataL1Supplier(res);
    });
}
ocirD.loadAll = function(){
	if(ocirD.selectedCountry() == "")	return ocirD.reset();
	$(".item").addClass("show-all");	
	ocirD.disableSubscribe(true);
	ocirD.renderBoxDonuts();
	ocirD.renderGridCef(); 
	ocirD.getCriticalEconomy();
	ocirD.getFinancialResilience();
	ocirD.getPlaybook();
	ocirD.getDataGridFmi();
	ocirD.getTotalReceiver();
	ocirD.getTotalSupplier(); 
	ocirD.getInvolvementReceiver();
	ocirD.getInvolvementSupplier(); 
	ocirD.getEntities();
	ocirD.getServiceRecipient();
	ocirD.getSegment()
	ocirD.renderGridOffering();
	ocirD.getL1Receiver();
	ocirD.getL1Supplier();
	ocirD.getServiceRecipientSupplier();

	ocirD.mapReceiver();
	ocirD.mapSupplier();
	ocirD.createGridSummaryReceiver();
	ocirD.createGridSummarySupplier();
	ocirD.createGridCriticalEconomy();	
	ocirD.createGridMapping();		

	
	ocirD.disableSubscribe(false);
}

ocirD.exportPdf = function(){
	ajaxIsStart(ocirD.pullRequest);	
	$(".item").addClass("show-all");
	kendo.drawing
    	.drawDOM($(".app-content"),{forcePageBreak:".slide:not(:first-child)", paperSize: [$(".app-content").width(), 910.89] })
    	.then(function(group){
      	kendo.drawing.pdf.saveAs(group, "ocirdashboard.pdf",(function(){
									$(".item").removeClass("show-all");  
									ajaxIsDone(ocirD.pullRequest);
								})(),"");
    	});
}
ocirD.getCountry = function(){
	var payload = ocirD.payload();
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/filtercountry",payload, function(res){
		ajaxIsDone(ocirD.pullRequest);
		ocirD.dataCountry(res);
	});
}
ocirD.getCef = function(){
	
	var payload = ocirD.payload();
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/filtercef",payload, function(res){
		ajaxIsDone(ocirD.pullRequest);
		ocirD.dataCef(res);
	});
}
ocirD.getNecessary = function(){

	var payload = ocirD.payload();
	ajaxIsStart(ocirD.pullRequest);
	ajaxPost("/countrydashboard/filternecessary",payload, function(res){
		ajaxIsDone(ocirD.pullRequest);
		ocirD.dataNecessery(res);
	});
}
ocirD.getFilter = function(except){
	if(except != "country")
		ocirD.getCountry();
	if(except != "cef")
		ocirD.getCef();
	if(except != "necessery")
		ocirD.getNecessary();
}
$(function(){
	var $slide = $('.slide-chart');
	$slide.carousel({
    	interval: false
	}); 
	$slide.on('slid', '', checkSlider);  // on caroussel move
	$slide.on('slid.bs.carousel', '', checkSlider); 
    checkSlider();
   
	ocirD.getFilter("");
	// ocirD.getCountry();
	// ocirD.getCef();
	// ocirD.getNecessary();
	ocirD.loadAll();	
});