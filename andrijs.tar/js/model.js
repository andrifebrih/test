 
      var chartFont = "10px Helvetica Neue";
      var chartLabelColor = "#58666e";
      chartLabelColor = "#000";
      var chartColors = ["#2890C0","#6AC17B","#6D6E71",
      "#6BA8D0","#9FD18B",
      "#A1C5E0","#C3E2C1","#BCBEC0",
      "#DBE8F3","#E9F4E7","#E6E7E8"];
      // chartColors = ["#005C84","#009FDA","#69BE28","#3F9C35","#2890C0","#6AC17B","#6BA8D0","#9FD18B","#A1C5E0","#C3E2C1"];
      // chartColors = ["#0075B2","#009FDA","#69BE28","#005C84",    "#6AC17B","#2890C0","#6BA8D0","#9FD18B","#A1C5E0","#C3E2C1"];

      var model = {
        Processing: ko.observable(true),
        currentMenu:ko.observable(),
        currentTitle:ko.observable(),
        MapDataSource:ko.observableArray([]),
        ViewDetail:ko.observable(true),
        FirstLoad:ko.observable(true),
        lastDateData : ko.observable(""),
        arrayLastDate : ko.observableArray([]), 
      };

      function numbformat(value,format){
        if(format==undefined){
          if(value<1000){
            format = "N0";
          }else{
            format = "N2";
          }
        }
        if(value>= 1000000000000){
          value = value/1000000000000;
          return kendo.toString(value,value<1?"N0":format)+"T";
        }
        else if(value >= 1000000000){
          value = value/1000000000;
          return kendo.toString(value,value<1?"N0":format)+"B";
        }
        else if(value>= 1000000){
          value = value/1000000;
          return kendo.toString(value,value<1?"N0":format)+"M";
        }
        else if(value >= 1000){
          value = value/1000;
          return kendo.toString(value,value<1?"N0":format)+"K";
        }else {
          return kendo.toString(value,format);
        }
      }
      
      String.prototype.capitalizeFirstLetter = function() {
          return this.charAt(0).toUpperCase() + this.slice(1);
      }
      function createCookie(name, value, days) {
        days = days || 365;
        if (days) {
          var date = new Date();
          date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
          var expires = "; expires=" + date.toGMTString();
        } else
          var expires = "";
        document.cookie = name + "=" + value + expires + "; path=/";
      }

      function readCookie(name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
          var c = ca[i];
          while (c.charAt(0) == ' ')
            c = c.substring(1, c.length);
          if (c.indexOf(nameEQ) == 0)
            return c.substring(nameEQ.length, c.length);
        }
        return null;
      }

      function eraseCookie(name) {
        createCookie(name, "", -1);
      }
      function checkViewDetailMode(){
        var viewDetail = readCookie("viewdetail");
        if(viewDetail!==null){
          model.ViewDetail(JSON.parse(viewDetail));
        }
      }
      checkViewDetailMode();
      var chartLabelDisplay = model.ViewDetail();

      model.ViewDetail.subscribe(function(newVal){
        chartLabelDisplay = newVal;
        var viewDetail = readCookie("viewdetail");
        createCookie("viewdetail",newVal,7);
         //if(!model.FirstLoad()){
          // $(".swal2-confirm").hide("fast");
          // var currentHeight = $(".swal2-spacer").height();
          // $(".swal2-spacer").height(0);
          // if(newVal){
          //   swal("","Entering screenshoot mode. Please wait..","info")
          // }else{
          //   swal("","Entering application mode. Please wait..","info")
          // }
          // setTimeout(function(){
          //   $(".swal2-confirm").show("fast");
          //   $(".swal2-spacer").height(currentHeight);
          //   swal.close()
          // }, 1000);
         //}
      });
      function getDefaultDatetimepicker() {
        var d = new Date();
        var DefaultDate = new Date();
        var day = moment(d).format("ddd");
        if (day != "Mon") {
          DefaultDate.setDate(DefaultDate.getDate() - 1);
        } else {
          DefaultDate.setDate(DefaultDate.getDate() - 3);
        }
        return moment(DefaultDate).format("YYYY-MM-DD")
      }

      function getUTCDate(strdate) {
        var d = moment.utc(strdate);
        return new Date(d.year(), d.month(), d.date(), 0, 0, 0)
      }
      function getUTCDateFull(strdate) {
        var d = moment.utc(strdate);
        return new Date(d.year(), d.month(), d.date(), d.hours(), d.minutes(), d.seconds())
      }

      function toUTC(d) {
        var year = d.getFullYear();
        var month = d.getMonth();
        var date = d.getDate();
        var hours = d.getHours();
        var minutes = d.getMinutes();
        var seconds = d.getSeconds();
        return moment(Date.UTC(year, month, date, hours, minutes, seconds)).toISOString();
      }

      function Logout() {
        localStorage.clear();
        window.location.href = "/logout/do";
      }

      function BreadCrumb(id, title, url, cssClass, action) {
        var obj = {
          _id: ko.observable(id),
          Title: ko.observable(title == undefined ? id : title),
          Url: url,
          Action: action,
          CssClass: cssClass
        };

        return obj;
      }

      model.CurrentDate = ko.observable();
      model.CurrentTime = ko.observable();
      model.IsFilterPresent = ko.observable();
      model.ParentId = ko.observableArray([]);
      model.PageId = ko.observable("");
      model.PageTopMenu = ko.observable("");
      model.MainMenus = ko.mapping.fromJS([]);
      model.RoleGroup = ko.observable("");
      model.TabMenuDasboard = ko.observable("");
      model.BreadCrumbs = ko.observableArray([]);
      
    function getServerDateTime() {
        var param = {};
        ajaxPost("/dashboard/getcurrentdate", param, function (res) {
          var d = new Date(res.Data.CurrentDate);
          var DefaultDate = new Date(res.Data.CurrentDate);
          var day = moment(d).format("ddd");
          if (day != "Mon") {
            DefaultDate.setDate(DefaultDate.getDate() - 1);
          } else {
            DefaultDate.setDate(DefaultDate.getDate() - 3);
          }
          model.CurrentDate(moment(new Date(DefaultDate)).format("YYYY-MM-DD"));
        });
    }
     
    model.getDataMenu = function (){
      	var param = {};
      	var url = "/acluser/getlisttopmenu";
      	console.log(url)
      	ajaxPost(url, param, function (res) {

      		var dataMenu = res.Data;
          	var sortMenu = Enumerable.From(dataMenu).OrderBy("$.Parent").ThenBy("$.IndexMenu").ToArray();
      	 	ko.mapping.fromJS(sortMenu, model.MainMenus);
      	});
    }
      // function convert(array) {
      //   var map = {};
      //   for (var i = 0; i < array.length; i++) {
      //     var obj = array[i];
      //     obj.submenu = [];

      //     map[obj.Id] = obj;

      //     var parent = obj.Parent || '-';
      //     if (!map[parent]) {
      //       map[parent] = {
      //         submenu: []
      //       };
      //     }
      //     map[parent].submenu.push(obj);
      //   }
      //   return map['-'].submenu;
      // }

      
      // function MenuItem(id, url, title, submenus) {

      //     var obj = {
      //          _id: ko.observable(id),
      //          Title: ko.observable(title == undefined ? id : title),
      //          Url: ko.observable(url.replace("~/",url)),
      //          Submenus: ko.observableArray(submenus)
      //     };
 
      //     var arr = submenus;
      //     for(var i in arr){
      //         obj.Submenus.push(
      //           new MenuItem(
      //             arr[i]._id,
      //             arr[i].url,
      //             arr[i].title,
      //             arr[i].submenu
      //           )
      //         );
      //     }
      //   return obj;
      // };
 
      // model.getDataMenu = function () {
      //   var url = "/acluser/getlisttopmenu";
      //   var param = {};
      //   ajaxPost(url, param, function (data) {
      //     var arrData = [];
      //     var baseURL = "";
      //     var dataMenu = data.Data;
      //     var sortMenu = Enumerable.From(dataMenu).OrderBy("$.Parent").ThenBy("$.IndexMenu").ToArray();
      //     // var dataTree = convert(sortMenu);
      //     // var arr = dataTree;
      //     for(var i in sortMenu){

      //       model.MainMenus.push(
      //         new MenuItem(
      //           sortMenu[i]._id,
      //           sortMenu[i].url,
      //           sortMenu[i].title,
      //           sortMenu[i].submenu
      //         )
      //       );
      //     }
      //   });
      // }

      // model.GetPageTitle = function (PageId, MenuList, ParentId) {
 
      //   var Title = "";
      //   for (var i in MenuList) {

      //     if (MenuList[i]._id == PageId) {
      //       Title = MenuList[i].Title
      //       ParentId.push(MenuList[i]._id);
      //       break;
      //     }
        
      //     if (Title == "" && MenuList[i].Submenus.length > 0) {
      //       Title = model.GetPageTitle(PageId, MenuList[i].submenu, ParentId)

      //       if (Title !== "") {
      //         ParentId.push(MenuList[i]._id);
      //       }
      //     }
      //   }
      //   return Title;
      // };

      // model.PageTitle = ko.computed(function () {
      //   var PageId = model.PageId();
      //   var PageTopMenu = model.PageTopMenu();
      //   var MenuList = ko.mapping.toJS(model.MainMenus());
      //   var Title = "";
      //   var ParentId = [];
      //   Title = model.GetPageTitle(PageId, MenuList, ParentId);
      //   model.currentMenu(PageTopMenu);
      //   model.currentTitle(PageId);
      //   model.ParentId(ParentId);
      //   return Title;
      // }, model);

      model.AppHomeButtonLoad = function (obj) {
        var id = obj._id;
        var url = obj.Url;
        var title = obj.Title;
        window.location.href = url;
      }

      model.BreadCrumbs.push(new BreadCrumb("youare", "You are here : ", "#", "youare"));
 