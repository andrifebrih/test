package main

import (
	"github.com/xuri/excelize"
	"fmt"
	"strconv"
)

func main() {
	// xlsx, err	:= excelize.OpenFile("D:/goproject/src/eaciit/finance/live/upload/201801041324/CostDB_V1Sample.xlsx")
	xlsx, err	:= excelize.OpenFile("/CTRLFW/EBBS/eaciit/finance/live/upload/201801091026/CostDB_V1.xlsx")
	if err != nil {
		fmt.Println(err.Error())
	}
	lines 	:= [][]string{}	
	fmt.Println(len(xlsx.GetSheetMap()), "====>> total sheet")
	for sheetinc, v := range xlsx.GetSheetMap() {
		if sheetinc == 1 { // only first sheet
			index 		:= xlsx.GetSheetIndex(v)
			fmt.Println(index,"<<<<<<<<<<<<")
			rows  		:= xlsx.GetRows("sheet" + strconv.Itoa(index)) // Get all the rows in a sheet.
			rowsTotal 	:= len(rows)
			fmt.Println("<<<<<<<<<<<<GetRow Excelize :", rowsTotal)
			columnTotal := 0
			if rowsTotal != 0 {
				columnTotal = len(rows[0])
			}
			fmt.Println(columnTotal, "<<<<total field kotor>>>>") //excelize add value "" when found null value, even null value not in title column
			for _, row := range rows {
				lines = append(lines, row)
			}
		}
	}

}
